# chap:manifolds-nonneg-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#chap:manifolds-nonneg-curvature
uses: []
```

# nonnegcurv

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#nonnegcurv
uses: []
```

# def:minimizing-geodesic-ray

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:minimizing-geodesic-ray
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# def:minimizing-geodesic-window

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:minimizing-geodesic-window
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-ray]]'
```

# def:has-min-segments

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:has-min-segments
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-window]]'
```

# lem:ultrafilter-limit-minimizing

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:ultrafilter-limit-minimizing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-window]]'
```

# lem:metric-limit-of-minimizing

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:metric-limit-of-minimizing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-window]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:ultrafilter-limit-minimizing]]'
```

# lem:ray-exists-metric

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:ray-exists-metric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-window]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:has-min-segments]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:ultrafilter-limit-minimizing]]'
```

# lem:ends-differ-at-compact

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:ends-differ-at-compact
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:space-of-ends]]'
```

# lem:end-component-unbounded

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:end-component-unbounded
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:space-of-ends]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:ends-transition]]'
```

# lem:line-exists-metric

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:line-exists-metric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-window]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:has-min-segments]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:space-of-ends]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:ultrafilter-limit-minimizing]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:ends-differ-at-compact]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:end-component-unbounded]]'
```

# lem:geodesic-continuous-dependence

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:geodesic-continuous-dependence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
```

# lem:limit-of-minimizing-geodesics

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:limit-of-minimizing-geodesics
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:geodesic-continuous-dependence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:minimizing-segment-exists

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:minimizing-segment-exists
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:cut-time-star-shaped]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:limit-of-minimizing-geodesics]]'
```

# lem:ends-exist

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:ends-exist
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:space-of-ends]]'
```

# ends

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#ends
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:minimizing-segment-exists]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:has-min-segments]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:ray-exists-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:line-exists-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:space-of-ends]]'
```

# def:busemann-approx

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:busemann-approx
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-ray]]'
```

# lem:busemann-approx-lipschitz

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-approx-lipschitz
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-approx]]'
```

# eqnBlip

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eqnBlip
uses: []
```

# lem:busemann-approx-antitone

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-approx-antitone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-approx]]'
```

# eqnBmono

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eqnBmono
uses: []
```

# lem:busemann-approx-lower-bound

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-approx-lower-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-approx]]'
```

# def:busemann-function

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:busemann-function
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-approx]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-approx-antitone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-approx-lower-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:ends-exist]]'
```

# lem:busemann-limit

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-approx-antitone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-approx-lower-bound]]'
```

# lem:busemann-le-approx

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-le-approx
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
```

# lem:busemann-lipschitz

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-lipschitz
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-approx-lipschitz]]'
```

# lem:busemann-lower-bound

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-lower-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-approx-lower-bound]]'
```

# lem:busemann-along-ray

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-along-ray
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
```

# def:asymptotic-ray

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:asymptotic-ray
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-ray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-window]]'
```

# lem:asymptotic-ray-exists

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:asymptotic-ray-exists
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:asymptotic-ray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:has-min-segments]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:metric-limit-of-minimizing]]'
```

# lem:asymptotic-ray

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:asymptotic-ray
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:asymptotic-ray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-approx-antitone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-lipschitz]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-le-approx]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-along-ray]]'
```

# cor:asymptotic-ray-busemann-bound

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:asymptotic-ray-busemann-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:asymptotic-ray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:asymptotic-ray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-lipschitz]]'
```

# lem:busemann-gradient-norm-one

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-gradient-norm-one
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:asymptotic-ray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:asymptotic-ray-exists]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:asymptotic-ray]]'
```

# eqnBlipgrad

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eqnBlipgrad
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# prop:busemann-laplacian

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#prop:busemann-laplacian
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# Blambda

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#Blambda
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#ex:distance-function-laplacian]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#rem:laplacian-weak-sense]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
```

# eqngradvanish

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eqngradvanish
uses: []
```

# eqnradial

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eqnradial
uses: []
```

# locallabel

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#locallabel
uses: []
```

# eq:tangential-acceleration

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eq:tangential-acceleration
uses: []
```

# eq:first-variation-energy

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eq:first-variation-energy
uses: []
```

# eq:laplacian-frame-sum

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eq:laplacian-frame-sum
uses: []
```

# eq:dual-metric-compat

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eq:dual-metric-compat
uses: []
```

# thm:length-comparison

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#thm:length-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
```

# lengthcompar

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lengthcompar
uses: []
```

# cor:angle-monotonicity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:angle-monotonicity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:length-comparison]]'
```

# anglemono

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#anglemono
uses: []
```

# cor:angle-comparison

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:angle-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:length-comparison]]'
```

# anglecompar

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#anglecompar
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:length-comparison]]'
```

# thm:soul-theorem

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#thm:soul-theorem
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
```

# soul

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#soul
uses: []
```

# rem:soul-theorem-positive-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#rem:soul-theorem-positive-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:soul-theorem]]'
```

# lem:angle-convergence-infinity

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:angle-convergence-infinity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:length-comparison]]'
```

# cor:distance-level-sets-homeomorphic

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:distance-level-sets-homeomorphic
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:angle-convergence-infinity]]'
```

# homeo

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#homeo
uses: []
```

# cor:distance-annuli-homotopy-sphere

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:distance-annuli-homotopy-sphere
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#cor:distance-level-sets-homeomorphic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:soul-theorem]]'
```

# htpytype

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#htpytype
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#cor:distance-level-sets-homeomorphic]]'
```

# ENDS

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#ENDS
uses: []
```

# def:ends-transition

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:ends-transition
uses: []
```

# lem:ends-transition-continuous

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:ends-transition-continuous
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:ends-transition]]'
```

# lem:ends-transition-id

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:ends-transition-id
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:ends-transition]]'
```

# lem:ends-transition-comp

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:ends-transition-comp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:ends-transition]]'
```

# def:space-of-ends

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:space-of-ends
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:ends-transition]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:ends-transition-comp]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:compact-set-in-codim-zero-submanifold]]'
```

# lem:compact-set-in-codim-zero-submanifold

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:compact-set-in-codim-zero-submanifold
uses: []
```

# lem:green-identity-compact-support

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:green-identity-compact-support
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
```

# claim:dirichlet-problem-small-balls

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#claim:dirichlet-problem-small-balls
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#cor:exponential-local-diffeomorphism]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
```

# claim:weak-subsolution-comparison

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#claim:weak-subsolution-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#rem:laplacian-weak-sense]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:green-identity-compact-support]]'
```

# lem:second-derivative-test-min

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:second-derivative-test-min
uses: []
```

# lem:second-derivative-test-max

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:second-derivative-test-max
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:second-derivative-test-min]]'
```

# lem:integral-curve-exists

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:integral-curve-exists
uses: []
```

# lem:differential-vanishes-at-max

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:differential-vanishes-at-max
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:integral-curve-exists]]'
```

# lem:hessian-nonpositive-at-max

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:hessian-nonpositive-at-max
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:differential-vanishes-at-max]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:integral-curve-exists]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:second-derivative-test-max]]'
```

# lem:smooth-local-extension

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:smooth-local-extension
uses: []
```

# lem:laplacian-nonpositive-at-max

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:laplacian-nonpositive-at-max
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:smooth-local-extension]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:differential-vanishes-at-max]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:hessian-nonpositive-at-max]]'
```

# lem:hopf-strong-maximum

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:hopf-strong-maximum
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-christoffel-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:laplacian-nonpositive-at-max]]'
```

# thm:maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#thm:maximum-principle
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#rem:laplacian-weak-sense]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:weak-harmonic-regularity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#claim:dirichlet-problem-small-balls]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#claim:weak-subsolution-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:green-identity-compact-support]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:hopf-strong-maximum]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
```

# thm:weak-harmonic-regularity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#thm:weak-harmonic-regularity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#rem:laplacian-weak-sense]]'
```

# eqnlocmax

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eqnlocmax
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#claim:dirichlet-problem-small-balls]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#claim:weak-subsolution-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:green-identity-compact-support]]'
```

# lem:gradient-norm-sq-gradient

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:gradient-norm-sq-gradient
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
```

# def:hessian-norm-sq

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:hessian-norm-sq
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
```

# lem:hessian-norm-sq-basic

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:hessian-norm-sq-basic
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:hessian-norm-sq]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
```

# lem:hessian-riesz-trace

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:hessian-riesz-trace
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:hessian-norm-sq]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
```

# lem:local-orthonormal-frame

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:local-orthonormal-frame
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# lem:laplacian-trace-commutation

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:laplacian-trace-commutation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:second-covariant-derivative-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:local-orthonormal-frame]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-covariant-derivative-tensorial]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:hessian-riesz-trace]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:laplacian-square-norm-one-form

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:laplacian-square-norm-one-form
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:normal-coordinates-expansion]]'
```

# lem:function-bochner-formula

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:function-bochner-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:gradient-norm-sq-gradient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:second-covariant-derivative-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:ricci-commutation-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:ricci-trace-curvature-operator]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:hessian-riesz-trace]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:laplacian-trace-commutation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:hessian-norm-sq]]'
```

# cor:bochner-vanishing

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:bochner-vanishing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:function-bochner-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:hessian-norm-sq]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# lem:covariant-derivative-along-maps

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:covariant-derivative-along-maps
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# lem:cov-deriv-along-curve

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:cov-deriv-along-curve
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:covariant-derivative-along-maps]]'
```

# lem:parallel-gradient-flow

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:parallel-gradient-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:covariant-derivative-along-maps]]'
```

# lem:parallel-gradient-level-sets

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:parallel-gradient-level-sets
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:parallel-gradient-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:covariant-derivative-along-maps]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# prop:parallel-gradient-splitting

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#prop:parallel-gradient-splitting
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:parallel-gradient-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:parallel-gradient-level-sets]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
```

# lem:busemann-along-line

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-along-line
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-window]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-le-approx]]'
```

# lem:busemann-pair-nonneg

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:busemann-pair-nonneg
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:minimizing-geodesic-window]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-approx]]'
```

# cor:busemann-pair-vanishes-on-line

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:busemann-pair-vanishes-on-line
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-along-line]]'
```

# lem:minimizing-line-implies-product

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:minimizing-line-implies-product
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# line

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#line
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:busemann-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#rem:laplacian-weak-sense]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#prop:busemann-laplacian]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:maximum-principle]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:weak-harmonic-regularity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:asymptotic-ray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:asymptotic-ray-exists]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:asymptotic-ray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-gradient-norm-one]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:function-bochner-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#prop:parallel-gradient-splitting]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-along-line]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:busemann-pair-nonneg]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#cor:busemann-pair-vanishes-on-line]]'
```

# thm:splitting-theorem

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#thm:splitting-theorem
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:space-of-ends]]'
```

# splitting

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#splitting
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:ends-exist]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:minimizing-line-implies-product]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:space-of-ends]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:compact-set-in-codim-zero-submanifold]]'
```

# def:epsilon-close-topology

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:epsilon-close-topology
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# epsclose

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#epsclose
uses: []
```

# eqnepsclose

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#eqnepsclose
uses: []
```

# rem:ricci-flow-metric-topology

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#rem:ricci-flow-metric-topology
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-close-topology]]'
```

# def:epsilon-neck

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:epsilon-neck
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-close-topology]]'
```

# epsneck

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#epsneck
uses: []
```

# lem:epsilon-neck-separates

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:epsilon-neck-separates
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:metric-sphere-meets-neck-topologically]]'
```

# neckseparate

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#neckseparate
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:metric-sphere-meets-neck-topologically]]'
```

# prop:epsilon-neck-narrow

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#prop:epsilon-neck-narrow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
```

# narrows

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#narrows
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:soul-theorem]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#prop:busemann-laplacian]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:neck-geodesic-directions]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:metric-sphere-meets-neck-topologically]]'
```

# cor:epsilon-neck-scale-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:epsilon-neck-scale-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:soul-theorem]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:epsilon-neck-separates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:metric-sphere-meets-neck-topologically]]'
```

# strnarrows

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#strnarrows
uses: []
```

# def:forward-difference-quotient

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#def:forward-difference-quotient
uses: []
```

# lem:forward-difference-quotient-mono

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:forward-difference-quotient-mono
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:forward-difference-quotient]]'
```

# lem:right-derivative-forward-difference-quotient

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:right-derivative-forward-difference-quotient
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:forward-difference-quotient]]'
```

# lem:forward-difference-quotient

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:forward-difference-quotient
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:forward-difference-quotient]]'
```

# fordiffquot

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#fordiffquot
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:forward-difference-quotient]]'
```

# lem:max-function-continuous-product

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:max-function-continuous-product
uses: []
```

# lem:forward-difference-maximum-product

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:forward-difference-maximum-product
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:forward-difference-quotient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:max-function-continuous-product]]'
```

# cor:forward-difference-maximum-product

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#cor:forward-difference-maximum-product
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:forward-difference-quotient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:max-function-continuous-product]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-maximum-product]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-quotient]]'
```

# lem:vector-field-flow-near-compact

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:vector-field-flow-near-compact
uses: []
```

# lem:forward-difference-maximum-flow

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#lem:forward-difference-maximum-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:forward-difference-quotient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-quotient]]'
```

# prop:forward-difference-maximum

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#prop:forward-difference-maximum
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:forward-difference-quotient]]'
```

# fordiffmax

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature.tex#fordiffmax
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:vector-field-flow-near-compact]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-maximum-flow]]'
```
