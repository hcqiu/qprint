# chap:surgery-delta-neck

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#chap:surgery-delta-neck
uses: []
```

# necksurgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#necksurgery
uses: []
```

# claim:neck-to-cap-distance-decreasing

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#claim:neck-to-cap-distance-decreasing
uses: []
```

# distdecrease

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#distdecrease
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#lem:standard-initial-metric-distance-decreasing]]'
```

# thm:local-surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#thm:local-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#claim:neck-to-cap-distance-decreasing]]'
```

# LOCALSURGERY

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#LOCALSURGERY
uses: []
```

# def:surgery-cap

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#def:surgery-cap
uses: []
```

# surgerycap

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#surgerycap
uses: []
```

# lem:surgery-cap-ball-bounds

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#lem:surgery-cap-ball-bounds
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#def:surgery-cap]]'
```

# capball

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#capball
uses: []
```

# confchange

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#confchange
uses: []
```

# qeqn

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#qeqn
uses: []
```

# cor:conformal-curvature-formula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#cor:conformal-curvature-formula
uses: []
```

# delta0

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#delta0
uses: []
```

# maineqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#maineqn
uses: []
```

# cor:scalar-curvature-nondecreasing-conformal

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#cor:scalar-curvature-nondecreasing-conformal
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#cor:conformal-curvature-formula]]'
```

# Rcompar

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#Rcompar
uses: []
```

# lem:near-cylinder-curvature-eigenbasis

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#lem:near-cylinder-curvature-eigenbasis
uses: []
```

# newbasis

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#newbasis
uses: []
```

# cor:curvature-diagonal-block-basis

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#cor:curvature-diagonal-block-basis
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#lem:near-cylinder-curvature-eigenbasis]]'
```

# 2ndnewbasis

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#2ndnewbasis
uses: []
```

# lem:rhat-matrix-adapted-basis

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#lem:rhat-matrix-adapted-basis
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#cor:curvature-diagonal-block-basis]]'
```

# Rhatmatrix

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#Rhatmatrix
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#cor:conformal-curvature-formula]]'
```

# cor:diagonalized-curvature-matrices

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#cor:diagonalized-curvature-matrices
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#lem:near-cylinder-curvature-eigenbasis]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#lem:rhat-matrix-adapted-basis]]'
```

# 13.10

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#13.10
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#lem:near-cylinder-curvature-eigenbasis]]'
```

# cor:conformal-eigenvalue-estimates

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#cor:conformal-eigenvalue-estimates
uses: []
```

# improve

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#improve
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#cor:diagonalized-curvature-matrices]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#lem:rhat-matrix-adapted-basis]]'
```

# cor:smallest-eigenvalue-increases

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#cor:smallest-eigenvalue-increases
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#cor:conformal-eigenvalue-estimates]]'
```

# smeigen

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#smeigen
uses: []
```

# lem:positive-eigenvalues-surgery-region

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#lem:positive-eigenvalues-surgery-region
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#cor:conformal-eigenvalue-estimates]]'
```

# nuprime>0

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#nuprime>0
uses: []
```

# prop:pinching-preserved-s-less-4

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#prop:pinching-preserved-s-less-4
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#cor:scalar-curvature-nondecreasing-conformal]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#lem:positive-eigenvalues-surgery-region]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#cor:smallest-eigenvalue-increases]]'
```

# lem:surgery-result-metric-ball-bounds

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#lem:surgery-result-metric-ball-bounds
uses: []
```

# stdballs

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck.tex#stdballs
uses: []
```
