# chap:geometric-limits

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#chap:geometric-limits
uses: []
```

# thm:short-time-blowup-limit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#thm:short-time-blowup-limit
uses: []
```

# smlmtflow

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#smlmtflow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#bcbd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#2ndmfdconv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#blowupposcurv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#partialflowlimit]]'
```

# lem:curvature-control-canonical-nbhd

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#lem:curvature-control-canonical-nbhd
uses: []
```

# controlnbhd

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#controlnbhd
uses: []
```

# Rineq

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#Rineq
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#bcbd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#2ndmfdconv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#blowupposcurv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#partialflowlimit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-control-canonical-nbhd]]'
```

# cor:uniform-backward-curvature-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#cor:uniform-backward-curvature-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-control-canonical-nbhd]]'
```

# cnnbhd2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#cnnbhd2
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-control-canonical-nbhd]]'
```

# cor:shi-bound-blowup-sequence

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#cor:shi-bound-blowup-sequence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#shi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#cor:uniform-backward-curvature-bound]]'
```

# claim:volume-noncollapsing-blowup

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:volume-noncollapsing-blowup
uses: []
```

# claim:canonical-neighborhood-persists

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:canonical-neighborhood-persists
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:short-time-blowup-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#canonvary]]'
```

# claim:limit-bounded-curvature

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:limit-bounded-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#claim:canonical-neighborhood-persists]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#localprod]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#narrows]]'
```

# thm:long-time-blowup-limit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#thm:long-time-blowup-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:short-time-blowup-limit]]'
```

# kaplimit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#kaplimit
uses: []
```

# rem:comparison-short-and-long-time-limits

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#rem:comparison-short-and-long-time-limits
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:short-time-blowup-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:long-time-blowup-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#blowupposcurv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#narrows]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#Harnack]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-control-canonical-nbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#cor:curvature-bound-near-basepoint]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#claim:distance-distortion-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#bcbd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#cor:distance-integral-bound]]'
```

# prop:extend-limit-flow-backward

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#prop:extend-limit-flow-backward
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:long-time-blowup-limit]]'
```

# maxT

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#maxT
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-control-canonical-nbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:short-time-blowup-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#cor:curvature-bound-near-basepoint]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#narrows]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#Harnack]]'
```

# lem:curvature-bound-compact-subset

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#lem:curvature-bound-compact-subset
uses: []
```

# compactbd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#compactbd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#claim:distance-distortion-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#bcbd]]'
```

# claim:distance-distortion-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:distance-distortion-bound
uses: []
```

# distch

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#distch
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#cor:distance-integral-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#Harnack]]'
```

# lem:far-point-with-distant-antipode

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#lem:far-point-with-distant-antipode
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#cor:angle-monotonicity]]'
```

# claim:curvature-bound-outside-large-ball

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:curvature-bound-outside-large-ball
uses: []
```

# outerbd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#outerbd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:far-point-with-distant-antipode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#claim:distance-distortion-bound]]'
```

# claim:neck-center-opposite-ends

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:neck-center-opposite-ends
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#claim:distance-distortion-bound]]'
```

# cor:curvature-bound-near-basepoint

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#cor:curvature-bound-near-basepoint
uses: []
```

# ancientlimit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#ancientlimit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-bound-compact-subset]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#claim:curvature-bound-outside-large-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#scalarevol]]'
```

# claim:uniform-curvature-bound-extended-interval

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:uniform-curvature-bound-extended-interval
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#cor:curvature-bound-near-basepoint]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-control-canonical-nbhd]]'
```

# def:standing-assumptions-singular-time

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#def:standing-assumptions-singular-time
uses: []
```

# assumptions

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#assumptions
uses: []
```

# thm:singular-time-limit-properties

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#thm:singular-time-limit-properties
uses: []
```

# omega

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#omega
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:standing-assumptions-singular-time]]'
```

# rem:proper-function

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#rem:proper-function
uses: []
```

# lem:omega-open-limit-metric

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#lem:omega-open-limit-metric
uses: []
```

# Rproper

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#Rproper
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:standing-assumptions-singular-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:singular-time-limit-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-control-canonical-nbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#shi]]'
```

# def:maximal-extension-to-time-T

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#def:maximal-extension-to-time-T
uses: []
```

# hatM

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#hatM
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:singular-time-limit-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:omega-open-limit-metric]]'
```

# lem:canonical-neighborhoods-at-time-T

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#lem:canonical-neighborhoods-at-time-T
uses: []
```

# omegacanon

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#omegacanon
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:maximal-extension-to-time-T]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:standing-assumptions-singular-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:curvature-control-canonical-nbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:omega-open-limit-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#canonvary]]'
```

# claim:limit-of-necks-is-neck

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:limit-of-necks-is-neck
uses: []
```

# epslimit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#epslimit
uses: []
```

# def:strong-epsilon-horn

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#def:strong-epsilon-horn
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:maximal-extension-to-time-T]]'
```

# def:strong-double-and-capped-horn

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#def:strong-double-and-capped-horn
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:strong-epsilon-horn]]'
```

# def:omega-rho

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#def:omega-rho
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:singular-time-limit-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:strong-epsilon-horn]]'
```

# lem:omega-component-classification

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#lem:omega-component-classification
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:canonical-neighborhoods-at-time-T]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:omega-rho]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#epstopology]]'
```

# rem:possibly-infinitely-many-horns

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#rem:possibly-infinitely-many-horns
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:strong-double-and-capped-horn]]'
```

# lem:finitely-many-horns-meeting-omega-rho

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#lem:finitely-many-horns-meeting-omega-rho
uses: []
```

# 2epshorns

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#2epshorns
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:omega-rho]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:standing-assumptions-singular-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:canonical-neighborhoods-at-time-T]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:omega-component-classification]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#Xcontainedin]]'
```

# thm:deep-delta-necks-in-horn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#thm:deep-delta-necks-in-horn
uses: []
```

# hexist

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#hexist
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:omega-rho]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#def:standing-assumptions-singular-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:short-time-blowup-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:splitting-theorem]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#blowupposcurv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#localprod]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#rm>0]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#2DGSS]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#bcbd]]'
```

# claim:rescaled-sequence-satisfies-hypotheses

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:rescaled-sequence-satisfies-hypotheses
uses: []
```

# hyp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#hyp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:short-time-blowup-limit]]'
```

# claim:ball-contained-in-horn-compact-closure

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:ball-contained-in-horn-compact-closure
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#bcbd]]'
```

# claim:limit-splits-as-cylinder

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:limit-splits-as-cylinder
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:splitting-theorem]]'
```

# claim:backward-flow-line-curvature-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#claim:backward-flow-line-curvature-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#neckcurv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#defncanonnbhd]]'
```

# cor:monotone-h-function

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#cor:monotone-h-function
uses: []
```

# hmonotone

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits.tex#hmonotone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:deep-delta-necks-in-horn]]'
```
