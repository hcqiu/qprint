# chap:noncollapsed

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#chap:noncollapsed
uses: []
```

# noncoll

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#noncoll
uses: []
```

# thm:kappa-noncollapsed-generalized-flow

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#thm:kappa-noncollapsed-generalized-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
```

# THM

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#THM
uses: []
```

# redvoleqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#redvoleqn
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-volume]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#thm:reduced-volume-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#thm:kappa-noncollapsed-generalized-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#prop:reduced-volume-upper-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#lem:reduced-volume-small-directions]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#claim:l-geodesic-stays-in-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#claim:volume-comparison-time-slices]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-first-derivative]]'
```

# prop:reduced-volume-upper-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#prop:reduced-volume-upper-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#thm:kappa-noncollapsed-generalized-flow]]'
```

# step

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#step
uses: []
```

# lem:reduced-volume-small-directions

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#lem:reduced-volume-small-directions
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#prop:reduced-volume-upper-bound]]'
```

# small

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#small
uses: []
```

# volineq

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#volineq
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#claim:l-geodesic-stays-in-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#claim:volume-comparison-time-slices]]'
```

# cor:reduced-volume-small-bound

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#cor:reduced-volume-small-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#lem:reduced-volume-small-directions]]'
```

# claim:scalar-curvature-gradient-metric-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#claim:scalar-curvature-gradient-metric-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#thm:kappa-noncollapsed-generalized-flow]]'
```

# nabR

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#nabR
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-first-derivative]]'
```

# claim:l-geodesic-norm-comparison

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#claim:l-geodesic-norm-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#claim:scalar-curvature-gradient-metric-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-geodesic-min-max-estimate]]'
```

# claim:l-geodesic-stays-in-ball

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#claim:l-geodesic-stays-in-ball
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#claim:l-geodesic-norm-comparison]]'
```

# inside

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#inside
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#claim:l-geodesic-norm-comparison]]'
```

# claim:volume-comparison-time-slices

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#claim:volume-comparison-time-slices
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#thm:kappa-noncollapsed-generalized-flow]]'
```

# volvomp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#volvomp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#claim:scalar-curvature-gradient-metric-bound]]'
```

# lem:reduced-volume-large-directions

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#lem:reduced-volume-large-directions
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#prop:reduced-volume-upper-bound]]'
```

# large

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#large
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-volume-integrand-monotone]]'
```

# thm:kappa-noncollapsed-compact-3-manifolds

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed.tex#thm:kappa-noncollapsed-compact-3-manifolds
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:bishop-gromov]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#thm:kappa-noncollapsed-generalized-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#prop:normalized-flow-short-time-bounds]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#thm:min-l-bound-n-half]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#prop:l-exp-lipschitz-complete]]'
```
