# def:isometry

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#def:isometry
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
```

# def:weak-laplacian

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#def:weak-laplacian
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# lem:abstract-cone-curvature-block

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:abstract-cone-curvature-block
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# lem:constant-curvature-exp-nonsingular-nonzero

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:constant-curvature-exp-nonsingular-nonzero
uses:
- '[[references/MorganTian/blueprint/src/chapters/formalization-support#lem:constant-curvature-normal-jacobi-profile]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
```

# lem:constant-curvature-normal-jacobi-profile

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:constant-curvature-normal-jacobi-profile
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:constant-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:parallel-frame]]'
```

# lem:constant-rescaling-connection-curvature

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:constant-rescaling-connection-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
```

# lem:distance-function-weak-laplacian-reduction

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:distance-function-weak-laplacian-reduction
uses:
- '[[references/MorganTian/blueprint/src/chapters/formalization-support#def:weak-laplacian]]'
- '[[references/MorganTian/blueprint/src/chapters/formalization-support#rem:laplacian-weak-green-identity]]'
```

# lem:immersed-patch-induced-connection

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:immersed-patch-induced-connection
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# lem:local-isometry-covering-connected-source

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:local-isometry-covering-connected-source
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-exponential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
```

# lem:matrix-jacobi-rauch-lower

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:matrix-jacobi-rauch-lower
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:vector-sturm-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-shape-riccati]]'
```

# lem:metric-segment-domain-radial

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:metric-segment-domain-radial
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:minimal-geodesic-no-conjugate]]'
```

# lem:pointwise-strongly-convex-normal-ball

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#lem:pointwise-strongly-convex-normal-ball
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# rem:cut-time-injectivity-radius-distance

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#rem:cut-time-injectivity-radius-distance
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time-locus]]'
```

# rem:ends-compactification

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#rem:ends-compactification
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:space-of-ends]]'
```

# rem:injectivity-radius-distance

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#rem:injectivity-radius-distance
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
```

# rem:injectivity-radius-frontier

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#rem:injectivity-radius-frontier
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
```

# rem:laplacian-weak-green-identity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#rem:laplacian-weak-green-identity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#rem:laplacian-weak-sense]]'
```

# rem:local-isometry-local-inverse

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#rem:local-isometry-local-inverse
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/formalization-support#def:isometry]]'
```

# rem:metric-book-cut-locus-agreement

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#rem:metric-book-cut-locus-agreement
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:injectivity-radius]]'
```

# rem:weak-harmonic-regularity-citation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/formalization-support.tex#rem:weak-harmonic-regularity-citation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:weak-harmonic-regularity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#claim:dirichlet-problem-small-balls]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#claim:weak-subsolution-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#rem:laplacian-weak-sense]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
```
