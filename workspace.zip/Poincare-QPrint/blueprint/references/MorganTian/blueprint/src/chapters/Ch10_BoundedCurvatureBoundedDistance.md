# chap:bounded-curvature-bounded-distance

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#chap:bounded-curvature-bounded-distance
uses: []
```

# 10.1

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#10.1
uses: []
```

# def:curvature-pinched-toward-positive

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#def:curvature-pinched-toward-positive
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# pinchdef

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#pinchdef
uses: []
```

# thm:bounded-curvature-bounded-distance

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#thm:bounded-curvature-bounded-distance
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:curvature-pinched-toward-positive]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:strong-epsilon-neck-canonical-neighborhood]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#nocones]]'
```

# bcbd

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#bcbd
uses: []
```

# sectincomp

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#sectincomp
uses: []
```

# weakerpos

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#weakerpos
uses: []
```

# claim:minimizing-geodesic-in-Xn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:minimizing-geodesic-in-Xn
uses: []
```

# claim:balanced-chain-subgeodesic

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:balanced-chain-subgeodesic
uses: []
```

# claim:neck-contained-in-Un

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:neck-contained-in-Un
uses: []
```

# claim:uniform-curvature-bound-reg-delta

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:uniform-curvature-bound-reg-delta
uses: []
```

# prop:incomplete-limit-tube-properties

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#prop:incomplete-limit-tube-properties
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:evolving-epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#claim:balanced-chain-subgeodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#claim:uniform-curvature-bound-reg-delta]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#basicconv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-derivative-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#smoothconv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#canonvary]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#Xcontainedin]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#partialflowlimit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#blowupposcurv]]'
```

# Uinfty

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#Uinfty
uses: []
```

# claim:points-in-Wplus-are-neck-centers

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:points-in-Wplus-are-neck-centers
uses: []
```

# claim:curvature-bounded-one-end-infinite-other

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:curvature-bounded-one-end-infinite-other
uses: []
```

# claim:flowline-exists-for-x

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:flowline-exists-for-x
uses: []
```

# claim:limiting-flow-nonnegative-curvature

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:limiting-flow-nonnegative-curvature
uses: []
```

# GromHaus

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#GromHaus
uses: []
```

# conemetric

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#conemetric
uses: []
```

# prop:cone-limit-gromov-hausdorff

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#prop:cone-limit-gromov-hausdorff
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#prop:incomplete-limit-tube-properties]]'
```

# statement

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#statement
uses: []
```

# claim:minimizing-ray-to-end-exists

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:minimizing-ray-to-end-exists
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#prop:incomplete-limit-tube-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#genint]]'
```

# claim:shortest-ray-equivalence

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:shortest-ray-equivalence
uses: []
```

# cor:unique-shortest-subray

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#cor:unique-shortest-subray
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#claim:shortest-ray-equivalence]]'
```

# distlim

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#distlim
uses: []
```

# lem:triangle-inequality-distance-to-end

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#lem:triangle-inequality-distance-to-end
uses: []
```

# def:direction-at-end

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#def:direction-at-end
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#cor:unique-shortest-subray]]'
```

# lem:multiple-directions-at-end

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#lem:multiple-directions-at-end
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:direction-at-end]]'
```

# morethanone

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#morethanone
uses: []
```

# rem:space-of-directions-topology

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#rem:space-of-directions-topology
uses: []
```

# def:angle-between-directions-theta

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#def:angle-between-directions-theta
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:direction-at-end]]'
```

# defntheta

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#defntheta
uses: []
```

# lem:theta-monotone-convergence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#lem:theta-monotone-convergence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:angle-between-directions-theta]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:length-comparison]]'
```

# thetaconv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#thetaconv
uses: []
```

# lem:theta-triangle-inequality

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#lem:theta-triangle-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:angle-between-directions-theta]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#cor:unique-shortest-subray]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#cor:angle-comparison]]'
```

# def:cone-of-directions

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#def:cone-of-directions
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:angle-between-directions-theta]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:direction-at-end]]'
```

# prop:cone-not-a-ray

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#prop:cone-not-a-ray
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:cone-of-directions]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#lem:multiple-directions-at-end]]'
```

# notray

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#notray
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#lem:multiple-directions-at-end]]'
```

# lem:cone-distance-upper-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#lem:cone-distance-upper-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:cone-of-directions]]'
```

# distcomp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#distcomp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:angle-between-directions-theta]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#lem:theta-monotone-convergence]]'
```

# cor:rescaled-cone-distance-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#cor:rescaled-cone-distance-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#lem:cone-distance-upper-bound]]'
```

# refdistcomp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#refdistcomp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#lem:cone-distance-upper-bound]]'
```

# lem:directions-net-cardinality-bound

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#lem:directions-net-cardinality-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:direction-at-end]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:angle-between-directions-theta]]'
```

# cor:directions-space-compact-net

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#cor:directions-space-compact-net
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#lem:directions-net-cardinality-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:cone-of-directions]]'
```

# deltanet

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#deltanet
uses: []
```

# prop:gromov-hausdorff-limit-is-cone

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#prop:gromov-hausdorff-limit-is-cone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#def:cone-of-directions]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#cor:directions-space-compact-net]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#prop:incomplete-limit-tube-properties]]'
```

# secondstatment

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#secondstatment
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#cor:directions-space-compact-net]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#cor:rescaled-cone-distance-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#lem:theta-monotone-convergence]]'
```

# rem:noncomplete-multiple-limits

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#rem:noncomplete-multiple-limits
uses: []
```

# claim:blowup-ratio-bounded

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance.tex#claim:blowup-ratio-bounded
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#prop:incomplete-limit-tube-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#prop:gromov-hausdorff-limit-is-cone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#S2intersection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#directions]]'
```
