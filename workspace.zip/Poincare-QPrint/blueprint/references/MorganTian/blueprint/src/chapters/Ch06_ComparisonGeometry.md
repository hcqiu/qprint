# chap:comparison-geometry

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#chap:comparison-geometry
uses: []
```

# lengthfn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lengthfn
uses: []
```

# def:parameterized-by-backward-time

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:parameterized-by-backward-time
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:time-slices-horizontal]]'
```

# def:l-length

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:l-length
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:parameterized-by-backward-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# Llength

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Llength
uses: []
```

# changeofvar

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#changeofvar
uses: []
```

# seqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#seqn
uses: []
```

# ex:l-length-euclidean

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#ex:l-length-euclidean
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# lem:l-length-euler-lagrange

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-length-euler-lagrange
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# EL

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#EL
uses: []
```

# EulerLag

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#EulerLag
uses: []
```

# rem:ricci-one-form-dual

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#rem:ricci-one-form-dual
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-euler-lagrange]]'
```

# variation

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#variation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# rem:horizontal-gradient-convention

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#rem:horizontal-gradient-convention
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-euler-lagrange]]'
```

# def:l-geodesic

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:l-geodesic
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-euler-lagrange]]'
```

# reparam

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#reparam
uses: []
```

# lem:l-geodesic-initial-limit

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-geodesic-initial-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
```

# def:l-geodesic-minimizing

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:l-geodesic-minimizing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# lem:l-jacobi-equation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-jacobi-equation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-euler-lagrange]]'
```

# jaceqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#jaceqn
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-euler-lagrange]]'
```

# def:l-jacobi-field

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:l-jacobi-field
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-jacobi-equation]]'
```

# lem:l-jacobi-field-initial-limit

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-jacobi-field-initial-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
```

# prop:l-length-second-variation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:l-length-second-variation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic-minimizing]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
```

# 2ndvarj

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#2ndvarj
uses: []
```

# lem:l-length-second-variation-formula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-length-second-variation-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# 2ndvari

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#2ndvari
uses: []
```

# crosspart

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#crosspart
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-euler-lagrange]]'
```

# rem:second-variation-determined-by-jacobi

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#rem:second-variation-determined-by-jacobi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-second-variation-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
```

# variremark

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#variremark
uses: []
```

# cor:l-jacobi-bilinear-symmetric

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:l-jacobi-bilinear-symmetric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
```

# symmY

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#symmY
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-second-variation-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-jacobi-bilinear-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic-minimizing]]'
```

# sect:Lexp

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#sect:Lexp
uses: []
```

# def:l-exponential-map

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:l-exponential-map
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
```

# defnD

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#defnD
uses: []
```

# lem:l-exponential-smooth

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-exponential-smooth
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
```

# lcdiffeo

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lcdiffeo
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-euler-lagrange]]'
```

# lem:l-exponential-differential

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-exponential-differential
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
```

# DLJacobi

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#DLJacobi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
```

# claim:l-exp-tau-derivative-limit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:l-exp-tau-derivative-limit
uses: []
```

# cor:l-length-second-variation-positive

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:l-length-second-variation-positive
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-second-variation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-exponential-differential]]'
```

# posform

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#posform
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-second-variation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-exponential-differential]]'
```

# lem:l-length-tilde-gradient

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-length-tilde-gradient
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# DtildeL

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#DtildeL
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-exponential-differential]]'
```

# lem:l-exponential-local-diffeomorphism

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-exponential-local-diffeomorphism
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-exponential-differential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
```

# locstr

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#locstr
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-exponential-differential]]'
```

# rem:l-exponential-backward-tau

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#rem:l-exponential-backward-tau
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-exponential-local-diffeomorphism]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-tilde-gradient]]'
```

# backwards

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#backwards
uses: []
```

# sect:InjDom

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#sect:InjDom
uses: []
```

# def:l-injectivity-set

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:l-injectivity-set
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# injdefn

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#injdefn
uses: []
```

# def:l-injectivity-domain

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:l-injectivity-domain
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-set]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
```

# L_x

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#L_x
uses: []
```

# def:minimal-l-length-function

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:minimal-l-length-function
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# prop:l-exponential-diffeomorphism

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:l-exponential-diffeomorphism
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-set]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:minimal-l-length-function]]'
```

# diffeo

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#diffeo
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-set]]'
```

# cor:l-length-gradient

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:l-length-gradient
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-tilde-gradient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-exponential-diffeomorphism]]'
```

# DL

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#DL
uses: []
```

# prop:injectivity-set-monotone

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:injectivity-set-monotone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-set]]'
```

# inclusion

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#inclusion
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-exponential-local-diffeomorphism]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-exponential-differential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-second-variation]]'
```

# prop:l-exponential-diffeomorphism-along-geodesic

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:l-exponential-diffeomorphism-along-geodesic
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic-minimizing]]'
```

# tausmooth

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#tausmooth
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-second-variation]]'
```

# lem:l-length-tau-derivative

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-length-tau-derivative
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:minimal-l-length-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
```

# Ltau

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Ltau
uses: []
```

# Ltaueqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Ltaueqn
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-length-gradient]]'
```

# secondorder

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#secondorder
uses: []
```

# prop:l-length-second-variation-general

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:l-length-second-variation-general
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# 2ndvariation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#2ndvariation
uses: []
```

# claim:covariant-derivative-inner-product-formula

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:covariant-derivative-inner-product-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-second-variation-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-jacobi-equation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#claim:covariant-derivative-inner-product-formula]]'
```

# def:adapted-vector-field

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:adapted-vector-field
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# firstYeqn

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#firstYeqn
uses: []
```

# lem:adapted-vector-field-norm

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:adapted-vector-field-norm
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:adapted-vector-field]]'
```

# adaptform

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#adaptform
uses: []
```

# secondYeqn

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#secondYeqn
uses: []
```

# prop:l-length-hessian-inequality

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:l-length-hessian-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:adapted-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:minimal-l-length-function]]'
```

# Hessineq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Hessineq
uses: []
```

# Hessin

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Hessin
uses: []
```

# Heqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Heqn
uses: []
```

# rem:h-quadratic-in-y

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#rem:h-quadratic-in-y
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-hessian-inequality]]'
```

# lem:l-geodesic-family-existence

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-geodesic-family-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
```

# lem:l-length-hessian-jacobi-formula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-length-hessian-jacobi-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:minimal-l-length-function]]'
```

# Jacobi

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Jacobi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-length-gradient]]'
```

# lem:adapted-jacobi-hessian-relation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:adapted-jacobi-hessian-relation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:adapted-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-jacobi-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:minimal-l-length-function]]'
```

# adapjab

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#adapjab
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-hessian-jacobi-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-geodesic-family-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-second-variation-general]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-length-gradient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:adapted-vector-field-norm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-second-variation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-second-variation-formula]]'
```

# Hessineq1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Hessineq1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-geodesic-family-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-second-variation-general]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-length-gradient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:adapted-vector-field-norm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-second-variation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-second-variation-formula]]'
```

# claim:mixed-partials-vanish

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:mixed-partials-vanish
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-second-variation-formula]]'
```

# prop:l-length-laplacian-inequality

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:l-length-laplacian-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-hessian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
```

# triL

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#triL
uses: []
```

# lineq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lineq
uses: []
```

# Hdefnn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Hdefnn
uses: []
```

# triLinequ

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#triLinequ
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-hessian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:adapted-jacobi-hessian-relation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:div-ricci-scalar-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:curvature-evolution]]'
```

# claim:h-sum-formula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:h-sum-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-hessian-inequality]]'
```

# Hclaim

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Hclaim
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:div-ricci-scalar-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:curvature-evolution]]'
```

# sect:redln

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#sect:redln
uses: []
```

# def:reduced-length

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:reduced-length
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:minimal-l-length-function]]'
```

# def:reduced-length-k-quantity

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:reduced-length-k-quantity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-laplacian-inequality]]'
```

# lem:k-quantity-continuity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:k-quantity-continuity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-k-quantity]]'
```

# Kequal

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Kequal
uses: []
```

# lem:reduced-length-k-formula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:reduced-length-k-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-k-quantity]]'
```

# Keqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Keqn
uses: []
```

# Kequat

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Kequat
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-laplacian-inequality]]'
```

# lem:reduced-length-differential-inequalities

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:reduced-length-differential-inequalities
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-k-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-laplacian-inequality]]'
```

# linequal

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#linequal
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-tau-derivative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-length-gradient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-k-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-laplacian-inequality]]'
```

# thm:reduced-length-differential-identities

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#thm:reduced-length-differential-identities
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-differential-inequalities]]'
```

# Ueqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Ueqn
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-differential-inequalities]]'
```

# cor:reduced-length-pde-inequalities

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:reduced-length-pde-inequalities
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#thm:reduced-length-differential-identities]]'
```

# lformula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lformula
uses: []
```

# def:reduced-length-tangential

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:reduced-length-tangential
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
```

# lem:reduced-length-tangential-tau-derivative

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:reduced-length-tangential-tau-derivative
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-tangential]]'
```

# tildeltau

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#tildeltau
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-tangential]]'
```

# cor:reduced-length-tangential-k-derivative

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:reduced-length-tangential-k-derivative
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-tangential-tau-derivative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-k-formula]]'
```

# tildelK

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#tildelK
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-tangential-tau-derivative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-k-formula]]'
```

# sect:lips

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#sect:lips
uses: []
```

# def:reduced-length-domain

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:reduced-length-domain
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length]]'
```

# prop:reduced-length-lipschitz

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:reduced-length-lipschitz
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-domain]]'
```

# lips

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lips
uses: []
```

# cor:reduced-length-lipschitz-time-slice

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:reduced-length-lipschitz-time-slice
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-length-lipschitz]]'
```

# def:l-parabolic-neighborhood

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:l-parabolic-neighborhood
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
```

# prop:reduced-length-lipschitz-precise

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:reduced-length-lipschitz-precise
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-parabolic-neighborhood]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-domain]]'
```

# lipaty

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lipaty
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-length-lipschitz-precise]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-parabolic-neighborhood]]'
```

# lem:l-geodesic-min-max-estimate

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-geodesic-min-max-estimate
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
```

# min-max

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#min-max
uses: []
```

# nablas

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#nablas
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
```

# cor:l-geodesic-speed-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:l-geodesic-speed-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-geodesic-min-max-estimate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# minmax

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#minmax
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-geodesic-min-max-estimate]]'
```

# lem:reduced-length-upper-bound-nearby

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:reduced-length-upper-bound-nearby
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-geodesic-speed-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-parabolic-neighborhood]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
```

# upperbd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#upperbd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-geodesic-speed-bound]]'
```

# claim:l-geodesic-endpoint-close-to-ball

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:l-geodesic-endpoint-close-to-ball
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-geodesic-speed-bound]]'
```

# 6.66

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#6.66
uses: []
```

# claim:l-length-concatenation-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:l-length-concatenation-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#claim:l-geodesic-endpoint-close-to-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-upper-bound-nearby]]'
```

# claim:parabolic-ball-containment

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:parabolic-ball-containment
uses: []
```

# claim:point-in-parabolic-neighborhood

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:point-in-parabolic-neighborhood
uses: []
```

# cor:reduced-length-full-measure

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:reduced-length-full-measure
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-parabolic-neighborhood]]'
```

# fullmeasure

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#fullmeasure
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-geodesic-speed-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
```

# claim:complement-injectivity-set-two-types

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:complement-injectivity-set-two-types
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
```

# twosets

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#twosets
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-geodesic-speed-bound]]'
```

# claim:l-length-nondifferentiable-at-multiple-geodesics

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:l-length-nondifferentiable-at-multiple-geodesics
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-tilde-gradient]]'
```

# def:reduced-volume

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#def:reduced-volume
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
```

# redvol

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#redvol
uses: []
```

# lem:reduced-volume-pullback

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:reduced-volume-pullback
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-volume]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-tangential]]'
```

# redvoltilde

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#redvoltilde
uses: []
```

# lem:l-length-rescaling

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:l-length-rescaling
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-length]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-geodesic]]'
```

# Lrescale

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Lrescale
uses: []
```

# rem:rescaling-norm-identity

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#rem:rescaling-norm-identity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-rescaling]]'
```

# cor:l-exponential-rescaling-identity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:l-exponential-rescaling-identity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-rescaling]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-tangential]]'
```

# COR

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#COR
uses: []
```

# lem:reduced-volume-integrand-scale-invariance

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#lem:reduced-volume-integrand-scale-invariance
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-volume]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-exponential-rescaling-identity]]'
```

# Qformula

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Qformula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-exponential-rescaling-identity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-rescaling]]'
```

# ex:l-exponential-euclidean

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#ex:l-exponential-euclidean
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-tangential]]'
```

# claim:reduced-volume-integrand-euclidean

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#claim:reduced-volume-integrand-euclidean
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#ex:l-exponential-euclidean]]'
```

# Arnquantity

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Arnquantity
uses: []
```

# prop:reduced-volume-integrand-limit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:reduced-volume-integrand-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#claim:reduced-volume-integrand-euclidean]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
```

# Jlimit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Jlimit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-volume-integrand-scale-invariance]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#claim:reduced-volume-integrand-euclidean]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-rescaling]]'
```

# cor:injectivity-set-contains-ball-small-tau

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:injectivity-set-contains-ball-small-tau
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-volume-integrand-limit]]'
```

# Jlimit1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Jlimit1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-volume-integrand-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-geodesic-min-max-estimate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-exponential-map]]'
```

# thm:reduced-volume-monotone

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#thm:reduced-volume-monotone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-volume]]'
```

# Amono

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Amono
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-volume-pullback]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-tangential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-volume-integrand-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-hessian-jacobi-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-hessian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-laplacian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:reduced-length-tangential-k-derivative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#claim:h-sum-formula]]'
```

# prop:reduced-volume-integrand-monotone

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#prop:reduced-volume-integrand-monotone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:reduced-length-tangential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-volume-integrand-limit]]'
```

# fmonotone

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#fmonotone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-length-hessian-jacobi-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-hessian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-laplacian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:reduced-length-tangential-k-derivative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-volume-integrand-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#claim:h-sum-formula]]'
```

# basic

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#basic
uses: []
```

# Jinequ

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Jinequ
uses: []
```

# Jineq

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#Jineq
uses: []
```

# cor:reduced-volume-bounded

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#cor:reduced-volume-bounded
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#thm:reduced-volume-monotone]]'
```

# finiteredvol

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry.tex#finiteredvol
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#thm:reduced-volume-monotone]]'
```
