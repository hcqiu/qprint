# chap:introduction

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#chap:introduction
uses: []
```

# thm:classification-fundamental-group-free-product

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#thm:classification-fundamental-group-free-product
uses: []
```

# Theorem1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#Theorem1
uses: []
```

# cor:poincare-and-spherical-space-form

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#cor:poincare-and-spherical-space-form
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch00_Introduction#thm:classification-fundamental-group-free-product]]'
```

# thm:ricci-flow-surgery-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#thm:ricci-flow-surgery-existence
uses: []
```

# surgery

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#surgery
uses: []
```

# thm:ricci-flow-surgery-finite-extinction

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#thm:ricci-flow-surgery-finite-extinction
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch00_Introduction#thm:ricci-flow-surgery-existence]]'
```

# finiteext

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#finiteext
uses: []
```

# cor:extinction-equivalence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#cor:extinction-equivalence
uses: []
```

# corequiv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#corequiv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch00_Introduction#thm:ricci-flow-surgery-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch00_Introduction#thm:ricci-flow-surgery-finite-extinction]]'
```

# rem:extinction-remarks

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#rem:extinction-remarks
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch00_Introduction#thm:classification-fundamental-group-free-product]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch00_Introduction#cor:extinction-equivalence]]'
```

# scalarflow

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#scalarflow
uses: []
```

# sectmax

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#sectmax
uses: []
```

# thm:compactness-based-ricci-flows

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#thm:compactness-based-ricci-flows
uses: []
```

# thm:compactness-kappa-solutions

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch00_Introduction.tex#thm:compactness-kappa-solutions
uses: []
```
