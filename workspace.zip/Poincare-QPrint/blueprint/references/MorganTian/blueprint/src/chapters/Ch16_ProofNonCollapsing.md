# chap:proof-noncollapsing

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#chap:proof-noncollapsing
uses: []
```

# sectnoncoll

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#sectnoncoll
uses: []
```

# prop:kappa-limit-noncollapsing

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#prop:kappa-limit-noncollapsing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#thm:main-existence-ricci-flow-surgery]]'
```

# KAPPALIMIT

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#KAPPALIMIT
uses: []
```

# rem:kappa-delta-dependence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#rem:kappa-delta-dependence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:kappa-limit-noncollapsing]]'
```

# rsmall

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#rsmall
uses: []
```

# prop:noncollapsing-small-scale-easy-case

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#prop:noncollapsing-small-scale-easy-case
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:strong-canonical-neighborhood-assumption]]'
```

# prop:minimizing-L-geodesics-exist

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#prop:minimizing-L-geodesics-exist
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:kappa-limit-noncollapsing]]'
```

# delta0ri+1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#delta0ri+1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#cor:minimizing-geodesic-to-earlier-slice]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:L-geodesics-exist-and-limit]]'
```

# prop:surgery-cap-evolution-alternative

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#prop:surgery-cap-evolution-alternative
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#def:surgery-cap]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:curvature-pinched-toward-positive-surgery]]'
```

# altern

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#altern
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-derivative-estimates]]'
```

# claim:surgery-cap-curvature-bound-uniform

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:surgery-cap-curvature-bound-uniform
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-derivative-estimates]]'
```

# cor:surgery-cap-smooth-limit

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#cor:surgery-cap-smooth-limit
uses: []
```

# lem:rescaled-surgery-limit-standard-flow

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#lem:rescaled-surgery-limit-standard-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-with-initial-derivatives]]'
```

# cor:surgery-cap-close-to-standard-up-to-theta

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#cor:surgery-cap-close-to-standard-up-to-theta
uses: []
```

# goodtotheta

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#goodtotheta
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-with-initial-derivatives]]'
```

# claim:ball-disjoint-from-surgery-spheres

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:ball-disjoint-from-surgery-spheres
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#cor:surgery-cap-close-to-standard-up-to-theta]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:embedded-sphere-isotopic-to-neck-fiber]]'
```

# rem:ball-removed-by-later-surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#rem:ball-removed-by-later-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
```

# def:overline-delta-0

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#def:overline-delta-0
uses: []
```

# defnoverlinedelta0

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#defnoverlinedelta0
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-solution-scalar-curvature-lower-bound]]'
```

# prop:long-L-length-near-surgery-cap

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#prop:long-L-length-near-surgery-cap
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
```

# bigell

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#bigell
uses: []
```

# *

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#*
uses: []
```

# **

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#**
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-solution-scalar-curvature-lower-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# claim:standard-solution-neck-at-infinity

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:standard-solution-neck-at-infinity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# lem:small-L-plus-avoids-surgery-caps

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#lem:small-L-plus-avoids-surgery-caps
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:long-L-length-near-surgery-cap]]'
```

# L_0

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#L_0
uses: []
```

# tau_1est

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#tau_1est
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:long-L-length-near-surgery-cap]]'
```

# rem:surgery-cap-radius-recollection

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#rem:surgery-cap-radius-recollection
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#def:surgery-cap]]'
```

# claim:energy-lower-bound-exit-ball

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:energy-lower-bound-exit-ball
uses: []
```

# def:disappearing-region-J

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#def:disappearing-region-J
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#def:surgery-operation]]'
```

# J

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#J
uses: []
```

# lem:short-energy-avoids-disappearing-region

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#lem:short-energy-avoids-disappearing-region
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#def:disappearing-region-J]]'
```

# 15.17

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#15.17
uses: []
```

# def:compact-subset-Y-ell

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#def:compact-subset-Y-ell
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#def:disappearing-region-J]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:long-L-length-near-surgery-cap]]'
```

# prop:L-geodesics-exist-and-limit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#prop:L-geodesics-exist-and-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#lem:small-L-plus-avoids-surgery-caps]]'
```

# Lgeoexist

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#Lgeoexist
uses: []
```

# L'ineq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#L'ineq
uses: []
```

# gamliminf1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#gamliminf1
uses: []
```

# gamliminf2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#gamliminf2
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#lem:small-L-plus-avoids-surgery-caps]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:long-L-length-near-surgery-cap]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#lem:l-geodesic-existence]]'
```

# claim:path-misses-P0-cap-neighborhood

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:path-misses-P0-cap-neighborhood
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#lem:small-L-plus-avoids-surgery-caps]]'
```

# claim:path-disjoint-from-J-near-surgery

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:path-disjoint-from-J-near-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#lem:short-energy-avoids-disappearing-region]]'
```

# cor:minimizing-geodesic-to-earlier-slice

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#cor:minimizing-geodesic-to-earlier-slice
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#lem:small-L-plus-avoids-surgery-caps]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:L-geodesics-exist-and-limit]]'
```

# bardelta1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#bardelta1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#cor:minimizing-geodesic-to-earlier-slice]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:L-geodesics-exist-and-limit]]'
```

# claim:Z-prime-compact

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:Z-prime-compact
uses: []
```

# lem:reduced-length-min-bound-3-2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#lem:reduced-length-min-bound-3-2
uses: []
```

# lvalue

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#lvalue
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#cor:minimizing-geodesic-to-earlier-slice]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:minimizing-L-geodesics-exist]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#cor:generalized-flow-n-half-bound]]'
```

# Lgamma1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#Lgamma1
uses: []
```

# claim:existence-of-tau0-low-curvature-point

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:existence-of-tau0-low-curvature-point
uses: []
```

# tau0cl

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#tau0cl
uses: []
```

# claim:tau0-estimates

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing.tex#claim:tau0-estimates
uses: []
```
