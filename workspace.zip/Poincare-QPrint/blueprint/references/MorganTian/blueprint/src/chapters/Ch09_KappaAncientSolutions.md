# chap:kappa-ancient-solutions

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#chap:kappa-ancient-solutions
uses: []
```

# kappasect

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#kappasect
uses: []
```

# def:kappa-noncollapsed

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:kappa-noncollapsed
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# kappadefn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#kappadefn
uses: []
```

# def:ancient-solution

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:ancient-solution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# ex:shrinking-sphere-kappa-solution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#ex:shrinking-sphere-kappa-solution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
```

# thm:two-dimensional-kappa-solution-preview

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#thm:two-dimensional-kappa-solution-preview
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:two-dimensional-gradient-shrinking-soliton]]'
```

# ex:round-sphere-quotient-kappa-solution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#ex:round-sphere-quotient-kappa-solution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
```

# ex:cylinder-kappa-solution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#ex:cylinder-kappa-solution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
```

# ex:cylinder-quotient-kappa-solution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#ex:cylinder-quotient-kappa-solution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#ex:cylinder-kappa-solution]]'
```

# ex:cylinder-with-circle-not-kappa-noncollapsed

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#ex:cylinder-with-circle-not-kappa-noncollapsed
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# prop:harnack-l-function-lipschitz-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:harnack-l-function-lipschitz-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# uniformlip

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#uniformlip
uses: []
```

# Kbartaueqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#Kbartaueqn
uses: []
```

# cor:l-function-gradient-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:l-function-gradient-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:harnack-l-function-lipschitz-bound]]'
```

# unianc

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#unianc
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:harnack-l-function-lipschitz-bound]]'
```

# sect9.2

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#sect9.2
uses: []
```

# thm:asymptotic-gradient-shrinking-soliton

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#thm:asymptotic-gradient-shrinking-soliton
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:gradient-shrinking-soliton]]'
```

# asympGSS

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#asympGSS
uses: []
```

# GSSequation

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#GSSequation
uses: []
```

# rem:asymptotic-soliton-caveats

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#rem:asymptotic-soliton-caveats
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-gradient-shrinking-soliton]]'
```

# claim:reduced-volume-rescaling

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:reduced-volume-rescaling
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-gradient-shrinking-soliton]]'
```

# scaleinv2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#scaleinv2
uses: []
```

# cor:reduced-volume-limit-constant

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:reduced-volume-limit-constant
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:reduced-volume-rescaling]]'
```

# redvolconst

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#redvolconst
uses: []
```

# limVeqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#limVeqn
uses: []
```

# claim:qk-length-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:qk-length-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-gradient-shrinking-soliton]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-function-gradient-bound]]'
```

# tausqtau

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#tausqtau
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-function-gradient-bound]]'
```

# cor:l-function-distance-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:l-function-distance-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:qk-length-bound]]'
```

# lxkest

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lxkest
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-function-gradient-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:qk-length-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:harnack-l-function-lipschitz-bound]]'
```

# cor:kappa-solution-geometric-limit-exists

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:kappa-solution-geometric-limit-exists
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-gradient-shrinking-soliton]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# cor:l-infinity-gradient-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:l-infinity-gradient-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-function-distance-bound]]'
```

# linfest

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#linfest
uses: []
```

# rem:l-infinity-not-reduced-length

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#rem:l-infinity-not-reduced-length
uses: []
```

# prop:l-infinity-differential-equations

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:l-infinity-differential-equations
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-infinity-gradient-bound]]'
```

# weakeqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#weakeqn
uses: []
```

# weak1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#weak1
uses: []
```

# weak2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#weak2
uses: []
```

# sect9.2.3

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#sect9.2.3
uses: []
```

# lem:gradient-convergence-distributions

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lem:gradient-convergence-distributions
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-infinity-gradient-bound]]'
```

# nablaconv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#nablaconv
uses: []
```

# firstdist

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#firstdist
uses: []
```

# 11

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#11
uses: []
```

# 12

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#12
uses: []
```

# claim:nabla-convergence-limsup-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:nabla-convergence-limsup-bound
uses: []
```

# lem:distribution-d-nonpositive

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lem:distribution-d-nonpositive
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:gradient-convergence-distributions]]'
```

# 1stlinftyeqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#1stlinftyeqn
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:gradient-convergence-distributions]]'
```

# cor:weighted-distribution-nonnegative

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:weighted-distribution-nonnegative
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:distribution-d-nonpositive]]'
```

# etimesdis

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#etimesdis
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:distribution-d-nonpositive]]'
```

# lem:l-function-lower-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lem:l-function-lower-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-gradient-shrinking-soliton]]'
```

# lowerbdd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lowerbdd
uses: []
```

# fform

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#fform
uses: []
```

# 1eqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#1eqn
uses: []
```

# 2eqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#2eqn
uses: []
```

# cor:l-function-lower-bound-refined

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:l-function-lower-bound-refined
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:l-function-lower-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:qk-length-bound]]'
```

# claim:absolute-convergence-weighted-distribution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:absolute-convergence-weighted-distribution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-function-lower-bound-refined]]'
```

# absconv1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#absconv1
uses: []
```

# cor:absolute-convergence-gradient-terms

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:absolute-convergence-gradient-terms
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:absolute-convergence-weighted-distribution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-function-gradient-bound]]'
```

# absconv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#absconv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:l-function-gradient-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:absolute-convergence-weighted-distribution]]'
```

# claim:absolute-convergence-laplacian-term

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:absolute-convergence-laplacian-term
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:absolute-convergence-weighted-distribution]]'
```

# absconv2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#absconv2
uses: []
```

# cor:weak-inequality-nonnegative-integral

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:weak-inequality-nonnegative-integral
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:absolute-convergence-weighted-distribution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:absolute-convergence-laplacian-term]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:weighted-distribution-nonnegative]]'
```

# weakneg

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#weakneg
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:absolute-convergence-weighted-distribution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:absolute-convergence-laplacian-term]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:weighted-distribution-nonnegative]]'
```

# sect9.2.5

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#sect9.2.5
uses: []
```

# claim:laplacian-integral-vanishes

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:laplacian-integral-vanishes
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:absolute-convergence-gradient-terms]]'
```

# tildeD

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#tildeD
uses: []
```

# constcon

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#constcon
uses: []
```

# wk=

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#wk=
uses: []
```

# prop:limit-gradient-shrinking-soliton-equation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:limit-gradient-shrinking-soliton-equation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:l-infinity-differential-equations]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:gradient-shrinking-soliton]]'
```

# gradshrink

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#gradshrink
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# lem:conjugate-heat-equation-soliton-identity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lem:conjugate-heat-equation-soliton-identity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# 9.1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#9.1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# dHeqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#dHeqn
uses: []
```

# feqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#feqn
uses: []
```

# claim:laplacian-time-derivative-commutation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:laplacian-time-derivative-commutation
uses: []
```

# 11.20

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#11.20
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# claim:laplacian-gradient-squared-formula

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:laplacian-gradient-squared-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-one-form]]'
```

# claim:flat-limit-length-function-form

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:flat-limit-length-function-form
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:limit-gradient-shrinking-soliton-equation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:conjugate-heat-equation-soliton-identity]]'
```

# lem:point-picking-general

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lem:point-picking-general
uses: []
```

# 4times

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#4times
uses: []
```

# cor:point-picking-time-independent

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:point-picking-time-independent
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:point-picking-general]]'
```

# pp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#pp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:point-picking-general]]'
```

# prop:splitting-at-infinity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:splitting-at-infinity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# prodatinf

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prodatinf
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:point-picking-time-independent]]'
```

# cor:no-two-dimensional-splitting-example

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:no-two-dimensional-splitting-example
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:splitting-at-infinity]]'
```

# compact2D

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#compact2D
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:point-picking-time-independent]]'
```

# GSS-1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#GSS-1
uses: []
```

# def:kappa-noncollapsed-riemannian-manifold

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:kappa-noncollapsed-riemannian-manifold
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# thm:gradient-shrinking-soliton-classification

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#thm:gradient-shrinking-soliton-classification
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed-riemannian-manifold]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:gradient-shrinking-soliton]]'
```

# GSSclass

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#GSSclass
uses: []
```

# Gdefn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#Gdefn
uses: []
```

# compactcs

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#compactcs
uses: []
```

# claim:compact-positive-curvature-round

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:compact-positive-curvature-round
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:gradient-shrinking-soliton-classification]]'
```

# cor:compact-asymptotic-soliton-classification

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:compact-asymptotic-soliton-classification
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:compact-positive-curvature-round]]'
```

# compactcase

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#compactcase
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:compact-positive-curvature-round]]'
```

# claim:non-strictly-positive-curvature-splitting

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:non-strictly-positive-curvature-splitting
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:gradient-shrinking-soliton-classification]]'
```

# flatssplit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#flatssplit
uses: []
```

# noncomp

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#noncomp
uses: []
```

# prop:no-noncompact-positive-curvature-soliton

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:no-noncompact-positive-curvature-soliton
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:gradient-shrinking-soliton-classification]]'
```

# noncompsol

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#noncompsol
uses: []
```

# Rfeqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#Rfeqn
uses: []
```

# dR

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#dR
uses: []
```

# sqrts

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#sqrts
uses: []
```

# X

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#X
uses: []
```

# sqrts2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#sqrts2
uses: []
```

# R_N

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#R_N
uses: []
```

# claim:ricci-integral-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:ricci-integral-bound
uses: []
```

# Yeqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#Yeqn
uses: []
```

# claim:ricci-cauchy-schwarz-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:ricci-cauchy-schwarz-bound
uses: []
```

# cor:noncompact-soliton-splitting-summary

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:noncompact-soliton-splitting-summary
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:non-strictly-positive-curvature-splitting]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:splitting-at-infinity]]'
```

# compact2Dsol

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#compact2Dsol
uses: []
```

# cor:two-dimensional-gradient-shrinking-soliton

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:two-dimensional-gradient-shrinking-soliton
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:no-two-dimensional-splitting-example]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:noncompact-soliton-splitting-summary]]'
```

# 2DGSS

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#2DGSS
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:no-two-dimensional-splitting-example]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:noncompact-soliton-splitting-summary]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-gradient-shrinking-soliton]]'
```

# claim:cylinder-limit-scalar-curvature-normalization

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:cylinder-limit-scalar-curvature-normalization
uses: []
```

# cor:three-dimensional-splitting-compact-surfaces

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:three-dimensional-splitting-compact-surfaces
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:splitting-at-infinity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:two-dimensional-gradient-shrinking-soliton]]'
```

# 3Dinfty

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#3Dinfty
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:splitting-at-infinity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:two-dimensional-gradient-shrinking-soliton]]'
```

# cor:three-dimensional-asymptotic-soliton-bounded-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:three-dimensional-asymptotic-soliton-bounded-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:three-dimensional-splitting-compact-surfaces]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:two-dimensional-gradient-shrinking-soliton]]'
```

# 3DGSSkappa

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#3DGSSkappa
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:three-dimensional-splitting-compact-surfaces]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:two-dimensional-gradient-shrinking-soliton]]'
```

# cor:asymptotic-soliton-classification-application

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:asymptotic-soliton-classification-application
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:three-dimensional-asymptotic-soliton-bounded-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:gradient-shrinking-soliton-classification]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-gradient-shrinking-soliton]]'
```

# def:asymptotic-scalar-curvature

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:asymptotic-scalar-curvature
uses: []
```

# prop:asymptotic-scalar-curvature-infinite

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:asymptotic-scalar-curvature-infinite
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:asymptotic-scalar-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# asympscal

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#asympscal
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:two-dimensional-gradient-shrinking-soliton]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:non-strictly-positive-curvature-splitting]]'
```

# claim:sphere-at-infinity-round

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:sphere-at-infinity-round
uses: []
```

# prop:universal-kappa-non-round

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:universal-kappa-non-round
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:compact-asymptotic-soliton-classification]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:gradient-shrinking-soliton-classification]]'
```

# kappa0

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#kappa0
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:compact-asymptotic-soliton-classification]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:gradient-shrinking-soliton-classification]]'
```

# thm:asymptotic-volume-zero

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#thm:asymptotic-volume-zero
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# asympvol

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#asympvol
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:two-dimensional-gradient-shrinking-soliton]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:splitting-at-infinity]]'
```

# prop:volume-comparison-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:volume-comparison-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-volume-zero]]'
```

# volcomp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#volcomp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-volume-zero]]'
```

# claim:asymptotic-volume-monotone

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:asymptotic-volume-monotone
uses: []
```

# cor:volume-bound-implies-curvature-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:volume-bound-implies-curvature-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:volume-comparison-bound]]'
```

# bdvolbdcurv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#bdvolbdcurv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:volume-comparison-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:point-picking-general]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:asymptotic-volume-zero]]'
```

# cor:global-curvature-bound-from-volume

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:global-curvature-bound-from-volume
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:volume-bound-implies-curvature-bound]]'
```

# global

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#global
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:volume-bound-implies-curvature-bound]]'
```

# thm:kappa-solution-compactness

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#thm:kappa-solution-compactness
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# compactkappa

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#compactkappa
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:uniform-curvature-bound-kappa-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:three-dimensional-asymptotic-soliton-bounded-curvature]]'
```

# lem:uniform-curvature-bound-kappa-solution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lem:uniform-curvature-bound-kappa-solution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-compactness]]'
```

# proposition

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#proposition
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:asymptotic-scalar-curvature-infinite]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:volume-bound-implies-curvature-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:three-dimensional-asymptotic-soliton-bounded-curvature]]'
```

# claim:curvature-ratio-bound-near-basepoint

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:curvature-ratio-bound-near-basepoint
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:volume-bound-implies-curvature-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:three-dimensional-asymptotic-soliton-bounded-curvature]]'
```

# 2Rbound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#2Rbound
uses: []
```

# V3

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#V3
uses: []
```

# lowerbd

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lowerbd
uses: []
```

# V/2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#V/2
uses: []
```

# V3/2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#V3/2
uses: []
```

# claim:distance-bound-under-rescaling

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:distance-bound-under-rescaling
uses: []
```

# claim:curvature-upper-bound-universal

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:curvature-upper-bound-universal
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:distance-bound-under-rescaling]]'
```

# zkbound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#zkbound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:distance-bound-under-rescaling]]'
```

# claim:basepoint-neighborhood-curvature-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:basepoint-neighborhood-curvature-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:curvature-ratio-bound-near-basepoint]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:curvature-upper-bound-universal]]'
```

# bdnearxk

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#bdnearxk
uses: []
```

# cor:curvature-bound-fixed-ball

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:curvature-bound-fixed-ball
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#claim:basepoint-neighborhood-curvature-bound]]'
```

# rho

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#rho
uses: []
```

# cor:curvature-derivative-bounds-universal

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:curvature-derivative-bounds-universal
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-compactness]]'
```

# derivcor

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#derivcor
uses: []
```

# gradest

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#gradest
uses: []
```

# timeest

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#timeest
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-compactness]]'
```

# def:c-epsilon-cap

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:c-epsilon-cap
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# epscap

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#epscap
uses: []
```

# rem:cap-core-ball-remark

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#rem:cap-core-ball-remark
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
```

# claim:cap-condition-time-derivative-equivalence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:cap-condition-time-derivative-equivalence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# partialtR

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#partialtR
uses: []
```

# def:c-component

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:c-component
uses: []
```

# Ccomponent

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#Ccomponent
uses: []
```

# def:epsilon-round-component

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:epsilon-round-component
uses: []
```

# defnepsround

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#defnepsround
uses: []
```

# def:canonical-neighborhood

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:canonical-neighborhood
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-component]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:epsilon-round-component]]'
```

# def:strong-epsilon-neck-canonical-neighborhood

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:strong-epsilon-neck-canonical-neighborhood
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-component]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:epsilon-round-component]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-close-topology]]'
```

# defncanonnbhd

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#defncanonnbhd
uses: []
```

# prop:canonical-neighborhood-stability

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:canonical-neighborhood-stability
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:strong-epsilon-neck-canonical-neighborhood]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:canonical-neighborhood]]'
```

# canonvary

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#canonvary
uses: []
```

# cor:strong-neck-centers-open

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:strong-neck-centers-open
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:canonical-neighborhood-stability]]'
```

# strepsopen

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#strepsopen
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:canonical-neighborhood-stability]]'
```

# def:epsilon-tube

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:epsilon-tube
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
```

# epstube

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#epstube
uses: []
```

# def:strong-epsilon-tube

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#def:strong-epsilon-tube
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:epsilon-tube]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:strong-epsilon-neck-canonical-neighborhood]]'
```

# prop:kappa-solution-trichotomy

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:kappa-solution-trichotomy
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:ancient-solution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:kappa-noncollapsed]]'
```

# infprod2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#infprod2
uses: []
```

# lem:noncompact-kappa-solution-neck-structure

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#lem:noncompact-kappa-solution-neck-structure
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:kappa-solution-trichotomy]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-compactness]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:two-dimensional-gradient-shrinking-soliton]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:uniform-curvature-bound-kappa-solution]]'
```

# prop:uniform-neck-structure-constants

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:uniform-neck-structure-constants
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:noncompact-kappa-solution-neck-structure]]'
```

# uniformD

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#uniformD
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-compactness]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:noncompact-kappa-solution-neck-structure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:canonical-neighborhood-stability]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:kappa-solution-trichotomy]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:strong-neck-centers-open]]'
```

# rem:uniform-neck-structure-basepoint-remark

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#rem:uniform-neck-structure-basepoint-remark
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:uniform-neck-structure-constants]]'
```

# claim:kq-scale-separation

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:kq-scale-separation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#lem:uniform-curvature-bound-kappa-solution]]'
```

# cor:noncompact-kappa-solution-tube-structure

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:noncompact-kappa-solution-tube-structure
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:uniform-neck-structure-constants]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:curvature-derivative-bounds-universal]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:strong-epsilon-tube]]'
```

# noncompkappa

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#noncompkappa
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:uniform-neck-structure-constants]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:curvature-derivative-bounds-universal]]'
```

# thm:compact-kappa-solution-structure

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#thm:compact-kappa-solution-structure
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:noncompact-kappa-solution-tube-structure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:strong-epsilon-tube]]'
```

# thmep3

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#thmep3
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:universal-kappa-non-round]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:noncompact-kappa-solution-tube-structure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:compact-asymptotic-soliton-classification]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:gradient-shrinking-soliton-classification]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-compactness]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:canonical-neighborhood-stability]]'
```

# claim:diameter-canonical-neighborhood-criterion

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#claim:diameter-canonical-neighborhood-criterion
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:noncompact-kappa-solution-tube-structure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-compactness]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:canonical-neighborhood-stability]]'
```

# prop:compact-kappa-solution-volume-curvature-bounds

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#prop:compact-kappa-solution-volume-curvature-bounds
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:compact-kappa-solution-structure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:universal-kappa-non-round]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-compactness]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:noncompact-kappa-solution-tube-structure]]'
```

# rem:round-kappa-solution-volume-remark

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#rem:round-kappa-solution-volume-remark
uses: []
```

# thm:kappa-solution-structure-summary

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#thm:kappa-solution-structure-summary
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:compact-kappa-solution-structure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:noncompact-kappa-solution-tube-structure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:compact-kappa-solution-volume-curvature-bounds]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:curvature-derivative-bounds-universal]]'
```

# kappasummary

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#kappasummary
uses: []
```

# nablaR

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#nablaR
uses: []
```

# dRdt

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#dRdt
uses: []
```

# cor:canonical-neighborhood-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:canonical-neighborhood-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#thm:kappa-solution-structure-summary]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:canonical-neighborhood]]'
```

# kappacannbhd

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#kappacannbhd
uses: []
```

# cor:canonical-neighborhood-limit-passage

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#cor:canonical-neighborhood-limit-passage
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:canonical-neighborhood-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:strong-epsilon-neck-canonical-neighborhood]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
```

# limitcannbhd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions.tex#limitcannbhd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#cor:canonical-neighborhood-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#prop:canonical-neighborhood-stability]]'
```
