# chap:maximum-principle

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#chap:maximum-principle
uses: []
```

# secmaxprin

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#secmaxprin
uses: []
```

# prop:scalar-curvature-min-evolution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#prop:scalar-curvature-min-evolution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# scalarevol

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#scalarevol
uses: []
```

# Rminineq

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#Rminineq
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-quotient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:curvature-evolution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# claim:scalar-min-derivative-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#claim:scalar-min-derivative-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# firstclaim

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#firstclaim
uses: []
```

# claim:scalar-min-forward-difference

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#claim:scalar-min-forward-difference
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#claim:scalar-min-derivative-bound]]'
```

# Rminprime

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#Rminprime
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#prop:forward-difference-maximum]]'
```

# def:vector-field-preserves-convex-set

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#def:vector-field-preserves-convex-set
uses: []
```

# lem:integral-curve-preserves-convex-set

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#lem:integral-curve-preserves-convex-set
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#def:vector-field-preserves-convex-set]]'
```

# 4.3.3

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#4.3.3
uses: []
```

# def:convex-subbundle-preserving-vector-field

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#def:convex-subbundle-preserving-vector-field
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#def:vector-field-preserves-convex-set]]'
```

# thm:maximum-principle-tensors-global

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:maximum-principle-tensors-global
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#def:convex-subbundle-preserving-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# MP

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#MP
uses: []
```

# thm:maximum-principle-tensors-varying-z

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:maximum-principle-tensors-varying-z
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#def:convex-subbundle-preserving-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# varyingZ

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#varyingZ
uses: []
```

# thm:maximum-principle-tensors-local

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:maximum-principle-tensors-local
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#def:convex-subbundle-preserving-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# localMP

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#localMP
uses: []
```

# def:normalized-initial-conditions

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#def:normalized-initial-conditions
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
```

# norminitcond

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#norminitcond
uses: []
```

# prop:normalized-flow-short-time-bounds

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#prop:normalized-flow-short-time-bounds
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#def:normalized-initial-conditions]]'
```

# kappa0r0t0

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#kappa0r0t0
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:curvature-evolution]]'
```

# prop:ricci-flow-extension-criterion

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#prop:ricci-flow-extension-criterion
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# flowextend

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#flowextend
uses: []
```

# lem:curvature-operator-ode-dimension-three

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#lem:curvature-operator-ode-dimension-three
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#prop:curvature-operator-evolution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# quad

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#quad
uses: []
```

# cor:nonnegative-curvature-operator-preserved

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#cor:nonnegative-curvature-operator-preserved
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# rm>0

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#rm>0
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:maximum-principle-tensors-global]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#lem:curvature-operator-ode-dimension-three]]'
```

# cor:nonnegative-ricci-preserved

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#cor:nonnegative-ricci-preserved
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# Ric>0

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#Ric>0
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:maximum-principle-tensors-global]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#lem:curvature-operator-ode-dimension-three]]'
```

# thm:strong-maximum-principle-heat

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:strong-maximum-principle-heat
uses: []
```

# SMPheat

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#SMPheat
uses: []
```

# prop:strong-maximum-principle-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#prop:strong-maximum-principle-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#def:convex-subbundle-preserving-vector-field]]'
```

# SMPcurv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#SMPcurv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:strong-maximum-principle-heat]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:maximum-principle-tensors-local]]'
```

# thm:vanishing-scalar-curvature-forces-flat

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:vanishing-scalar-curvature-forces-flat
uses: []
```

# firststrongmax

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#firststrongmax
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:curvature-evolution]]'
```

# cor:local-product-splitting-ricci-null-eigenvalue

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#cor:local-product-splitting-ricci-null-eigenvalue
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# localprod

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#localprod
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#cor:nonnegative-ricci-preserved]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:curvature-evolution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#prop:strong-maximum-principle-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:vanishing-scalar-curvature-forces-flat]]'
```

# cor:global-product-splitting-cover

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#cor:global-product-splitting-cover
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#cor:local-product-splitting-ricci-null-eigenvalue]]'
```

# nullspace

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#nullspace
uses: []
```

# rem:product-splitting-cover-classification

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#rem:product-splitting-cover-classification
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#cor:global-product-splitting-cover]]'
```

# prop:no-nonflat-cones-from-ricci-flow

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#prop:no-nonflat-cones-from-ricci-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cone]]'
```

# nocones

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#nocones
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:cone-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:vanishing-scalar-curvature-forces-flat]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#cor:local-product-splitting-ricci-null-eigenvalue]]'
```

# thm:nonnegative-ricci-flow-becomes-round

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:nonnegative-ricci-flow-becomes-round
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#cor:nonnegative-ricci-preserved]]'
```

# flowtoround

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#flowtoround
uses: []
```

# thm:positive-ricci-soliton-round

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:positive-ricci-soliton-round
uses: []
```

# sphsf

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#sphsf
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:nonnegative-ricci-flow-becomes-round]]'
```

# rem:roundness-shrinking-soliton-preview

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#rem:roundness-shrinking-soliton-preview
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:positive-ricci-soliton-round]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:gradient-shrinking-soliton]]'
```

# thm:pinching-toward-positive-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:pinching-toward-positive-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# pinch

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#pinch
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#prop:scalar-curvature-min-evolution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:maximum-principle-tensors-varying-z]]'
```

# rem:pinching-negative-eigenvalues-small

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#rem:pinching-negative-eigenvalues-small
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:pinching-toward-positive-curvature]]'
```

# claim:pinching-region-convex

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#claim:pinching-region-convex
uses: []
```

# claim:pinching-initial-condition

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#claim:pinching-initial-condition
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#claim:pinching-region-convex]]'
```

# claim:pinching-auxiliary-quantity-nonnegative

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#claim:pinching-auxiliary-quantity-nonnegative
uses: []
```

# claim:pinching-vector-field-preserves-family

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#claim:pinching-vector-field-preserves-family
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#claim:pinching-region-convex]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#claim:pinching-auxiliary-quantity-nonnegative]]'
```

# Sineq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#Sineq
uses: []
```

# dX

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#dX
uses: []
```

# dX1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#dX1
uses: []
```

# dW

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#dW
uses: []
```

# thm:pinching-persists-from-time-a

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:pinching-persists-from-time-a
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:pinching-toward-positive-curvature]]'
```

# pincha

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#pincha
uses: []
```

# Rlower

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#Rlower
uses: []
```

# RXineq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#RXineq
uses: []
```

# cor:curvature-bound-from-scalar-pinching

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#cor:curvature-bound-from-scalar-pinching
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:pinching-persists-from-time-a]]'
```

# def:curvature-pinched-toward-positive

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#def:curvature-pinched-toward-positive
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:pinching-toward-positive-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# pinchd

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#pinchd
uses: []
```

# thm:shrinking-soliton-round

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:shrinking-soliton-round
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:nonnegative-ricci-flow-becomes-round]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:pinching-toward-positive-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#cor:nonnegative-curvature-operator-preserved]]'
```

# thm:ricci-soliton-einstein-dimension-three

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:ricci-soliton-einstein-dimension-three
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:einstein-manifold]]'
```

# ivey

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#ivey
uses: []
```

# thm:hamilton-harnack-inequality

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:hamilton-harnack-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# Harnack

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#Harnack
uses: []
```

# rem:harnack-inequality-zero-field-case

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#rem:harnack-inequality-zero-field-case
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:hamilton-harnack-inequality]]'
```

# cor:ancient-flow-scalar-curvature-nondecreasing

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#cor:ancient-flow-scalar-curvature-nondecreasing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:hamilton-harnack-inequality]]'
```

# posderiv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#posderiv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:hamilton-harnack-inequality]]'
```

# thm:harnack-inequality-integrated

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#thm:harnack-inequality-integrated
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# Harnack2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple.tex#Harnack2
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:hamilton-harnack-inequality]]'
```
