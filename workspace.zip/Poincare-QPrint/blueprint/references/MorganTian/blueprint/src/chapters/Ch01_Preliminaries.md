# chap:prelim

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#chap:prelim
uses: []
```

# sectprelim

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#sectprelim
uses: []
```

# def:riemannian-metric

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:riemannian-metric
uses: []
```

# thm:levi-civita-connection

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#thm:levi-civita-connection
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# Koszul

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#Koszul
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# Gamma

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#Gamma
uses: []
```

# Hessian

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#Hessian
uses: []
```

# lem:hessian-symmetric

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:hessian-symmetric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# Hessformula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#Hessformula
uses: []
```

# hessform

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#hessform
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# laplacformula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#laplacformula
uses: []
```

# def:riemann-curvature-tensor

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:riemann-curvature-tensor
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# claim:curvature-symmetries-bianchi

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#claim:curvature-symmetries-bianchi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
```

# Bianchi

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#Bianchi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# def:sectional-curvature

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:sectional-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
```

# lem:constant-curvature-tensor

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:constant-curvature-tensor
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# def:curvature-operator

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:curvature-operator
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
```

# def:curvature-operator-norm

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:curvature-operator-norm
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
```

# def:ricci-curvature

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:ricci-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
```

# lem:ricci-trace-curvature-operator

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:ricci-trace-curvature-operator
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# lem:div-ricci-scalar-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:div-ricci-scalar-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# divRic

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#divRic
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# def:second-covariant-derivative-vector-field

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:second-covariant-derivative-vector-field
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:second-covariant-derivative-tensorial

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:second-covariant-derivative-tensorial
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:second-covariant-derivative-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:ricci-commutation-vector-field

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:ricci-commutation-vector-field
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:second-covariant-derivative-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:laplacian-one-form

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:laplacian-one-form
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# lapformula

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lapformula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:second-covariant-derivative-vector-field]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:ricci-commutation-vector-field]]'
```

# oneformcomm

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#oneformcomm
uses: []
```

# Hcomm

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#Hcomm
uses: []
```

# thm:uniformization

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#thm:uniformization
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
```

# modelpolar

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#modelpolar
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:constant-curvature-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-covering]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-rigidity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-exponential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:model-spaces]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:model-polar-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:submanifold-connection]]'
```

# def:einstein-manifold

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:einstein-manifold
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
```

# ex:einstein-dimension-2-3

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#ex:einstein-dimension-2-3
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:einstein-manifold]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# rem:einstein-space-form

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#rem:einstein-space-form
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#ex:einstein-dimension-2-3]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:uniformization]]'
```

# def:cone

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:cone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# conedefn

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#conedefn
uses: []
```

# prop:cone-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#prop:cone-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# conecurv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#conecurv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# cor:cone-eigenvalues

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#cor:cone-eigenvalues
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:cone-curvature]]'
```

# def:geodesic

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:geodesic
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:covariant-commutation-jacobi

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:covariant-commutation-jacobi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# lem:jacobi-field-coordinates

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:jacobi-field-coordinates
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:covariant-commutation-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
```

# lem:chart-curvature-coordinates

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:chart-curvature-coordinates
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:covariant-commutation-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# lem:parallel-frame

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:parallel-frame
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:second-order-linear-ode

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:second-order-linear-ode
uses: []
```

# def:conjugate-point

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:conjugate-point
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-field-coordinates]]'
```

# prop:minimal-geodesic-no-conjugate

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#prop:minimal-geodesic-no-conjugate
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
```

# jacmin

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#jacmin
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:second-variation-minimal-geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:index-form-negative-at-conjugate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# rem:part1-corner-rigidity-route

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#rem:part1-corner-rigidity-route
uses: []
```

# claim:second-variation-minimal-geodesic

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#claim:second-variation-minimal-geodesic
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# secvarindex

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#secvarindex
uses: []
```

# indexnonneg

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#indexnonneg
uses: []
```

# rem:second-variation-chart-route

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#rem:second-variation-chart-route
uses: []
```

# lem:chart-metric-compatibility

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:chart-metric-compatibility
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:second-variation-energy-chart

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:second-variation-energy-chart
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:chart-metric-compatibility]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:covariant-commutation-jacobi]]'
```

# lem:index-form-negative-at-conjugate

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:index-form-negative-at-conjugate
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:parallel-frame]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# def:exponential-map

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:exponential-map
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# lem:normal-ball

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:normal-ball
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
```

# lem:exponential-differential-jacobi

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:exponential-differential-jacobi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:parallel-frame]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:covariant-commutation-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-field-coordinates]]'
```

# cor:exponential-local-diffeomorphism

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#cor:exponential-local-diffeomorphism
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:minimal-geodesic-no-conjugate]]'
```

# star

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#star
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:minimal-geodesic-no-conjugate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
```

# lem:minimizing-geodesic-exists

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:minimizing-geodesic-exists
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:normal-ball]]'
```

# thm:hopf-rinow

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#thm:hopf-rinow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:minimizing-geodesic-exists]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# def:cut-locus

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:cut-locus
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
```

# def:cut-time

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:cut-time
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# lem:minimizing-downward-closed

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:minimizing-downward-closed
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time]]'
```

# def:cut-time-locus

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:cut-time-locus
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:minimizing-downward-closed]]'
```

# lem:segment-domain-star-shaped

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:segment-domain-star-shaped
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time]]'
```

# lem:cut-locus-properties

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:cut-locus-properties
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:segment-domain-star-shaped]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:localized-cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:normal-ball]]'
```

# lem:cut-time-measurable

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:cut-time-measurable
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:minimizing-downward-closed]]'
```

# def:cut-vectors

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:cut-vectors
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time]]'
```

# lem:radial-graph-null

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:radial-graph-null
uses: []
```

# lem:exp-preserves-null

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:exp-preserves-null
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
```

# lem:cut-locus-null

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:cut-locus-null
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-vectors]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:cut-time-measurable]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-graph-null]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exp-preserves-null]]'
```

# prop:exponential-diffeomorphism-cut-locus

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#prop:exponential-diffeomorphism-cut-locus
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:cut-locus-properties]]'
```

# lem:cut-time-star-shaped

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:cut-time-star-shaped
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:cut-locus-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:minimal-geodesic-no-conjugate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
```

# def:injectivity-radius

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:injectivity-radius
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
```

# lem:klingenberg-loop

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:klingenberg-loop
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
```

# def:local-isometry

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:local-isometry
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# lem:local-isometry-exponential

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:local-isometry-exponential
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
```

# lem:local-isometry-normal-balls

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:local-isometry-normal-balls
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:normal-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-exponential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# lem:local-isometry-rigidity

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:local-isometry-rigidity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-exponential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:normal-ball]]'
```

# lem:local-isometry-covering

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:local-isometry-covering
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-exponential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
```

# lem:submanifold-connection

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:submanifold-connection
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# lem:constant-curvature-jacobi

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:constant-curvature-jacobi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:constant-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
```

# dexpformula

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#dexpformula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:constant-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
```

# lem:model-polar-isometry

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:model-polar-isometry
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:constant-curvature-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-covering]]'
```

# lem:model-spaces

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:model-spaces
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:constant-curvature-tensor]]'
```

# invconf

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#invconf
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:constant-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:cone-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
```

# metricexp

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#metricexp
uses: []
```

# lem:normal-coordinates-expansion

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:normal-coordinates-expansion
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:constant-curvature-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# lem:laplacian-christoffel-formula

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:laplacian-christoffel-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:laplacian-local-formula

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:laplacian-local-formula
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-christoffel-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
```

# rem:laplacian-weak-sense

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#rem:laplacian-weak-sense
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/formalization-support#def:weak-laplacian]]'
```

# calabi

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#calabi
uses: []
```

# ex:distance-function-laplacian

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#ex:distance-function-laplacian
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:laplacian-local-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#rem:laplacian-weak-sense]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:cut-locus-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:exponential-diffeomorphism-cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:cut-time-star-shaped]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:volume-element-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/formalization-support#rem:laplacian-weak-green-identity]]'
```

# def:sinh-comparison-function

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:sinh-comparison-function
uses: []
```

# lem:radial-jacobi-orthogonal

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:radial-jacobi-orthogonal
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
```

# lem:jacobi-operator-symmetric

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:jacobi-operator-symmetric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
```

# lem:geodesic-polar-form

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:geodesic-polar-form
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-jacobi-orthogonal]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-operator-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#claim:curvature-symmetries-bianchi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-small-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:parallel-frame]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-matrix-inverse]]'
```

# lem:jacobi-small-time

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:jacobi-small-time
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
```

# lem:jacobi-matrix-inverse

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:jacobi-matrix-inverse
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-small-time]]'
```

# lem:jacobi-matrix-nonsingular

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:jacobi-matrix-nonsingular
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:parallel-frame]]'
```

# lem:radial-shape-riccati

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:radial-shape-riccati
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-matrix-inverse]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-small-time]]'
```

# lem:radial-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:radial-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-shape-riccati]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:operator-riccati-upper]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:trace-riccati-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:ratio-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-small-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
```

# lem:radial-volume-element

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:radial-volume-element
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-shape-riccati]]'
```

# lem:scalar-riccati-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:scalar-riccati-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
```

# lem:ratio-monotone

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:ratio-monotone
uses: []
```

# lem:scalar-sturm-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:scalar-sturm-comparison
uses: []
```

# lem:vector-sturm-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:vector-sturm-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:scalar-sturm-comparison]]'
```

# lem:jacobi-frame-reduction

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:jacobi-frame-reduction
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:parallel-frame]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-field-coordinates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:vector-sturm-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# lem:conjugate-sturm

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:conjugate-sturm
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-field-coordinates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:chart-curvature-coordinates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-frame-reduction]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:vector-sturm-comparison]]'
```

# lem:operator-riccati-lower

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:operator-riccati-lower
uses: []
```

# lem:operator-riccati-upper

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:operator-riccati-upper
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:scalar-riccati-comparison]]'
```

# lem:rauch-lower

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:rauch-lower
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:operator-riccati-lower]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:ratio-monotone]]'
```

# lem:jacobi-metric-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:jacobi-metric-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:parallel-frame]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-frame-reduction]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-operator-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-comparison]]'
```

# lem:frame-sectional-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:frame-sectional-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-metric-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-shape-riccati]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
```

# lem:exp-pullback-metric-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:exp-pullback-metric-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:frame-sectional-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-matrix-nonsingular]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:conjugate-sturm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# lem:exp-pullback-volume-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:exp-pullback-volume-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:volume-element-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-matrix-nonsingular]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-volume-element]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# thm:sectional-curvature-comparison

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#thm:sectional-curvature-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
```

# SCC

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#SCC
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:minimal-geodesic-no-conjugate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:jacobi-metric-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:operator-riccati-upper]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:ratio-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:cut-locus-properties]]'
```

# lem:local-diffeomorphism-bounded-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:local-diffeomorphism-bounded-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator-norm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
```

# localdiffeo

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#localdiffeo
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:conjugate-sturm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator-norm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:second-order-linear-ode]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
```

# lem:trace-riccati-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:trace-riccati-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:scalar-riccati-comparison]]'
```

# lem:volume-element-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:volume-element-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-volume-element]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:trace-riccati-comparison]]'
```

# lem:frame-volume-comparison

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:frame-volume-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-shape-riccati]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:radial-volume-element]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:trace-riccati-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:ratio-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
```

# thm:ricci-curvature-comparison

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#thm:ricci-curvature-comparison
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
```

# riccurvcomp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#riccurvcomp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:minimal-geodesic-no-conjugate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:volume-element-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
```

# lem:localized-cut-locus

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:localized-cut-locus
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:conjugate-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:minimal-geodesic-no-conjugate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:normal-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:minimizing-geodesic-exists]]'
```

# lem:integral-ratio-monotone

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:integral-ratio-monotone
uses: []
```

# lem:integral-ratio-normalized

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:integral-ratio-normalized
uses: []
```

# lem:frame-bishop-gromov

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:frame-bishop-gromov
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:frame-volume-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:integral-ratio-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:integral-ratio-normalized]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
```

# def:chart-volume-density

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:chart-volume-density
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# lem:volume-density-change

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:volume-density-change
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:chart-volume-density]]'
```

# lem:riemannian-measure-well-defined

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:riemannian-measure-well-defined
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:chart-volume-density]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:volume-density-change]]'
```

# def:riemannian-measure

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:riemannian-measure
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:chart-volume-density]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:riemannian-measure-well-defined]]'
```

# lem:riemannian-measure-jacobian

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:riemannian-measure-jacobian
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-measure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:chart-volume-density]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:riemannian-measure-well-defined]]'
```

# def:riemannian-jacobian

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#def:riemannian-jacobian
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:chart-volume-density]]'
```

# lem:riemannian-measure-jacobian-global

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:riemannian-measure-jacobian-global
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-measure]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-jacobian]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:riemannian-measure-jacobian]]'
```

# lem:exponential-riemannian-jacobian

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:exponential-riemannian-jacobian
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-jacobian]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:volume-density-change]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:cut-time-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#prop:exponential-diffeomorphism-cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:riemannian-measure-jacobian-global]]'
```

# lem:polar-coordinates

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:polar-coordinates
uses: []
```

# lem:model-ball-volume

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:model-ball-volume
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:polar-coordinates]]'
```

# lem:bishop-gromov-ball

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:bishop-gromov-ball
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:polar-coordinates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:model-ball-volume]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sinh-comparison-function]]'
```

# thm:bishop-gromov

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#thm:bishop-gromov
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:ricci-curvature-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:bishop-gromov-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-measure]]'
```

# BishopGromov

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#BishopGromov
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:volume-element-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:localized-cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:model-polar-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:normal-ball]]'
```

# lem:metric-rescaling

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:metric-rescaling
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator-norm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:levi-civita-connection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# prop:injectivity-radius-volume

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#prop:injectivity-radius-volume
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator-norm]]'
```

# injvol

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#injvol
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:rauch-lower]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator-norm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
```

# lem:pullback-ball

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:pullback-ball
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:exponential-map]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:local-isometry]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-exponential]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:local-isometry-normal-balls]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:normal-ball]]'
```

# lem:pullback-unique-minimizers

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:pullback-unique-minimizers
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:pullback-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:rauch-lower]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:conjugate-sturm]]'
```

# twosided

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#twosided
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:pullback-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:rauch-lower]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:conjugate-sturm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:scalar-riccati-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:localized-cut-locus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
```

# lem:loop-multiples-distinct

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#lem:loop-multiples-distinct
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:pullback-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:pullback-unique-minimizers]]'
```

# deckisometry

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#deckisometry
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:pullback-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:pullback-unique-minimizers]]'
```

# thm:volume-injectivity-radius

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#thm:volume-injectivity-radius
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator-norm]]'
```

# volinj

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#volinj
uses: []
```

# volinjcount

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries.tex#volinjcount
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator-norm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:hopf-rinow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:conjugate-sturm]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:klingenberg-loop]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:pullback-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:pullback-unique-minimizers]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:loop-multiples-distinct]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:volume-element-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:geodesic-polar-form]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:bishop-gromov]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:ricci-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:metric-rescaling]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:exponential-differential-jacobi]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:model-polar-isometry]]'
```
