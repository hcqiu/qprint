# chap:standard-solution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#chap:standard-solution
uses: []
```

# stdsolnsect

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#stdsolnsect
uses: []
```

# def:standard-initial-metric

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#def:standard-initial-metric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:sectional-curvature]]'
```

# defn:stinmetr

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#defn:stinmetr
uses: []
```

# lem:existence-standard-initial-metric

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#lem:existence-standard-initial-metric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-initial-metric]]'
```

# stdinit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#stdinit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-initial-metric]]'
```

# lem:standard-initial-metric-asymptotic-bounds

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#lem:standard-initial-metric-asymptotic-bounds
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#lem:existence-standard-initial-metric]]'
```

# A_0

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#A_0
uses: []
```

# def:standard-ricci-flow

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#def:standard-ricci-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-initial-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# thm:standard-solution-existence-uniqueness

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#thm:standard-solution-existence-uniqueness
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# stdsoln

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#stdsoln
uses: []
```

# lem:standard-flow-complete-positive-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#lem:standard-flow-complete-positive-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
```

# third

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#third
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#prop:forward-difference-maximum]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#lem:curvature-evolution-frame]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#nullspace]]'
```

# prop:standard-flow-asymptotic-cylinder

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#prop:standard-flow-asymptotic-cylinder
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#ex:shrinking-round-cylinder]]'
```

# item5

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#item5
uses: []
```

# cor:standard-flow-time-bound-one

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cor:standard-flow-time-bound-one
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# 1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# eq1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq1
uses: []
```

# eq.3

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq.3
uses: []
```

# lem:v-tensor-evolution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#lem:v-tensor-evolution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
```

# 12.9

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#12.9
uses: []
```

# eq.4

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq.4
uses: []
```

# eqn1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eqn1
uses: []
```

# rem:covariant-derivative-one-forms

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rem:covariant-derivative-one-forms
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
```

# claim:commuting-covariant-derivatives

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#claim:commuting-covariant-derivatives
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemann-curvature-tensor]]'
```

# eq.5

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq.5
uses: []
```

# eq.6

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq.6
uses: []
```

# eq.7

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq.7
uses: []
```

# cor:standard-solution-rotationally-symmetric

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cor:standard-solution-rotationally-symmetric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
```

# prop:standard-flow-kappa-noncollapsed

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#prop:standard-flow-kappa-noncollapsed
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
```

# stdkappa

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#stdkappa
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#prop:forward-difference-maximum]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#n/2]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch08_NonCollapsed#THM]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# claim:standard-flow-curvature-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#claim:standard-flow-curvature-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# 12.4

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#12.4
uses: []
```

# eq2.1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq2.1
uses: []
```

# eq2.2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq2.2
uses: []
```

# RDfloweqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#RDfloweqn
uses: []
```

# eqRcDeTurck

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eqRcDeTurck
uses: []
```

# lem:harmonic-map-flow-ricci-deturck

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#lem:harmonic-map-flow-ricci-deturck
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
```

# 12.7

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#12.7
uses: []
```

# cor:ricci-deturck-uniqueness-implies-ricci-uniqueness

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cor:ricci-deturck-uniqueness-implies-ricci-uniqueness
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#lem:harmonic-map-flow-ricci-deturck]]'
```

# dtuniqtouniq

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#dtuniqtouniq
uses: []
```

# eq2.4

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eq2.4
uses: []
```

# claim:radial-coordinate-properties

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#claim:radial-coordinate-properties
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
```

# cl12.20

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cl12.20
uses: []
```

# ansatz

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#ansatz
uses: []
```

# lem:even-odd-radial-functions

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#lem:even-odd-radial-functions
uses: []
```

# cor:r-squared-smooth-function

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cor:r-squared-smooth-function
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#claim:radial-coordinate-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#lem:even-odd-radial-functions]]'
```

# rcor

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rcor
uses: []
```

# Bdefn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#Bdefn
uses: []
```

# claim:f-odd-smooth-function

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#claim:f-odd-smooth-function
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#cor:r-squared-smooth-function]]'
```

# cor:f-factorization-rh

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cor:f-factorization-rh
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#claim:f-odd-smooth-function]]'
```

# eqrothar

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eqrothar
uses: []
```

# newform

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#newform
uses: []
```

# defofG

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#defofG
uses: []
```

# betterharMapeq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#betterharMapeq
uses: []
```

# rem:choice-of-dimension-n-plus-2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rem:choice-of-dimension-n-plus-2
uses: []
```

# claim:harmonic-map-flow-asymptotics

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#claim:harmonic-map-flow-asymptotics
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# asympt

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#asympt
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# prop:harmonic-map-flow-short-time-existence

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#prop:harmonic-map-flow-short-time-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
```

# rhoIntg

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rhoIntg
uses: []
```

# rhodiffeq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rhodiffeq
uses: []
```

# rho_i est

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rho_i
  est
uses: []
```

# rhoiminus

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rhoiminus
uses: []
```

# Flip

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#Flip
uses: []
```

# rhoInfIntg

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rhoInfIntg
uses: []
```

# rhoHolder

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rhoHolder
uses: []
```

# harmsec

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#harmsec
uses: []
```

# rho_iDcay

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rho_iDcay
uses: []
```

# rhodecay

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rhodecay
uses: []
```

# prop:harmonic-map-flow-existence-decay

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#prop:harmonic-map-flow-existence-decay
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:harmonic-map-flow-short-time-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#claim:harmonic-map-flow-asymptotics]]'
```

# harmapflow

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#harmapflow
uses: []
```

# prop:ricci-deturck-uniqueness-noncompact

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#prop:ricci-deturck-uniqueness-noncompact
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-ricci-flow]]'
```

# RDuniq

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#RDuniq
uses: []
```

# eqestforunique

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#eqestforunique
uses: []
```

# cor:standard-solution-deturck-agreement

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cor:standard-solution-deturck-agreement
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:harmonic-map-flow-existence-decay]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:ricci-deturck-uniqueness-noncompact]]'
```

# duniq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#duniq
uses: []
```

# thm:standard-solution-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#thm:standard-solution-canonical-neighborhoods
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-existence-uniqueness]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-kappa-noncollapsed]]'
```

# R_0cannbhd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#R_0cannbhd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-kappa-noncollapsed]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#kaplimit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#smlmtflow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#limitcannbhd]]'
```

# claim:kappa-solution-volume-ratio-small

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#claim:kappa-solution-volume-ratio-small
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#asympvol]]'
```

# thm:standard-solution-time-interval-one

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#thm:standard-solution-time-interval-one
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-canonical-neighborhoods]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#cor:standard-flow-time-bound-one]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#shiw/deriv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#kaplimit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#asympvol]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:bishop-gromov]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#lem:distance-nonincreasing]]'
```

# prop:standard-solution-scalar-curvature-lower-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#prop:standard-solution-scalar-curvature-lower-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-canonical-neighborhoods]]'
```

# Restim

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#Restim
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-canonical-neighborhoods]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#lem:distance-nonincreasing]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#controlnbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#canonvary]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#narrows]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#omega]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#kaplimit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#asympvol]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:bishop-gromov]]'
```

# thm:standard-solution-trichotomy

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#thm:standard-solution-trichotomy
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-canonical-neighborhoods]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-solution-scalar-curvature-lower-bound]]'
```

# stdsolncannbhd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#stdsolncannbhd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-canonical-neighborhoods]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-solution-scalar-curvature-lower-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#prop:standard-flow-asymptotic-cylinder]]'
```

# rem:evolving-neck-rescaled-time

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rem:evolving-neck-rescaled-time
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:evolving-epsilon-neck]]'
```

# cor:standard-solution-cap-near-tip

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cor:standard-solution-cap-near-tip
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-trichotomy]]'
```

# stdsolncap

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#stdsolncap
uses: []
```

# rem:tip-and-a0-definitions

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#rem:tip-and-a0-definitions
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#lem:standard-initial-metric-asymptotic-bounds]]'
```

# cor:generalized-flow-limit-trichotomy

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#cor:generalized-flow-limit-trichotomy
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-trichotomy]]'
```

# stdsolnlimit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#stdsolnlimit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#thm:standard-solution-trichotomy]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#canonvary]]'
```

# lem:standard-initial-metric-distance-decreasing

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#lem:standard-initial-metric-distance-decreasing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#def:standard-initial-metric]]'
```

# decrease

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution.tex#decrease
uses: []
```
