# chap:ricci-flow-with-surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#chap:ricci-flow-with-surgery
uses: []
```

# sect:surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#sect:surgery
uses: []
```

# def:space-time-general

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:space-time-general
uses: []
```

# def:surgery-space-time

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:surgery-space-time
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:space-time-general]]'
```

# spacetime

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#spacetime
uses: []
```

# def:compatible-with-time-vector-field

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:compatible-with-time-vector-field
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:surgery-space-time]]'
```

# def:regular-singular-time-surgery

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:regular-singular-time-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:surgery-space-time]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:compatible-with-time-vector-field]]'
```

# lem:time-slice-smooth-manifold

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#lem:time-slice-smooth-manifold
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:surgery-space-time]]'
```

# def:horizontal-subbundle

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:horizontal-subbundle
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#lem:time-slice-smooth-manifold]]'
```

# def:horizontal-metric

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:horizontal-metric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:horizontal-subbundle]]'
```

# def:ricci-flow-with-surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:ricci-flow-with-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:horizontal-metric]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:surgery-space-time]]'
```

# GRFEq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#GRFEq
uses: []
```

# rem:one-sided-lie-derivative

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#rem:one-sided-lie-derivative
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:ricci-flow-with-surgery]]'
```

# ex:ordinary-flow-as-surgery-flow

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#ex:ordinary-flow-as-surgery-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:ricci-flow-with-surgery]]'
```

# lem:gluing-ricci-flows-with-surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#lem:gluing-ricci-flows-with-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:ricci-flow-with-surgery]]'
```

# gluingsoln

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#gluingsoln
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#prop:smooth-patching]]'
```

# prop:interior-generalized-ricci-flow

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#prop:interior-generalized-ricci-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:ricci-flow-with-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
```

# def:metric-ball-spacetime

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:metric-ball-spacetime
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:surgery-space-time]]'
```

# def:parabolic-neighborhood-surgery

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:parabolic-neighborhood-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:metric-ball-spacetime]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:compatible-with-time-vector-field]]'
```

# def:kappa-noncollapsed-surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:kappa-noncollapsed-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:parabolic-neighborhood-surgery]]'
```

# defnkappa

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#defnkappa
uses: []
```

# rem:epsilon-round-kappa-dependence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#rem:epsilon-round-kappa-dependence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:kappa-noncollapsed-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:epsilon-round-component]]'
```

# def:curvature-pinched-toward-positive-surgery

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:curvature-pinched-toward-positive-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:ricci-flow-with-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# def:strong-canonical-neighborhood-assumption

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery.tex#def:strong-canonical-neighborhood-assumption
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:evolving-epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:canonical-neighborhood]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:strong-epsilon-neck-canonical-neighborhood]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:compatible-with-time-vector-field]]'
```
