# chap:finite-time-extinction

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#chap:finite-time-extinction
uses: []
```

# energy

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#energy
uses: []
```

# thm:finite-time-extinction-main

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#thm:finite-time-extinction-main
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#MAIN]]'
```

# extinct

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#extinct
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:eventual-trivial-pi2]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:w3-forward-difference-quotient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#MAIN]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-quotient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#thm:finite-time-extinction-main]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#Tgood0good]]'
```

# def:path-of-components

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:path-of-components
uses: []
```

# lem:free-product-rank-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:free-product-rank-bound
uses: []
```

# grouptheory

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#grouptheory
uses: []
```

# def:homotopically-essential-family

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:homotopically-essential-family
uses: []
```

# lem:homotopically-essential-family-finite

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:homotopically-essential-family-finite
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:free-product-rank-bound]]'
```

# def:homotopically-essential-surgery

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:homotopically-essential-surgery
uses: []
```

# claim:invariant-s-monotone

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:invariant-s-monotone
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#surgerytoptype]]'
```

# prop:finitely-many-homotopically-essential-surgeries

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#prop:finitely-many-homotopically-essential-surgeries
uses: []
```

# homess

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#homess
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#surgerytoptype]]'
```

# lem:minimal-sphere-energy-gap

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:minimal-sphere-energy-gap
uses: []
```

# claim:minimal-sphere-area-variation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:minimal-sphere-area-variation
uses: []
```

# varareaform

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#varareaform
uses: []
```

# ha1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#ha1
uses: []
```

# ha2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#ha2
uses: []
```

# ha3

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#ha3
uses: []
```

# claim:sphere-area-growth-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:sphere-area-growth-bound
uses: []
```

# lem:w2-forward-difference-quotient

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:w2-forward-difference-quotient
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:minimal-sphere-energy-gap]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-quotient]]'
```

# W_2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#W_2
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:minimal-sphere-area-variation]]'
```

# prop:eventual-trivial-pi2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#prop:eventual-trivial-pi2
uses: []
```

# pi2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#pi2
uses: []
```

# cor:sphere-theorem-no-rp2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:sphere-theorem-no-rp2
uses: []
```

# spherethm

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#spherethm
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:eventual-trivial-pi2]]'
```

# rem:pi2-disappearing-components

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#rem:pi2-disappearing-components
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#thm:finite-time-extinction-main]]'
```

# claim:loop-space-pi2-pi3-iso

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:loop-space-pi2-pi3-iso
uses: []
```

# def:w-xi-spanning-disk-functional

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:w-xi-spanning-disk-functional
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:eventual-trivial-pi2]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:w2-forward-difference-quotient]]'
```

# Wdefn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#Wdefn
uses: []
```

# claim:w-xi-continuity-nonsurgery

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:w-xi-continuity-nonsurgery
uses: []
```

# claim:w-xi-surgery-semicontinuity

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:w-xi-surgery-semicontinuity
uses: []
```

# def:w-a-t-ode-solution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:w-a-t-ode-solution
uses: []
```

# wdiffeqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#wdiffeqn
uses: []
```

# def:a-function-integral

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:a-function-integral
uses: []
```

# claim:w-a-t-explicit-formula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:w-a-t-explicit-formula
uses: []
```

# vclaim

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#vclaim
uses: []
```

# lem:short-loops-trivial-pi3

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:short-loops-trivial-pi3
uses: []
```

# shortpi2triv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#shortpi2triv
uses: []
```

# cor:short-loop-bounds-small-disk

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:short-loop-bounds-small-disk
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:short-loops-trivial-pi3]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:w-a-t-explicit-formula]]'
```

# shlnsharea

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#shlnsharea
uses: []
```

# prop:w3-forward-difference-quotient

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#prop:w3-forward-difference-quotient
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:eventual-trivial-pi2]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#def:w-xi-spanning-disk-functional]]'
```

# W_3fordiff

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#W_3fordiff
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:eventual-trivial-pi2]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:w3-forward-difference-quotient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#MAIN]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-quotient]]'
```

# claim:free-product-implies-pi2-nonzero

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:free-product-implies-pi2-nonzero
uses: []
```

# claim:x-t1-nontrivial-pi3

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:x-t1-nontrivial-pi3
uses: []
```

# sect:csf

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#sect:csf
uses: []
```

# claim:curve-shrinking-short-time-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:curve-shrinking-short-time-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:curve-deformation-existence]]'
```

# curvshrexist

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#curvshrexist
uses: []
```

# lem:embedded-curve-shrinking-area-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:embedded-curve-shrinking-area-bound
uses: []
```

# embcase

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#embcase
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:minimal-sphere-area-variation]]'
```

# cor:embedded-curve-shrinking-area-comparison

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:embedded-curve-shrinking-area-comparison
uses: []
```

# claim:curve-shrinking-approximation-suffices

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:curve-shrinking-approximation-suffices
uses: []
```

# lem:immersed-curve-shrinking-area-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:immersed-curve-shrinking-area-bound
uses: []
```

# nonembeasycase

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#nonembeasycase
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:embedded-curve-shrinking-area-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-quotient]]'
```

# not:curve-shrinking-spacetime

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#not:curve-shrinking-spacetime
uses: []
```

# spacetimehat

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#spacetimehat
uses: []
```

# lem:spacetime-christoffel

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:spacetime-christoffel
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#not:curve-shrinking-spacetime]]'
```

# hatchristoffel

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#hatchristoffel
uses: []
```

# hatEq1

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#hatEq1
uses: []
```

# hatEq2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#hatEq2
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#not:curve-shrinking-spacetime]]'
```

# lem:curve-shrinking-first-variation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:curve-shrinking-first-variation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#not:curve-shrinking-spacetime]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:spacetime-christoffel]]'
```

# 1stcurvshr

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#1stcurvshr
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:spacetime-christoffel]]'
```

# lem:curve-shrinking-curvature-evolution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:curve-shrinking-curvature-evolution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#not:curve-shrinking-spacetime]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:spacetime-christoffel]]'
```

# 2ndcurvshr

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#2ndcurvshr
uses: []
```

# hatEq3

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#hatEq3
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-first-variation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:spacetime-christoffel]]'
```

# rem:curve-shrinking-evolution-erratum

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#rem:curve-shrinking-evolution-erratum
uses: []
```

# cor:curve-shrinking-curvature-inequality-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:curve-shrinking-curvature-inequality-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-curvature-evolution]]'
```

# *4'

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#*4'
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-curvature-evolution]]'
```

# claim:curve-shrinking-curvature-inequality

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:curve-shrinking-curvature-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:curve-shrinking-curvature-inequality-bound]]'
```

# 3rdcurvshr

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#3rdcurvshr
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:curve-shrinking-curvature-inequality-bound]]'
```

# lem:curve-shrinking-length-curvature-growth

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:curve-shrinking-length-curvature-growth
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-curvature-inequality]]'
```

# 1835

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#1835
uses: []
```

# Lformula

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#Lformula
uses: []
```

# dLdteqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#dLdteqn
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-first-variation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-curvature-inequality]]'
```

# cor:curve-shrinking-length-curvature-exponential-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:curve-shrinking-length-curvature-exponential-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-length-curvature-growth]]'
```

# lncurvgrowth

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lncurvgrowth
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-length-curvature-growth]]'
```

# rem:total-curvature-needs-initial-length

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#rem:total-curvature-needs-initial-length
uses: []
```

# claim:ramp-function-evolution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:ramp-function-evolution
uses: []
```

# rampcomp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#rampcomp
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-first-variation]]'
```

# def:ramp-curve

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:ramp-curve
uses: []
```

# cor:ramp-preserved-under-flow

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:ramp-preserved-under-flow
uses: []
```

# ubd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#ubd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:ramp-function-evolution]]'
```

# lem:curve-shrinking-exists-for-ramps

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:curve-shrinking-exists-for-ramps
uses: []
```

# csforramps

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#csforramps
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-short-time-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-curvature-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:ramp-function-evolution]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:ramp-preserved-under-flow]]'
```

# lem:minimal-annulus-area-growth

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:minimal-annulus-area-growth
uses: []
```

# mugrowth

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#mugrowth
uses: []
```

# cor:minimal-annulus-exponential-growth

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:minimal-annulus-exponential-growth
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:curve-deformation-existence]]'
```

# def:n-polygonal-approximation

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:n-polygonal-approximation
uses: []
```

# claim:polygonal-approximation-properties

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:polygonal-approximation-properties
uses: []
```

# onec

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#onec
uses: []
```

# claim:polygonal-approximation-uniform

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:polygonal-approximation-uniform
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:polygonal-approximation-properties]]'
```

# uniformc

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#uniformc
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:polygonal-approximation-properties]]'
```

# cor:polygonal-approximation-of-family

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:polygonal-approximation-of-family
uses: []
```

# Gammaapprox

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#Gammaapprox
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:polygonal-approximation-uniform]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:polygonal-approximation-of-family]]'
```

# claim:smoothed-approximation-ramp-bounds

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:smoothed-approximation-ramp-bounds
uses: []
```

# lem:good-approximation-family

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:good-approximation-family
uses: []
```

# goodapprox

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#goodapprox
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:polygonal-approximation-of-family]]'
```

# claim:area-forward-difference-linear-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:area-forward-difference-linear-bound
uses: []
```

# areachange

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#areachange
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-length-curvature-growth]]'
```

# C5eqn

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#C5eqn
uses: []
```

# lem:curve-shrinking-shi-estimate

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:curve-shrinking-shi-estimate
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:curve-deformation-existence]]'
```

# CSSHI

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#CSSHI
uses: []
```

# rem:shi-constants-depend-on-initial-data

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#rem:shi-constants-depend-on-initial-data
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-shi-estimate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:curve-deformation-existence]]'
```

# claim:piecewise-domination-estimate

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:piecewise-domination-estimate
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:area-forward-difference-linear-bound]]'
```

# C1C4delta

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#C1C4delta
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:w-a-t-explicit-formula]]'
```

# claim:approximate-piecewise-domination-estimate

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:approximate-piecewise-domination-estimate
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:piecewise-domination-estimate]]'
```

# deltaprime

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#deltaprime
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:piecewise-domination-estimate]]'
```

# claim:curve-shrinking-flow-limit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:curve-shrinking-flow-limit
uses: []
```

# limitcs

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#limitcs
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-short-time-existence]]'
```

# rem:short-loop-length-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#rem:short-loop-length-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:immersed-curve-shrinking-area-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-flow-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:area-forward-difference-linear-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:piecewise-domination-estimate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:approximate-piecewise-domination-estimate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:curve-shrinking-length-curvature-exponential-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-deformation-single-point-estimate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:curve-deformation-existence]]'
```

# xicomp

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#xicomp
uses: []
```

# lem:curve-deformation-single-point-estimate

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:curve-deformation-single-point-estimate
uses: []
```

# xistronger

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#xistronger
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:area-forward-difference-linear-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:w-a-t-explicit-formula]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:curve-shrinking-length-curvature-exponential-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:piecewise-domination-estimate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-short-time-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:immersed-curve-shrinking-area-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-flow-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#rem:short-loop-length-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:approximate-piecewise-domination-estimate]]'
```

# lem:mu-net-area-comparison

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:mu-net-area-comparison
uses: []
```

# muarea

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#muarea
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:minimal-annulus-area-growth]]'
```

# lem:ramp-length-comparison-small-annulus

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:ramp-length-comparison-small-annulus
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:curve-deformation-existence]]'
```

# BARMU

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#BARMU
uses: []
```

# claim:mu-net-length-comparison

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:mu-net-length-comparison
uses: []
```

# mulength

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#mulength
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:curve-shrinking-length-curvature-exponential-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:ramp-length-comparison-small-annulus]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:minimal-annulus-area-growth]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:mu-net-area-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-deformation-single-point-estimate]]'
```

# prop:curve-deformation-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#prop:curve-deformation-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:w3-forward-difference-quotient]]'
```

# XI

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#XI
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:mu-net-area-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-deformation-single-point-estimate]]'
```

# 18.5

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#18.5
uses: []
```

# claim:branch-point-metric-deformation

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:branch-point-metric-deformation
uses: []
```

# claim:perturbed-metric-curvature-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:perturbed-metric-curvature-bound
uses: []
```

# rem:high-curvature-set-length-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#rem:high-curvature-set-length-bound
uses: []
```

# Ylengthrem

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#Ylengthrem
uses: []
```

# claim:exponential-map-local-diffeomorphism

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:exponential-map-local-diffeomorphism
uses: []
```

# expcomp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#expcomp
uses: []
```

# claim:focusing-triangle-angle-curvature-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:focusing-triangle-angle-curvature-bound
uses: []
```

# theta/Kbd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#theta/Kbd
uses: []
```

# claim:focusing-triangle-vertex-geodesic

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:focusing-triangle-vertex-geodesic
uses: []
```

# avgeo

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#avgeo
uses: []
```

# claim:focusing-triangle-vertex-geodesic-unique

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:focusing-triangle-vertex-geodesic-unique
uses: []
```

# rem:focusing-triangle-vertex-geodesic-embedded

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#rem:focusing-triangle-vertex-geodesic-embedded
uses: []
```

# claim:arc-length-derivative-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:arc-length-derivative-bound
uses: []
```

# lem:focusing-triangle-base-length-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:focusing-triangle-base-length-bound
uses: []
```

# laest

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#laest
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:focusing-triangle-angle-curvature-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:focusing-triangle-vertex-geodesic]]'
```

# cor:focusing-triangle-base-bound-collection

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:focusing-triangle-base-bound-collection
uses: []
```

# muepsbd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#muepsbd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:focusing-triangle-base-length-bound]]'
```

# lem:geodesic-no-trivial-embedded-loop

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:geodesic-no-trivial-embedded-loop
uses: []
```

# noloops

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#noloops
uses: []
```

# claim:local-embedding-of-geodesic-family

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:local-embedding-of-geodesic-family
uses: []
```

# locemb

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#locemb
uses: []
```

# claim:focusing-triangle-limit-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:focusing-triangle-limit-existence
uses: []
```

# limittri

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#limittri
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:local-embedding-of-geodesic-family]]'
```

# claim:maximal-focusing-triangles-disjoint

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:maximal-focusing-triangles-disjoint
uses: []
```

# def:maximal-focusing-triangle-set

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#def:maximal-focusing-triangle-set
uses: []
```

# claim:remaining-set-length-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:remaining-set-length-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:focusing-triangle-base-bound-collection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#rem:high-curvature-set-length-bound]]'
```

# claim:exponential-map-embedding-on-remainder

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:exponential-map-embedding-on-remainder
uses: []
```

# lem:no-geodesic-spans-c0-to-c0

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:no-geodesic-spans-c0-to-c0
uses: []
```

# Dxacross

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#Dxacross
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:geodesic-no-trivial-embedded-loop]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:local-embedding-of-geodesic-family]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:focusing-triangle-limit-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:focusing-triangle-base-bound-collection]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#rem:high-curvature-set-length-bound]]'
```

# lem:geodesic-no-embedded-loop-general

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:geodesic-no-embedded-loop-general
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:no-geodesic-spans-c0-to-c0]]'
```

# lem:far-apart-geodesics-disjoint

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:far-apart-geodesics-disjoint
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:no-geodesic-spans-c0-to-c0]]'
```

# cor:focusing-triangle-from-short-arc

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:focusing-triangle-from-short-arc
uses: []
```

# noholes

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#noholes
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:no-geodesic-spans-c0-to-c0]]'
```

# cor:geodesic-family-intersection-summary

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:geodesic-family-intersection-summary
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#prop:annulus-boundary-length-estimate]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:focusing-triangle-from-short-arc]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:no-geodesic-spans-c0-to-c0]]'
```

# focussummary

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#focussummary
uses: []
```

# claim:focusing-triangle-total-base-length-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:focusing-triangle-total-base-length-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:focusing-triangle-base-bound-collection]]'
```

# prop:annulus-boundary-length-estimate

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#prop:annulus-boundary-length-estimate
uses: []
```

# annlengthest

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#annlengthest
uses: []
```

# 18.6

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#18.6
uses: []
```

# claim:curve-shrinking-length-curvature-uniform-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:curve-shrinking-length-curvature-uniform-bound
uses: []
```

# C0claim

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#C0claim
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:curve-shrinking-length-curvature-exponential-bound]]'
```

# claim:cutoff-function-time-derivative-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:cutoff-function-time-derivative-bound
uses: []
```

# 1887

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#1887
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-first-variation]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-length-curvature-uniform-bound]]'
```

# claim:cutoff-weighted-curvature-integral-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:cutoff-weighted-curvature-integral-bound
uses: []
```

# claim1885

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim1885
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:cutoff-function-time-derivative-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-curvature-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#lem:curve-shrinking-length-curvature-growth]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#claim:curve-shrinking-length-curvature-uniform-bound]]'
```

# cor:cutoff-weighted-curvature-integral-sqrt-bound

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:cutoff-weighted-curvature-integral-sqrt-bound
uses: []
```

# cor:curvature-integral-uniform-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#cor:curvature-integral-uniform-bound
uses: []
```

# D_4cor

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#D_4cor
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction#cor:curve-shrinking-length-curvature-exponential-bound]]'
```

# 1814

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#1814
uses: []
```

# claim:graph-flow-velocity-comparison

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:graph-flow-velocity-comparison
uses: []
```

# curvflowcompare

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#curvflowcompare
uses: []
```

# claim:graph-flow-angle-and-norm-bounds

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:graph-flow-angle-and-norm-bounds
uses: []
```

# 1891

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#1891
uses: []
```

# claim:graph-flow-connection-term-bounds

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:graph-flow-connection-term-bounds
uses: []
```

# psiclaim

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#psiclaim
uses: []
```

# Z_t

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#Z_t
uses: []
```

# Vest

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#Vest
uses: []
```

# claim:graph-flow-mixed-derivative-bound

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#claim:graph-flow-mixed-derivative-bound
uses: []
```

# lem:curve-shrinking-shi-estimate-first-inequality

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#lem:curve-shrinking-shi-estimate-first-inequality
uses: []
```

# csshi1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch18_FiniteTimeExtinction.tex#csshi1
uses: []
```
