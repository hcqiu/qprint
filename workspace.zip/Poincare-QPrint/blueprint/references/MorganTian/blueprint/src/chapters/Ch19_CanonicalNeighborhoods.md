# chap:canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#chap:canonical-neighborhoods
uses: []
```

# sect:canonnbhd

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#sect:canonnbhd
uses: []
```

# lem:neck-shortening-curve

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:neck-shortening-curve
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# curveshort

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#curveshort
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# lem:epsilon-neck-curvature-pinching

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:epsilon-neck-curvature-pinching
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# neckcurv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#neckcurv
uses: []
```

# cor:embedded-sphere-isotopic-to-neck-fiber

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#cor:embedded-sphere-isotopic-to-neck-fiber
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# s2isotopic

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#s2isotopic
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:epsilon-neck-curvature-pinching]]'
```

# lem:neck-geodesic-directions

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:neck-geodesic-directions
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# directions

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#directions
uses: []
```

# cor:neck-distance-estimates

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#cor:neck-distance-estimates
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# neckgeo

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#neckgeo
uses: []
```

# cor:shortest-geodesic-crosses-neck-once

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#cor:shortest-geodesic-crosses-neck-once
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# compint

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#compint
uses: []
```

# lem:geodesic-crosses-neck-once-general

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:geodesic-crosses-neck-once-general
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# genint

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#genint
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:shortest-geodesic-crosses-neck-once]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:neck-distance-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:neck-geodesic-directions]]'
```

# cor:minimal-geodesic-through-core

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#cor:minimal-geodesic-through-core
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
```

# coreint

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#coreint
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:neck-distance-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:shortest-geodesic-crosses-neck-once]]'
```

# lem:neck-distance-comparison-external-point

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:neck-distance-comparison-external-point
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# neckdistcomp

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#neckdistcomp
uses: []
```

# lem:metric-sphere-meets-neck-topologically

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:metric-sphere-meets-neck-topologically
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# topiso

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#topiso
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:neck-distance-comparison-external-point]]'
```

# prop:overlapping-necks-properties

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#prop:overlapping-necks-properties
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# S2intersection

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#S2intersection
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:embedded-sphere-isotopic-to-neck-fiber]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:epsilon-neck-curvature-pinching]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:neck-geodesic-directions]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:neck-distance-estimates]]'
```

# def:chain-of-epsilon-necks

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#def:chain-of-epsilon-necks
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# lem:chain-union-diffeomorphic-cylinder

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:chain-union-diffeomorphic-cylinder
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#def:chain-of-epsilon-necks]]'
```

# S2timesI

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#S2timesI
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:overlapping-necks-properties]]'
```

# cor:chain-frontier

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#cor:chain-frontier
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#def:chain-of-epsilon-necks]]'
```

# chainfrontier

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#chainfrontier
uses: []
```

# lem:infinite-chain-frontier

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:infinite-chain-frontier
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#def:chain-of-epsilon-necks]]'
```

# inffrontier

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#inffrontier
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:neck-distance-estimates]]'
```

# lem:chain-fibration-by-spheres

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:chain-fibration-by-spheres
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#def:chain-of-epsilon-necks]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:epsilon-neck-curvature-pinching]]'
```

# distineq

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#distineq
uses: []
```

# lem:two-necks-form-balanced-chain

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:two-necks-form-balanced-chain
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#def:chain-of-epsilon-necks]]'
```

# firstchain

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#firstchain
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:neck-distance-estimates]]'
```

# lem:extend-balanced-chain

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:extend-balanced-chain
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#def:chain-of-epsilon-necks]]'
```

# addaneck

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#addaneck
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:two-necks-form-balanced-chain]]'
```

# prop:balanced-chain-covers-connected-set

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#prop:balanced-chain-covers-connected-set
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#def:chain-of-epsilon-necks]]'
```

# epschains

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#epschains
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:extend-balanced-chain]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:infinite-chain-frontier]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:chain-union-diffeomorphic-cylinder]]'
```

# lem:manifold-covered-by-necks-classification

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#lem:manifold-covered-by-necks-classification
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# S2times01

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#S2times01
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:balanced-chain-covers-connected-set]]'
```

# prop:connected-set-in-caps-and-necks

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#prop:connected-set-in-caps-and-necks
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
```

# Xcontainedin

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#Xcontainedin
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:balanced-chain-covers-connected-set]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:manifold-covered-by-necks-classification]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:overlapping-necks-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:neck-distance-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:epsilon-neck-curvature-pinching]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:infinite-chain-frontier]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
```

# claim:no-infinite-chain-of-caps

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#claim:no-infinite-chain-of-caps
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#lem:epsilon-neck-curvature-pinching]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:neck-distance-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:overlapping-necks-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
```

# claim:isotopic-sphere-gives-component

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#claim:isotopic-sphere-gives-component
uses: []
```

# sinside

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#sinside
uses: []
```

# claim:cap-union-is-component

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#claim:cap-union-is-component
uses: []
```

# cccomponent

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#cccomponent
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#claim:isotopic-sphere-gives-component]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:overlapping-necks-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#cor:neck-distance-estimates]]'
```

# prop:classification-covered-by-necks-caps

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#prop:classification-covered-by-necks-caps
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:connected-set-in-caps-and-necks]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#def:c-epsilon-cap]]'
```

# epstopology

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods.tex#epstopology
uses: []
```
