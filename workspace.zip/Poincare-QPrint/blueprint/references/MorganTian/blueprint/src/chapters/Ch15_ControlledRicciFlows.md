# chap:controlled-ricci-flows

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#chap:controlled-ricci-flows
uses: []
```

# claim:normalized-initial-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#claim:normalized-initial-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:local-existence-uniqueness]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#prop:smooth-patching]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-derivative-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#prop:normalized-flow-short-time-bounds]]'
```

# newkappa0r0t0

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#newkappa0r0t0
uses: []
```

# prop:neck-gluing

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#prop:neck-gluing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:strong-canonical-neighborhood-assumption]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:evolving-epsilon-neck]]'
```

# neckglue

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#neckglue
uses: []
```

# firstassumpt

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#firstassumpt
uses: []
```

# prop:surgery-topological-type

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#prop:surgery-topological-type
uses: []
```

# surgerytoptype

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#surgerytoptype
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:classification-covered-by-necks-caps]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#prop:balanced-chain-covers-connected-set]]'
```

# cor:geometrization-inherited-across-surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#cor:geometrization-inherited-across-surgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#prop:surgery-topological-type]]'
```

# Tgood0good

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#Tgood0good
uses: []
```

# def:surgery-scale-function

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#def:surgery-scale-function
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:deep-delta-necks-in-horn]]'
```

# hrestricted

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#hrestricted
uses: []
```

# def:time-steps-T-i

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#def:time-steps-T-i
uses: []
```

# def:surgery-parameter-sequences

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#def:surgery-parameter-sequences
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#prop:neck-gluing]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#claim:normalized-initial-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#lem:standard-initial-metric-asymptotic-bounds]]'
```

# surgeryparams

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#surgeryparams
uses: []
```

# sect:process

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#sect:process
uses: []
```

# def:surgery-operation

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#def:surgery-operation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#lem:gluing-ricci-flows-with-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:singular-time-limit-properties]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#thm:deep-delta-necks-in-horn]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#lem:finitely-many-horns-meeting-omega-rho]]'
```

# thm:main-existence-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#thm:main-existence-ricci-flow-surgery
uses:
- '[[#def:curvature-pinched-toward-positive]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#def:strong-canonical-neighborhood-assumption]]'
```

# MAIN

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#MAIN
uses: []
```

# cor:ricci-flow-surgery-exists-all-time

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#cor:ricci-flow-surgery-exists-all-time
uses: []
```

# RFSexists

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#RFSexists
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#thm:main-existence-ricci-flow-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#prop:normalized-flow-short-time-bounds]]'
```

# lem:surgery-preserves-assumptions-pinching

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#lem:surgery-preserves-assumptions-pinching
uses: []
```

# 14.26

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#14.26
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch14_RicciFlowWithSurgery#lem:gluing-ricci-flows-with-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:pinching-persists-from-time-a]]'
```

# prop:surgery-distance-decreasing

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#prop:surgery-distance-decreasing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#def:surgery-parameter-sequences]]'
```

# surgerydist

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#surgerydist
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
```

# rem:nonseparating-surgery-sphere

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows.tex#rem:nonseparating-surgery-sphere
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#prop:surgery-distance-decreasing]]'
```
