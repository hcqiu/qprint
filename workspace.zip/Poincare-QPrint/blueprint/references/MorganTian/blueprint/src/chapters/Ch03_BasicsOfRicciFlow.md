# chap:flowbasics

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#chap:flowbasics
uses: []
```

# flowbasics

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#flowbasics
uses: []
```

# def:ricci-flow

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:ricci-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# Ricciflow

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#Ricciflow
uses: []
```

# def:space-time

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:space-time
uses: []
```

# defnRicci

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#defnRicci
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# ex:einstein-ricci-flow

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#ex:einstein-ricci-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:einstein-manifold]]'
```

# ex:fubini-study-metric

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#ex:fubini-study-metric
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:einstein-manifold]]'
```

# ex:shrinking-round-cylinder

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#ex:shrinking-round-cylinder
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# def:evolving-epsilon-neck

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:evolving-epsilon-neck
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#def:epsilon-neck]]'
```

# strongepsneck

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#strongepsneck
uses: []
```

# soliton

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#soliton
uses: []
```

# claim:soliton-generation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#claim:soliton-generation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# solitonclaim

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#solitonclaim
uses: []
```

# def:gradient-shrinking-soliton

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:gradient-shrinking-soliton
uses: []
```

# prop:gradient-shrinking-soliton-generation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#prop:gradient-shrinking-soliton-generation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:gradient-shrinking-soliton]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#lem:hessian-symmetric]]'
```

# GSSgeneration

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#GSSgeneration
uses: []
```

# GSS

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#GSS
uses: []
```

# def:gradient-shrinking-soliton-generator

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:gradient-shrinking-soliton-generator
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:gradient-shrinking-soliton]]'
```

# 3.3

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#3.3
uses: []
```

# thm:local-existence-uniqueness

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#thm:local-existence-uniqueness
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# compuniq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#compuniq
uses: []
```

# brokeneqn

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#brokeneqn
uses: []
```

# prop:smooth-patching

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#prop:smooth-patching
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# patch

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#patch
uses: []
```

# evolcurv

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#evolcurv
uses: []
```

# thm:curvature-evolution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#thm:curvature-evolution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# thmRmevol

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#thmRmevol
uses: []
```

# Rmevol

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#Rmevol
uses: []
```

# Ricevol

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#Ricevol
uses: []
```

# Revol

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#Revol
uses: []
```

# dvolevol

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#dvolevol
uses: []
```

# lem:distance-nonincreasing

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#lem:distance-nonincreasing
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# posdistdec

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#posdistdec
uses: []
```

# lem:metric-volume-distortion

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#lem:metric-volume-distortion
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:curvature-evolution]]'
```

# evolframe

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#evolframe
uses: []
```

# frameevol

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#frameevol
uses: []
```

# claim:orthonormal-frame-preservation

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#claim:orthonormal-frame-preservation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# ortho

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#ortho
uses: []
```

# cor:pullback-metric-constant

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#cor:pullback-metric-constant
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#claim:orthonormal-frame-preservation]]'
```

# framecoord

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#framecoord
uses: []
```

# lem:curvature-evolution-frame

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#lem:curvature-evolution-frame
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# M

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#M
uses: []
```

# Mdefn

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#Mdefn
uses: []
```

# prop:curvature-operator-evolution

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#prop:curvature-operator-evolution
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:curvature-operator]]'
```

# Mevol

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#Mevol
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#lem:curvature-evolution-frame]]'
```

# rem:bianchi-identity-operator-squares

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#rem:bianchi-identity-operator-squares
uses: []
```

# prop:distance-variation-lower-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#prop:distance-variation-lower-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# I.8.3

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#I.8.3
uses: []
```

# rem:forward-difference-quotient

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#rem:forward-difference-quotient
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# claim:geodesic-length-suffices

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#claim:geodesic-length-suffices
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# geosuff

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#geosuff
uses: []
```

# claim:minimal-geodesic-time-derivative

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#claim:minimal-geodesic-time-derivative
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:geodesic]]'
```

# 3.23

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#3.23
uses: []
```

# geoineq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#geoineq
uses: []
```

# eq2ndvar

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#eq2ndvar
uses: []
```

# 2ndvaria

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#2ndvaria
uses: []
```

# sformula

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#sformula
uses: []
```

# cor:distance-variation-complete

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#cor:distance-variation-complete
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# 2ndI.8.3

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#2ndI.8.3
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#prop:distance-variation-lower-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#claim:geodesic-length-suffices]]'
```

# cor:distance-integral-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#cor:distance-integral-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# corI.8.3

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#corI.8.3
uses: []
```

# liminf

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#liminf
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#cor:distance-variation-complete]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:forward-difference-quotient]]'
```

# thm:shi-first-derivative

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#thm:shi-first-derivative
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# firstshi

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#firstshi
uses: []
```

# thm:shi-derivative-estimates

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#thm:shi-derivative-estimates
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# shi

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#shi
uses: []
```

# thm:shi-with-initial-derivatives

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#thm:shi-with-initial-derivatives
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# shiw/deriv

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#shiw/deriv
uses: []
```

# strongineq

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#strongineq
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#prop:parabolic-cutoff-function]]'
```

# claim:function-evolution-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#claim:function-evolution-bound
uses: []
```

# Fm

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#Fm
uses: []
```

# prop:parabolic-cutoff-function

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#prop:parabolic-cutoff-function
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# etaprop

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#etaprop
uses: []
```

# rem:shi-derivative-variant

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#rem:shi-derivative-variant
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-with-initial-derivatives]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-first-derivative]]'
```

# cor:ricci-flow-curvature-bounds

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#cor:ricci-flow-curvature-bounds
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-with-initial-derivatives]]'
```

# Cinftybd

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#Cinftybd
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#prop:parabolic-cutoff-function]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# curderfor

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#curderfor
uses: []
```

# 1steqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#1steqn
uses: []
```

# 2ndeqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#2ndeqn
uses: []
```

# 3rdeqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#3rdeqn
uses: []
```

# 4theqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#4theqn
uses: []
```

# 5theqn

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#5theqn
uses: []
```

# def:generalized-spacetime

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:generalized-spacetime
uses: []
```

# def:time-slices-horizontal

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:time-slices-horizontal
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-spacetime]]'
```

# def:generalized-ricci-flow

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:generalized-ricci-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-spacetime]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:time-slices-horizontal]]'
```

# rem:generalized-ricci-flow-local

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#rem:generalized-ricci-flow-local
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
```

# def:compatible-embedding

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:compatible-embedding
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-spacetime]]'
```

# def:regular-singular-time

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:regular-singular-time
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:time-slices-horizontal]]'
```

# def:scaling-translation

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:scaling-translation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
```

# def:parabolic-neighborhoods

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow.tex#def:parabolic-neighborhoods
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-spacetime]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
```
