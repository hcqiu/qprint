# sectcannbhd

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#sectcannbhd
uses: []
```

# prop:canonical-neighborhood-extends

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#prop:canonical-neighborhood-extends
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:kappa-limit-noncollapsing]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#thm:main-existence-ricci-flow-surgery]]'
```

# extend

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#extend
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:kappa-limit-noncollapsing]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#kaplimit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#limitcannbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#sliceconv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#canonvary]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#narrows]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#controlnbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:long-L-length-near-surgery-cap]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#lem:surgery-cap-ball-bounds]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#defncanonnbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#defnepsround]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#Ccomponent]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#neckcurv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#A_0]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#Restim]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#stdsoln]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#bigell]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#neckglue]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#stdsolncannbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#def:overline-delta-0]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
```

# lem:limit-canonical-neighborhood-fails-at-surgery-scale

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#lem:limit-canonical-neighborhood-fails-at-surgery-scale
uses: []
```

# 16.2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#16.2
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:long-L-length-near-surgery-cap]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#lem:surgery-cap-ball-bounds]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#defncanonnbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#defnepsround]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#Ccomponent]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#canonvary]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch19_CanonicalNeighborhoods#neckcurv]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#A_0]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#Restim]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#stdsoln]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#bigell]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#neckglue]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#stdsolncannbhd]]'
```

# rem:limit-canonical-neighborhood-is-cap

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#rem:limit-canonical-neighborhood-is-cap
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof#lem:limit-canonical-neighborhood-fails-at-surgery-scale]]'
```

# claim:tilde-t-prime-bounded-by-theta1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#claim:tilde-t-prime-bounded-by-theta1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#def:overline-delta-0]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
```

# claim:w-ab-in-ball-image

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#claim:w-ab-in-ball-image
uses: []
```

# DQ

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#DQ
uses: []
```

# claim:limit-points-have-canonical-neighborhood

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#claim:limit-points-have-canonical-neighborhood
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch13_SurgeryDeltaNeck#thm:local-surgery]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#omegacanon]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#epslimit]]'
```

# lem:std-cap-canonical-neighborhood

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#lem:std-cap-canonical-neighborhood
uses: []
```

# lemstdcan

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#lemstdcan
uses: []
```

# hequat

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#hequat
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#A_0]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#stdsoln]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#posdistdec]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#stdsolncannbhd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch09_KappaAncientSolutions#canonvary]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#neckglue]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#def:overline-delta-0]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#Restim]]'
```

# claim:elapsed-time-bounded-by-theta1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#claim:elapsed-time-bounded-by-theta1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:surgery-cap-evolution-alternative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#def:overline-delta-0]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#Restim]]'
```

# claim:curvature-bound-along-backward-flow-lines

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#claim:curvature-bound-along-backward-flow-lines
uses: []
```

# D(A)delta(A)

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#D(A)delta(A)
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch16_ProofNonCollapsing#prop:kappa-limit-noncollapsing]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch10_BoundedCurvatureBoundedDistance#bcbd]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#controlnbhd]]'
```

# claim:parabolic-neighborhood-or-canonical-neighborhood

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#claim:parabolic-neighborhood-or-canonical-neighborhood
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof#claim:curvature-bound-along-backward-flow-lines]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof#lem:std-cap-canonical-neighborhood]]'
```

# claim:uniform-t-prime-independent-of-A

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#claim:uniform-t-prime-independent-of-A
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof#lem:std-cap-canonical-neighborhood]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch11_GeometricLimits#controlnbhd]]'
```

# sectcomplete

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#sectcomplete
uses: []
```

# lem:bounded-number-of-surgeries

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#lem:bounded-number-of-surgeries
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch15_ControlledRicciFlows#thm:main-existence-ricci-flow-surgery]]'
```

# bddsurgery

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch17_CompletionOfProof.tex#bddsurgery
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch12_StandardSolution#A_0]]'
```
