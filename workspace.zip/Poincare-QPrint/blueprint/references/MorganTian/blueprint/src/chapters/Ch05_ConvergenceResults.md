# chap:convergence-results

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#chap:convergence-results
uses: []
```

# def:delta-regular-point

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:delta-regular-point
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# deltareg

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#deltareg
uses: []
```

# lem:reg-delta-closed

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#lem:reg-delta-closed
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-regular-point]]'
```

# def:geometric-limit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:geometric-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-regular-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#def:riemannian-metric]]'
```

# smoothconv

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#smoothconv
uses: []
```

# rem:geometric-limit-incomplete-condition

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#rem:geometric-limit-incomplete-condition
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
```

# lem:geometric-limit-uniqueness

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#lem:geometric-limit-uniqueness
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-regular-point]]'
```

# thm:geometric-limit-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#thm:geometric-limit-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-regular-point]]'
```

# basicconv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#basicconv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:volume-injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-regular-point]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#lem:gaussian-coordinates-convergence]]'
```

# lem:gaussian-coordinates-convergence

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#lem:gaussian-coordinates-convergence
uses: []
```

# lem:partial-limit-complete-is-limit

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#lem:partial-limit-complete-is-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-regular-point]]'
```

# thm:manifold-convergence-complete-limit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#thm:manifold-convergence-complete-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#thm:geometric-limit-existence]]'
```

# mfdconv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#mfdconv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:bishop-gromov]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#thm:geometric-limit-existence]]'
```

# cor:manifold-convergence-volume-noncollapsed

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#cor:manifold-convergence-volume-noncollapsed
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#thm:manifold-convergence-complete-limit]]'
```

# 2ndmfdconv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#2ndmfdconv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:bishop-gromov]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch01_Preliminaries#thm:volume-injectivity-radius]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#thm:manifold-convergence-complete-limit]]'
```

# thm:ricci-flow-slice-convergence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#thm:ricci-flow-slice-convergence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:time-slices-horizontal]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
```

# sliceconv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#sliceconv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#thm:manifold-convergence-complete-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-derivative-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#cor:manifold-convergence-volume-noncollapsed]]'
```

# def:partial-geometric-limit-ricci-flow

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:partial-geometric-limit-ricci-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:time-slices-horizontal]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
```

# def:geometric-limit-ricci-flow

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:geometric-limit-ricci-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:partial-geometric-limit-ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
```

# prop:partial-flow-limit-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#prop:partial-flow-limit-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
```

# partialflowlimit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#partialflowlimit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-derivative-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
```

# thm:ricci-flow-geometric-limit-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#thm:ricci-flow-geometric-limit-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#thm:ricci-flow-slice-convergence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#prop:partial-flow-limit-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:compatible-embedding]]'
```

# flowlimit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#flowlimit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#thm:ricci-flow-slice-convergence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#prop:partial-flow-limit-existence]]'
```

# cor:ricci-flow-extension-bounded-curvature

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#cor:ricci-flow-extension-bounded-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-derivative-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#prop:smooth-patching]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
```

# def:delta-net

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:delta-net
uses: []
```

# epsnet

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#epsnet
uses: []
```

# lem:gromov-hausdorff-triangle-inequality

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#lem:gromov-hausdorff-triangle-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-net]]'
```

# def:gromov-hausdorff-convergence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:gromov-hausdorff-convergence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-net]]'
```

# GHconverge

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#GHconverge
uses: []
```

# ex:gromov-hausdorff-limit-point

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#ex:gromov-hausdorff-limit-point
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence]]'
```

# def:realization-sequence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:realization-sequence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence]]'
```

# seqconv

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#seqconv
uses: []
```

# lem:gromov-hausdorff-net-characterization

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#lem:gromov-hausdorff-net-characterization
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:delta-net]]'
```

# lem:gromov-hausdorff-limit-uniqueness-compact

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#lem:gromov-hausdorff-limit-uniqueness-compact
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#lem:gromov-hausdorff-triangle-inequality]]'
```

# def:gromov-hausdorff-convergence-unbounded

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:gromov-hausdorff-convergence-unbounded
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence]]'
```

# lem:gromov-hausdorff-limit-uniqueness-locally-compact

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#lem:gromov-hausdorff-limit-uniqueness-locally-compact
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence-unbounded]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#lem:gromov-hausdorff-limit-uniqueness-compact]]'
```

# ex:geometric-implies-gromov-hausdorff-convergence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#ex:geometric-implies-gromov-hausdorff-convergence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence-unbounded]]'
```

# def:length-space

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:length-space
uses: []
```

# thm:gromov-hausdorff-precompactness

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#thm:gromov-hausdorff-precompactness
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:length-space]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence-unbounded]]'
```

# GHcompact

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#GHcompact
uses: []
```

# def:space-of-directions-infinity

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:space-of-directions-infinity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:length-space]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:length-comparison]]'
```

# claim:space-of-directions-compact

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#claim:space-of-directions-compact
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:space-of-directions-infinity]]'
```

# prop:tits-cone-gromov-hausdorff-limit

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#prop:tits-cone-gromov-hausdorff-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:space-of-directions-infinity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#claim:space-of-directions-compact]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:gromov-hausdorff-convergence-unbounded]]'
```

# conelimit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#conelimit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:length-comparison]]'
```

# def:blow-up-limit

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#def:blow-up-limit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:generalized-ricci-flow]]'
```

# thm:blow-up-limit-nonnegative-curvature

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#thm:blow-up-limit-nonnegative-curvature
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:blow-up-limit]]'
```

# blowupposcurv

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#blowupposcurv
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:blow-up-limit]]'
```

# cor:blow-up-limit-nonnegative-curvature-pinched

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#cor:blow-up-limit-nonnegative-curvature-pinched
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#thm:blow-up-limit-nonnegative-curvature]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch04_MaximumPrinciple#thm:pinching-toward-positive-curvature]]'
```

# thm:splitting-at-infinity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#thm:splitting-at-infinity
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults#def:geometric-limit]]'
```

# topsplit

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch05_ConvergenceResults.tex#topsplit
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#thm:length-comparison]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#lem:minimizing-line-implies-product]]'
```
