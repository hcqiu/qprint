# chap:complete-ricci-flows

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#chap:complete-ricci-flows
uses: []
```

# newcomp2

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#newcomp2
uses: []
```

# def:complete-bounded-curvature-flow

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#def:complete-bounded-curvature-flow
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#def:ricci-flow]]'
```

# compmetric

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#compmetric
uses: []
```

# lem:l-geodesic-existence

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#lem:l-geodesic-existence
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:complete-bounded-curvature-flow]]'
```

# geoexist

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#geoexist
uses: []
```

# lem:l-geodesic-extension

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#lem:l-geodesic-extension
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:complete-bounded-curvature-flow]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#lem:l-geodesic-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:l-geodesic-min-max-estimate]]'
```

# def:reduced-length-global

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#def:reduced-length-global
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#lem:l-geodesic-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#def:l-injectivity-domain]]'
```

# prop:l-exp-lipschitz-complete

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#prop:l-exp-lipschitz-complete
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# lipcomplete

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#lipcomplete
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-derivative-estimates]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-length-lipschitz-precise]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-exponential-diffeomorphism]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:injectivity-set-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:reduced-length-full-measure]]'
```

# cor:l-continuous-ae-smooth

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#cor:l-continuous-ae-smooth
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#prop:l-exp-lipschitz-complete]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# def:upper-barrier

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#def:upper-barrier
uses: []
```

# prop:l-barrier-inequality

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#prop:l-barrier-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:upper-barrier]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# weaksense

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#weaksense
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#lem:l-geodesic-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:reduced-length-pde-inequalities]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-exponential-diffeomorphism-along-geodesic]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-length-differential-inequalities]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:k-quantity-continuity]]'
```

# rem:horizontal-laplacian-convention

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#rem:horizontal-laplacian-convention
uses: []
```

# claim:l-min-achieved-compact

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#claim:l-min-achieved-compact
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# 8.1

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#8.1
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-geodesic-speed-bound]]'
```

# thm:min-l-bound-n-half

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#thm:min-l-bound-n-half
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# n/2

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#n/2
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#claim:l-min-achieved-compact]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#prop:l-barrier-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch02_ManifoldsNonNegativeCurvature#prop:forward-difference-maximum]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-geodesic-speed-bound]]'
```

# cor:generalized-flow-n-half-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#cor:generalized-flow-n-half-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# compactcoro

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#compactcoro
uses: []
```

# thm:l-weak-inequalities

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#thm:l-weak-inequalities
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:reduced-length-pde-inequalities]]'
```

# weak

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#weak
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#cor:l-tau-weak-laplacian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:reduced-length-pde-inequalities]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#prop:l-exp-lipschitz-complete]]'
```

# rem:l-weak-inequalities-interpretation

```qprint
kind: lemma
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#rem:l-weak-inequalities-interpretation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#thm:l-weak-inequalities]]'
```

# lem:l-barrier-hessian-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#lem:l-barrier-hessian-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# phisupport

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#phisupport
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch03_BasicsOfRicciFlow#thm:shi-first-derivative]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#lem:l-geodesic-existence]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#prop:l-exp-lipschitz-complete]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-length-gradient]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:l-geodesic-speed-bound]]'
```

# claim:euclidean-approximating-ball

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#claim:euclidean-approximating-ball
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#lem:l-barrier-hessian-bound]]'
```

# Hessdiff

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#Hessdiff
uses: []
```

# claim:strictly-concave-barrier

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#claim:strictly-concave-barrier
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#claim:euclidean-approximating-ball]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#lem:l-barrier-hessian-bound]]'
```

# claim:one-dim-barrier-maximum-principle

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#claim:one-dim-barrier-maximum-principle
uses: []
```

# cor:l-tau-uniform-convexity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#cor:l-tau-uniform-convexity
uses: []
```

# lineineq

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#lineineq
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#claim:strictly-concave-barrier]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#claim:one-dim-barrier-maximum-principle]]'
```

# claim:smooth-convex-approximation

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#claim:smooth-convex-approximation
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#cor:l-tau-uniform-convexity]]'
```

# def:starred-integral

```qprint
kind: definition
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#def:starred-integral
uses: []
```

# claim:beta-weak-laplacian-inequality

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#claim:beta-weak-laplacian-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#cor:l-tau-uniform-convexity]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:starred-integral]]'
```

# wineq

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#wineq
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#claim:smooth-convex-approximation]]'
```

# rem:laplacian-convention-metric-gt

```qprint
kind: theorem
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#rem:laplacian-convention-metric-gt
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#claim:beta-weak-laplacian-inequality]]'
```

# cor:l-tau-weak-laplacian-inequality

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#cor:l-tau-weak-laplacian-inequality
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:starred-integral]]'
```

# ltauineq

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#ltauineq
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#claim:beta-weak-laplacian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#cor:l-tau-weak-laplacian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:reduced-length-pde-inequalities]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#prop:l-exp-lipschitz-complete]]'
```

# lem:reduced-volume-flat-space

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#lem:reduced-volume-flat-space
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# flat

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#flat
uses: []
```

# thm:reduced-volume-monotone-bound

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#thm:reduced-volume-monotone-bound
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
```

# 4pi

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#4pi
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#prop:l-exp-lipschitz-complete]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#lem:reduced-volume-pullback]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-volume-integrand-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#thm:reduced-volume-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#cor:injectivity-set-contains-ball-small-tau]]'
```

# prop:reduced-volume-rigidity

```qprint
kind: other
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#prop:reduced-volume-rigidity
uses: []
```

# 4picase

```qprint
kind: proof
status: not_started
tex: references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows.tex#4picase
uses:
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#def:reduced-length-global]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#thm:reduced-volume-monotone-bound]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch07_CompleteRicciFlows#lem:reduced-volume-flat-space]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:reduced-volume-integrand-monotone]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-hessian-inequality]]'
- '[[references/MorganTian/blueprint/src/chapters/Ch06_ComparisonGeometry#prop:l-length-laplacian-inequality]]'
```
