# chap:smooth-manifolds

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/content.tex#chap:smooth-manifolds
uses: []
```

# chap:smooth-maps

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/content.tex#chap:smooth-maps
uses: []
```

# chap:tangent-vectors

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/content.tex#chap:tangent-vectors
uses: []
```

# chap:submersions-immersions-embeddings

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/content.tex#chap:submersions-immersions-embeddings
uses: []
```

# chap:submanifolds

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/content.tex#chap:submanifolds
uses: []
```

# chap:sards-theorem

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/content.tex#chap:sards-theorem
uses: []
```

# chap:lie-groups

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/content.tex#chap:lie-groups
uses: []
```

# chap:vector-fields

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/content.tex#chap:vector-fields
uses: []
```
