# prob:1-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-1
uses: []
```

# prob:1-10

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-10
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#ex:1-36]]'
```

# prob:1-11

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-11
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:1-7]]'
```

# prob:1-12

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-12
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#prop:1-45]]'
```

# prob:1-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-2
uses: []
```

# prob:1-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-4
uses: []
```

# prob:1-5

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-5
uses: []
```

# prob:1-6

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-6
uses: []
```

# prob:1-7

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-7
uses: []
```

# prob:1-9

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:1-9
uses: []
```

# prob:2-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-1
uses: []
```

# prob:2-13

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-13
uses: []
```

# prob:2-14

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-14
uses: []
```

# prob:2-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-2
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#prop:2-12]]'
```

# prob:2-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-3
uses: []
```

# prob:2-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-4
uses: []
```

# prob:2-6

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-6
uses: []
```

# prob:2-7

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-7
uses: []
```

# prob:2-8

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-8
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:1-9]]'
```

# prob:2-9

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:2-9
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:2-8]]'
```

# prob:3-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:3-2
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-14]]'
```

# prob:3-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:3-4
uses: []
```

# prob:3-5

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:3-5
uses: []
```

# prob:4-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:4-1
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter4#thm:4-5]]'
```

# prob:4-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:4-2
uses: []
```

# prob:5-14

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:5-14
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter5#thm:5-32]]'
```

# prob:5-19

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:5-19
uses: []
```

# prob:5-20

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:5-20
uses: []
```

# prob:5-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:5-4
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter4#ex:4-19]]'
```

# prob:6-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:6-3
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter6#cor:6-22]]'
```

# prob:7-11

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-11
uses: []
```

# prob:7-12

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-12
uses: []
```

# prob:7-17

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-17
uses: []
```

# prob:7-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-2
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-14]]'
```

# prob:7-22

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-22
uses: []
```

# prob:7-23

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-23
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:7-22]]'
```

# prob:7-24

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-24
uses: []
```

# prob:7-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-3
uses: []
```

# prob:7-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-4
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#cor:3-25]]'
```

# prob:7-5

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-5
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter7#thm:7-9]]'
```

# prob:7-6

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-6
uses: []
```

# prob:7-8

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-8
uses: []
```

# prob:7-9

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:7-9
uses: []
```

# prob:8-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-1
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#lem:8-6]]'
```

# prob:8-11

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-11
uses: []
```

# prob:8-16

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-16
uses: []
```

# prob:8-19

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-19
uses: []
```

# prob:8-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-2
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#ex:8-3]]'
```

# prob:8-20

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-20
uses: []
```

# prob:8-21

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-21
uses: []
```

# prob:8-22

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-22
uses: []
```

# prob:8-23

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-23
uses: []
```

# prob:8-24

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-24
uses: []
```

# prob:8-25

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-25
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:7-2]]'
```

# prob:8-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-3
uses: []
```

# prob:8-31

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-31
uses: []
```

# prob:8-5

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-5
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-11]]'
```

# prob:8-6

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-6
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:7-22]]'
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:7-23]]'
```

# prob:8-7

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-7
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:7-22]]'
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:8-6]]'
```

# prob:8-8

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-8
uses: []
```

# prob:8-9

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/formalization-support.tex#prob:8-9
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-19]]'
```
