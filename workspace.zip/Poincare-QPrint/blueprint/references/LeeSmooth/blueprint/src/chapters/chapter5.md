# def:5-28-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-28-extra-1
uses: []
```

# def:5-28-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-28-extra-2
uses: []
```

# cor:5-6

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#cor:5-6
uses: []
```

# def:5-29-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-29-extra-1
uses: []
```

# def:5-30-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-30-extra-1
uses: []
```

# def:5-31-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-31-extra-1
uses: []
```

# exer:5-20

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#exer:5-20
uses: []
```

# thm:5-27

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#thm:5-27
uses: []
```

# cor:5-30

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#cor:5-30
uses: []
```

# def:5-32-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-32-extra-2
uses: []
```

# thm:5-32

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#thm:5-32
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:5-14]]'
```

# not:5-34-extra-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#not:5-34-extra-1
uses: []
```

# lem:5-34

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#lem:5-34
uses: []
```

# not:5-35-extra-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#not:5-35-extra-1
uses: []
```

# def:5-35-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-35-extra-3
uses: []
```

# def:5-36-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-36-extra-2
uses: []
```

# def:5-36-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#def:5-36-extra-4
uses: []
```

# thm:5-53

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#thm:5-53
uses: []
```

# rem:5-36-extra-5

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#rem:5-36-extra-5
uses: []
```

# exer:5-10

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#exer:5-10
uses: []
```

# exer:5-54

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter5.tex#exer:5-54
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter5#thm:5-53]]'
```
