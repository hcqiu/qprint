# def:1-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-extra-2
uses: []
```

# ex:1-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-3
uses: []
```

# ex:1-5

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-5
uses: []
```

# exer:1-6

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#exer:1-6
uses: []
```

# exer:1-7

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#exer:1-7
uses: []
```

# ex:1-8

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-8
uses: []
```

# ex:1-9

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-9
uses: []
```

# def:1-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-extra-3
uses: []
```

# def:1-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-extra-4
uses: []
```

# lem:1-13

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#lem:1-13
uses: []
```

# def:1-2-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-2-extra-1
uses: []
```

# def:1-2-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-2-extra-2
uses: []
```

# def:1-2-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-2-extra-3
uses: []
```

# def:1-2-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-2-extra-4
uses: []
```

# def:1-2-extra-5

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-2-extra-5
uses: []
```

# prop:1-17

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#prop:1-17
uses: []
```

# rem:1-2-extra-6

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#rem:1-2-extra-6
uses: []
```

# def:1-3-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-3-extra-1
uses: []
```

# prop:1-19

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#prop:1-19
uses: []
```

# not:1-3-extra-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#not:1-3-extra-2
uses: []
```

# ex:1-22

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-22
uses: []
```

# ex:1-23

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-23
uses: []
```

# ex:1-24

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-24
uses: []
```

# not:1-4-extra-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#not:1-4-extra-1
uses: []
```

# ex:1-27

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-27
uses: []
```

# ex:1-28

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-28
uses: []
```

# ex:1-30

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-30
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#ex:1-3]]'
```

# ex:1-33

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-33
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#ex:1-5]]'
```

# prob:1-8

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#prob:1-8
uses: []
```

# lem:1-35

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#lem:1-35
uses: []
```

# ex:1-36

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#ex:1-36
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#ex:1-28]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#lem:1-35]]'
```

# def:1-5-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-5-extra-1
uses: []
```

# thm:1-37

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#thm:1-37
uses: []
```

# def:1-6-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-6-extra-2
uses: []
```

# def:1-6-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#def:1-6-extra-3
uses: []
```

# exer:1-44

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#exer:1-44
uses: []
```

# prop:1-45

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#prop:1-45
uses: []
```

# thm:1-46

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#thm:1-46
uses: []
```

# exer:1-14

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#exer:1-14
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#lem:1-13]]'
```

# exer:1-18

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#exer:1-18
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#prop:1-17]]'
```

# exer:1-20

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter1.tex#exer:1-20
uses: []
```
