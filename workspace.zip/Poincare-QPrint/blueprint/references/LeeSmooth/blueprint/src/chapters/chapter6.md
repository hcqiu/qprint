# def:6-38-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#def:6-38-extra-1
uses: []
```

# exer:6-1

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#exer:6-1
uses: []
```

# lem:6-2

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#lem:6-2
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter6#exer:6-1]]'
```

# prop:6-3

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#prop:6-3
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter6#lem:6-2]]'
```

# cor:6-4

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#cor:6-4
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter6#prop:6-3]]'
```

# def:6-38-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#def:6-38-extra-2
uses: []
```

# lem:6-6

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#lem:6-6
uses: []
```

# exer:6-7

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#exer:6-7
uses: []
```

# prop:6-8

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#prop:6-8
uses: []
```

# thm:6-9

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#thm:6-9
uses: []
```

# def:6-41-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#def:6-41-extra-1
uses: []
```

# cor:6-22

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#cor:6-22
uses: []
```

# def:6-42-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#def:6-42-extra-1
uses: []
```

# def:6-42-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#def:6-42-extra-3
uses: []
```

# def:6-43-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#def:6-43-extra-1
uses: []
```

# lem:6-28

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#lem:6-28
uses: []
```

# def:6-44-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#def:6-44-extra-2
uses: []
```

# prop:6-34

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#prop:6-34
uses: []
```

# def:6-44-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter6.tex#def:6-44-extra-3
uses: []
```
