# rem:2-8-extra-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#rem:2-8-extra-1
uses: []
```

# not:2-8-extra-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#not:2-8-extra-3
uses: []
```

# exer:2-3

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#exer:2-3
uses: []
```

# def:2-8-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-8-extra-4
uses: []
```

# def:2-8-extra-5

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-8-extra-5
uses: []
```

# prop:2-4

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#prop:2-4
uses: []
```

# prop:2-5

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#prop:2-5
uses: []
```

# prop:2-6

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#prop:2-6
uses: []
```

# cor:2-8

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#cor:2-8
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#prop:2-6]]'
```

# def:2-8-extra-6

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-8-extra-6
uses: []
```

# exer:2-9

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#exer:2-9
uses: []
```

# prop:2-10

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#prop:2-10
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#exer:2-9]]'
```

# prop:2-12

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#prop:2-12
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:2-2]]'
```

# rem:2-8-extra-7

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#rem:2-8-extra-7
uses: []
```

# ex:2-13

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#ex:2-13
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#ex:1-33]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#ex:1-8]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#prob:1-8]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#prop:2-12]]'
```

# def:2-9-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-9-extra-1
uses: []
```

# ex:2-14

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#ex:2-14
uses: []
```

# thm:2-17

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#thm:2-17
uses: []
```

# lem:2-20

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#lem:2-20
uses: []
```

# lem:2-21

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#lem:2-21
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#lem:2-20]]'
```

# def:2-10-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-10-extra-1
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#lem:2-21]]'
```

# lem:2-22

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#lem:2-22
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#lem:2-21]]'
```

# def:2-10-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-10-extra-2
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#lem:2-22]]'
```

# def:2-10-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-10-extra-3
uses: []
```

# def:2-10-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-10-extra-4
uses: []
```

# thm:2-23

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#thm:2-23
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#lem:1-13]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter2#lem:2-22]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#prop:1-19]]'
```

# def:2-11-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#def:2-11-extra-1
uses: []
```

# prop:2-25

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#prop:2-25
uses: []
```

# prop:2-28

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#prop:2-28
uses: []
```

# thm:2-29

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#thm:2-29
uses: []
```

# exer:2-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#exer:2-1
uses: []
```

# exer:2-11

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#exer:2-11
uses: []
```

# exer:2-24

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#exer:2-24
uses: []
```

# exer:2-7

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter2.tex#exer:2-7
uses: []
```
