# def:3-13-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-13-extra-1
uses: []
```

# def:3-13-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-13-extra-2
uses: []
```

# lem:3-1

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#lem:3-1
uses: []
```

# def:3-13-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-13-extra-3
uses: []
```

# lem:3-4

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#lem:3-4
uses: []
```

# def:3-14-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-14-extra-1
uses: []
```

# prop:3-6

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-6
uses: []
```

# prop:3-8

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-8
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#lem:3-4]]'
```

# prop:3-9

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-9
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-8]]'
```

# prop:3-10

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-10
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-6]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-9]]'
```

# lem:3-11

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#lem:3-11
uses: []
```

# prop:3-12

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-12
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#lem:3-11]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-6]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-9]]'
```

# def:3-14-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-14-extra-2
uses: []
```

# prop:3-13

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-13
uses: []
```

# prop:3-14

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-14
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:3-2]]'
```

# def:3-15-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-15-extra-1
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-6]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-9]]'
```

# prop:3-15

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-15
uses: []
```

# def:3-15-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-15-extra-2
uses: []
```

# rem:3-15-extra-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#rem:3-15-extra-3
uses: []
```

# rem:3-15-extra-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#rem:3-15-extra-4
uses: []
```

# ex:3-16

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#ex:3-16
uses: []
```

# rem:3-15-extra-5

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#rem:3-15-extra-5
uses: []
```

# def:3-16-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-16-extra-1
uses: []
```

# prop:3-18

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-18
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter1#lem:1-35]]'
```

# not:3-16-extra-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#not:3-16-extra-2
uses: []
```

# exer:3-19

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#exer:3-19
uses: []
```

# def:3-16-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-16-extra-3
uses: []
```

# prop:3-21

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-21
uses: []
```

# not:3-16-extra-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#not:3-16-extra-4
uses: []
```

# def:3-17-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-17-extra-1
uses: []
```

# prop:3-23

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-23
uses: []
```

# prop:3-24

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#prop:3-24
uses: []
```

# cor:3-25

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#cor:3-25
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-23]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-24]]'
```

# def:3-18-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-18-extra-1
uses: []
```

# def:3-18-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-18-extra-4
uses: []
```

# def:3-19-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-19-extra-1
uses: []
```

# def:3-19-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-19-extra-2
uses: []
```

# ex:3-26

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#ex:3-26
uses: []
```

# def:3-19-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-19-extra-3
uses: []
```

# def:3-19-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#def:3-19-extra-4
uses: []
```

# exer:3-17

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#exer:3-17
uses: []
```

# exer:3-27

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#exer:3-27
uses: []
```

# exer:3-5

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#exer:3-5
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#lem:3-4]]'
```

# exer:3-7

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter3.tex#exer:3-7
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter3#prop:3-6]]'
```
