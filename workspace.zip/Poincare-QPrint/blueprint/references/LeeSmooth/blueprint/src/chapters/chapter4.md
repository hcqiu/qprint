# def:4-22-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#def:4-22-extra-1
uses: []
```

# thm:4-5

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#thm:4-5
uses: []
```

# exer:4-10

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#exer:4-10
uses: []
```

# def:4-24-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#def:4-24-extra-1
uses: []
```

# ex:4-19

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#ex:4-19
uses: []
```

# lem:4-21

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#lem:4-21
uses: []
```

# def:4-25-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#def:4-25-extra-1
uses: []
```

# def:4-26-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#def:4-26-extra-1
uses: []
```

# exer:4-39

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#exer:4-39
uses: []
```

# prop:4-46

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#prop:4-46
uses: []
```

# exer:4-24

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#exer:4-24
uses: []
```

# exer:4-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter4.tex#exer:4-4
uses: []
```
