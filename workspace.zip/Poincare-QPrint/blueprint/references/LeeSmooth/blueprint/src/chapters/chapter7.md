# def:7-46-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-46-extra-1
uses: []
```

# not:7-46-extra-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#not:7-46-extra-2
uses: []
```

# prop:7-1

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#prop:7-1
uses: []
```

# ex:7-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#ex:7-3
uses: []
```

# def:7-47-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-47-extra-1
uses: []
```

# ex:7-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#ex:7-4
uses: []
```

# thm:7-9

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#thm:7-9
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:7-5]]'
```

# def:7-49-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-49-extra-1
uses: []
```

# prop:7-11

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#prop:7-11
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter5#cor:5-30]]'
```

# def:7-49-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-49-extra-2
uses: []
```

# exer:7-13

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#exer:7-13
uses: []
```

# prop:7-14

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#prop:7-14
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter7#exer:7-13]]'
```

# def:7-49-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-49-extra-3
uses: []
```

# ex:7-18

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#ex:7-18
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter7#ex:7-3]]'
```

# ex:7-22

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#ex:7-22
uses: []
```

# def:7-50-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-50-extra-2
uses: []
```

# prop:7-23

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#prop:7-23
uses: []
```

# def:7-50-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-50-extra-3
uses: []
```

# def:7-50-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-50-extra-4
uses: []
```

# ex:7-27

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#ex:7-27
uses: []
```

# ex:7-29

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#ex:7-29
uses: []
```

# ex:7-30

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#ex:7-30
uses: []
```

# def:7-51-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-51-extra-1
uses: []
```

# exer:7-31

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#exer:7-31
uses: []
```

# ex:7-32

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#ex:7-32
uses: []
```

# prop:7-33

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#prop:7-33
uses: []
```

# def:7-52-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-52-extra-1
uses: []
```

# def:7-52-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#def:7-52-extra-2
uses: []
```

# prop:7-37

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#prop:7-37
uses: []
```

# exer:7-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#exer:7-2
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter7#prop:7-1]]'
```

# exer:7-34

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#exer:7-34
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter7#prop:7-33]]'
```

# exer:7-8

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter7.tex#exer:7-8
uses: []
```
