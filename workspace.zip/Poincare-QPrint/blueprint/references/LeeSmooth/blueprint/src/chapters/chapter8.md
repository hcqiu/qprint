# ex:8-2

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#ex:8-2
uses: []
```

# ex:8-3

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#ex:8-3
uses: []
```

# ex:8-4

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#ex:8-4
uses: []
```

# lem:8-6

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#lem:8-6
uses: []
```

# prop:8-7

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-7
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#lem:8-6]]'
```

# prop:8-8

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-8
uses: []
```

# def:8-55-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-55-extra-1
uses: []
```

# prop:8-11

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-11
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/formalization-support#prob:8-5]]'
```

# def:8-55-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-55-extra-2
uses: []
```

# ex:8-12

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#ex:8-12
uses: []
```

# lem:8-13

```qprint
kind: lemma
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#lem:8-13
uses: []
```

# def:8-55-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-55-extra-3
uses: []
```

# not:8-56-extra-1

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#not:8-56-extra-1
uses: []
```

# def:8-57-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-57-extra-1
uses: []
```

# prop:8-16

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-16
uses: []
```

# ex:8-17

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#ex:8-17
uses: []
```

# prop:8-19

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-19
uses: []
```

# def:8-57-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-57-extra-2
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-19]]'
```

# cor:8-21

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#cor:8-21
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-16]]'
```

# def:8-58-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-58-extra-1
uses: []
```

# def:8-59-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-59-extra-1
uses: []
```

# prop:8-26

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-26
uses: []
```

# ex:8-27

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#ex:8-27
uses: []
```

# prop:8-28

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-28
uses: []
```

# prop:8-30

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-30
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-16]]'
```

# cor:8-31

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#cor:8-31
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-30]]'
```

# def:8-60-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-60-extra-1
uses: []
```

# prop:8-33

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-33
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#cor:8-31]]'
```

# def:8-60-extra-2

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-60-extra-2
uses: []
```

# def:8-60-extra-3

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-60-extra-3
uses: []
```

# def:8-60-extra-4

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-60-extra-4
uses: []
```

# exer:8-34

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#exer:8-34
uses: []
```

# exer:8-35

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#exer:8-35
uses: []
```

# ex:8-36

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#ex:8-36
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-28]]'
```

# def:8-60-extra-5

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-60-extra-5
uses: []
```

# thm:8-37

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#thm:8-37
uses: []
```

# not:8-60-extra-6

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#not:8-60-extra-6
uses: []
```

# cor:8-38

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#cor:8-38
uses: []
```

# def:8-60-extra-7

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-60-extra-7
uses: []
```

# cor:8-39

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#cor:8-39
uses: []
```

# prop:8-41

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-41
uses: []
```

# prop:8-48

```qprint
kind: theorem
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#prop:8-48
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter7#ex:7-18]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-41]]'
```

# def:8-62-extra-1

```qprint
kind: definition
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#def:8-62-extra-1
uses: []
```

# exer:8-18

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#exer:8-18
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#ex:8-17]]'
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-16]]'
```

# exer:8-29

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#exer:8-29
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-28]]'
```

# exer:8-9

```qprint
kind: other
status: not_started
tex: references/LeeSmooth/blueprint/src/chapters/chapter8.tex#exer:8-9
uses:
- '[[references/LeeSmooth/blueprint/src/chapters/chapter8#prop:8-8]]'
```
