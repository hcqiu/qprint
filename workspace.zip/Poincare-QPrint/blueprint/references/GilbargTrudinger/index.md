---
title: references/GilbargTrudinger
---

## Blueprint

- [[references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch03-classical-maximum-principle.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch06-schauder-approach.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch11-topological-fixed-point.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch14-boundary-gradient.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.md]]
- [[references/GilbargTrudinger/blueprint/src/chapters/ch17-fully-nonlinear.md]]
