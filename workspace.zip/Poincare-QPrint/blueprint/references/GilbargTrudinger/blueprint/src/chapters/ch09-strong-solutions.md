# gt-ch09-thm-aleksandrov-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-aleksandrov-maximum-principle
uses: []
```

# gt-ch09-lem-contact-set-determinant-estimate

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-lem-contact-set-determinant-estimate
uses: []
```

# gt-ch09-lem-contact-set-principal-part

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-lem-contact-set-principal-part
uses: []
```

# gt-ch09-lem-weighted-contact-set

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-lem-weighted-contact-set
uses: []
```

# gt-ch09-thm-strong-dirichlet-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-strong-dirichlet-uniqueness
uses: []
```

# gt-ch09-thm-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-strong-maximum-principle
uses: []
```

# gt-ch09-lem-distribution-function-identities

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-lem-distribution-function-identities
uses: []
```

# gt-ch09-thm-marcinkiewicz-interpolation

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-marcinkiewicz-interpolation
uses: []
```

# gt-ch09-thm-calderon-zygmund-newtonian

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-calderon-zygmund-newtonian
uses: []
```

# gt-ch09-cor-calderon-zygmund-poisson

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-cor-calderon-zygmund-poisson
uses: []
```

# gt-ch09-thm-interior-w2p-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-interior-w2p-estimate
uses: []
```

# gt-ch09-lem-flat-boundary-poisson

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-lem-flat-boundary-poisson
uses: []
```

# gt-ch09-thm-local-boundary-w2p-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-local-boundary-w2p-estimate
uses: []
```

# gt-ch09-thm-coercive-global-w2p-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-coercive-global-w2p-estimate
uses: []
```

# gt-ch09-thm-strong-dirichlet-w2p

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-strong-dirichlet-w2p
uses: []
```

# gt-ch09-lem-boundary-integrability-bootstrap

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-lem-boundary-integrability-bootstrap
uses: []
```

# gt-ch09-lem-dirichlet-apriori-w2p

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-lem-dirichlet-apriori-w2p
uses: []
```

# gt-ch09-cor-strong-dirichlet-continuous-data

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-cor-strong-dirichlet-continuous-data
uses: []
```

# gt-ch09-thm-higher-regularity-strong-solutions

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-higher-regularity-strong-solutions
uses: []
```

# gt-ch09-thm-local-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-local-maximum-principle
uses: []
```

# gt-ch09-cor-local-minimum-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-cor-local-minimum-principle
uses: []
```

# gt-ch09-thm-weak-harnack

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-weak-harnack
uses: []
```

# gt-ch09-lem-cube-level-set-growth

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-lem-cube-level-set-growth
uses: []
```

# gt-ch09-cor-interior-holder-oscillation

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-cor-interior-holder-oscillation
uses: []
```

# gt-ch09-cor-interior-harnack

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-cor-interior-harnack
uses: []
```

# gt-ch09-thm-boundary-local-maximum

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-boundary-local-maximum
uses: []
```

# gt-ch09-thm-boundary-weak-harnack

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-boundary-weak-harnack
uses: []
```

# gt-ch09-cor-boundary-oscillation-exterior-cone

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-cor-boundary-oscillation-exterior-cone
uses: []
```

# gt-ch09-cor-global-holder-exterior-cone

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-cor-global-holder-exterior-cone
uses: []
```

# gt-ch09-thm-dirichlet-exterior-cone

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-dirichlet-exterior-cone
uses: []
```

# gt-ch09-thm-boundary-holder-normal-quotient

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch09-strong-solutions.tex#gt-ch09-thm-boundary-holder-normal-quotient
uses: []
```
