# gilbarg-trudinger.thm.15.1.gradient-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.1.gradient-maximum-principle
uses: []
```

# gt:thm-15-2

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gt:thm-15-2
uses: []
```

# gilbarg-trudinger.thm.15.3.local-gradient-structure

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.3.local-gradient-structure
uses: []
```

# gilbarg-trudinger.lem.15.4.oscillation-quadratic-growth

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.lem.15.4.oscillation-quadratic-growth
uses: []
```

# gilbarg-trudinger.thm.15.5.natural-growth-gradient-bounds

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.5.natural-growth-gradient-bounds
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient#gilbarg-trudinger.thm.15.3.local-gradient-structure]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient#gilbarg-trudinger.lem.15.4.oscillation-quadratic-growth]]'
```

# gilbarg-trudinger.thm.15.6.divergence-global-gradient

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.6.divergence-global-gradient
uses: []
```

# gilbarg-trudinger.thm.15.7.weak-solution-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.7.weak-solution-holder
uses: []
```

# gilbarg-trudinger.thm.15.8.divergence-interior-gradient

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.8.divergence-interior-gradient
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient#gilbarg-trudinger.thm.15.7.weak-solution-holder]]'
```

# gilbarg-trudinger.thm.15.9.divergence-global-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.9.divergence-global-bound
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient#gilbarg-trudinger.thm.15.8.divergence-interior-gradient]]'
```

# gilbarg-trudinger.thm.15.10.uniformly-elliptic-existence

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.10.uniformly-elliptic-existence
uses: []
```

# gilbarg-trudinger.thm.15.11.divergence-existence

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.11.divergence-existence
uses: []
```

# gilbarg-trudinger.thm.15.12.nondivergence-existence

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.12.nondivergence-existence
uses: []
```

# gilbarg-trudinger.thm.15.13.general-domain-existence

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.13.general-domain-existence
uses: []
```

# gilbarg-trudinger.thm.15.14.convex-domain-existence

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.14.convex-domain-existence
uses: []
```

# gilbarg-trudinger.thm.15.15.convex-divergence-existence

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.15.convex-divergence-existence
uses: []
```

# gilbarg-trudinger.thm.15.16.strict-boundary-curvature

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.16.strict-boundary-curvature
uses: []
```

# gilbarg-trudinger.thm.15.17.nonstrict-boundary-curvature

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.17.nonstrict-boundary-curvature
uses: []
```

# gilbarg-trudinger.thm.15.18.continuous-data

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.18.continuous-data
uses: []
```

# gilbarg-trudinger.thm.15.19.continuous-divergence-data

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch15-global-interior-gradient.tex#gilbarg-trudinger.thm.15.19.continuous-divergence-data
uses: []
```
