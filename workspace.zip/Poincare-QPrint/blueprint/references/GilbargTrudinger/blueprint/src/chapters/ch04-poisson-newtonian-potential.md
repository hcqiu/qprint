# gt:def-holder-pointwise

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:def-holder-pointwise
uses: []
```

# gt:def-holder-uniform-local

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:def-holder-uniform-local
uses: []
```

# gt:def-holder-spaces

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:def-holder-spaces
uses: []
```

# gt:lem-newtonian-c1

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:lem-newtonian-c1
uses: []
```

# gt:lem-newtonian-c2

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:lem-newtonian-c2
uses: []
```

# gt:thm-dirichlet-poisson

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-dirichlet-poisson
uses: []
```

# gt:lem-newtonian-holder-ball

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:lem-newtonian-holder-ball
uses: []
```

# gt:thm-poisson-compact-support

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-compact-support
uses: []
```

# gt:thm-poisson-interior-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-interior-holder
uses: []
```

# gt:cor-poisson-compactness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:cor-poisson-compactness
uses: []
```

# gt:thm-poisson-interior-weighted

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-interior-weighted
uses: []
```

# gt:thm-poisson-ball-unbounded

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-ball-unbounded
uses: []
```

# gt:lem-newtonian-holder-halfball

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:lem-newtonian-holder-halfball
uses: []
```

# gt:thm-poisson-halfball-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-halfball-holder
uses: []
```

# gt:thm-poisson-partial-boundary

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-partial-boundary
uses: []
```

# gt:thm-poisson-ball-boundary

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-ball-boundary
uses: []
```

# gt:cor-poisson-ball-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:cor-poisson-ball-dirichlet
uses: []
```

# gt:thm-poisson-first-derivative-interior

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-first-derivative-interior
uses: []
```

# gt:thm-poisson-first-derivative-halfball

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch04-poisson-newtonian-potential.tex#gt:thm-poisson-first-derivative-halfball
uses: []
```
