# gt-ch12-def-quasiconformal-mapping

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-def-quasiconformal-mapping
uses: []
```

# gt-ch12-lem-dirichlet-integral-growth

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-lem-dirichlet-integral-growth
uses: []
```

# gt-ch12-lem-dirichlet-growth-holder

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-lem-dirichlet-growth-holder
uses: []
```

# gt-ch12-thm-holder-quasiconformal-mappings

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-thm-holder-quasiconformal-mappings
uses: []
```

# gt-ch12-thm-interior-holder-gradient-linear

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-thm-interior-holder-gradient-linear
uses: []
```

# gt-ch12-thm-dirichlet-uniformly-elliptic

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-thm-dirichlet-uniformly-elliptic
uses: []
```

# gt-ch12-def-bounded-slope

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-def-bounded-slope
uses: []
```

# gt-ch12-def-three-point

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-def-three-point
uses: []
```

# gt-ch12-lem-bounded-slope-gradient

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-lem-bounded-slope-gradient
uses: []
```

# gt-ch12-thm-dirichlet-nonuniformly-elliptic

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-thm-dirichlet-nonuniformly-elliptic
uses: []
```

# gt-ch12-prop-bounded-slope-three-point-equivalence

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch12-equations-two-variables.tex#gt-ch12-prop-bounded-slope-three-point-equivalence
uses: []
```
