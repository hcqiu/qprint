# gt-def-8-divergence-form-generalized-solution

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-def-8-divergence-form-generalized-solution
uses: []
```

# gt-rem-8-classical-generalized-equivalence

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-classical-generalized-equivalence
uses: []
```

# gt-conv-8-ellipticity-coefficient-bounds

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-conv-8-ellipticity-coefficient-bounds
uses: []
```

# gt-def-8-generalized-dirichlet-problem

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-def-8-generalized-dirichlet-problem
uses: []
```

# gt-prop-8-bounded-weak-form

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-prop-8-bounded-weak-form
uses: []
```

# gt-def-8-sobolev-boundary-inequalities

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-def-8-sobolev-boundary-inequalities
uses: []
```

# gt-conv-8-weak-zeroth-order-sign

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-conv-8-weak-zeroth-order-sign
uses: []
```

# gt-thm-8-1-weak-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-1-weak-maximum-principle
uses: []
```

# gt-cor-8-2-uniqueness-zero

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-cor-8-2-uniqueness-zero
uses: []
```

# gt-thm-8-3-solvability-generalized-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-3-solvability-generalized-dirichlet
uses: []
```

# gt-lem-8-4-coercivity-estimate

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-lem-8-4-coercivity-estimate
uses: []
```

# gt-lem-8-5-compact-embedding

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-lem-8-5-compact-embedding
uses: []
```

# gt-thm-8-6-fredholm-alternative

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-6-fredholm-alternative
uses: []
```

# gt-cor-8-7-resolvent-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-cor-8-7-resolvent-estimate
uses: []
```

# gt-rem-8-adjoint-sign-solvability

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-adjoint-sign-solvability
uses: []
```

# gt-thm-8-8-interior-w22

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-8-interior-w22
uses: []
```

# gt-thm-8-9-strong-dirichlet-solvability

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-9-strong-dirichlet-solvability
uses: []
```

# gt-rem-8-continuous-principal-coefficients

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-continuous-principal-coefficients
uses: []
```

# gt-ex-8-discontinuous-principal-nonuniqueness

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-ex-8-discontinuous-principal-nonuniqueness
uses: []
```

# gt-thm-8-10-higher-interior-regularity

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-10-higher-interior-regularity
uses: []
```

# gt-cor-8-11-interior-smoothness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-cor-8-11-interior-smoothness
uses: []
```

# gt-thm-8-12-global-w22

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-12-global-w22
uses: []
```

# gt-thm-8-13-higher-global-regularity

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-13-higher-global-regularity
uses: []
```

# gt-thm-8-14-smooth-classical-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-14-smooth-classical-dirichlet
uses: []
```

# gt-thm-8-15-global-boundedness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-15-global-boundedness
uses: []
```

# gt-rem-8-constant-boundary-bound

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-constant-boundary-bound
uses: []
```

# gt-thm-8-16-global-apriori-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-16-global-apriori-bound
uses: []
```

# gt-rem-8-adjoint-sign-maximum-bound

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-adjoint-sign-maximum-bound
uses: []
```

# gt-thm-8-17-local-boundedness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-17-local-boundedness
uses: []
```

# gt-thm-8-18-weak-harnack

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-18-weak-harnack
uses: []
```

# gt-thm-8-19-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-19-strong-maximum-principle
uses: []
```

# gt-thm-8-20-harnack

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-20-harnack
uses: []
```

# gt-cor-8-21-harnack-subdomain

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-cor-8-21-harnack-subdomain
uses: []
```

# gt-thm-8-22-interior-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-22-interior-holder
uses: []
```

# gt-lem-8-23-oscillation-iteration

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-lem-8-23-oscillation-iteration
uses: []
```

# gt-thm-8-24-interior-holder-norm

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-24-interior-holder-norm
uses: []
```

# gt-rem-8-local-constant-dependence

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-local-constant-dependence
uses: []
```

# gt-def-8-boundary-portion-inequality

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-def-8-boundary-portion-inequality
uses: []
```

# gt-thm-8-25-boundary-local-boundedness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-25-boundary-local-boundedness
uses: []
```

# gt-thm-8-26-boundary-weak-harnack

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-26-boundary-weak-harnack
uses: []
```

# gt-def-8-exterior-cone-condition

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-def-8-exterior-cone-condition
uses: []
```

# gt-thm-8-27-boundary-oscillation

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-27-boundary-oscillation
uses: []
```

# gt-cor-8-28-uniform-boundary-continuity

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-cor-8-28-uniform-boundary-continuity
uses: []
```

# gt-thm-8-29-boundary-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-29-boundary-holder
uses: []
```

# gt-rem-8-boundary-oscillation-trace

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-boundary-oscillation-trace
uses: []
```

# gt-thm-8-30-continuous-dirichlet-cone

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-30-continuous-dirichlet-cone
uses: []
```

# gt-def-8-regular-boundary-point

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-def-8-regular-boundary-point
uses: []
```

# gt-rem-8-regular-points-laplacian

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-regular-points-laplacian
uses: []
```

# gt-thm-8-31-continuous-dirichlet-wiener

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-31-continuous-dirichlet-wiener
uses: []
```

# gt-rem-8-integrable-lower-order-coefficients

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-integrable-lower-order-coefficients
uses: []
```

# gt-thm-8-32-interior-gradient-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-32-interior-gradient-holder
uses: []
```

# gt-thm-8-33-global-gradient-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-33-global-gradient-holder
uses: []
```

# gt-thm-8-34-c1alpha-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-34-c1alpha-dirichlet
uses: []
```

# gt-cor-8-35-w12-global-gradient-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-cor-8-35-w12-global-gradient-estimate
uses: []
```

# gt-cor-8-36-partial-boundary-gradient-regularity

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-cor-8-36-partial-boundary-gradient-regularity
uses: []
```

# gt-rem-8-integrable-scalar-datum

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-integrable-scalar-datum
uses: []
```

# gt-thm-8-37-variational-spectrum

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-37-variational-spectrum
uses: []
```

# gt-rem-8-eigenfunction-regularity

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-rem-8-eigenfunction-regularity
uses: []
```

# gt-thm-8-38-simple-positive-first-eigenfunction

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-38-simple-positive-first-eigenfunction
uses: []
```

# gt-def-8-generalized-mixed-boundary-problem

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-def-8-generalized-mixed-boundary-problem
uses: []
```

# gt-thm-8-mixed-boundary-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-mixed-boundary-maximum-principle
uses: []
```

# gt-cor-8-mixed-boundary-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-cor-8-mixed-boundary-uniqueness
uses: []
```

# gt-prop-8-alternative-maximum-hypotheses

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-prop-8-alternative-maximum-hypotheses
uses: []
```

# gt-prop-8-interior-energy-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-prop-8-interior-energy-estimate
uses: []
```

# gt-prop-8-symmetric-harnack-constant

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-prop-8-symmetric-harnack-constant
uses: []
```

# gt-prop-8-sobolev-poisson-sharpness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-prop-8-sobolev-poisson-sharpness
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch03-classical-maximum-principle#gt-ch3-poisson]]'
```

# gt-lem-8-planar-circle-oscillation

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-lem-8-planar-circle-oscillation
uses: []
```

# gt-lem-8-capacity-measure

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-lem-8-capacity-measure
uses: []
```

# gt-thm-8-finite-measure-unbounded-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch08-generalized-solutions.tex#gt-thm-8-finite-measure-unbounded-dirichlet
uses: []
```
