# gt.eq1.1

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.1
uses: []
```

# gt.eq1.2

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.2
uses: []
```

# gt.eq1.3

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.3
uses: []
```

# gt.eq1.4

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.4
uses: []
```

# gt.eq1.5

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.5
uses: []
```

# gt.eq1.6

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.6
uses: []
```

# gt.eq1.7

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.7
uses: []
```

# gt.eq1.8

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.8
uses: []
```

# gt.eq1.9

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.9
uses: []
```

# gt.eq1.10

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.10
uses: []
```

# gt.eq1.11

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.eq1.11
uses: []
```

# gt.not.basic-notation

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch01-introduction.tex#gt.not.basic-notation
uses: []
```
