# gt.def5.1.contraction-mapping

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.1.contraction-mapping
uses: []
```

# gt.eq5.1

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.1
uses: []
```

# gt.thm5.1

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.1
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.1.contraction-mapping]]'
```

# gt.def5.2.bounded-linear-operator

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.2.bounded-linear-operator
uses: []
```

# gt.eq5.2

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.2
uses: []
```

# gt.thm5.2

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.2
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.thm5.1]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.2.bounded-linear-operator]]'
```

# gt.eq5.3

```qprint
kind: proof
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.3
uses: []
```

# gt.def5.3.compact-mapping

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.3.compact-mapping
uses: []
```

# gt.thm5.3

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.3
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.3.compact-mapping]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.lem5.4]]'
```

# gt.eq5.4

```qprint
kind: proof
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.4
uses: []
```

# gt.lem5.4

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.lem5.4
uses: []
```

# gt.def5.3.eigenvalue

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.3.eigenvalue
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.thm5.3]]'
```

# gt.thm5.5

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.5
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.3.compact-mapping]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.lem5.4]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.3.eigenvalue]]'
```

# gt.def5.4.dual-space

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.4.dual-space
uses: []
```

# gt.eq5.5

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.5
uses: []
```

# gt.def5.4.reflexive

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.4.reflexive
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.4.dual-space]]'
```

# gt.def5.4.adjoint

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.4.adjoint
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.2.bounded-linear-operator]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.4.dual-space]]'
```

# gt.eq5.6

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.6
uses: []
```

# gt.def5.5.inner-product

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.5.inner-product
uses: []
```

# gt.eq5.7

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.7
uses: []
```

# gt.eq5.8

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.8
uses: []
```

# gt.eq5.9

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.9
uses: []
```

# gt.def5.5.hilbert-space

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.5.hilbert-space
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.5.inner-product]]'
```

# gt.def5.6.orthogonal

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.6.orthogonal
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.5.inner-product]]'
```

# gt.thm5.6

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.6
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.5.hilbert-space]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.6.orthogonal]]'
```

# gt.thm5.7

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.7
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.thm5.6]]'
```

# gt.def5.8.bilinear

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.8.bilinear
uses: []
```

# gt.eq5.10

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.10
uses: []
```

# gt.eq5.11

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.11
uses: []
```

# gt.thm5.8

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.8
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.8.bilinear]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.thm5.7]]'
```

# gt.def5.9.adjoint-hilbert

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.9.adjoint-hilbert
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.5.hilbert-space]]'
```

# gt.eq5.12

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.12
uses: []
```

# gt.lem5.9

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.lem5.9
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.3.compact-mapping]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.9.adjoint-hilbert]]'
```

# gt.lem5.10

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.lem5.10
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.9.adjoint-hilbert]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.thm5.6]]'
```

# gt.thm5.11

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.11
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.3.compact-mapping]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.thm5.5]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.5.hilbert-space]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.9.adjoint-hilbert]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.lem5.9]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.lem5.10]]'
```

# gt.eq5.13

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq5.13
uses: []
```

# gt.def5.10.weak-convergence

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.def5.10.weak-convergence
uses: []
```

# gt.thm5.12

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.thm5.12
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.5.hilbert-space]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.thm5.7]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces#gt.def5.10.weak-convergence]]'
```

# gt.lem6.1

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.lem6.1
uses: []
```

# gt.eq6.3

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch05-banach-hilbert-spaces.tex#gt.eq6.3
uses: []
```
