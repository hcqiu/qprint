# gt:rem-sobolev-weak-poisson

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:rem-sobolev-weak-poisson
uses: []
```

# gt:sec-lp-spaces

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:sec-lp-spaces
uses: []
```

# gt:def-sobolev-lp-spaces

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:def-sobolev-lp-spaces
uses: []
```

# gt:prop-sobolev-lp-inequalities

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:prop-sobolev-lp-inequalities
uses: []
```

# gt:def-sobolev-normalized-lp-functional

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:def-sobolev-normalized-lp-functional
uses: []
```

# gt:prop-sobolev-normalized-lp-functional

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:prop-sobolev-normalized-lp-functional
uses: []
```

# gt:def-sobolev-mollification

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:def-sobolev-mollification
uses: []
```

# gt:lem-sobolev-regularization-uniform

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-regularization-uniform
uses: []
```

# gt:lem-sobolev-regularization-lp

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-regularization-lp
uses: []
```

# gt:def-sobolev-weak-derivative

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:def-sobolev-weak-derivative
uses: []
```

# gt:lem-sobolev-mollifier-derivative

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-mollifier-derivative
uses: []
```

# gt:thm-sobolev-weak-derivative-approx

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-weak-derivative-approx
uses: []
```

# gt:prop-sobolev-weak-calculus

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:prop-sobolev-weak-calculus
uses: []
```

# gt:lem-sobolev-chain-rule-c1

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-chain-rule-c1
uses: []
```

# gt:lem-sobolev-positive-negative-parts

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-positive-negative-parts
uses: []
```

# gt:lem-sobolev-constant-gradient-zero

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-constant-gradient-zero
uses: []
```

# gt:thm-sobolev-piecewise-chain-rule

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-piecewise-chain-rule
uses: []
```

# gt:sec-wkp-spaces

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:sec-wkp-spaces
uses: []
```

# gt:def-sobolev-wkp-spaces

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:def-sobolev-wkp-spaces
uses: []
```

# gt:thm-sobolev-density-smooth

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-density-smooth
uses: []
```

# gt:prop-sobolev-segment-density

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:prop-sobolev-segment-density
uses: []
```

# gt:thm-sobolev-embedding-basic

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-embedding-basic
uses: []
```

# gt:rem-sobolev-sharp-constant

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:rem-sobolev-sharp-constant
uses: []
```

# gt:cor-sobolev-embedding-higher-order

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:cor-sobolev-embedding-higher-order
uses: []
```

# gt:prop-sobolev-cone-embedding

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:prop-sobolev-cone-embedding
uses: []
```

# gt:sec-potential-estimates

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:sec-potential-estimates
uses: []
```

# gt:def-sobolev-riesz-potential

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:def-sobolev-riesz-potential
uses: []
```

# gt:prop-sobolev-riesz-potential-one

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:prop-sobolev-riesz-potential-one
uses: []
```

# gt:lem-sobolev-riemann-potential-mapping

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-riemann-potential-mapping
uses: []
```

# gt:rem-sobolev-riesz-endpoint

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:rem-sobolev-riesz-endpoint
uses: []
```

# gt:lem-sobolev-riemann-potential-exponential

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-riemann-potential-exponential
uses: []
```

# gt:lem-sobolev-newtonian-representation

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-newtonian-representation
uses: []
```

# gt:thm-sobolev-moser-trudinger

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-moser-trudinger
uses: []
```

# gt:cor-sobolev-moser-trudinger-higher-order

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:cor-sobolev-moser-trudinger-higher-order
uses: []
```

# gt:lem-sobolev-convex-average-estimate

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-convex-average-estimate
uses: []
```

# gt:thm-sobolev-morrey

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-morrey
uses: []
```

# gt:cor-sobolev-global-estimates

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:cor-sobolev-global-estimates
uses: []
```

# gt:sec-morrey-john-nirenberg

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:sec-morrey-john-nirenberg
uses: []
```

# gt:def-sobolev-morrey-space

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:def-sobolev-morrey-space
uses: []
```

# gt:prop-sobolev-morrey-inclusions

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:prop-sobolev-morrey-inclusions
uses: []
```

# gt:lem-sobolev-morrey-potential-bound

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-morrey-potential-bound
uses: []
```

# gt:thm-sobolev-morrey-growth

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-morrey-growth
uses: []
```

# gt:lem-sobolev-morrey-potential-exponential

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-morrey-potential-exponential
uses: []
```

# gt:thm-sobolev-john-nirenberg

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-john-nirenberg
uses: []
```

# gt:thm-sobolev-kondrachov

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-kondrachov
uses: []
```

# gt:cor-sobolev-kondrachov-higher-order

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:cor-sobolev-kondrachov-higher-order
uses: []
```

# gt:def-sobolev-difference-quotient

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:def-sobolev-difference-quotient
uses: []
```

# gt:lem-sobolev-difference-quotient-bound

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-difference-quotient-bound
uses: []
```

# gt:lem-sobolev-difference-quotient-criterion

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:lem-sobolev-difference-quotient-criterion
uses: []
```

# gt:thm-sobolev-extension

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-extension
uses: []
```

# gt:thm-sobolev-general-embedding

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-general-embedding
uses: []
```

# gt:thm-sobolev-interpolation-zero

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-interpolation-zero
uses: []
```

# gt:thm-sobolev-interpolation-domain

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch07-sobolev-spaces.tex#gt:thm-sobolev-interpolation-domain
uses: []
```
