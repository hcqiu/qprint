# gilbarg-trudinger.thm.10.1.comparison-principle

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.thm.10.1.comparison-principle
uses: []
```

# gilbarg-trudinger.thm.10.2.dirichlet-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.thm.10.2.dirichlet-uniqueness
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles#gilbarg-trudinger.thm.10.1.comparison-principle]]'
```

# gilbarg-trudinger.thm.10.3.apriori-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.thm.10.3.apriori-bound
uses: []
```

# gilbarg-trudinger.thm.10.4.aleksandrov-type-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.thm.10.4.aleksandrov-type-bound
uses: []
```

# gilbarg-trudinger.thm.10.5.integral-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.thm.10.5.integral-bound
uses: []
```

# gilbarg-trudinger.cor.10.6.prescribed-mean-curvature-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.cor.10.6.prescribed-mean-curvature-bound
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles#gilbarg-trudinger.thm.10.5.integral-bound]]'
```

# gilbarg-trudinger.ex.10.3.solution-dependent-counterexample

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.ex.10.3.solution-dependent-counterexample
uses: []
```

# gilbarg-trudinger.thm.10.7.comparison-divergence-form

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.thm.10.7.comparison-divergence-form
uses: []
```

# gilbarg-trudinger.lem.10.8.divergence-form-maximum-bound

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.lem.10.8.divergence-form-maximum-bound
uses: []
```

# gilbarg-trudinger.thm.10.9.divergence-form-apriori-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.thm.10.9.divergence-form-apriori-estimate
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles#gilbarg-trudinger.lem.10.8.divergence-form-maximum-bound]]'
```

# gilbarg-trudinger.thm.10.10.small-data-divergence-form-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch10-quasilinear-maximum-principles.tex#gilbarg-trudinger.thm.10.10.small-data-divergence-form-bound
uses: []
```
