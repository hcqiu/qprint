# thm:gt13-holder-gradient-13-1

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.tex#thm:gt13-holder-gradient-13-1
uses: []
```

# thm:gt13-holder-gradient-13-2

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.tex#thm:gt13-holder-gradient-13-2
uses: []
```

# thm:gt13-holder-gradient-13-3

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.tex#thm:gt13-holder-gradient-13-3
uses: []
```

# thm:gt13-holder-gradient-13-4

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.tex#thm:gt13-holder-gradient-13-4
uses: []
```

# lem:gt13-holder-gradient-13-5

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.tex#lem:gt13-holder-gradient-13-5
uses: []
```

# thm:gt13-holder-gradient-13-6

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.tex#thm:gt13-holder-gradient-13-6
uses: []
```

# thm:gt13-holder-gradient-13-7

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.tex#thm:gt13-holder-gradient-13-7
uses: []
```

# thm:gt13-holder-gradient-13-8

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch13-holder-gradient.tex#thm:gt13-holder-gradient-13-8
uses: []
```
