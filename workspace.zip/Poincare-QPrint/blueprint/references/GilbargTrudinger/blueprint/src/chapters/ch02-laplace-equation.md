# gt.thm2.1

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.1
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.1]]'
```

# gt.thm2.2

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.2
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.1]]'
```

# gt.thm2.3

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.3
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.3]]'
```

# gt.thm2.4

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.4
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.3]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.1]]'
```

# gt.thm2.5

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.5
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.1]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.5]]'
```

# gt.thm2.6

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.6
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.5]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.6]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.2]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.3]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.4]]'
```

# gt.thm2.7

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.7
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.6]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.2]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.3]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.4]]'
```

# gt.thm2.8

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.8
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.5]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.8]]'
```

# gt.thm2.9

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.9
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.5]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.8]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.9]]'
```

# gt.thm2.10

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.10
uses: []
```

# gt.thm2.11

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.11
uses: []
```

# gt.thm2.12

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.12
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.9]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.12]]'
```

# gt.lem2.13

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.lem2.13
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.thm2.12]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.lem2.13]]'
```

# gt.thm2.14

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation.tex#gt.thm2.14
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch02-laplace-equation#gt.lem2.13]]'
```
