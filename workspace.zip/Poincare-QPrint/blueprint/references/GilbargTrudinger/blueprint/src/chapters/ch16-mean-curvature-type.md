# gilbarg-trudinger.def.tangential-gradient

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.def.tangential-gradient
uses: []
```

# gilbarg-trudinger.lem.16.1.tangential-integration-by-parts

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.lem.16.1.tangential-integration-by-parts
uses: []
```

# gilbarg-trudinger.def.laplace-beltrami

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.def.laplace-beltrami
uses: []
```

# gilbarg-trudinger.lem.16.2.mean-value

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.lem.16.2.mean-value
uses: []
```

# gilbarg-trudinger.lem.16.3.potential-estimate

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.lem.16.3.potential-estimate
uses: []
```

# gilbarg-trudinger.lem.16.4.surface-morrey-estimate

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.lem.16.4.surface-morrey-estimate
uses: []
```

# gilbarg-trudinger.remark.compact-support-potential

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.remark.compact-support-potential
uses: []
```

# gilbarg-trudinger.thm.16.5.interior-gradient-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.5.interior-gradient-bound
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.lem.16.3.potential-estimate]]'
```

# gilbarg-trudinger.cor.16.6.nonnegative-gradient-bound

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.cor.16.6.nonnegative-gradient-bound
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.thm.16.5.interior-gradient-bound]]'
```

# gilbarg-trudinger.cor.16.7.higher-derivative-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.cor.16.7.higher-derivative-estimate
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.thm.16.5.interior-gradient-bound]]'
```

# gilbarg-trudinger.thm.16.8.minimal-surface-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.8.minimal-surface-dirichlet
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.cor.16.7.higher-derivative-estimate]]'
```

# gilbarg-trudinger.thm.16.9.conditional-dirichlet-solvability

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.9.conditional-dirichlet-solvability
uses: []
```

# gilbarg-trudinger.thm.16.10.prescribed-mean-curvature-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.10.prescribed-mean-curvature-dirichlet
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.thm.16.9.conditional-dirichlet-solvability]]'
```

# gilbarg-trudinger.thm.16.11.constant-mean-curvature-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.11.constant-mean-curvature-dirichlet
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.thm.16.9.conditional-dirichlet-solvability]]'
```

# gilbarg-trudinger.prop.16.mean-curvature-type-characterization

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.prop.16.mean-curvature-type-characterization
uses: []
```

# gilbarg-trudinger.thm.16.12.bernstein

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.12.bernstein
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.cor.16.19.quasiconformal-gauss-map-bernstein]]'
```

# gilbarg-trudinger.lem.16.surface-coarea

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.lem.16.surface-coarea
uses: []
```

# gilbarg-trudinger.lem.16.13.dirichlet-bound

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.lem.16.13.dirichlet-bound
uses: []
```

# gilbarg-trudinger.thm.16.14.dirichlet-decay

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.14.dirichlet-decay
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.lem.16.13.dirichlet-bound]]'
```

# gilbarg-trudinger.thm.16.15.quasiconformal-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.15.quasiconformal-holder
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.thm.16.14.dirichlet-decay]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.lem.16.4.surface-morrey-estimate]]'
```

# gilbarg-trudinger.lem.16.16.area-growth

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.lem.16.16.area-growth
uses: []
```

# gilbarg-trudinger.lem.16.17.local-connectivity

```qprint
kind: lemma
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.lem.16.17.local-connectivity
uses: []
```

# gilbarg-trudinger.thm.16.18.gauss-map-holder

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.18.gauss-map-holder
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.lem.16.17.local-connectivity]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.thm.16.15.quasiconformal-holder]]'
```

# gilbarg-trudinger.remark.16.101-consequences

```qprint
kind: other
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.remark.16.101-consequences
uses: []
```

# gilbarg-trudinger.cor.16.19.quasiconformal-gauss-map-bernstein

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.cor.16.19.quasiconformal-gauss-map-bernstein
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.thm.16.18.gauss-map-holder]]'
```

# gilbarg-trudinger.thm.16.20.interior-curvature-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.20.interior-curvature-estimate
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.thm.16.18.gauss-map-holder]]'
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.lem.16.17.local-connectivity]]'
```

# gilbarg-trudinger.thm.16.21.two-dimensional-gradient-estimate

```qprint
kind: theorem
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.thm.16.21.two-dimensional-gradient-estimate
uses:
- '[[references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type#gilbarg-trudinger.lem.16.17.local-connectivity]]'
```

# gilbarg-trudinger.def.16.113.parametric-functional

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.def.16.113.parametric-functional
uses: []
```

# gilbarg-trudinger.def.16.116.elliptic-parametric-functional

```qprint
kind: definition
status: not_started
tex: references/GilbargTrudinger/blueprint/src/chapters/ch16-mean-curvature-type.tex#gilbarg-trudinger.def.16.116.elliptic-parametric-functional
uses: []
```
