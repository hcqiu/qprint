# thm:kernel-estimates-ricci-lower-bound

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec02-kernel-estimates.tex#thm:kernel-estimates-ricci-lower-bound
uses: []
```

# rem:gradient-kernel-estimate

```qprint
kind: other
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec02-kernel-estimates.tex#rem:gradient-kernel-estimate
uses: []
```

# prop:coercive-hessian-estimate

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec02-kernel-estimates.tex#prop:coercive-hessian-estimate
uses: []
```

# prop:pointwise-sobolev-estimate

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec02-kernel-estimates.tex#prop:pointwise-sobolev-estimate
uses: []
```

# thm:ricci-lower-bound-pointwise-estimate

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec02-kernel-estimates.tex#thm:ricci-lower-bound-pointwise-estimate
uses: []
```
