# prop:relative-volume-estimates

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#prop:relative-volume-estimates
uses: []
```

# rem:relative-volume-star-shaped

```qprint
kind: other
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#rem:relative-volume-star-shaped
uses: []
```

# rem:ricci-models

```qprint
kind: other
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#rem:ricci-models
uses: []
```

# prop:refined-injectivity-angle-lower-estimates

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#prop:refined-injectivity-angle-lower-estimates
uses: []
```

# thm:local-injectivity-radius-bound

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#thm:local-injectivity-radius-bound
uses: []
```

# lem:radial-class-concatenation

```qprint
kind: lemma
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#lem:radial-class-concatenation
uses: []
```

# lem:even-covering

```qprint
kind: lemma
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#lem:even-covering
uses: []
```

# lem:iterated-geodesic-loops

```qprint
kind: lemma
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#lem:iterated-geodesic-loops
uses: []
```

# thm:injectivity-radius-relative-volume

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#thm:injectivity-radius-relative-volume
uses: []
```

# thm:asymptotic-ricci-compactness

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#thm:asymptotic-ricci-compactness
uses: []
```

# thm:asymptotic-ricci-volume-growth

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#thm:asymptotic-ricci-volume-growth
uses:
- '[[references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity#prop:relative-volume-estimates]]'
```

# rem:sharpness-volume-growth-estimates

```qprint
kind: other
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec04-volume-injectivity.tex#rem:sharpness-volume-growth-estimates
uses: []
```
