# thm:c0-bounded-geometry-kernel-estimates

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec03-bounded-geometry.tex#thm:c0-bounded-geometry-kernel-estimates
uses:
- '[[references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed#cor:derivative-tail-estimate]]'
```

# cor:c0-bounded-geometry-exponential-decay

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec03-bounded-geometry.tex#cor:c0-bounded-geometry-exponential-decay
uses:
- '[[references/CheegerGromovTaylor/blueprint/src/chapters/sec03-bounded-geometry#thm:c0-bounded-geometry-kernel-estimates]]'
```

# thm:pdo-representation-of-functional-calculus

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec03-bounded-geometry.tex#thm:pdo-representation-of-functional-calculus
uses: []
```

# def:holomorphic-strip-symbol-class

```qprint
kind: definition
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec03-bounded-geometry.tex#def:holomorphic-strip-symbol-class
uses: []
```

# thm:lp-continuity-strip-holomorphic-symbols

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec03-bounded-geometry.tex#thm:lp-continuity-strip-holomorphic-symbols
uses: []
```
