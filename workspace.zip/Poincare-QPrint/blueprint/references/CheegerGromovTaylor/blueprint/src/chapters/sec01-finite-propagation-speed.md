# def:finite-propagation-class

```qprint
kind: definition
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed.tex#def:finite-propagation-class
uses: []
```

# prop:tail-estimate

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed.tex#prop:tail-estimate
uses: []
```

# cor:derivative-tail-estimate

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed.tex#cor:derivative-tail-estimate
uses: []
```

# prop:local-elliptic-estimate

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed.tex#prop:local-elliptic-estimate
uses: []
```

# thm:kernel-estimates-bounded-curvature

```qprint
kind: theorem
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed.tex#thm:kernel-estimates-bounded-curvature
uses:
- '[[references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed#prop:local-elliptic-estimate]]'
- '[[references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed#cor:derivative-tail-estimate]]'
```

# rem:sectional-curvature-kernel-estimate

```qprint
kind: other
status: not_started
tex: references/CheegerGromovTaylor/blueprint/src/chapters/sec01-finite-propagation-speed.tex#rem:sectional-curvature-kernel-estimate
uses: []
```
