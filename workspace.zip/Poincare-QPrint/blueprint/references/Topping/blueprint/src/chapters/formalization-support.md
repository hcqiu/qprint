# topping-ch10-perelman-reference

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-ch10-perelman-reference
uses: []
```

# topping-ch8-classical-entropy-link

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-ch8-classical-entropy-link
uses: []
```

# topping-ch8-no-collapsing-perelman

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-ch8-no-collapsing-perelman
uses: []
```

# topping-ch8-no-collapsing-variant

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-ch8-no-collapsing-variant
uses: []
```

# topping-gradient-flow-volume-preserving-remark

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-gradient-flow-volume-preserving-remark
uses: []
```

# topping-intro-cigar-soliton

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-intro-cigar-soliton
uses: []
```

# topping-maxpr-curvature-doubling

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-maxpr-curvature-doubling
uses: []
```

# topping-maxpr-perelman-volume

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-maxpr-perelman-volume
uses: []
```

# topping-maxpr-preserved-curvature-conditions

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-maxpr-preserved-curvature-conditions
uses: []
```

# topping-pde-principal-symbol-fourier-convention

```qprint
kind: other
status: not_started
tex: references/Topping/blueprint/src/chapters/formalization-support.tex#topping-pde-principal-symbol-fourier-convention
uses: []
```
