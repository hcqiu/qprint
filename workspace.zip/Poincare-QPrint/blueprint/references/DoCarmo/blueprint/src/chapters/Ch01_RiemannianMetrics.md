# chap:dc-riemannian-metrics

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#chap:dc-riemannian-metrics
uses: []
```

# def:dc-ch1-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:dc-ch1-2-1
uses: []
```

# def:dc-ch1-2-2

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:dc-ch1-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
```

# def:dc-ch1-2-3

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:dc-ch1-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-2]]'
```

# ex:dc-ch1-2-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:dc-ch1-2-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
```

# ex:dc-ch1-2-5

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:dc-ch1-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:dc-ch1-2-4]]'
```

# ex:dc-ch1-2-6

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:dc-ch1-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#prop:dc-ch0-5-4]]'
```

# prop:dc-ch1-2-6-leftinv

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#prop:dc-ch1-2-6-leftinv
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
```

# ex:dc-ch1-2-7

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:dc-ch1-2-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:dc-ch1-2-5]]'
```

# def:dc-ch1-2-8

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:dc-ch1-2-8
uses: []
```

# def:dc-ch1-2-9

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:dc-ch1-2-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-8]]'
```

# lem:dc-ch1-2-9-isom

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#lem:dc-ch1-2-9-isom
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-9]]'
```

# prop:dc-ch1-2-10

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#prop:dc-ch1-2-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#thm:dc-ch0-5-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:dc-ch1-2-4]]'
```

# rem:dc-ch1-2-11

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:dc-ch1-2-11
uses:
- '[[references/DoCarmo/blueprint/src/chapters/formalization-support#lem:dc-ch1-2-11-pointwise]]'
```

# rem:dc-ch1-2-12

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:dc-ch1-2-12
uses: []
```
