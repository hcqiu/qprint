# chap:dc-jacobi-fields

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#chap:dc-jacobi-fields
uses: []
```

# def:dc-ch5-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#def:dc-ch5-2-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-parallel-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-ode]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-frame-reduction]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-frame-existence]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-real-curvature]]'
```

# lem:dc-ch5-2-1-parallel-frame

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-1-parallel-frame
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-1-coord]]'
```

# lem:dc-ch5-2-1-ode

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-1-ode
uses: []
```

# lem:dc-ch5-2-1-frame-reduction

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-1-frame-reduction
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-parallel-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#prop:dc-ch2-2-2]]'
```

# lem:dc-ch5-2-1-frame-existence

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-1-frame-existence
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-parallel-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-ode]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-frame-reduction]]'
```

# lem:dc-ch5-2-1-real-curvature

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-1-real-curvature
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-frame-existence]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#rem:dc-ch4-2-6]]'
```

# rem:dc-ch5-2-2

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#rem:dc-ch5-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# ex:dc-ch5-2-3

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#ex:dc-ch5-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#lem:dc-ch4-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-3-const-form]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-3-jacobi-op]]'
```

# lem:dc-ch5-2-3-const-form

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-3-const-form
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#lem:dc-ch4-3-4]]'
```

# lem:dc-ch5-2-3-jacobi-op

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-3-jacobi-op
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-3-const-form]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-9]]'
```

# prop:dc-ch5-2-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#prop:dc-ch5-2-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# cor:dc-ch5-2-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#cor:dc-ch5-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# rem:dc-ch5-2-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#rem:dc-ch5-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-2-4]]'
```

# lem:dc-ch5-2-7-taylor-ode

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-7-taylor-ode
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch5-2-7-frame-smooth

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-7-frame-smooth
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-parallel-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-real-curvature]]'
```

# prop:dc-ch5-2-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#prop:dc-ch5-2-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-7-taylor-ode]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-7-frame-smooth]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# rem:dc-ch5-2-8

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#rem:dc-ch5-2-8
uses: []
```

# cor:dc-ch5-2-9

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#cor:dc-ch5-2-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-2-7]]'
```

# lem:dc-ch5-2-10-sqrt

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#lem:dc-ch5-2-10-sqrt
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-9]]'
```

# cor:dc-ch5-2-10

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#cor:dc-ch5-2-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-2-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-10-sqrt]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-9]]'
```

# rem:dc-ch5-2-11

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#rem:dc-ch5-2-11
uses: []
```

# def:dc-ch5-3-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#def:dc-ch5-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# rem:dc-ch5-3-2

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#rem:dc-ch5-3-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#rem:dc-ch5-2-2]]'
```

# ex:dc-ch5-3-3

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#ex:dc-ch5-3-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#ex:dc-ch5-2-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#rem:dc-ch5-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-5]]'
```

# def:dc-ch5-3-4

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#def:dc-ch5-3-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-1]]'
```

# prop:dc-ch5-3-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#prop:dc-ch5-3-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-1]]'
```

# prop:dc-ch5-3-6

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#prop:dc-ch5-3-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# cor:dc-ch5-3-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#cor:dc-ch5-3-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-6]]'
```

# cor:dc-ch5-3-8

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#cor:dc-ch5-3-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#rem:dc-ch5-3-2]]'
```

# prop:dc-ch5-3-9

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#prop:dc-ch5-3-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-1]]'
```

# cor:dc-ch5-3-10

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#cor:dc-ch5-3-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-3-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-1]]'
```

# ex:dc-ch5-3-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields.tex#ex:dc-ch5-3-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-4]]'
```
