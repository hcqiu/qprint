# chap:dc-sphere-theorem

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#chap:dc-sphere-theorem
uses: []
```

# thm:dc-ch13-1-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#thm:dc-ch13-1-1
uses: []
```

# prop:dc-ch13-2-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#prop:dc-ch13-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-9]]'
```

# ex:dc-ch13-2-3

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#ex:dc-ch13-2-3
uses: []
```

# ex:dc-ch13-2-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#ex:dc-ch13-2-4
uses: []
```

# ex:dc-ch13-2-5

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#ex:dc-ch13-2-5
uses: []
```

# rem:dc-ch13-2-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#rem:dc-ch13-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#ex:dc-ch13-2-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#ex:dc-ch13-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#ex:dc-ch13-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-2]]'
```

# cor:dc-ch13-2-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#cor:dc-ch13-2-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-2]]'
```

# cor:dc-ch13-2-8

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#cor:dc-ch13-2-8
uses: []
```

# prop:dc-ch13-2-9

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#prop:dc-ch13-2-9
uses: []
```

# cor:dc-ch13-2-10

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#cor:dc-ch13-2-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-9]]'
```

# cor:dc-ch13-2-11

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#cor:dc-ch13-2-11
uses: []
```

# prop:dc-ch13-2-12

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#prop:dc-ch13-2-12
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-2]]'
```

# prop:dc-ch13-2-13

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#prop:dc-ch13-2-13
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#prop:dc-ch10-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-12]]'
```

# prop:dc-ch13-3-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#prop:dc-ch13-3-1
uses: []
```

# lem:dc-ch13-3-2

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#lem:dc-ch13-3-2
uses: []
```

# lem:dc-ch13-3-3

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#lem:dc-ch13-3-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-13]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-12]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#lem:dc-ch13-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#cor:dc-ch13-2-10]]'
```

# prop:dc-ch13-3-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#prop:dc-ch13-3-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-2-12]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#ex:dc-ch13-2-4]]'
```

# rem:dc-ch13-3-5

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#rem:dc-ch13-3-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#prop:dc-ch13-3-4]]'
```

# lem:dc-ch13-4-1

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#lem:dc-ch13-4-1
uses: []
```

# lem:dc-ch13-4-2

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#lem:dc-ch13-4-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#ex:dc-ch13-2-5]]'
```

# lem:dc-ch13-4-3

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#lem:dc-ch13-4-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#lem:dc-ch13-4-2]]'
```

# rem:dc-ch13-4-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#rem:dc-ch13-4-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#thm:dc-ch13-1-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#lem:dc-ch13-4-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem#lem:dc-ch13-4-3]]'
```

# rem:dc-ch13-2-1

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch13_SphereTheorem.tex#rem:dc-ch13-2-1
uses: []
```
