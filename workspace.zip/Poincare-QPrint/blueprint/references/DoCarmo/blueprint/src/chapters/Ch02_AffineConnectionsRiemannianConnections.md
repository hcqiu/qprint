# chap:dc-affine-connections-riemannian-connections

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#chap:dc-affine-connections-riemannian-connections
uses: []
```

# def:dc-ch2-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#def:dc-ch2-2-1
uses: []
```

# prop:dc-ch2-2-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#prop:dc-ch2-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-coord]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-c-coord]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-c-bridge]]'
```

# lem:dc-ch2-2-2-coord

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-2-2-coord
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-7-christoffel]]'
```

# lem:dc-ch2-2-2-c-coord

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-2-2-c-coord
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-coord]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-7-christoffel]]'
```

# lem:dc-ch2-2-2-c-formula10

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-2-2-c-formula10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-koszul]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-7-christoffel]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#thm:dc-ch2-3-6]]'
```

# lem:dc-ch2-2-2-c-bridge

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-2-2-c-bridge
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-c-coord]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-c-formula10]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#thm:dc-ch2-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-7-christoffel]]'
```

# rem:dc-ch2-2-3

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#rem:dc-ch2-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#rem:dc-ch0-5-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-1]]'
```

# rem:dc-ch2-2-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#rem:dc-ch2-2-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#prop:dc-ch2-2-2]]'
```

# def:dc-ch2-2-5

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#def:dc-ch2-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-coord]]'
```

# lem:dc-ch2-2-6-coeff

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-2-6-coeff
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-5]]'
```

# prop:dc-ch2-2-6

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#prop:dc-ch2-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-exist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-unique]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-transport]]'
```

# lem:dc-ch2-2-6-exist

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-2-6-exist
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-coeff]]'
```

# lem:dc-ch2-2-6-unique

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-2-6-unique
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-coord]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-coeff]]'
```

# lem:dc-ch2-2-6-transport

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-2-6-transport
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-exist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-unique]]'
```

# def:dc-ch2-3-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#def:dc-ch2-3-1
uses: []
```

# prop:dc-ch2-3-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#prop:dc-ch2-3-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#prop:dc-ch2-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-2-coord]]'
```

# cor:dc-ch2-3-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#cor:dc-ch2-3-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#prop:dc-ch2-3-2]]'
```

# lem:dc-ch2-3-2-coord

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-3-2-coord
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-coord]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-7-christoffel]]'
```

# lem:dc-ch2-3-1-coord

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-3-1-coord
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-2-coord]]'
```

# def:dc-ch2-3-4

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#def:dc-ch2-3-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-1]]'
```

# rem:dc-ch2-3-5

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#rem:dc-ch2-3-5
uses: []
```

# lem:dc-ch2-3-6-koszul

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-3-6-koszul
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#cor:dc-ch2-3-3]]'
```

# lem:dc-ch2-tangent-extension

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-tangent-extension
uses: []
```

# lem:dc-ch2-3-6-unique

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-3-6-unique
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-koszul]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-tangent-extension]]'
```

# lem:dc-ch2-3-6-welldef

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-3-6-welldef
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-koszul]]'
```

# lem:dc-ch2-3-6-affine

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-3-6-affine
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-welldef]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-koszul]]'
```

# lem:dc-ch2-3-6-exist

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#lem:dc-ch2-3-6-exist
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-koszul]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-welldef]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-tangent-extension]]'
```

# thm:dc-ch2-3-6

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#thm:dc-ch2-3-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#cor:dc-ch2-3-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-koszul]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-unique]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-welldef]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-6-exist]]'
```

# def:dc-ch2-3-7-christoffel

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#def:dc-ch2-3-7-christoffel
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
```

# rem:dc-ch2-3-7

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#rem:dc-ch2-3-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#thm:dc-ch2-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-7-christoffel]]'
```

# prop:dc-ch2-2-6-riemannian

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections.tex#prop:dc-ch2-2-6-riemannian
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-exist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-unique]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-6-transport]]'
```
