# chap:dc-spaces-of-constant-curvature

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#chap:dc-spaces-of-constant-curvature
uses: []
```

# lem:dc-ch8-2-1-jacobi-transfer

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-transfer
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-jacobi-transfer-const

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-transfer-const
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-transfer]]'
```

# lem:dc-ch8-2-1-velocity-frame

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-velocity-frame
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-parallel-ortho-frame

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-parallel-ortho-frame
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-transported-frame

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-transported-frame
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-parallel-ortho-frame]]'
```

# lem:dc-ch8-2-1-parallel-transport-map

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-parallel-transport-map
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-phi

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-phi
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-parallel-transport-map]]'
```

# lem:dc-ch8-2-1-curvature-bridge

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-curvature-bridge
uses: []
```

# lem:dc-ch8-2-1-hmatch-transfer

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-hmatch-transfer
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-curvature-bridge]]'
```

# lem:dc-ch8-2-1-frame-coeff-bridge

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-frame-coeff-bridge
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-parallel-ortho-frame]]'
```

# lem:dc-ch8-2-1-jacobi-norm-transfer-general

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-norm-transfer-general
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-frame-coeff-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-hmatch-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-frame-chart-interface

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-frame-chart-interface
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-hmatch-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-transported-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-parallel-transport-map]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-phi]]'
```

# lem:dc-ch8-2-1-jacobi-norm-transfer-manifold

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-norm-transfer-manifold
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-frame-chart-interface]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer-general]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-parallel-ortho-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-jacobi-reversal

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-reversal
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-jacobi-backward-uniqueness

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-backward-uniqueness
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-reversal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-jacobi-interior-data

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-interior-data
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-backward-uniqueness]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-exp-norm-transfer-general

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-exp-norm-transfer-general
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-interior-data]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-polarization]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-equiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-mfderiv-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-2-semiconjugacy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate]]'
```

# lem:dc-ch8-2-1-metric-ortho-basis

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-metric-ortho-basis
uses: []
```

# lem:dc-ch8-2-1-cartan-frame-data

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-cartan-frame-data
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-phi]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-transported-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-parallel-transport-map]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-metric-ortho-basis]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-velocity-frame]]'
```

# lem:dc-ch8-2-1-exp-norm-transfer-general-discharged

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-exp-norm-transfer-general-discharged
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer-general]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-cartan-frame-data]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-normal]]'
```

# lem:dc-ch8-2-1-local-isometry-packaging

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-local-isometry-packaging
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer-general-discharged]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-single-chart]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-diff-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/formalization-support#lem:dc-ch8-2-1-window-transfer]]'
```

# lem:dc-ch8-2-1-window

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-window
uses: []
```

# lem:dc-ch8-2-1-single-chart

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-single-chart
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-frame-chart-interface]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer-general]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/formalization-support#lem:dc-ch8-2-1-chart-partition]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-radial-chart]]'
```

# lem:dc-ch8-2-1-jacobi-const-solution

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-const-solution
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-jacobi-norm-transfer

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-jacobi-norm-transfer
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-const-solution]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-exp-norm-transfer

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-exp-norm-transfer
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
```

# lem:dc-ch8-2-1-no-conjugate

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-no-conjugate
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-const-solution]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-1]]'
```

# lem:dc-ch8-2-1-exp-local-diffeo

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-exp-local-diffeo
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-equiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-2]]'
```

# lem:dc-ch8-2-1-no-conjugate-normal

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-no-conjugate-normal
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-local-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-mfderiv-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-5]]'
```

# lem:dc-ch8-2-1-polarization

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-polarization
uses: []
```

# lem:dc-ch8-2-1-exp-equiv

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-exp-equiv
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-5]]'
```

# lem:dc-ch8-2-1-mfderiv-bridge

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-mfderiv-bridge
uses: []
```

# lem:dc-ch8-2-1-exp-diff-zero

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-exp-diff-zero
uses: []
```

# lem:dc-ch8-2-1-no-conjugate-zero

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-no-conjugate-zero
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-mfderiv-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-diff-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-5]]'
```

# lem:dc-ch8-2-1-no-conjugate-ball

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-no-conjugate-ball
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-local-diffeo]]'
```

# lem:dc-ch8-2-1-exp-norm-transfer-mfderiv

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-exp-norm-transfer-mfderiv
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-mfderiv-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-equiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-const-solution]]'
```

# lem:dc-ch8-2-2-semiconjugacy

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-2-semiconjugacy
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer-mfderiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-diff-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-polarization]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-local-diffeo]]'
```

# thm:dc-ch8-2-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#thm:dc-ch8-2-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#cor:dc-ch5-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-parallel-ortho-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-transported-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-hmatch-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-curvature-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-frame-coeff-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer-general]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-frame-chart-interface]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-single-chart]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer-general]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-phi]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-parallel-transport-map]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-equiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-local-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-polarization]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-mfderiv-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-diff-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer-mfderiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-reversal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-backward-uniqueness]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-interior-data]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-local-isometry-packaging]]'
```

# cor:dc-ch8-2-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#cor:dc-ch8-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-transfer-const]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-velocity-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-const-solution]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-equiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-local-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-polarization]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-mfderiv-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-diff-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer-mfderiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-2-semiconjugacy]]'
```

# cor:dc-ch8-2-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#cor:dc-ch8-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-transfer-const]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-velocity-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-jacobi-const-solution]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-equiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-local-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-polarization]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-mfderiv-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-diff-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-zero]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer-mfderiv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-2-semiconjugacy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#cor:dc-ch8-2-2]]'
```

# def:dc-ch8-3-hyperbolic-space

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#def:dc-ch8-3-hyperbolic-space
uses: []
```

# lem:dc-ch8-3-conformal-curvature

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-conformal-curvature
uses: []
```

# lem:dc-ch8-3-chart-curvature

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-chart-curvature
uses: []
```

# lem:dc-ch8-3-hyperbolic-chart-gram

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-hyperbolic-chart-gram
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-3-hyperbolic-space]]'
```

# lem:dc-ch8-3-hyperbolic-christoffel

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-hyperbolic-christoffel
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-hyperbolic-chart-gram]]'
```

# lem:dc-ch8-3-inverse-gram-coord

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-inverse-gram-coord
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-hyperbolic-chart-gram]]'
```

# lem:dc-ch8-3-pointwise-curvature-form

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-pointwise-curvature-form
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-chart-curvature]]'
```

# prop:dc-ch8-3-const-curv

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#prop:dc-ch8-3-const-curv
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-conformal-curvature]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-chart-curvature]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-pointwise-curvature-form]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-hyperbolic-chart-gram]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-hyperbolic-christoffel]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-inverse-gram-coord]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#cor:dc-ch4-3-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-3-hyperbolic-space]]'
```

# lem:dc-ch8-3-christoffel-contraction

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-christoffel-contraction
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-hyperbolic-christoffel]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-inverse-gram-coord]]'
```

# lem:dc-ch8-3-geodesic-equation

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-geodesic-equation
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-christoffel-contraction]]'
```

# lem:dc-ch8-3-vertical-geodesic

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-vertical-geodesic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-geodesic-equation]]'
```

# lem:dc-ch8-3-semicircle-geodesic

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-3-semicircle-geodesic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-geodesic-equation]]'
```

# prop:dc-ch8-3-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#prop:dc-ch8-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#ex:dc-ch3-3-10]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-geodesic-equation]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-vertical-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-3-semicircle-geodesic]]'
```

# thm:dc-ch8-4-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#thm:dc-ch8-4-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#thm:dc-ch8-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-4-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#prop:dc-ch8-3-const-curv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-1-covering-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-1-covering-simplyconnected]]'
```

# lem:dc-ch8-4-2-geodesic-push

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-4-2-geodesic-push
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
```

# lem:dc-ch8-4-2-agree-locus

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-4-2-agree-locus
uses: []
```

# lem:dc-ch8-4-2-propagation

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-4-2-propagation
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-4-2-geodesic-push]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-expmap-ray]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-2-2]]'
```

# lem:dc-ch8-4-2

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-4-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-4-2-agree-locus]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-4-2-propagation]]'
```

# prop:dc-ch8-4-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#prop:dc-ch8-4-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#thm:dc-ch8-4-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-1-covering-simplyconnected]]'
```

# prop:dc-ch8-4-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#prop:dc-ch8-4-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#prop:dc-ch8-4-3]]'
```

# prop:dc-ch8-4-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#prop:dc-ch8-4-5
uses: []
```

# def:dc-ch8-5-conformal

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#def:dc-ch8-5-conformal
uses: []
```

# lem:dc-ch8-5-conformal-angle

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-5-conformal-angle
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-5-conformal]]'
```

# ex:dc-ch8-5-1

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#ex:dc-ch8-5-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-5-conformal]]'
```

# lem:dc-ch8-5-conformal-comp

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-5-conformal-comp
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-5-conformal]]'
```

# thm:dc-ch8-5-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#thm:dc-ch8-5-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/formalization-support#lem:dc-ch8-5-differential-core]]'
```

# thm:dc-ch8-5-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#thm:dc-ch8-5-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-5-conformal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-3-hyperbolic-space]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#cor:dc-ch8-2-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#thm:dc-ch8-5-2]]'
```

# rem:dc-ch8-5-4

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#rem:dc-ch8-5-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-5-conformal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-3-hyperbolic-space]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#thm:dc-ch8-5-3]]'
```

# lem:dc-ch8-2-1-radial-chart

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature.tex#lem:dc-ch8-2-1-radial-chart
uses: []
```
