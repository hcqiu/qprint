# chap:dc-rauch-comparison-theorem

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#chap:dc-rauch-comparison-theorem
uses: []
```

# lem:dc-ch10-2-1

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#lem:dc-ch10-2-1
uses: []
```

# lem:dc-ch10-2-2

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#lem:dc-ch10-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#lem:dc-ch10-2-1]]'
```

# thm:dc-ch10-2-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#thm:dc-ch10-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#lem:dc-ch10-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-6]]'
```

# prop:dc-ch10-2-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#prop:dc-ch10-2-4
uses: []
```

# prop:dc-ch10-2-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#prop:dc-ch10-2-5
uses: []
```

# rem:dc-ch10-2-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#rem:dc-ch10-2-6
uses: []
```

# rem:dc-ch10-2-7

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#rem:dc-ch10-2-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#rem:dc-ch9-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#rem:dc-ch10-2-6]]'
```

# thm:dc-ch10-3-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#thm:dc-ch10-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#lem:dc-ch10-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#lem:dc-ch10-3-3]]'
```

# lem:dc-ch10-3-2

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#lem:dc-ch10-3-2
uses: []
```

# lem:dc-ch10-3-3

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#lem:dc-ch10-3-3
uses: []
```

# cor:dc-ch10-3-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#cor:dc-ch10-3-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#rem:dc-ch10-2-7]]'
```

# cor:dc-ch10-3-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#cor:dc-ch10-3-5
uses: []
```

# rem:dc-ch10-3-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#rem:dc-ch10-3-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#thm:dc-ch10-3-1]]'
```

# rem:dc-ch10-3-7

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#rem:dc-ch10-3-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#thm:dc-ch10-3-1]]'
```

# rem:dc-ch10-3-8

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#rem:dc-ch10-3-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#thm:dc-ch10-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#rem:dc-ch10-2-7]]'
```

# lem:dc-ch10-4-1

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#lem:dc-ch10-4-1
uses: []
```

# def:dc-ch10-4-2

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#def:dc-ch10-4-2
uses: []
```

# ex:dc-ch10-4-3

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#ex:dc-ch10-4-3
uses: []
```

# prop:dc-ch10-4-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#prop:dc-ch10-4-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#lem:dc-ch10-4-1]]'
```

# def:dc-ch10-4-5

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#def:dc-ch10-4-5
uses: []
```

# ex:dc-ch10-4-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#ex:dc-ch10-4-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#prop:dc-ch10-4-4]]'
```

# def:dc-ch10-4-7

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#def:dc-ch10-4-7
uses: []
```

# lem:dc-ch10-4-8

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#lem:dc-ch10-4-8
uses: []
```

# thm:dc-ch10-4-9

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem.tex#thm:dc-ch10-4-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#lem:dc-ch10-4-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#thm:dc-ch10-2-3]]'
```
