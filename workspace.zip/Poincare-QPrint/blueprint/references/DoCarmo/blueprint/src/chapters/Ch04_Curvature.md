# chap:dc-curvature

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#chap:dc-curvature
uses: []
```

# def:dc-ch4-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#def:dc-ch4-2-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-1]]'
```

# prop:dc-ch4-2-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#prop:dc-ch4-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
```

# rem:dc-ch4-2-3

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#rem:dc-ch4-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#rem:dc-ch4-2-6]]'
```

# prop:dc-ch4-2-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#prop:dc-ch4-2-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-3-jacobi]]'
```

# prop:dc-ch4-2-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#prop:dc-ch4-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#cor:dc-ch2-3-3]]'
```

# rem:dc-ch4-2-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#rem:dc-ch4-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#rem:dc-ch2-2-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-7-christoffel]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
```

# prop:dc-ch4-3-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#prop:dc-ch4-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-3-2]]'
```

# def:dc-ch4-3-2

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#def:dc-ch4-3-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
```

# lem:dc-ch4-3-3

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#lem:dc-ch4-3-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
```

# lem:dc-ch4-3-4

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#lem:dc-ch4-3-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#lem:dc-ch4-3-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
```

# cor:dc-ch4-3-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#cor:dc-ch4-3-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#lem:dc-ch4-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#lem:dc-ch4-3-3]]'
```

# def:dc-ch4-4-ricci-form

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#def:dc-ch4-4-ricci-form
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
```

# prop:dc-ch4-4-ricci-symm

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#prop:dc-ch4-4-ricci-symm
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-4-ricci-form]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
```

# def:dc-ch4-4-scalar

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#def:dc-ch4-4-scalar
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-4-ricci-form]]'
```

# lem:dc-ch4-4-1

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#lem:dc-ch4-4-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#prop:dc-ch2-2-2]]'
```

# def:dc-ch4-5-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#def:dc-ch4-5-1
uses: []
```

# ex:dc-ch4-5-2

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#ex:dc-ch4-5-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-5-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
```

# ex:dc-ch4-5-3

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#ex:dc-ch4-5-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-5-1]]'
```

# ex:dc-ch4-5-4

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#ex:dc-ch4-5-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-5-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-1]]'
```

# rem:dc-ch4-5-5

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#rem:dc-ch4-5-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-5-1]]'
```

# rem:dc-ch4-5-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#rem:dc-ch4-5-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#rem:dc-ch4-5-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#ex:dc-ch4-5-3]]'
```

# def:dc-ch4-5-7

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#def:dc-ch4-5-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-5-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-2-1]]'
```

# ex:dc-ch4-5-8

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#ex:dc-ch4-5-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-5-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#ex:dc-ch4-5-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-1]]'
```

# ex:dc-ch4-5-9

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch04_Curvature.tex#ex:dc-ch4-5-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#rem:dc-ch4-5-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-5-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-1]]'
```
