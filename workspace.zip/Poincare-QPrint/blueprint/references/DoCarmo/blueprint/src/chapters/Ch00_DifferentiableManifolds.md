# chap:dc-differentiable-manifolds

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#chap:dc-differentiable-manifolds
uses: []
```

# def:dc-ch0-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#def:dc-ch0-2-1
uses: []
```

# rem:dc-ch0-2-2

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#rem:dc-ch0-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-1]]'
```

# rem:dc-ch0-2-3

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#rem:dc-ch0-2-3
uses: []
```

# ex:dc-ch0-2-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-2-4
uses: []
```

# def:dc-ch0-2-5

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#def:dc-ch0-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-1]]'
```

# def:dc-ch0-2-6

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#def:dc-ch0-2-6
uses: []
```

# prop:dc-ch0-2-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#prop:dc-ch0-2-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-6]]'
```

# def:dc-ch0-2-8

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#def:dc-ch0-2-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#prop:dc-ch0-2-7]]'
```

# def:dc-ch0-2-9

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#def:dc-ch0-2-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-5]]'
```

# lem:dc-ch0-2-9-iso

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-2-9-iso
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-8]]'
```

# thm:dc-ch0-2-10

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#thm:dc-ch0-2-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-9]]'
```

# def:dc-ch0-3-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#def:dc-ch0-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-8]]'
```

# ex:dc-ch0-3-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-3-6
uses: []
```

# prop:dc-ch0-3-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#prop:dc-ch0-3-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-3-7-embedding]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-3-7-normalform]]'
```

# lem:dc-ch0-3-7-embedding

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-3-7-embedding
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-3-1]]'
```

# lem:dc-ch0-3-7-normalform

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-3-7-normalform
uses: []
```

# ex:dc-ch0-4-1

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-4-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#def:dc-ch0-2-1]]'
```

# lem:dc-ch0-4-1-manifold

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-4-1-manifold
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#ex:dc-ch0-4-1]]'
```

# ex:dc-ch0-4-2

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-4-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#ex:dc-ch0-3-6]]'
```

# ex:dc-ch0-4-3

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-4-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#ex:dc-ch0-4-2]]'
```

# def:dc-ch0-4-4

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#def:dc-ch0-4-4
uses: []
```

# ex:dc-ch0-4-5

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-4-5
uses: []
```

# ex:dc-ch0-4-7

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-4-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#ex:dc-ch0-2-4]]'
```

# ex:dc-ch0-4-8

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-4-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#ex:dc-ch0-4-7]]'
```

# def:dc-ch0-5-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#def:dc-ch0-5-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#ex:dc-ch0-4-1]]'
```

# lem:dc-ch0-5-2

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2-unique]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2-commutator]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2-smooth]]'
```

# lem:dc-ch0-5-2-commutator

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-2-commutator
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# lem:dc-ch0-5-2-unique

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-2-unique
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# lem:dc-ch0-5-2-smooth

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-2-smooth
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# lem:dc-ch0-5-3-antisymm

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-3-antisymm
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# lem:dc-ch0-5-3-jacobi

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-3-jacobi
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# lem:dc-ch0-5-3-jacobi-cyclic

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-3-jacobi-cyclic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-3-jacobi]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-3-antisymm]]'
```

# lem:dc-ch0-5-3-bilinear

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-3-bilinear
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# lem:dc-ch0-5-3-leibniz

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-3-leibniz
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# prop:dc-ch0-5-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#prop:dc-ch0-5-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-3-antisymm]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-3-jacobi-cyclic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-3-bilinear]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-3-leibniz]]'
```

# prop:dc-ch0-5-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#prop:dc-ch0-5-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# lem:dc-ch0-5-5

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-5
uses: []
```

# thm:dc-ch0-5-6

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#thm:dc-ch0-5-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-6-exists]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-6-onlyif-complete]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-6-component]]'
```

# lem:dc-ch0-5-6-sigmacompact-core

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-sigmacompact-core
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#thm:dc-ch0-5-6]]'
```

# lem:dc-ch0-5-6-onlyif

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-onlyif
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-6-sigmacompact-core]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#thm:dc-ch0-5-6]]'
```

# lem:dc-ch0-5-6-onlyif-pou

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-onlyif-pou
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-6-onlyif]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#thm:dc-ch0-5-6]]'
```

# lem:dc-ch0-5-6-hausdorff

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-hausdorff
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#thm:dc-ch0-5-6]]'
```

# lem:dc-ch0-5-6-onlyif-complete

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-onlyif-complete
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-6-hausdorff]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-6-onlyif-pou]]'
```

# lem:dc-ch0-5-6-exists

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-exists
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#thm:dc-ch0-5-6]]'
```

# lem:dc-ch0-5-6-sum

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-sum
uses: []
```

# rem:dc-ch0-5-7

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#rem:dc-ch0-5-7
uses: []
```

# ex:dc-ch0-3-2

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-3-2
uses: []
```

# ex:dc-ch0-3-3

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-3-3
uses: []
```

# ex:dc-ch0-3-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-3-4
uses: []
```

# ex:dc-ch0-3-5

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-3-5
uses: []
```

# ex:dc-ch0-4-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-4-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#ex:dc-ch0-4-5]]'
```

# ex:dc-ch0-4-9

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#ex:dc-ch0-4-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#ex:dc-ch0-4-8]]'
```

# lem:dc-ch0-5-6-component

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-component
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-6-fixed-cover]]'
```

# lem:dc-ch0-5-6-fixed-cover

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds.tex#lem:dc-ch0-5-6-fixed-cover
uses: []
```
