# chap:dc-complete-manifolds-hopf-rinow-hadamard

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#chap:dc-complete-manifolds-hopf-rinow-hadamard
uses: []
```

# def:dc-ch7-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#def:dc-ch7-2-1
uses: []
```

# def:dc-ch7-2-2

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#def:dc-ch7-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
```

# lem:dc-ch7-2-3-geodesic-push

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-3-geodesic-push
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-rays-are-geodesics]]'
```

# prop:dc-ch7-2-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#prop:dc-ch7-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-3-geodesic-push]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
```

# def:dc-ch7-2-4

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#def:dc-ch7-2-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-1]]'
```

# lem:dc-ch7-2-4-finite

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-4-finite
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
```

# lem:dc-ch7-2-5-chart

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-5-chart
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
```

# lem:dc-ch7-2-5-pos

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-5-pos
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-5-chart]]'
```

# prop:dc-ch7-2-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#prop:dc-ch7-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-4-finite]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-5-pos]]'
```

# prop:dc-ch7-2-6

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#prop:dc-ch7-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-4-finite]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-5-chart]]'
```

# cor:dc-ch7-2-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#cor:dc-ch7-2-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#prop:dc-ch7-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#prop:dc-ch7-2-6]]'
```

# thm:dc-ch7-2-8

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#thm:dc-ch7-2-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#prop:dc-ch7-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#cor:dc-ch3-3-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-b-to-c]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-a-to-b]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-b-iff-e]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-lipschitz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-c-to-d]]'
```

# lem:dc-ch7-2-8-b-to-c

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-b-to-c
uses: []
```

# lem:dc-ch7-2-8-b-iff-e

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-b-iff-e
uses: []
```

# lem:dc-ch7-2-8-lipschitz

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-lipschitz
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-1-constspeed]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
```

# lem:dc-ch7-2-8-christoffel-transform

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-christoffel-transform
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#def:dc-ch2-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#thm:dc-ch2-3-6]]'
```

# lem:dc-ch7-2-8-chart-independence

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-chart-independence
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-christoffel-transform]]'
```

# lem:dc-ch7-2-8-flow-geodesic

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-flow-geodesic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-independence]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-pointwise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6-reparam]]'
```

# lem:dc-ch7-2-8-uniqueness

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-uniqueness
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-independence]]'
```

# lem:dc-ch7-2-8-gram-bound

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-gram-bound
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-1-constspeed]]'
```

# lem:dc-ch7-2-8-c-to-d

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-c-to-d
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-lipschitz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-flow-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-uniqueness]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-gram-bound]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6-reparam]]'
```

# lem:dc-ch7-2-8-a-to-b

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-a-to-b
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-step]]'
```

# lem:dc-ch7-2-8-chart-length

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-chart-length
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-gram-bound]]'
```

# lem:dc-ch7-2-8-normal-ball-dist

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-normal-ball-dist
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-radius]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-reach]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-rayspeed]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-gram-bound]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-length]]'
```

# lem:dc-ch7-2-8-ray-geodesic

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-ray-geodesic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-independence]]'
```

# lem:dc-ch7-2-8-sphere-min

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-sphere-min
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-gram-bound]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-length]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-normal-ball-dist]]'
```

# lem:dc-ch7-2-8-step

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-8-step
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-ray-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-sphere-min]]'
```

# cor:dc-ch7-2-9

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#cor:dc-ch7-2-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-c-to-d]]'
```

# lem:dc-ch7-2-10-lipschitz

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-10-lipschitz
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-2]]'
```

# cor:dc-ch7-2-10

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#cor:dc-ch7-2-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-10-lipschitz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#prop:dc-ch7-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#thm:dc-ch7-2-8]]'
```

# thm:dc-ch7-3-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#thm:dc-ch7-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-1-covering-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-1-assembly]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-pullback-metric]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-pole-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-expmap-global]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-expmap-smooth]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#thm:dc-ch7-2-8]]'
```

# lem:dc-ch7-3-2-no-conjugate

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-2-no-conjugate
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#lem:dc-ch5-2-1-real-curvature]]'
```

# lem:dc-ch7-3-2

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-2-no-conjugate]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-expmap-smooth]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#prop:dc-ch5-3-5]]'
```

# lem:dc-ch7-3-3-length-expansion

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-3-length-expansion
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-9]]'
```

# lem:dc-ch7-3-3-relatively-compact-lift

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-3-relatively-compact-lift
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-length-expansion]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#thm:dc-ch7-2-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
```

# lem:dc-ch7-3-3-local-lift

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-3-local-lift
uses: []
```

# lem:dc-ch7-3-3-path-lifting

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-3-path-lifting
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#thm:dc-ch7-2-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-length-expansion]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-relatively-compact-lift]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-local-lift]]'
```

# lem:dc-ch7-3-3-lift-unique

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-3-lift-unique
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-path-lifting]]'
```

# lem:dc-ch7-3-3-chart-length-finite

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-3-chart-length-finite
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-9]]'
```

# lem:dc-ch7-3-3-closed-image

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-3-closed-image
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-path-lifting]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-chart-length-finite]]'
```

# lem:dc-ch7-3-3

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#thm:dc-ch7-2-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-length-expansion]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-relatively-compact-lift]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-local-lift]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-path-lifting]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-lift-unique]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-chart-length-finite]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-closed-image]]'
```

# lem:dc-ch7-3-1-covering-simplyconnected

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-1-covering-simplyconnected
uses: []
```

# lem:dc-ch7-3-1-covering-diffeo

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-1-covering-diffeo
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-1-covering-simplyconnected]]'
```

# lem:dc-ch7-3-expmap-global

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-expmap-global
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#thm:dc-ch7-2-8]]'
```

# lem:dc-ch7-3-expmap-smooth

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-expmap-smooth
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-expmap-global]]'
```

# lem:dc-ch7-3-1-assembly

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-1-assembly
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-1-covering-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-a-to-b]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3]]'
```

# lem:dc-ch7-3-4-pullback-metric

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-4-pullback-metric
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-3-length-expansion]]'
```

# lem:dc-ch7-3-4-pole-diffeo

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-4-pole-diffeo
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-1-assembly]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-pullback-metric]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-expmap-global]]'
```

# lem:dc-ch7-3-4-ray-reduction

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-4-ray-reduction
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-pole-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-pullback-metric]]'
```

# lem:dc-ch7-3-4-rays-are-geodesics

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-3-4-rays-are-geodesics
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-pullback-metric]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-expmap-global]]'
```

# rem:dc-ch7-3-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#rem:dc-ch7-3-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-pole-diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-ray-reduction]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-4-rays-are-geodesics]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-3-expmap-global]]'
```

# lem:dc-ch7-2-5-minimizing

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard.tex#lem:dc-ch7-2-5-minimizing
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
```
