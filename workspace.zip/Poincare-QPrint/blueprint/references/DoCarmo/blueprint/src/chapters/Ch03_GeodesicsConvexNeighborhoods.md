# chap:dc-geodesics-convex-neighborhoods

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#chap:dc-geodesics-convex-neighborhoods
uses: []
```

# def:dc-ch3-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-2-1
uses: []
```

# lem:dc-ch3-2-1-constspeed

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-1-constspeed
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-2-coord]]'
```

# lem:dc-ch3-2-2-pointwise

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-2-pointwise
uses: []
```

# lem:dc-ch3-2-2-flow

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-2-flow
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-pointwise]]'
```

# lem:dc-ch3-2-2-c1dep

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-2-c1dep
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-flow]]'
```

# lem:dc-ch3-2-2-variational

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-2-variational
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-c1dep]]'
```

# lem:dc-ch3-2-2-c2dep

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-2-c2dep
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-c1dep]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-variational]]'
```

# thm:dc-ch3-2-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#thm:dc-ch3-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-pointwise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-c1dep]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-variational]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-c2dep]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-cinfty]]'
```

# lem:dc-ch3-2-3

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
```

# def:dc-ch3-2-4

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-2-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-3]]'
```

# lem:dc-ch3-2-5-exist

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-5-exist
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-pointwise]]'
```

# lem:dc-ch3-2-5-unique

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-5-unique
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-pointwise]]'
```

# lem:dc-ch3-2-5-velocity

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-5-velocity
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-exist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-unique]]'
```

# lem:dc-ch3-2-5-equation

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-5-equation
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-exist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-velocity]]'
```

# prop:dc-ch3-2-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#prop:dc-ch3-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-exist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-unique]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-chart-family]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-metric-family]]'
```

# lem:dc-ch3-2-6-reparam

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-6-reparam
uses: []
```

# lem:dc-ch3-2-6

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6-reparam]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-unique]]'
```

# lem:dc-ch3-2-7-pointwise

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-7-pointwise
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
```

# lem:dc-ch3-2-7-vuniform

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-7-vuniform
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-exist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-unique]]'
```

# lem:dc-ch3-2-7-c1flow

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-7-c1flow
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-c1dep]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-vuniform]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-4]]'
```

# lem:dc-ch3-2-7-c2flow

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-7-c2flow
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-c1flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-variational]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-c2dep]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-4]]'
```

# prop:dc-ch3-2-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#prop:dc-ch3-2-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-vuniform]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-c1flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-c2flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-unique]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-metric-ball]]'
```

# rem:dc-ch3-2-8

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#rem:dc-ch3-2-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
```

# def:dc-ch3-expmap

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-expmap
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-exist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-unique]]'
```

# lem:dc-ch3-expmap-ray

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-expmap-ray
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
```

# lem:dc-ch3-2-9-dexp

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-dexp
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-expmap-ray]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-velocity]]'
```

# lem:dc-ch3-2-9-strict

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-strict
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-vuniform]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-dexp]]'
```

# lem:dc-ch3-2-9-c1ball

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-c1ball
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-c1flow]]'
```

# lem:dc-ch3-2-9-c1

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-c1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1ball]]'
```

# lem:dc-ch3-2-9-invertible

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-invertible
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-strict]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1]]'
```

# lem:dc-ch3-2-9-c1diffeo

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-c1diffeo
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-invertible]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-strict]]'
```

# lem:dc-ch3-2-9-c2ball

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-c2ball
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-c2flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1]]'
```

# lem:dc-ch3-2-9-c2diffeo

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-c2diffeo
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c2ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-invertible]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
```

# prop:dc-ch3-2-9

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#prop:dc-ch3-2-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-expmap-ray]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-dexp]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-strict]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-invertible]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c2ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c2diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-cinfty]]'
```

# ex:dc-ch3-2-10

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#ex:dc-ch3-2-10
uses: []
```

# ex:dc-ch3-2-11

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#ex:dc-ch3-2-11
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-2-5]]'
```

# def:dc-ch3-3-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-3-1
uses: []
```

# def:dc-ch3-3-2

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-3-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-1]]'
```

# def:dc-ch3-3-3

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-3-3
uses: []
```

# lem:dc-ch3-3-4

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-4
uses: []
```

# lem:dc-ch3-3-5-rayode

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-5-rayode
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-vuniform]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-c2flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c2ball]]'
```

# lem:dc-ch3-3-5-surface

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-5-surface
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-2-coord]]'
```

# lem:dc-ch3-3-5-ball

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-5-ball
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-rayode]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-surface]]'
```

# lem:dc-ch3-3-5-radial

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-5-radial
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-ball]]'
```

# lem:dc-ch3-3-5

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-ball]]'
```

# lem:dc-ch3-3-6-radius

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-radius
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-radial]]'
```

# lem:dc-ch3-3-6-reach

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-reach
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-radius]]'
```

# lem:dc-ch3-3-6-rayspeed

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-rayspeed
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-rayode]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
```

# lem:dc-ch3-3-6-ball

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-ball
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-radius]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-rayspeed]]'
```

# lem:dc-ch3-3-6-normal

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-normal
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
```

# lem:dc-ch3-3-6-piecewise

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-piecewise
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-normal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-radius]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-rayspeed]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-invertible]]'
```

# lem:dc-ch3-3-6-competitor

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-competitor
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-piecewise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
```

# lem:dc-ch3-3-6-equality-radial

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-equality-radial
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-radius]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-invertible]]'
```

# lem:dc-ch3-3-6-equality-ray

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-equality-ray
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-radial]]'
```

# lem:dc-ch3-3-6-confinement

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-confinement
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-competitor]]'
```

# lem:dc-ch3-3-6-equality-manifold

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-equality-manifold
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-ray]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-radial]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-length]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-confinement]]'
```

# lem:dc-ch3-3-6-equality-geodesic

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-equality-geodesic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-ray-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-confinement]]'
```

# lem:dc-ch3-3-6-equality-ray-piecewise

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-equality-ray-piecewise
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-radial]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-ray]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-radius]]'
```

# lem:dc-ch3-3-6-confinement-piecewise

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-confinement-piecewise
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-competitor]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-confinement]]'
```

# lem:dc-ch3-3-6-equality-manifold-piecewise

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-6-equality-manifold-piecewise
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-ray-piecewise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-confinement-piecewise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-length]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-manifold]]'
```

# prop:dc-ch3-3-6

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#prop:dc-ch3-3-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-normal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-piecewise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-competitor]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-radial]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-ray]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-confinement]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-ray-piecewise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-confinement-piecewise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-manifold-piecewise]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-radius]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-rayspeed]]'
```

# lem:dc-ch3-3-7-descent

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-7-descent
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-vuniform]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-independence]]'
```

# lem:dc-ch3-3-7-descent-velocity

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-7-descent-velocity
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
```

# lem:dc-ch3-3-7-pairmap

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-7-pairmap
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-vuniform]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-c1dep]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-strict]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
```

# lem:dc-ch3-3-7-c1pair

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-7-c1pair
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-7-c1flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-pairmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1]]'
```

# lem:dc-ch3-3-7-flow-agree

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-7-flow-agree
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-uniqueness]]'
```

# lem:dc-ch3-3-7-invertible

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-7-invertible
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-pairmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-c1pair]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-flow-agree]]'
```

# thm:dc-ch3-3-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#thm:dc-ch3-3-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-2-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent-velocity]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-pairmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-c1pair]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-invertible]]'
```

# rem:dc-ch3-3-8

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#rem:dc-ch3-3-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
```

# lem:dc-ch3-3-9-corner

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-9-corner
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#def:dc-ch7-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-gram-bound]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-length]]'
```

# lem:dc-ch3-3-9-anchored

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-9-anchored
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-normal-ball-dist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-gram-bound]]'
```

# lem:dc-ch3-3-9-localization

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-9-localization
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-9-anchored]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-9-corner]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-ray-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6-reparam]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
```

# cor:dc-ch3-3-9

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#cor:dc-ch3-3-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-equality-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-9-localization]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-9-corner]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-9-anchored]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-chart-length]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
```

# ex:dc-ch3-3-10

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#ex:dc-ch3-3-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#cor:dc-ch3-3-9]]'
```

# lem:dc-ch3-4-1-leibniz

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-leibniz
uses: []
```

# lem:dc-ch3-4-1-dF

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-dF
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-leibniz]]'
```

# lem:dc-ch3-4-1-ddF

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-ddF
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-leibniz]]'
```

# lem:dc-ch3-4-1-radialcoord

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-radialcoord
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-expmap]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
```

# lem:dc-ch3-4-1-hessian-center

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-hessian-center
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-ddF]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-radialcoord]]'
```

# lem:dc-ch3-4-1-posdef

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-posdef
uses: []
```

# lem:dc-ch3-4-1-outside

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-outside
uses: []
```

# lem:dc-ch3-4-1-strict-outside

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-strict-outside
uses: []
```

# lem:dc-ch3-4-1-continuity

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-continuity
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-ddF]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c2diffeo]]'
```

# lem:dc-ch3-4-1-poscenter

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-poscenter
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-posdef]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c2diffeo]]'
```

# lem:dc-ch3-4-1-posnbhd

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-posnbhd
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-continuity]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-poscenter]]'
```

# lem:dc-ch3-4-1-homog

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-homog
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-posnbhd]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-6]]'
```

# lem:dc-ch3-4-1-fidentity

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-fidentity
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-dF]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-ddF]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-leibniz]]'
```

# lem:dc-ch3-4-1-flowreading

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-flowreading
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-fidentity]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-continuity]]'
```

# lem:dc-ch3-4-1

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-flowreading]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-homog]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-outside]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-posnbhd]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-dF]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-ddF]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-hessian-center]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-radialcoord]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-posdef]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-continuity]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-poscenter]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-5-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-fidentity]]'
```

# lem:dc-ch3-4-1-strict

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-1-strict
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-flowreading]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-homog]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-strict-outside]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-posnbhd]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
```

# lem:dc-ch3-4-2-rebase

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-rebase
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-strict]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-unique]]'
```

# lem:dc-ch3-4-2-nomax

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-nomax
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-rebase]]'
```

# lem:dc-ch3-4-2-bridge

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-bridge
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-nomax]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-3-6]]'
```

# lem:dc-ch3-4-2-bridge-ball

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-bridge-ball
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-3-6]]'
```

# lem:dc-ch3-4-2-maxdeduction

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-maxdeduction
uses: []
```

# def:dc-ch3-4-2-stronglyconvex

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-4-2-stronglyconvex
uses: []
```

# lem:dc-ch3-4-2-speedchart

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-speedchart
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-1-constspeed]]'
```

# lem:dc-ch3-4-2-velbound

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-velbound
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-speedchart]]'
```

# lem:dc-ch3-4-2-invdiagonal

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-invdiagonal
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
```

# lem:dc-ch3-4-2-pairsmall

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-pairsmall
uses: []
```

# lem:dc-ch3-4-2-velsmall

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-velsmall
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-pairsmall]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-invdiagonal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
```

# lem:dc-ch3-4-2-interior

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-interior
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-nomax]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-bridge-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-maxdeduction]]'
```

# lem:dc-ch3-4-2-gramsmall

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-gramsmall
uses: []
```

# lem:dc-ch3-4-2-interior-minimizing

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-interior-minimizing
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-interior]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-velbound]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-speedchart]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-gramsmall]]'
```

# lem:dc-ch3-geodesic-pathlength

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-geodesic-pathlength
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-1-constspeed]]'
```

# lem:dc-ch3-4-2-segment-length

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-segment-length
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-geodesic-pathlength]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent-velocity]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-speedchart]]'
```

# lem:dc-ch3-4-2-segment-edist

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-segment-edist
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-segment-length]]'
```

# lem:dc-ch3-4-2-join-metric

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-join-metric
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-segment-length]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-segment-edist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-velsmall]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-geodesic-pathlength]]'
```

# lem:dc-ch3-4-2-endpoint-id

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-endpoint-id
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-7-descent]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-2-1]]'
```

# lem:dc-ch3-4-2-competitor-lb

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-competitor-lb
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-radius]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-6-competitor]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-gramsmall]]'
```

# lem:dc-ch3-4-2-lowerbound

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-lowerbound
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-competitor-lb]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-endpoint-id]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-geodesic-pathlength]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-speedchart]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-3-6]]'
```

# lem:dc-ch3-4-2-minimizing-interior

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-minimizing-interior
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-join-metric]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-interior-minimizing]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#cor:dc-ch3-3-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-4-2-stronglyconvex]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-lowerbound]]'
```

# lem:dc-ch3-4-2-stronglyconvex-reduction

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-stronglyconvex-reduction
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-minimizing-interior]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-4-2-stronglyconvex]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-3-6]]'
```

# lem:dc-ch3-4-2-minimizing-interior-uncond

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-minimizing-interior-uncond
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-minimizing-interior]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-lowerbound]]'
```

# lem:dc-ch3-4-2-stronglyconvex-uniq

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-stronglyconvex-uniq
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-stronglyconvex-reduction]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-lowerbound]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-minimizing-interior-uncond]]'
```

# lem:dc-ch3-4-2-eqon-flow-reading

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-eqon-flow-reading
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-endpoint-id]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-4]]'
```

# lem:dc-ch3-4-2-uniqueness-engine

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-uniqueness-engine
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-eqon-flow-reading]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
```

# lem:dc-ch3-4-2-window

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-window
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-4]]'
```

# lem:dc-ch3-4-2-speed-dist

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-4-2-speed-dist
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#prop:dc-ch3-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-4]]'
```

# prop:dc-ch3-4-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#prop:dc-ch3-4-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-1-strict]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-rebase]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-window]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-speed-dist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-nomax]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-bridge-ball]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-maxdeduction]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-speedchart]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-velbound]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-interior]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-interior-minimizing]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-gramsmall]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-invdiagonal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-pairsmall]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-velsmall]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-segment-length]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-segment-edist]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-join-metric]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-minimizing-interior]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-stronglyconvex-reduction]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-lowerbound]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-minimizing-interior-uncond]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-stronglyconvex-uniq]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-endpoint-id]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-competitor-lb]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-eqon-flow-reading]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-4-2-uniqueness-engine]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-4-2-stronglyconvex]]'
```

# def:dc-ch3-3-1-piecewise-transport

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-3-1-piecewise-transport
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-1]]'
```

# def:dc-ch3-3-1-vertex-angle

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-3-1-vertex-angle
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-1]]'
```

# def:dc-ch3-3-3-formal

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#def:dc-ch3-3-3-formal
uses: []
```

# lem:dc-ch3-2-2-cinfty

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-2-cinfty
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-flow]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-2-c1dep]]'
```

# lem:dc-ch3-2-5-chart-family

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-5-chart-family
uses: []
```

# lem:dc-ch3-2-5-metric-ball

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-5-metric-ball
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#lem:dc-ch7-2-8-gram-bound]]'
```

# lem:dc-ch3-2-5-metric-family

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-5-metric-family
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-chart-family]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-5-metric-ball]]'
```

# lem:dc-ch3-2-9-cinfty

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-2-9-cinfty
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c2diffeo]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-invertible]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-9-c1diffeo]]'
```

# lem:dc-ch3-3-1-edist

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods.tex#lem:dc-ch3-3-1-edist
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-1]]'
```
