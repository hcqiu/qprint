# cor:dc-ch5-3-3-conjugate-locus-endpoint

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/formalization-support.tex#cor:dc-ch5-3-3-conjugate-locus-endpoint
uses:
- '[[references/DoCarmo/blueprint/src/chapters/formalization-support#cor:dc-ch5-3-3-first-conjugate]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-4]]'
```

# cor:dc-ch5-3-3-first-conjugate

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/formalization-support.tex#cor:dc-ch5-3-3-first-conjugate
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#ex:dc-ch5-3-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch05_JacobiFields#def:dc-ch5-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-no-conjugate]]'
```

# lem:dc-ch1-2-11-pointwise

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/formalization-support.tex#lem:dc-ch1-2-11-pointwise
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
```

# lem:dc-ch8-2-1-chart-partition

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/formalization-support.tex#lem:dc-ch8-2-1-chart-partition
uses: []
```

# lem:dc-ch8-2-1-window-transfer

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/formalization-support.tex#lem:dc-ch8-2-1-window-transfer
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-window]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#lem:dc-ch8-2-1-exp-norm-transfer-general-discharged]]'
```

# lem:dc-ch8-5-differential-core

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/formalization-support.tex#lem:dc-ch8-5-differential-core
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch08_SpacesOfConstantCurvature#def:dc-ch8-5-conformal]]'
```

# lem:dc-ch9-3-7-orientation-det

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/formalization-support.tex#lem:dc-ch9-3-7-orientation-det
uses: []
```
