# chap:dc-isometric-immersions

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#chap:dc-isometric-immersions
uses: []
```

# def:dc-ch6-2-patch

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-patch
uses: []
```

# lem:dc-ch6-2-proj

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-proj
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-patch]]'
```

# def:dc-ch6-2-induced-connection

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-induced-connection
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-patch]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#thm:dc-ch2-3-6]]'
```

# prop:dc-ch6-2-induced-connection

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#prop:dc-ch6-2-induced-connection
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-induced-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-proj]]'
```

# def:dc-ch6-2-B

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-B
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-induced-connection]]'
```

# prop:dc-ch6-2-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#prop:dc-ch6-2-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-proj]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-induced-connection]]'
```

# lem:dc-ch6-2-locality

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-locality
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-patch]]'
```

# def:dc-ch6-2-2

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-locality]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-normal-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-3-weingarten]]'
```

# prop:dc-ch6-2-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#prop:dc-ch6-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-normal-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-3-weingarten]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-locality]]'
```

# ex:dc-ch6-2-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#ex:dc-ch6-2-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-4-principal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-8-euclidean-opens]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#ex:dc-ch6-2-8]]'
```

# rem:dc-ch6-2-4-covering

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#rem:dc-ch6-2-4-covering
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#ex:dc-ch6-2-4]]'
```

# def:dc-ch6-2-4-principal

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-4-principal
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
```

# thm:dc-ch6-2-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#thm:dc-ch6-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-curvatures]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-3-1]]'
```

# rem:dc-ch6-2-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#rem:dc-ch6-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#thm:dc-ch6-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-4-principal]]'
```

# lem:dc-ch6-2-7-koszul

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-7-koszul
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-induced-connection]]'
```

# lem:dc-ch6-2-7-plane

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-7-plane
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-3-1]]'
```

# def:dc-ch6-2-7-pushforward

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-7-pushforward
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-8-euclidean-opens]]'
```

# lem:dc-ch6-2-7-pushforward-naturality

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-7-pushforward-naturality
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-7-pushforward]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch00_DifferentiableManifolds#lem:dc-ch0-5-2]]'
```

# def:dc-ch6-2-7-isometry

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-7-isometry
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-patch]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-7-pushforward]]'
```

# lem:dc-ch6-2-7-connection

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-7-connection
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-7-isometry]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-7-koszul]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-7-pushforward-naturality]]'
```

# lem:dc-ch6-2-7-curvature

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-7-curvature
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-7-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-curvatures]]'
```

# lem:dc-ch6-2-7-gauss-form

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-7-gauss-form
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#prop:dc-ch4-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-8-euclidean-opens]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-1]]'
```

# rem:dc-ch6-2-7

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#rem:dc-ch6-2-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#rem:dc-ch6-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-7-isometry]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-4-principal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-7-curvature]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-7-gauss-form]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-7-plane]]'
```

# lem:dc-ch6-2-8-euclidean

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-8-euclidean
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#thm:dc-ch2-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-constant-curvature]]'
```

# lem:dc-ch6-2-8-euclidean-opens

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-8-euclidean-opens
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#thm:dc-ch2-3-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-constant-curvature]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-8-euclidean]]'
```

# ex:dc-ch6-2-8

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#ex:dc-ch6-2-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-patch]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#thm:dc-ch6-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#rem:dc-ch6-2-6]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-8-euclidean-opens]]'
```

# def:dc-ch6-2-8-geodesic

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-8-geodesic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
```

# def:dc-ch6-2-9-geodesic-field

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-9-geodesic-field
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-induced-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-8-geodesic]]'
```

# lem:dc-ch6-2-9-existence

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-9-existence
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-9-geodesic-field]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-induced-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-proj]]'
```

# prop:dc-ch6-2-9

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#prop:dc-ch6-2-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-8-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-9-geodesic-field]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-9-existence]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-locality]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-9-field]]'
```

# rem:dc-ch6-2-9-interpretation

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#rem:dc-ch6-2-9-interpretation
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#thm:dc-ch6-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-8-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-3-2]]'
```

# rem:dc-ch6-2-9-exp-surface

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#rem:dc-ch6-2-9-exp-surface
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-9]]'
```

# def:dc-ch6-2-10

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-2-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-4-principal]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
```

# def:dc-ch6-3-normal-connection

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-3-normal-connection
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-patch]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-B]]'
```

# prop:dc-ch6-3-normal-connection-laws

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#prop:dc-ch6-3-normal-connection-laws
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-normal-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-proj]]'
```

# lem:dc-ch6-3-weingarten

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-3-weingarten
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-normal-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-B]]'
```

# def:dc-ch6-3-curvatures

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-3-curvatures
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-induced-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-normal-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
```

# lem:dc-ch6-3-decomposition

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-3-decomposition
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-curvatures]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-proj]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-normal-connection]]'
```

# prop:dc-ch6-3-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#prop:dc-ch6-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-curvatures]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-3-decomposition]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-3-weingarten]]'
```

# rem:dc-ch6-3-2

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#rem:dc-ch6-3-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#thm:dc-ch6-2-5]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-3-1]]'
```

# def:dc-ch6-3-constant-curvature

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-3-constant-curvature
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#lem:dc-ch4-3-4]]'
```

# rem:dc-ch6-3-3

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#rem:dc-ch6-3-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-covderiv-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-constant-curvature]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
```

# def:dc-ch6-3-covderiv-B

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#def:dc-ch6-3-covderiv-B
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-induced-connection]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-normal-connection]]'
```

# lem:dc-ch6-3-covderiv-reduce

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-3-covderiv-reduce
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-covderiv-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-3-weingarten]]'
```

# prop:dc-ch6-3-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#prop:dc-ch6-3-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-covderiv-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-3-covderiv-reduce]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-3-decomposition]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-induced-connection]]'
```

# rem:dc-ch6-3-5

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#rem:dc-ch6-3-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-constant-curvature]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-3-normal-connection]]'
```

# lem:dc-ch6-2-9-field

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions.tex#lem:dc-ch6-2-9-field
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-8-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-9-geodesic-field]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-9-existence]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-B]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#def:dc-ch6-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#lem:dc-ch6-2-locality]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch06_IsometricImmersions#prop:dc-ch6-2-1]]'
```
