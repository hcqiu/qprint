# chap:dc-variations-of-energy

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#chap:dc-variations-of-energy
uses: []
```

# def:dc-ch9-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#def:dc-ch9-2-1
uses: []
```

# prop:dc-ch9-2-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#prop:dc-ch9-2-2
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#thm:dc-ch3-3-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-2-exponential]]'
```

# def:dc-ch9-2-2-energy

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#def:dc-ch9-2-2-energy
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-9]]'
```

# lem:dc-ch9-2-2-smooth-speed-integrable

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-2-smooth-speed-integrable
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
```

# lem:dc-ch9-2-2-schwarz

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-2-schwarz
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
```

# lem:dc-ch9-2-3

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#cor:dc-ch3-3-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-2-schwarz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-inequality]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-equality-case]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-arclength-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-pointwise-arclength]]'
```

# lem:dc-ch9-2-3-arclength-bridge

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-3-arclength-bridge
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
```

# lem:dc-ch9-2-3-geodesic-equality

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-3-geodesic-equality
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-2-schwarz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-2-1-constspeed]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
```

# lem:dc-ch9-2-3-inequality

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-3-inequality
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-geodesic-equality]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-2-schwarz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
```

# lem:dc-ch9-2-3-smooth-variation-energy-min

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-3-smooth-variation-energy-min
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-2-smooth-speed-integrable]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-arclength-bridge]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-inequality]]'
```

# lem:dc-ch9-2-3-equality-case

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-3-equality-case
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-geodesic-equality]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-2-schwarz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
```

# def:dc-ch9-2-covariant-pair

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#def:dc-ch9-2-covariant-pair
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#prop:dc-ch2-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-2-2-coord]]'
```

# lem:dc-ch9-2-covariant-pair-leibniz

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-covariant-pair-leibniz
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-2-coord]]'
```

# lem:dc-ch9-2-4-symmetry

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-4-symmetry
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#lem:dc-ch3-3-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch03_GeodesicsConvexNeighborhoods#def:dc-ch3-3-3]]'
```

# lem:dc-ch9-2-4-energy-density

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-4-energy-density
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch02_AffineConnectionsRiemannianConnections#lem:dc-ch2-3-2-coord]]'
```

# lem:dc-ch9-2-4-parts

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-4-parts
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-covariant-pair-leibniz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# lem:dc-ch9-2-4-density-self

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-4-density-self
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-covariant-pair-leibniz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# lem:dc-ch9-2-4-symmetry-manifold

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-4-symmetry-manifold
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# lem:dc-ch9-2-4-under-integral

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-4-under-integral
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-density-self]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# lem:dc-ch9-2-4-segment

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-4-segment
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-under-integral]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-parts]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# prop:dc-ch9-2-4

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#prop:dc-ch9-2-4
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-energy-density]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-parts]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-density-self]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-under-integral]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-segment]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-piecewise-assembly]]'
```

# lem:dc-ch9-2-5-geodesic

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-5-geodesic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-parts]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# prop:dc-ch9-2-5

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#prop:dc-ch9-2-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#prop:dc-ch9-2-4]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#prop:dc-ch9-2-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-5-geodesic]]'
```

# rem:dc-ch9-2-7

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-2-7
uses: []
```

# lem:dc-ch9-2-8-under-integral

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-8-under-integral
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-covariant-pair-leibniz]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-under-integral]]'
```

# lem:dc-ch9-2-8-energy-snd-deriv

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-8-energy-snd-deriv
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-under-integral]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-under-integral]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# lem:dc-ch9-2-8-curvature-substitution

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-8-curvature-substitution
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#lem:dc-ch4-4-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
```

# lem:dc-ch9-2-8-curvature-substitution-manifold

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-8-curvature-substitution-manifold
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-curvature-substitution]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry-manifold]]'
```

# lem:dc-ch9-2-8-segment

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-8-segment
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-energy-snd-deriv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-curvature-substitution-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-parts]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-5-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# prop:dc-ch9-2-8

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#prop:dc-ch9-2-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-energy-snd-deriv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-curvature-substitution-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-parts]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-5-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-jump-sum]]'
```

# rem:dc-ch9-2-9

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-2-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#prop:dc-ch9-2-8]]'
```

# lem:dc-ch9-2-9-segment

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-9-segment
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-energy-snd-deriv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-curvature-substitution-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-parts]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# rem:dc-ch9-2-10

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-2-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#prop:dc-ch9-2-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#rem:dc-ch9-2-9]]'
```

# lem:dc-ch9-2-10-differentiation

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-10-differentiation
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-covariant-pair-leibniz]]'
```

# def:dc-ch9-2-10-index-form

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#def:dc-ch9-2-10-index-form
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-2-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch01_RiemannianMetrics#def:dc-ch1-2-9]]'
```

# lem:dc-ch9-2-10-formula6

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-10-formula6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-10-index-form]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-energy-snd-deriv]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-symmetry-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-curvature-substitution-manifold]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-5-geodesic]]'
```

# rem:dc-ch9-2-12

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-2-12
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#rem:dc-ch9-2-7]]'
```

# lem:dc-ch9-3-1-velocity-frame

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-1-velocity-frame
uses: []
```

# lem:dc-ch9-3-1-index-form-scaled

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-1-index-form-scaled
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-10-index-form]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-covariant-pair]]'
```

# lem:dc-ch9-3-1-index-form-frame

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-1-index-form-frame
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-index-form-scaled]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-velocity-frame]]'
```

# lem:dc-ch9-3-1-sine-variation

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-1-sine-variation
uses: []
```

# lem:dc-ch9-3-1-sine-energy-min

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-1-sine-energy-min
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-smooth-variation-energy-min]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-sine-variation]]'
```

# lem:dc-ch9-3-1-second-order-min

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-1-second-order-min
uses: []
```

# lem:dc-ch9-3-1-index-sum-neg

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-1-index-sum-neg
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-velocity-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-index-form-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-3-ricci-sectional]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-10-index-form]]'
```

# thm:dc-ch9-3-1

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#thm:dc-ch9-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#prop:dc-ch9-2-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-velocity-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-index-form-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-index-sum-neg]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-sine-variation]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-sine-energy-min]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-second-order-min]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-3-ricci-sectional]]'
```

# cor:dc-ch9-3-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#cor:dc-ch9-3-2
uses: []
```

# lem:dc-ch9-3-2-compact-cover

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-2-compact-cover
uses: []
```

# lem:dc-ch9-3-3-ricci-sectional

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-3-ricci-sectional
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch04_Curvature#def:dc-ch4-4-ricci-form]]'
```

# cor:dc-ch9-3-3

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#cor:dc-ch9-3-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#thm:dc-ch9-3-1]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#cor:dc-ch9-3-2]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-3-ricci-sectional]]'
```

# rem:dc-ch9-3-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-3-4
uses: []
```

# rem:dc-ch9-3-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-3-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#thm:dc-ch9-3-1]]'
```

# thm:dc-ch9-3-7

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#thm:dc-ch9-3-7
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#rem:dc-ch9-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-2-schwarz]]'
```

# lem:dc-ch9-3-8

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-8
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#rem:dc-ch9-2-9]]'
- '[[references/DoCarmo/blueprint/src/chapters/formalization-support#lem:dc-ch9-3-7-orientation-det]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-2-schwarz]]'
```

# rem:dc-ch9-3-9

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-3-9
uses: []
```

# cor:dc-ch9-3-10

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#cor:dc-ch9-3-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#thm:dc-ch9-3-7]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#cor:dc-ch9-3-3]]'
```

# rem:dc-ch9-3-11

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-3-11
uses: []
```

# lem:dc-ch9-2-2-exponential

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-2-exponential
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-1]]'
```

# lem:dc-ch9-2-3-pointwise-arclength

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-3-pointwise-arclength
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-equality-case]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-3-arclength-bridge]]'
```

# lem:dc-ch9-2-4-piecewise-assembly

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-4-piecewise-assembly
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-segment]]'
```

# lem:dc-ch9-2-5-geodesic-energy

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-5-geodesic-energy
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-4-segment]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-5-geodesic]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-1]]'
```

# lem:dc-ch9-2-8-jump-sum

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-8-jump-sum
uses: []
```

# lem:dc-ch9-2-8-piecewise-assembly

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-2-8-piecewise-assembly
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-segment]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-2-8-jump-sum]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#def:dc-ch9-2-2-energy]]'
```

# lem:dc-ch9-3-3-sectional-analytic

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#lem:dc-ch9-3-3-sectional-analytic
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-3-ricci-sectional]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-velocity-frame]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#lem:dc-ch9-3-1-index-sum-neg]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch07_CompleteManifoldsHopfRinowHadamard#thm:dc-ch7-2-8]]'
```

# rem:dc-ch9-2-11

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-2-11
uses: []
```

# rem:dc-ch9-2-6

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-2-6
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy#prop:dc-ch9-2-5]]'
```

# rem:dc-ch9-3-5

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch09_VariationsOfEnergy.tex#rem:dc-ch9-3-5
uses: []
```
