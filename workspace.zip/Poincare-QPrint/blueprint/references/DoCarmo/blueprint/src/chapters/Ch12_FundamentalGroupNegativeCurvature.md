# chap:dc-fundamental-group-negative-curvature

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#chap:dc-fundamental-group-negative-curvature
uses: []
```

# def:dc-ch12-2-1

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#def:dc-ch12-2-1
uses: []
```

# thm:dc-ch12-2-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#thm:dc-ch12-2-2
uses: []
```

# rem:dc-ch12-2-3

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#rem:dc-ch12-2-3
uses: []
```

# rem:dc-ch12-2-4

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#rem:dc-ch12-2-4
uses: []
```

# def:dc-ch12-2-5

```qprint
kind: definition
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#def:dc-ch12-2-5
uses: []
```

# prop:dc-ch12-2-6

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#prop:dc-ch12-2-6
uses: []
```

# lem:dc-ch12-3-1

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#lem:dc-ch12-3-1
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch10_RauchComparisonTheorem#prop:dc-ch10-2-5]]'
```

# thm:dc-ch12-3-2

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#thm:dc-ch12-3-2
uses: []
```

# lem:dc-ch12-3-3

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#lem:dc-ch12-3-3
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature#lem:dc-ch12-3-1]]'
```

# lem:dc-ch12-3-4

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#lem:dc-ch12-3-4
uses: []
```

# lem:dc-ch12-3-5

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#lem:dc-ch12-3-5
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature#prop:dc-ch12-2-6]]'
```

# ex:dc-ch12-3-6

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#ex:dc-ch12-3-6
uses: []
```

# ex:dc-ch12-3-7

```qprint
kind: proof
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#ex:dc-ch12-3-7
uses: []
```

# thm:dc-ch12-3-8

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#thm:dc-ch12-3-8
uses: []
```

# lem:dc-ch12-3-9

```qprint
kind: lemma
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#lem:dc-ch12-3-9
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature#lem:dc-ch12-3-1]]'
```

# thm:dc-ch12-3-10

```qprint
kind: theorem
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#thm:dc-ch12-3-10
uses:
- '[[references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature#thm:dc-ch12-3-8]]'
- '[[references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature#lem:dc-ch12-3-5]]'
```

# rem:dc-ch12-3-11

```qprint
kind: other
status: not_started
tex: references/DoCarmo/blueprint/src/chapters/Ch12_FundamentalGroupNegativeCurvature.tex#rem:dc-ch12-3-11
uses: []
```
