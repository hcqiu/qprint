# chap:kl-without-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/content.tex#chap:kl-without-surgery
uses: []
```

# chap:kl-with-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/content.tex#chap:kl-with-surgery
uses: []
```
