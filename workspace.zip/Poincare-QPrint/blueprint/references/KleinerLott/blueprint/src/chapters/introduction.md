# overview0

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#overview0
uses: []
```

# prop:kl-overview-ricci-flow-approach-manifold-geometrization-existence-riemannian-metrics

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#prop:kl-overview-ricci-flow-approach-manifold-geometrization-existence-riemannian-metrics
uses: []
```

# introclaim1

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#introclaim1
uses: []
```

# prop:kl-overview-ricci-flow-approach-manifold-geometrization-existence-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#prop:kl-overview-ricci-flow-approach-manifold-geometrization-existence-ricci-flow-surgery
uses: []
```

# introclaim2

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#introclaim2
uses: []
```

# prop:kl-overview-ricci-flow-approach-manifold-geometrization-ricci-flow-surgery-proposition

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#prop:kl-overview-ricci-flow-approach-manifold-geometrization-ricci-flow-surgery-proposition
uses: []
```

# introclaim3

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#introclaim3
uses: []
```

# prop:kl-overview-ricci-flow-approach-manifold-geometrization-ricci-flow-surgery-proposition-4

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#prop:kl-overview-ricci-flow-approach-manifold-geometrization-ricci-flow-surgery-proposition-4
uses: []
```

# introclaim4

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#introclaim4
uses: []
```

# prop:kl-overview-ricci-flow-approach-manifold-geometrization-existence-sectional-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#prop:kl-overview-ricci-flow-approach-manifold-geometrization-existence-sectional-curvature
uses: []
```

# introclaim5

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#introclaim5
uses: []
```

# prop:kl-overview-ricci-flow-approach-manifold-geometrization-graph-manifolds-proposition

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#prop:kl-overview-ricci-flow-approach-manifold-geometrization-graph-manifolds-proposition
uses: []
```

# introclaim6

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#introclaim6
uses: []
```

# prop:kl-overview-ricci-flow-approach-manifold-geometrization-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#prop:kl-overview-ricci-flow-approach-manifold-geometrization-existence-kappa-solutions
uses: []
```

# introclaim7

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#introclaim7
uses: []
```

# prop:kl-overview-ricci-flow-approach-manifold-geometrization-rigidity-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#prop:kl-overview-ricci-flow-approach-manifold-geometrization-rigidity-kappa-solutions
uses: []
```

# introclaim8

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#introclaim8
uses: []
```

# bound

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#bound
uses: []
```

# overview1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/introduction.tex#overview1
uses: []
```
