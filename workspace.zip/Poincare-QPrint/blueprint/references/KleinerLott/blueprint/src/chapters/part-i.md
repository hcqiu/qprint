# I.1.1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.1.1
uses: []
```

# Derivation of first equation of Section 1.1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Derivation of first
  equation of Section 1.1
uses: []
```

# def:kl-f-entropy-f-entropy-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-f-entropy-f-entropy-definition
uses: []
```

# prop:kl-f-entropy-first-variation-f-entropy

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-f-entropy-first-variation-f-entropy
uses: []
```

# measvar

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#measvar
uses: []
```

# id

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#id
uses: []
```

# Fvariation

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Fvariation
uses: []
```

# putting

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#putting
uses: []
```

# Fflow

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Fflow
uses: []
```

# Fchange

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Fchange
uses: []
```

# newevolution

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#newevolution
uses: []
```

# Fder

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Fder
uses: []
```

# backwards

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#backwards
uses: []
```

# Gaussianintegral

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Gaussianintegral
uses: []
```

# Gaussianintegral2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Gaussianintegral2
uses: []
```

# I.2.2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.2.2
uses: []
```

# prop:kl-invariant-its-applications-uniqueness-f-entropy

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-invariant-its-applications-uniqueness-f-entropy
uses: []
```

# def:kl-invariant-its-applications-lambda-invariant

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-invariant-its-applications-lambda-invariant
uses: []
```

# prop:kl-invariant-its-applications-monotonicity-entropy

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-invariant-its-applications-monotonicity-entropy
uses: []
```

# mono

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#mono
uses: []
```

# def:kl-invariant-its-applications-steady-breather-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-invariant-its-applications-steady-breather-definition
uses: []
```

# prop:kl-invariant-its-applications-rigidity-steady-breathers

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-invariant-its-applications-rigidity-steady-breathers
uses: []
```

# steadybreather

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#steadybreather
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-invariant-its-applications-monotonicity-entropy]]'
```

# lem:kl-invariant-its-applications-differential-inequality-entropy

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-invariant-its-applications-differential-inequality-entropy
uses: []
```

# 2/3

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#2/3
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-invariant-its-applications-monotonicity-entropy]]'
```

# dlambdadt

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#dlambdadt
uses: []
```

# using

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#using
uses: []
```

# prop:kl-rescaled-invariant-monotonicity-rescaled-lambda-invariant

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-rescaled-invariant-monotonicity-rescaled-lambda-invariant
uses: []
```

# expandingprop

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#expandingprop
uses: []
```

# ttest

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#ttest
uses: []
```

# cs

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cs
uses: []
```

# cor:kl-rescaled-invariant-rigidity-at-constant-rescaled-lambda

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-rescaled-invariant-rigidity-at-constant-rescaled-lambda
uses: []
```

# expp

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#expp
uses: []
```

# def:kl-rescaled-invariant-expanding-breather-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-rescaled-invariant-expanding-breather-definition
uses: []
```

# prop:kl-rescaled-invariant-rigidity-expanding-breathers

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-rescaled-invariant-rigidity-expanding-breathers
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-rescaled-invariant-rigidity-at-constant-rescaled-lambda]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-rescaled-invariant-monotonicity-rescaled-lambda-invariant]]'
```

# prop:kl-gradient-steady-solitons-compact-manifolds-compactness-ricci-solitons

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-gradient-steady-solitons-compact-manifolds-compactness-ricci-solitons
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-invariant-its-applications-monotonicity-entropy]]'
```

# riemmetric

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#riemmetric
uses: []
```

# lem:kl-ricci-flow-as-gradient-flow-gradient-flow-formula-lambda-invariant

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-ricci-flow-as-gradient-flow-gradient-flow-formula-lambda-invariant
uses: []
```

# eqnlambdadef

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#eqnlambdadef
uses: []
```

# feqn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#feqn
uses: []
```

# lambdavar

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lambdavar
uses: []
```

# gradflow

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#gradflow
uses: []
```

# Basic Example for Section 3.1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Basic Example for Section
  3.1
uses: []
```

# def:kl-w-entropy-w-entropy-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-w-entropy-w-entropy-definition
uses: []
```

# prop:kl-w-entropy-first-variation-w-entropy

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-w-entropy-first-variation-w-entropy
uses: []
```

# Wvar

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Wvar
uses: []
```

# oldeqn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#oldeqn
uses: []
```

# Wtimeder

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Wtimeder
uses: []
```

# neweqn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#neweqn
uses: []
```

# Wnorm

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Wnorm
uses: []
```

# def:kl-w-entropy-shrinking-breather-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-w-entropy-shrinking-breather-definition
uses: []
```

# prop:kl-w-entropy-rigidity-shrinking-breathers

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-w-entropy-rigidity-shrinking-breathers
uses: []
```

# def:kl-no-local-collapsing-theorem-i-locally-collapsing-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-no-local-collapsing-theorem-i-locally-collapsing-definition
uses: []
```

# rem:kl-no-local-collapsing-theorem-i-estimates-noncollapsing

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-no-local-collapsing-theorem-i-estimates-noncollapsing
uses: []
```

# thm:kl-no-local-collapsing-theorem-i-noncollapsing-theorem

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-no-local-collapsing-theorem-i-noncollapsing-theorem
uses: []
```

# noncollthm

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#noncollthm
uses: []
```

# normalization

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#normalization
uses: []
```

# mess

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#mess
uses: []
```

# rem:kl-no-local-collapsing-theorem-i-estimates-scalar-curvature

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-no-local-collapsing-theorem-i-estimates-scalar-curvature
uses: []
```

# def:kl-no-local-collapsing-theorem-i-kappa-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-no-local-collapsing-theorem-i-kappa-noncollapsing
uses: []
```

# noncollapsed1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#noncollapsed1
uses: []
```

# rem:kl-no-local-collapsing-theorem-i-structural-remark-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-no-local-collapsing-theorem-i-structural-remark-noncollapsing
uses: []
```

# I.5

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.5
uses: []
```

# I.7

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.7
uses: []
```

# defL

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#defL
uses: []
```

# reducedl

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#reducedl
uses: []
```

# reducedv

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#reducedv
uses: []
```

# 7Euclidean

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#7Euclidean
uses: []
```

# Lremarks

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Lremarks
uses: []
```

# firstvariation

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#firstvariation
uses: []
```

# Lgeod

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Lgeod
uses: []
```

# changetos

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#changetos
uses: []
```

# sE-L

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#sE-L
uses: []
```

# dr

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#dr
uses: []
```

# grad1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#grad1
uses: []
```

# gradsq

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#gradsq
uses: []
```

# timed

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#timed
uses: []
```

# Hexp

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Hexp
uses: []
```

# grad2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#grad2
uses: []
```

# ddt

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#ddt
uses: []
```

# parts

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#parts
uses: []
```

# sub4

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#sub4
uses: []
```

# touse1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#touse1
uses: []
```

# ttouse1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#ttouse1
uses: []
```

# xxx

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#xxx
uses: []
```

# sub1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#sub1
uses: []
```

# sub2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#sub2
uses: []
```

# Hess

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Hess
uses: []
```

# Qeqn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Qeqn
uses: []
```

# hesseq

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#hesseq
uses: []
```

# 7.9

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#7.9
uses: []
```

# diffeq

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#diffeq
uses: []
```

# sub3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#sub3
uses: []
```

# Htilde

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Htilde
uses: []
```

# 7.10

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#7.10
uses: []
```

# touse2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#touse2
uses: []
```

# dY

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#dY
uses: []
```

# sharp

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#sharp
uses: []
```

# monoV

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#monoV
uses: []
```

# lem:kl-monotonicity-reduced-volume-estimates-reduced-volume

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-monotonicity-reduced-volume-estimates-reduced-volume
uses: []
```

# lowerbound

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lowerbound
uses: []
```

# lbound

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lbound
uses: []
```

# bbound1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#bbound1
uses: []
```

# bbound2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#bbound2
uses: []
```

# I.(7.15)

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.(7.15)
uses: []
```

# barrier

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#barrier
uses: []
```

# lem:kl-reduced-l-geometry-positivity-reduced-l-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-reduced-l-geometry-positivity-reduced-l-geometry
uses: []
```

# neg

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#neg
uses: []
```

# illustrate

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#illustrate
uses: []
```

# pphieqn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#pphieqn
uses: []
```

# illustrate2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#illustrate2
uses: []
```

# ineqtoshow

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#ineqtoshow
uses: []
```

# I.(7.16)

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.(7.16)
uses: []
```

# I.7.3

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.7.3
uses: []
```

# def:kl-no-local-collapsing-theorem-ii-kappa-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-no-local-collapsing-theorem-ii-kappa-noncollapsing
uses: []
```

# noncollapsed2

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#noncollapsed2
uses: []
```

# thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#def:kl-no-local-collapsing-theorem-ii-kappa-noncollapsing]]'
```

# nolocalcollapse

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#nolocalcollapse
uses: []
```

# diffmess

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#diffmess
uses: []
```

# secI.8.3

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#secI.8.3
uses: []
```

# lem:kl-length-distortion-estimates-length-distortion-estimates-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-length-distortion-estimates-length-distortion-estimates-lemma
uses: []
```

# crudelemma

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#crudelemma
uses: []
```

# rem:kl-length-distortion-estimates-structural-remark-length-distortion-estimates

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-length-distortion-estimates-structural-remark-length-distortion-estimates
uses: []
```

# similar

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#similar
uses: []
```

# conclusion

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#conclusion
uses: []
```

# lem:kl-length-distortion-estimates-distance-distortion-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-length-distortion-estimates-distance-distortion-lemma
uses: []
```

# distancedist

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#distancedist
uses: []
```

# cor:kl-length-distortion-estimates-estimates-length-distortion-estimates

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-length-distortion-estimates-estimates-length-distortion-estimates
uses: []
```

# bound1

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#bound1
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
```

# lem:kl-length-distortion-estimates-estimates-distance-distortion

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-length-distortion-estimates-estimates-distance-distortion
uses: []
```

# I.8.3a

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.8.3a
uses: []
```

# def:kl-no-local-collapsing-propagates-forward-time-larger-scales-kappa-solutions-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-no-local-collapsing-propagates-forward-time-larger-scales-kappa-solutions-definition
uses: []
```

# thm:kl-no-local-collapsing-propagates-forward-time-larger-scales-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-no-local-collapsing-propagates-forward-time-larger-scales-existence-kappa-solutions
uses: []
```

# 8.2thm

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#8.2thm
uses: []
```

# rem:kl-no-local-collapsing-propagates-forward-time-larger-scales-estimates-no-local-collapsing-propagates-forward-time-larger-scales

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-no-local-collapsing-propagates-forward-time-larger-scales-estimates-no-local-collapsing-propagates-forward-time-larger-scales
uses: []
```

# 8.2fix

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#8.2fix
uses: []
```

# phieqn

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#phieqn
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#rem:kl-length-distortion-estimates-structural-remark-length-distortion-estimates]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions]]'
```

# I.9

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.9
uses: []
```

# veqn

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#veqn
uses: []
```

# prop:kl-perelman-s-differential-harnack-inequality-harnack-inequalities-proposition

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-perelman-s-differential-harnack-inequality-harnack-inequalities-proposition
uses: []
```

# localized

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#localized
uses: []
```

# I.(9.1)

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.(9.1)
uses: []
```

# der

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#der
uses: []
```

# cor:kl-perelman-s-differential-harnack-inequality-monotonicity-harnack-inequalities

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-perelman-s-differential-harnack-inequality-monotonicity-harnack-inequalities
uses: []
```

# whenever

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#whenever
uses: []
```

# cor:kl-perelman-s-differential-harnack-inequality-harnack-inequalities-corollary

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-perelman-s-differential-harnack-inequality-harnack-inequalities-corollary
uses: []
```

# corI.9.3

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#corI.9.3
uses: []
```

# cor:kl-perelman-s-differential-harnack-inequality-convergence-harnack-inequalities

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-perelman-s-differential-harnack-inequality-convergence-harnack-inequalities
uses: []
```

# compare

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#compare
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-perelman-s-differential-harnack-inequality-monotonicity-harnack-inequalities]]'
```

# rem:kl-perelman-s-differential-harnack-inequality-structural-remark-harnack-inequalities

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-perelman-s-differential-harnack-inequality-structural-remark-harnack-inequalities
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-perelman-s-differential-harnack-inequality-convergence-harnack-inequalities]]'
```

# statement of I.10.1

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#statement of I.10.1
uses: []
```

# thm:kl-statement-pseudolocality-theorem-pseudolocality-theorem

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-statement-pseudolocality-theorem-pseudolocality-theorem
uses: []
```

# thmI.10.1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thmI.10.1
uses: []
```

# lem:kl-point-selection-argument-point-selection-argument-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-point-selection-argument-point-selection-argument-lemma
uses: []
```

# Claim 1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Claim 1
uses: []
```

# I.(10.1)

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.(10.1)
uses: []
```

# I.(10.2)

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.(10.2)
uses: []
```

# lem:kl-getting-parabolic-regions-getting-parabolic-regions-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-getting-parabolic-regions-getting-parabolic-regions-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-point-selection-argument-point-selection-argument-lemma]]'
```

# Claim 2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Claim 2
uses: []
```

# I.(10.1a)

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.(10.1a)
uses: []
```

# I.(10.3)

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.(10.3)
uses: []
```

# 32.4

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#32.4
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-point-selection-argument-point-selection-argument-lemma]]'
```

# Claim3

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Claim3
uses: []
```

# lem:kl-upper-bound-integral-integral-bound-pseudolocality

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-upper-bound-integral-integral-bound-pseudolocality
uses: []
```

# stoccomplete

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#stoccomplete
uses: []
```

# lem:kl-upper-bound-integral-integral-bound-pseudolocality-2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-upper-bound-integral-integral-bound-pseudolocality-2
uses: []
```

# Claim 3

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Claim 3
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-perelman-s-differential-harnack-inequality-harnack-inequalities-corollary]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-getting-parabolic-regions-getting-parabolic-regions-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-upper-bound-integral-integral-bound-pseudolocality]]'
```

# pfI.10.1

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#pfI.10.1
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-perelman-s-differential-harnack-inequality-harnack-inequalities-corollary]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-getting-parabolic-regions-getting-parabolic-regions-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-upper-bound-integral-integral-bound-pseudolocality]]'
```

# largebound

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#largebound
uses: []
```

# ut

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#ut
uses: []
```

# somme

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#somme
uses: []
```

# contra1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#contra1
uses: []
```

# Beckner

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Beckner
uses: []
```

# contra2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#contra2
uses: []
```

# cor:kl-volumes-future-balls-volume-corollary

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-volumes-future-balls-volume-corollary
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-statement-pseudolocality-theorem-pseudolocality-theorem]]'
```

# corI.10.2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#corI.10.2
uses: []
```

# cor:kl-noncollapsing-at-future-times-existence-kappa-solutions

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-noncollapsing-at-future-times-existence-kappa-solutions
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-volumes-future-balls-volume-corollary]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-propagates-forward-time-larger-scales-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-statement-pseudolocality-theorem-pseudolocality-theorem]]'
```

# I.10.5

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.10.5
uses: []
```

# thm:kl-diffeomorphism-finiteness-existence-riemannian-metrics

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-diffeomorphism-finiteness-existence-riemannian-metrics
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-volumes-future-balls-volume-corollary]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-statement-pseudolocality-theorem-pseudolocality-theorem]]'
```

# secI.11.1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#secI.11.1
uses: []
```

# def:kl-solutions-kappa-noncollapsing

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-solutions-kappa-noncollapsing
uses: []
```

# I.11.2

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.11.2
uses: []
```

# prop:kl-asymptotic-solitons-existence-ricci-solitons

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-asymptotic-solitons-existence-ricci-solitons
uses: []
```

# asympsoliton

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#asympsoliton
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-perelman-s-differential-harnack-inequality-harnack-inequalities-proposition]]'
```

# upperl

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#upperl
uses: []
```

# Perelmanbound

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Perelmanbound
uses: []
```

# I.11.3

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.11.3
uses: []
```

# cor:kl-two-dimensional-solutions-kappa-solutions-corollary

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-two-dimensional-solutions-kappa-solutions-corollary
uses: []
```

# 2Dsoliton

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#2Dsoliton
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-asymptotic-solitons-existence-ricci-solitons]]'
```

# rem:kl-two-dimensional-solutions-structural-remark-ricci-solitons

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-two-dimensional-solutions-structural-remark-ricci-solitons
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-two-dimensional-solutions-kappa-solutions-corollary]]'
```

# 11.4proof

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#11.4proof
uses: []
```

# def:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-asymptotic-scalar-curvature-ratio-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-asymptotic-scalar-curvature-ratio-definition
uses: []
```

# thm:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-compactness-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-compactness-kappa-solutions
uses: []
```

# asympscalar

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#asympscalar
uses: []
```

# curvevol

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#curvevol
uses: []
```

# diff1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#diff1
uses: []
```

# diff2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#diff2
uses: []
```

# lem:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-scalar-curvature-lemma

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-scalar-curvature-lemma
uses: []
```

# def:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-asymptotic-volume-ratio-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-asymptotic-volume-ratio-definition
uses: []
```

# prop:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-existence-kappa-solutions
uses: []
```

# propI.11.4

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#propI.11.4
uses: []
```

# cor:kl-solution-curvature-normalized-volume-control-each-other-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-solution-curvature-normalized-volume-control-each-other-existence-kappa-solutions
uses: []
```

# 11.4cors

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#11.4cors
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-existence-curvature-operators]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-length-distortion-estimates-estimates-length-distortion-estimates]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-necklike-behavior-at-infinity-three-dimensional-solution-strong-version-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-necklike-behavior-at-infinity-three-dimensional-solution-weak-version-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-two-dimensional-solutions-kappa-solutions-corollary]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-volume-bound-existence-curvature-operators]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-notation-terminology-smooth-closeness-epsilon-necks]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-alternate-proof-corollary-2dsoliton-using-proposition-propi-11-4-corolla-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-getting-parabolic-regions-getting-parabolic-regions-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-necklike-behavior-at-infinity-three-dimensional-solution-strong-version-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-point-selection-argument-point-selection-argument-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-statement-pseudolocality-theorem-pseudolocality-theorem]]'
```

# altpf11.3

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#altpf11.3
uses: []
```

# lem:kl-alternate-proof-corollary-2dsoliton-using-proposition-propi-11-4-corolla-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-alternate-proof-corollary-2dsoliton-using-proposition-propi-11-4-corolla-existence-kappa-solutions
uses: []
```

# 2dvol

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#2dvol
uses: []
```

# volnotsmall

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#volnotsmall
uses: []
```

# halfvol

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#halfvol
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-solution-curvature-normalized-volume-control-each-other-existence-kappa-solutions]]'
```

# cor:kl-volume-bound-existence-curvature-operators

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-volume-bound-existence-curvature-operators
uses: []
```

# corI.11.5

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#corI.11.5
uses: []
```

# volbig

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#volbig
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-length-distortion-estimates-estimates-length-distortion-estimates]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-existence-kappa-solutions]]'
```

# cor:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-existence-curvature-operators

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-existence-curvature-operators
uses: []
```

# corI.11.6

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#corI.11.6
uses: []
```

# Rbound3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Rbound3
uses: []
```

# rem:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-structural-remark-curvature-operators

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-structural-remark-curvature-operators
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-existence-curvature-operators]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-volume-bound-existence-curvature-operators]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-getting-parabolic-regions-getting-parabolic-regions-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-point-selection-argument-point-selection-argument-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-statement-pseudolocality-theorem-pseudolocality-theorem]]'
```

# cc

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cc
uses: []
```

# lll

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lll
uses: []
```

# cor:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-existence-curvature-operators-3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-existence-curvature-operators-3
uses: []
```

# I.11.6end

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.11.6end
uses: []
```

# pf11.7

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#pf11.7
uses: []
```

# thm:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions
uses: []
```

# thmI.11.7

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thmI.11.7
uses: []
```

# C

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#C
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-solution-curvature-normalized-volume-control-each-other-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-two-dimensional-solutions-kappa-solutions-corollary]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-existence-kappa-solutions]]'
```

# rem:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions
uses: []
```

# rem:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions-3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions-3
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-two-dimensional-solutions-kappa-solutions-corollary]]'
```

# cor:kl-compactness-space-three-dimensional-solutions-kappa-solutions-corollary

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-compactness-space-three-dimensional-solutions-kappa-solutions-corollary
uses: []
```

# def:kl-necklike-behavior-at-infinity-three-dimensional-solution-weak-version-kappa-solution-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-necklike-behavior-at-infinity-three-dimensional-solution-weak-version-kappa-solution-definition
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-notation-terminology-smooth-closeness-epsilon-necks]]'
```

# cor:kl-necklike-behavior-at-infinity-three-dimensional-solution-weak-version-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-necklike-behavior-at-infinity-three-dimensional-solution-weak-version-existence-kappa-solutions
uses: []
```

# corI.11.8

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#corI.11.8
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-solution-curvature-normalized-volume-control-each-other-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions]]'
```

# strongversion

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#strongversion
uses: []
```

# cor:kl-necklike-behavior-at-infinity-three-dimensional-solution-strong-version-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-necklike-behavior-at-infinity-three-dimensional-solution-strong-version-existence-kappa-solutions
uses: []
```

# neckstructure

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#neckstructure
uses: []
```

# lem:kl-necklike-behavior-at-infinity-three-dimensional-solution-strong-version-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-necklike-behavior-at-infinity-three-dimensional-solution-strong-version-existence-kappa-solutions
uses: []
```

# annoy

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#annoy
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-solution-curvature-normalized-volume-control-each-other-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions]]'
```

# prop:kl-more-properties-solutions-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-more-properties-solutions-existence-kappa-solutions
uses: []
```

# neckcrit

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#neckcrit
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-necklike-behavior-at-infinity-three-dimensional-solution-strong-version-existence-kappa-solutions]]'
```

# cor:kl-more-properties-solutions-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-more-properties-solutions-existence-kappa-solutions
uses: []
```

# longsegment

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#longsegment
uses: []
```

# secI.11.9

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#secI.11.9
uses: []
```

# prop:kl-getting-uniform-value-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#prop:kl-getting-uniform-value-existence-kappa-solutions
uses: []
```

# propI.11.9

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#propI.11.9
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-three-dimensional-noncompact-noncollapsed-gradient-shrinkers-standard-compactness-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-asymptotic-solitons-existence-ricci-solitons]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions]]'
```

# rem:kl-getting-uniform-value-existence-ricci-solitons

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-getting-uniform-value-existence-ricci-solitons
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-three-dimensional-noncompact-noncollapsed-gradient-shrinkers-standard-compactness-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-asymptotic-solitons-existence-ricci-solitons]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions]]'
```

# II.1.2

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#II.1.2
uses: []
```

# lem:kl-three-dimensional-noncompact-noncollapsed-gradient-shrinkers-standard-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-three-dimensional-noncompact-noncollapsed-gradient-shrinkers-standard-existence-kappa-solutions
uses: []
```

# nosoliton

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#nosoliton
uses: []
```

# IIeqn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#IIeqn
uses: []
```

# gradR

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#gradR
uses: []
```

# cor:kl-three-dimensional-noncompact-noncollapsed-gradient-shrinkers-standard-compactness-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-three-dimensional-noncompact-noncollapsed-gradient-shrinkers-standard-compactness-kappa-solutions
uses: []
```

# cornosoliton

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cornosoliton
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-two-dimensional-solutions-kappa-solutions-corollary]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-three-dimensional-noncompact-noncollapsed-gradient-shrinkers-standard-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/appendices#thm:kl-maximum-principles-existence-curvature-operators]]'
```

# I.12.1

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.12.1
uses: []
```

# def:kl-canonical-neighborhood-theorem-almost-nonnegative-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#def:kl-canonical-neighborhood-theorem-almost-nonnegative-curvature
uses: []
```

# pinchingdef

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#pinchingdef
uses: []
```

# phieqnn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#phieqnn
uses: []
```

# rem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#def:kl-canonical-neighborhood-theorem-almost-nonnegative-curvature]]'
```

# double

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#double
uses: []
```

# lem:kl-canonical-neighborhood-theorem-convergence-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-canonical-neighborhood-theorem-convergence-canonical-neighborhoods
uses: []
```

# almost nonneg

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#almost nonneg
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#def:kl-canonical-neighborhood-theorem-almost-nonnegative-curvature]]'
```

# thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods
uses: []
```

# thmI.12.1

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thmI.12.1
uses: []
```

# addbd

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#addbd
uses: []
```

# dists

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#dists
uses: []
```

# rem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods-5

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods-5
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#rem:kl-canonical-neighborhood-theorem-structural-remark-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
```

# wangg

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#wangg
uses: []
```

# lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
```

# ptpicking

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#ptpicking
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
```

# lem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods
uses: []
```

# grad

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#grad
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions]]'
```

# lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-8

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-8
uses: []
```

# claim1

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#claim1
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods]]'
```

# lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-9

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-9
uses: []
```

# rescaled

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rescaled
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-8]]'
```

# lem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods-10

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods-10
uses: []
```

# nearlyround

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#nearlyround
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-more-properties-solutions-existence-kappa-solutions]]'
```

# rem:kl-canonical-neighborhood-theorem-structural-remark-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-canonical-neighborhood-theorem-structural-remark-canonical-neighborhoods
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#rem:kl-canonical-neighborhood-theorem-existence-canonical-neighborhoods-5]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions]]'
```

# wang

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#wang
uses: []
```

# I.12.2

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.12.2
uses: []
```

# thm:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-positivity-scalar-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-positivity-scalar-curvature
uses: []
```

# thmI.12.2

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thmI.12.2
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-9]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-propagates-forward-time-larger-scales-existence-kappa-solutions]]'
```

# rem:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-existence-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-existence-noncollapsing
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#rem:kl-no-local-collapsing-propagates-forward-time-larger-scales-estimates-no-local-collapsing-propagates-forward-time-larger-scales]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-propagates-forward-time-larger-scales-existence-kappa-solutions]]'
```

# rmkI.12.2

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rmkI.12.2
uses: []
```

# lem:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-existence-kappa-solutions
uses: []
```

# 12.2lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#12.2lemma
uses: []
```

# rem:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-structural-remark-thick-thin-geometry

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-structural-remark-thick-thin-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-9]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-propagates-forward-time-larger-scales-existence-kappa-solutions]]'
```

# I.12.3

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.12.3
uses: []
```

# lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature
uses: []
```

# Alexlemma

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#Alexlemma
uses: []
```

# thm:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature
uses: []
```

# thmI.12.3

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thmI.12.3
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-curvature-bounds-ricci-flow-solutions-nonnegative-curvature-operator-ass-existence-curvature-operators-3]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#rem:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-existence-noncollapsing]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-positivity-scalar-curvature]]'
```

# I.12.4

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.12.4
uses: []
```

# cor:kl-small-balls-strongly-negative-curvature-volume-collapsed-positivity-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#cor:kl-small-balls-strongly-negative-curvature-volume-collapsed-positivity-curvature
uses: []
```

# corI.12.4

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#corI.12.4
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-positivity-scalar-curvature]]'
```

# I.13.1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#I.13.1
uses: []
```

# thinpart

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thinpart
uses: []
```

# thm:kl-thick-thin-decomposition-nonsingular-flows-existence-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thm:kl-thick-thin-decomposition-nonsingular-flows-existence-thick-thin-geometry
uses: []
```

# thmI.13.1

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#thmI.13.1
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-small-balls-strongly-negative-curvature-volume-collapsed-positivity-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-positivity-scalar-curvature]]'
```

# rem:kl-thick-thin-decomposition-nonsingular-flows-estimates-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-i.tex#rem:kl-thick-thin-decomposition-nonsingular-flows-estimates-thick-thin-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-later-scalar-curvature-bounds-bigger-balls-from-curvature-volume-bounds-positivity-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-thick-thin-decomposition-nonsingular-flows-existence-thick-thin-geometry]]'
```
