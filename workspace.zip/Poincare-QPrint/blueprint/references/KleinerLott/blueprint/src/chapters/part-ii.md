# overview2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#overview2
uses: []
```

# notationterminology

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#notationterminology
uses: []
```

# def:kl-notation-terminology-smooth-closeness-epsilon-necks

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-notation-terminology-smooth-closeness-epsilon-necks
uses: []
```

# closenessdef

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#closenessdef
uses: []
```

# def:kl-notation-terminology-epsilon-tubes-horns-caps

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-notation-terminology-epsilon-tubes-horns-caps
uses: []
```

# rem:kl-notation-terminology-positivity-notation-terminology

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-notation-terminology-positivity-notation-terminology
uses: []
```

# remepsilon

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#remepsilon
uses: []
```

# lem:kl-notation-terminology-neck-geometry-lemma

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-notation-terminology-neck-geometry-lemma
uses: []
```

# II.1

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.1
uses: []
```

# lem:kl-three-dimensional-solutions-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-three-dimensional-solutions-existence-kappa-solutions
uses: []
```

# noncompactsoliton

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#noncompactsoliton
uses: []
```

# lem:kl-three-dimensional-solutions-kappa-solutions-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-three-dimensional-solutions-kappa-solutions-lemma
uses: []
```

# onlyneck

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#onlyneck
uses: []
```

# lem:kl-three-dimensional-solutions-compactness-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-three-dimensional-solutions-compactness-kappa-solutions
uses: []
```

# S3RP3

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#S3RP3
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#cor:kl-necklike-behavior-at-infinity-three-dimensional-solution-strong-version-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-compactness-space-three-dimensional-solutions-compactness-kappa-solutions]]'
```

# lem:kl-three-dimensional-solutions-existence-kappa-solutions-4

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-three-dimensional-solutions-existence-kappa-solutions-4
uses: []
```

# derivativeestimates

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#derivativeestimates
uses: []
```

# derestimates

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#derestimates
uses: []
```

# eqnderestimatesrinverse

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eqnderestimatesrinverse
uses: []
```

# lem:kl-three-dimensional-solutions-existence-kappa-solutions-5

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5
uses: []
```

# nbhd

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#nbhd
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-kappa-solutions-lemma]]'
```

# rem:kl-three-dimensional-solutions-structural-remark-three-dimensional-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-three-dimensional-solutions-structural-remark-three-dimensional-solutions
uses: []
```

# II.2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.2
uses: []
```

# rem:kl-standard-solutions-structural-remark-standard-solutions

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-standard-solutions-structural-remark-standard-solutions
uses: []
```

# def:kl-standard-solutions-standard-solution-definition

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-standard-solutions-standard-solution-definition
uses: []
```

# defstandardsolution

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#defstandardsolution
uses: []
```

# lem:kl-standard-solutions-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-standard-solutions-existence-kappa-solutions
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-standard-solutions-standard-solution-definition]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
```

# lemstandard0

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemstandard0
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions]]'
```

# claim2

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#claim2
uses: []
```

# lem:kl-blow-up-time-standard-solution-compactness-standard-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions
uses: []
```

# lemclaim2

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemclaim2
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-standard-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/appendices#thm:kl-maximum-principles-existence-curvature-operators]]'
```

# secclaim4

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#secclaim4
uses: []
```

# lem:kl-blow-up-time-standard-solution-standard-solutions-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-blow-up-time-standard-solution-standard-solutions-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions]]'
```

# lemclaim4

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemclaim4
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-8]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-standard-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-4]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#prop:kl-asymptotic-scalar-curvature-asymptotic-volume-ratio-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-statement-pseudolocality-theorem-pseudolocality-theorem]]'
```

# lem:kl-blow-up-time-standard-solution-standard-solutions-lemma-3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-blow-up-time-standard-solution-standard-solutions-lemma-3
uses: []
```

# scalarblowup

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#scalarblowup
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-8]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
```

# secclaim5

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#secclaim5
uses: []
```

# lem:kl-canonical-neighborhood-property-standard-solutions-existence-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-canonical-neighborhood-property-standard-solutions-existence-canonical-neighborhoods
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-4]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5]]'
```

# claim5

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#claim5
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-standard-solutions-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-standard-solutions-lemma-3]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-standard-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-4]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
```

# standardlycompact

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#standardlycompact
uses: []
```

# lem:kl-compactness-space-standard-solutions-compactness-standard-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-compactness-space-standard-solutions-compactness-standard-solutions
uses: []
```

# standardcompactness

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#standardcompactness
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-standard-solutions-lemma]]'
```

# claimII.2.1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#claimII.2.1
uses: []
```

# lem:kl-rotational-symmetry-standard-solutions-standard-solutions-lemma

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-rotational-symmetry-standard-solutions-standard-solutions-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions]]'
```

# Killingevolution

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Killingevolution
uses: []
```

# bigmess1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#bigmess1
uses: []
```

# bigmess2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#bigmess2
uses: []
```

# bigmess3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#bigmess3
uses: []
```

# M2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#M2
uses: []
```

# claim3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#claim3
uses: []
```

# Weqn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Weqn
uses: []
```

# heqn

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#heqn
uses: []
```

# hder

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#hder
uses: []
```

# wder

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#wder
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions]]'
```

# II.3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.3
uses: []
```

# def:kl-structure-at-first-singularity-time-bounded-curvature-regular-set

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-structure-at-first-singularity-time-bounded-curvature-regular-set
uses: []
```

# lem:kl-structure-at-first-singularity-time-structure-at-first-singularity-time-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-structure-at-first-singularity-time-lemma
uses: []
```

# omegaopen

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#omegaopen
uses: []
```

# lem:kl-structure-at-first-singularity-time-compactness-structure-at-first-singularity-time

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-compactness-structure-at-first-singularity-time
uses: []
```

# omeganoncompact

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#omeganoncompact
uses: []
```

# lem:kl-structure-at-first-singularity-time-rigidity-structure-at-first-singularity-time

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-rigidity-structure-at-first-singularity-time
uses: []
```

# standard

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#standard
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5]]'
```

# lem:kl-structure-at-first-singularity-time-volume-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-volume-lemma
uses: []
```

# volumeomega

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#volumeomega
uses: []
```

# lem:kl-structure-at-first-singularity-time-existence-structure-at-first-singularity-time

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-existence-structure-at-first-singularity-time
uses: []
```

# lemrinverseextends

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemrinverseextends
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-structure-at-first-singularity-time-structure-at-first-singularity-time-lemma]]'
```

# def:kl-structure-at-first-singularity-time-curvature-sublevel-regular-set

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-structure-at-first-singularity-time-curvature-sublevel-regular-set
uses: []
```

# lem:kl-structure-at-first-singularity-time-characterization-structure-at-first-singularity-time

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-characterization-structure-at-first-singularity-time
uses: []
```

# lemoverlinerisproper

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemoverlinerisproper
uses: []
```

# lem:kl-structure-at-first-singularity-time-neck-geometry-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-neck-geometry-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5]]'
```

# doublehorn

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#doublehorn
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-structure-at-first-singularity-time-existence-structure-at-first-singularity-time]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions]]'
```

# lem:kl-structure-at-first-singularity-time-existence-cap-geometry

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-existence-cap-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5]]'
```

# eqndecompv

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eqndecompv
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-structure-at-first-singularity-time-compactness-structure-at-first-singularity-time]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-structure-at-first-singularity-time-volume-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5]]'
```

# lem:kl-structure-at-first-singularity-time-structure-at-first-singularity-time-lemma-11

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-structure-at-first-singularity-time-structure-at-first-singularity-time-lemma-11
uses: []
```

# reconstruct

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#reconstruct
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5]]'
```

# rem:kl-structure-at-first-singularity-time-estimates-diameter

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-structure-at-first-singularity-time-estimates-diameter
uses: []
```

# Ricci flow with surgery

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Ricci flow with surgery
uses: []
```

# def:kl-ricci-flow-surgery-general-setting-ricci-flow-surgery-definition

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-ricci-flow-surgery-general-setting-ricci-flow-surgery-definition
uses: []
```

# flowwithsurgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#flowwithsurgery
uses: []
```

# def:kl-priori-assumptions-canonical-neighborhood-assumption

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-priori-assumptions-canonical-neighborhood-assumption
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-canonical-neighborhood-property-standard-solutions-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-4]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-three-dimensional-solutions-existence-kappa-solutions-5]]'
```

# canonicalnbhddef

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#canonicalnbhddef
uses: []
```

# II.(1.3)estimates

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.(1.3)estimates
uses: []
```

# rem:kl-priori-assumptions-continuation-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-priori-assumptions-continuation-canonical-neighborhoods
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-performing-surgery-continuing-flows-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#rem:kl-performing-surgery-continuing-flows-structural-remark-canonical-neighborhoods]]'
```

# rem:kl-priori-assumptions-continuation-kappa-solutions

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-priori-assumptions-continuation-kappa-solutions
uses: []
```

# def:kl-priori-assumptions-curvature-pinching-assumption

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-priori-assumptions-curvature-pinching-assumption
uses: []
```

# phipinchingdef

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#phipinchingdef
uses: []
```

# def:kl-priori-assumptions-surgery-priori-assumptions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-priori-assumptions-surgery-priori-assumptions
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-curvature-pinching-assumption]]'
```

# apriori

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#apriori
uses: []
```

# lem:kl-curvature-bounds-from-priori-assumptions-estimates-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-curvature-bounds-from-priori-assumptions-estimates-curvature
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
```

# claim1II.4.2

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#claim1II.4.2
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-canonical-neighborhood-theorem-canonical-neighborhoods-lemma-8]]'
```

# lem:kl-curvature-bounds-from-priori-assumptions-canonical-neighborhoods-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-curvature-bounds-from-priori-assumptions-canonical-neighborhoods-lemma
uses: []
```

# claim2II.4.2

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#claim2II.4.2
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
```

# lem:kl-necks-horns-existence-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-necks-horns-existence-ricci-flow-surgery
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-surgery-priori-assumptions]]'
```

# lemmaII.4.3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemmaII.4.3
uses: []
```

# hexists

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#hexists
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-compactness-standard-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-canonical-neighborhoods-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-structure-at-first-singularity-time-characterization-structure-at-first-singularity-time]]'
```

# rem:kl-necks-horns-monotonicity-neck-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-necks-horns-monotonicity-neck-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-necks-horns-existence-ricci-flow-surgery]]'
```

# surgery

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#surgery
uses: []
```

# lem:kl-surgery-pinching-condition-ricci-flow-surgery-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-surgery-pinching-condition-ricci-flow-surgery-lemma
uses: []
```

# lemroundoff

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemroundoff
uses: []
```

# eqnderivcomparision

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eqnderivcomparision
uses: []
```

# Rvar

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rvar
uses: []
```

# confscalar

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#confscalar
uses: []
```

# confcurv

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#confcurv
uses: []
```

# min1

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#min1
uses: []
```

# lem:kl-surgery-pinching-condition-positivity-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-surgery-pinching-condition-positivity-ricci-flow-surgery
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-surgery-pinching-condition-ricci-flow-surgery-lemma]]'
```

# capoff

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#capoff
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-surgery-pinching-condition-ricci-flow-surgery-lemma]]'
```

# lem:kl-surgery-pinching-condition-existence-standard-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-surgery-pinching-condition-existence-standard-solutions
uses:
- '[[references/KleinerLott/blueprint/src/chapters/appendices#def:kl-almost-nonnegative-curvature-positivity-curvature-operators]]'
```

# preservingphipinching

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#preservingphipinching
uses: []
```

# II.4.4

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.4.4
uses: []
```

# def:kl-performing-surgery-continuing-flows-ricci-flow-cutoff

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-performing-surgery-continuing-flows-ricci-flow-cutoff
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-surgery-priori-assumptions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-necks-horns-existence-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-surgery-pinching-condition-existence-standard-solutions]]'
```

# rdeltacutoffflowdef

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rdeltacutoffflowdef
uses: []
```

# rem:kl-performing-surgery-continuing-flows-existence-canonical-neighborhoods

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-performing-surgery-continuing-flows-existence-canonical-neighborhoods
uses: []
```

# lem:kl-performing-surgery-continuing-flows-rigidity-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-performing-surgery-continuing-flows-rigidity-ricci-flow-surgery
uses: []
```

# reconstruct2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#reconstruct2
uses: []
```

# rem:kl-performing-surgery-continuing-flows-structural-remark-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-performing-surgery-continuing-flows-structural-remark-ricci-flow-surgery
uses: []
```

# volumelossremark

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#volumelossremark
uses: []
```

# rem:kl-performing-surgery-continuing-flows-existence-ricci-flow-surgery

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-performing-surgery-continuing-flows-existence-ricci-flow-surgery
uses: []
```

# lem:kl-performing-surgery-continuing-flows-existence-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-performing-surgery-continuing-flows-existence-canonical-neighborhoods
uses:
- '[[references/KleinerLott/blueprint/src/chapters/appendices#def:kl-almost-nonnegative-curvature-positivity-curvature-operators]]'
```

# extendit

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#extendit
uses:
- '[[references/KleinerLott/blueprint/src/chapters/appendices#def:kl-almost-nonnegative-curvature-positivity-curvature-operators]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-performing-surgery-continuing-flows-ricci-flow-cutoff]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-canonical-neighborhood-property-standard-solutions-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-surgery-pinching-condition-existence-standard-solutions]]'
```

# rem:kl-performing-surgery-continuing-flows-structural-remark-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-performing-surgery-continuing-flows-structural-remark-canonical-neighborhoods
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
```

# 30

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#30
uses: []
```

# secII.4.5

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#secII.4.5
uses: []
```

# lem:kl-evolution-surgery-cap-existence-standard-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-evolution-surgery-cap-existence-standard-solutions
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-necks-horns-existence-ricci-flow-surgery]]'
```

# II.4.5

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.4.5
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-standard-solutions-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-evolution-surgery-cap-existence-standard-solutions-2]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-necks-horns-existence-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-standard-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-surgery-pinching-condition-existence-standard-solutions]]'
```

# lem:kl-evolution-surgery-cap-existence-standard-solutions-2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-evolution-surgery-cap-existence-standard-solutions-2
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-necks-horns-existence-ricci-flow-surgery]]'
```

# intermediate

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#intermediate
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-standard-solutions-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-standard-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-surgery-pinching-condition-existence-standard-solutions]]'
```

# lem:kl-evolution-surgery-cap-ricci-flow-surgery-lemma

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-evolution-surgery-cap-ricci-flow-surgery-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-blow-up-time-standard-solution-standard-solutions-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-standard-solutions-existence-kappa-solutions]]'
```

# II.4.6

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.4.6
uses: []
```

# cor:kl-curves-that-penetrate-surgery-region-ricci-flow-surgery-corollary

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#cor:kl-curves-that-penetrate-surgery-region-ricci-flow-surgery-corollary
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-evolution-surgery-cap-existence-standard-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-necks-horns-existence-ricci-flow-surgery]]'
```

# corollaryII.4.6

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#corollaryII.4.6
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-canonical-neighborhood-property-standard-solutions-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-evolution-surgery-cap-existence-standard-solutions]]'
```

# cor:kl-technical-estimate-existence-technical-estimate

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#cor:kl-technical-estimate-existence-technical-estimate
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-evolution-surgery-cap-existence-standard-solutions]]'
```

# Rbound

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rbound
uses: []
```

# rem:kl-technical-estimate-estimates-standard-solutions

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-technical-estimate-estimates-standard-solutions
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#cor:kl-technical-estimate-existence-technical-estimate]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-canonical-neighborhood-property-standard-solutions-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-evolution-surgery-cap-existence-standard-solutions]]'
```

# II.5

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.5
uses: []
```

# def:kl-statement-existence-theorem-ricci-flow-surgery-normalized-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-statement-existence-theorem-ricci-flow-surgery-normalized-definition
uses: []
```

# prop:kl-statement-existence-theorem-ricci-flow-surgery-monotonicity-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-statement-existence-theorem-ricci-flow-surgery-monotonicity-kappa-solutions
uses: []
```

# surgeryflowexists

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#surgeryflowexists
uses: []
```

# lfunctionandsurgerysection

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lfunctionandsurgerysection
uses: []
```

# newbarrier

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#newbarrier
uses: []
```

# lem:kl-reduced-l-geometry-existence-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-reduced-l-geometry-existence-ricci-flow-surgery
uses: []
```

# minimizersexist

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#minimizersexist
uses: []
```

# lem:kl-reduced-l-geometry-existence-reduced-length

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-reduced-l-geometry-existence-reduced-length
uses: []
```

# stillleq3/2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#stillleq3/2
uses: []
```

# rem:kl-reduced-l-geometry-structural-remark-reduced-length

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-reduced-l-geometry-structural-remark-reduced-length
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-reduced-l-geometry-existence-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-reduced-l-geometry-positivity-reduced-l-geometry]]'
```

# def:kl-reduced-l-geometry-kappa-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-reduced-l-geometry-kappa-noncollapsing
uses: []
```

# surgerycollapsedef

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#surgerycollapsedef
uses: []
```

# lem:kl-reduced-l-geometry-existence-reduced-volume

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-reduced-l-geometry-existence-reduced-volume
uses: []
```

# localreducedvolume

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#localreducedvolume
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions]]'
```

# II.5.2section

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.5.2section
uses: []
```

# def:kl-establishing-noncollapsing-presence-surgery-noncollapsing-definition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-establishing-noncollapsing-presence-surgery-noncollapsing-definition
uses: []
```

# lem:kl-establishing-noncollapsing-presence-surgery-existence-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-establishing-noncollapsing-presence-surgery-existence-noncollapsing
uses: []
```

# lplusbig

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lplusbig
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#cor:kl-curves-that-penetrate-surgery-region-ricci-flow-surgery-corollary]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-evolution-surgery-cap-existence-standard-solutions]]'
```

# h<<r

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#h<<r
uses: []
```

# aandthetaconditions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#aandthetaconditions
uses: []
```

# deltasmall

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#deltasmall
uses: []
```

# p'sdisjoint

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#p'sdisjoint
uses: []
```

# lem:kl-establishing-noncollapsing-presence-surgery-vanishing-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-establishing-noncollapsing-presence-surgery-vanishing-noncollapsing
uses: []
```

# Rev

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rev
uses: []
```

# lem:kl-establishing-noncollapsing-presence-surgery-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-establishing-noncollapsing-presence-surgery-existence-kappa-solutions
uses: []
```

# II.5.2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.5.2
uses: []
```

# rem:kl-establishing-noncollapsing-presence-surgery-estimates-kappa-solutions

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-establishing-noncollapsing-presence-surgery-estimates-kappa-solutions
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-canonical-neighborhood-property-standard-solutions-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-canonical-neighborhoods-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-estimates-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-existence-noncollapsing]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-vanishing-noncollapsing]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-evolution-surgery-cap-existence-standard-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-performing-surgery-continuing-flows-existence-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-reduced-l-geometry-existence-reduced-length]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-reduced-l-geometry-existence-reduced-volume]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-reduced-l-geometry-existence-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-standard-solutions-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-structure-at-first-singularity-time-characterization-structure-at-first-singularity-time]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-statement-existence-theorem-ricci-flow-surgery-monotonicity-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions]]'
```

# llplus

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#llplus
uses: []
```

# lplusupper

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lplusupper
uses: []
```

# Rbound2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rbound2
uses: []
```

# kappa1

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#kappa1
uses: []
```

# lem:kl-establishing-noncollapsing-presence-surgery-kappa-solutions-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-establishing-noncollapsing-presence-surgery-kappa-solutions-lemma
uses: []
```

# r0/100

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#r0/100
uses: []
```

# F_1condition

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#F_1condition
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-standard-solutions-existence-kappa-solutions]]'
```

# surgeryflow

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#surgeryflow
uses: []
```

# lem:kl-construction-ricci-flow-surgery-ricci-flow-surgery-lemma

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-construction-ricci-flow-surgery-ricci-flow-surgery-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-canonical-neighborhoods-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-structure-at-first-singularity-time-characterization-structure-at-first-singularity-time]]'
```

# lem:kl-construction-ricci-flow-surgery-convergence-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-construction-ricci-flow-surgery-convergence-ricci-flow-surgery
uses: []
```

# bdrysmoothness

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#bdrysmoothness
uses: []
```

# 2q+1

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#2q+1
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-canonical-neighborhoods-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-estimates-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-evolution-surgery-cap-existence-standard-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-statement-existence-theorem-ricci-flow-surgery-monotonicity-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-canonical-neighborhood-theorem-compactness-canonical-neighborhoods]]'
```

# II.6

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.6
uses: []
```

# lem:kl-double-sided-curvature-bound-thick-part-compactness-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-double-sided-curvature-bound-thick-part-compactness-thick-thin-geometry
uses: []
```

# pscempty

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#pscempty
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-vanishing-noncollapsing]]'
```

# lem:kl-double-sided-curvature-bound-thick-part-compactness-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-double-sided-curvature-bound-thick-part-compactness-ricci-flow-surgery
uses: []
```

# finitetime

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#finitetime
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-performing-surgery-continuing-flows-rigidity-ricci-flow-surgery]]'
```

# cor:kl-double-sided-curvature-bound-thick-part-existence-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#cor:kl-double-sided-curvature-bound-thick-part-existence-ricci-flow-surgery
uses: []
```

# II.6.8

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.6.8
uses: []
```

# II.6.5

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.6.5
uses: []
```

# lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature
uses: []
```

# I.11.6(a)

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#I.11.6(a)
uses: []
```

# lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature-4

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature-4
uses: []
```

# II.6.5(a)

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.6.5(a)
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
```

# lem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-sectional-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-sectional-curvature
uses: []
```

# Alexlemma2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Alexlemma2
uses: []
```

# rem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-volume

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-volume
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-sectional-curvature]]'
```

# prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-canonical-neighborhoods
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
```

# propII.6.3

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#propII.6.3
uses: []
```

# prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-thick-thin-geometry
uses: []
```

# propII.6.4

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#propII.6.4
uses: []
```

# prop:kl-canonical-neighborhoods-later-curvature-bounds-bigger-balls-from-curvatu-existence-canonical-neighborhoods

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-canonical-neighborhoods-later-curvature-bounds-bigger-balls-from-curvatu-existence-canonical-neighborhoods
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#def:kl-priori-assumptions-canonical-neighborhood-assumption]]'
```

# prop:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature
uses: []
```

# lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature-6

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature-6
uses: []
```

# extra

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#extra
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-estimates-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature-4]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-sectional-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-canonical-neighborhoods]]'
```

# lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-scalar-curvature-lemma

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-scalar-curvature-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-estimates-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-scalar-curvature-lemma]]'
```

# lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature-8

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature-8
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-estimates-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-i#lem:kl-length-distortion-estimates-distance-distortion-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-sectional-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-canonical-neighborhoods]]'
```

# rem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-existence-scalar-curvature
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-thick-thin-geometry]]'
```

# rem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-structural-remark-scalar-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-structural-remark-scalar-curvature
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#cor:kl-double-sided-curvature-bound-thick-part-existence-ricci-flow-surgery]]'
```

# hmax

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#hmax
uses: []
```

# II.7.1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.7.1
uses: []
```

# lem:kl-noncollapsed-pointed-limits-hyperbolic-monotonicity-noncollapsing

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-noncollapsed-pointed-limits-hyperbolic-monotonicity-noncollapsing
uses: []
```

# dVdt

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#dVdt
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-vanishing-noncollapsing]]'
```

# def:kl-noncollapsed-pointed-limits-hyperbolic-noncollapsing-definition

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-noncollapsed-pointed-limits-hyperbolic-noncollapsing-definition
uses: []
```

# VR

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#VR
uses: []
```

# lem:kl-noncollapsed-pointed-limits-hyperbolic-noncollapsing-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-noncollapsed-pointed-limits-hyperbolic-noncollapsing-lemma
uses: []
```

# Rhatev

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rhatev
uses: []
```

# Rhat

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rhat
uses: []
```

# cor:kl-noncollapsed-pointed-limits-hyperbolic-monotonicity-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#cor:kl-noncollapsed-pointed-limits-hyperbolic-monotonicity-noncollapsing
uses: []
```

# Rmono

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rmono
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-noncollapsed-pointed-limits-hyperbolic-noncollapsing-lemma]]'
```

# lem:kl-noncollapsed-pointed-limits-hyperbolic-noncollapsing-lemma-5

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-noncollapsed-pointed-limits-hyperbolic-noncollapsing-lemma-5
uses: []
```

# RVlemma

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#RVlemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-vanishing-noncollapsing]]'
```

# prop:kl-noncollapsed-pointed-limits-hyperbolic-convergence-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-noncollapsed-pointed-limits-hyperbolic-convergence-noncollapsing
uses: []
```

# propII.7.1

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#propII.7.1
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-noncollapsed-pointed-limits-hyperbolic-noncollapsing-lemma]]'
```

# poscont

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#poscont
uses: []
```

# Ralign

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Ralign
uses: []
```

# lem:kl-noncollapsed-regions-lower-curvature-bound-almost-hyperbolic-large-scale-noncollapsing-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-noncollapsed-regions-lower-curvature-bound-almost-hyperbolic-large-scale-noncollapsing-lemma
uses: []
```

# lemII.7.2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemII.7.2
uses: []
```

# closeness

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#closeness
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#cor:kl-double-sided-curvature-bound-thick-part-existence-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-noncollapsed-pointed-limits-hyperbolic-convergence-noncollapsing]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-proof-double-sided-curvature-bound-thick-part-modulo-two-propositions-existence-canonical-neighborhoods]]'
```

# def:kl-thick-thin-decomposition-curvature-scale

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-thick-thin-decomposition-curvature-scale
uses: []
```

# lem:kl-thick-thin-decomposition-thick-thin-geometry-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-thick-thin-decomposition-thick-thin-geometry-lemma
uses: []
```

# bigenough

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#bigenough
uses: []
```

# Rblowup

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rblowup
uses: []
```

# rem:kl-thick-thin-decomposition-estimates-canonical-neighborhoods

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-thick-thin-decomposition-estimates-canonical-neighborhoods
uses: []
```

# def:kl-thick-thin-decomposition-thick-thin-decomposition

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-thick-thin-decomposition-thick-thin-decomposition
uses: []
```

# lem:kl-thick-thin-decomposition-existence-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-thick-thin-decomposition-existence-thick-thin-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-thick-thin-decomposition-thick-thin-geometry-lemma]]'
```

# applies

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#applies
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-thick-thin-decomposition-thick-thin-geometry-lemma]]'
```

# hyprig

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#hyprig
uses: []
```

# prop:kl-hyperbolic-rigidity-stabilization-thick-part-monotonicity-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-hyperbolic-rigidity-stabilization-thick-part-monotonicity-thick-thin-geometry
uses: []
```

# slowisotopy

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#slowisotopy
uses: []
```

# rem:kl-hyperbolic-rigidity-stabilization-thick-part-characterization-thick-thin-geometry

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-hyperbolic-rigidity-stabilization-thick-part-characterization-thick-thin-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-hyperbolic-rigidity-stabilization-thick-part-monotonicity-thick-thin-geometry]]'
```

# def:kl-hyperbolic-rigidity-stabilization-thick-part-pointed-smooth-closeness

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-hyperbolic-rigidity-stabilization-thick-part-pointed-smooth-closeness
uses: []
```

# fapprox

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#fapprox
uses: []
```

# lem:kl-hyperbolic-rigidity-stabilization-thick-part-existence-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-hyperbolic-rigidity-stabilization-thick-part-existence-thick-thin-geometry
uses: []
```

# prasad

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prasad
uses: []
```

# def:kl-hyperbolic-rigidity-stabilization-thick-part-hyperbolic-pointed-limit-space

```qprint
kind: definition
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#def:kl-hyperbolic-rigidity-stabilization-thick-part-hyperbolic-pointed-limit-space
uses: []
```

# lem:kl-hyperbolic-rigidity-stabilization-thick-part-existence-cap-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-hyperbolic-rigidity-stabilization-thick-part-existence-cap-geometry
uses: []
```

# II.7.2again

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.7.2again
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-noncollapsed-regions-lower-curvature-bound-almost-hyperbolic-large-scale-noncollapsing-lemma]]'
```

# inctori

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#inctori
uses: []
```

# prop:kl-incompressibility-cuspidal-tori-incompressibility-cuspidal-tori-proposition

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-incompressibility-cuspidal-tori-incompressibility-cuspidal-tori-proposition
uses: []
```

# propincompressible

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#propincompressible
uses: []
```

# injeqn

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#injeqn
uses: []
```

# lem:kl-incompressibility-cuspidal-tori-incompressibility-cuspidal-tori-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-incompressibility-cuspidal-tori-incompressibility-cuspidal-tori-lemma
uses: []
```

# stablelemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#stablelemma
uses: []
```

# eqnpi1inclusion

```qprint
kind: lemma
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eqnpi1inclusion
uses: []
```

# lem:kl-incompressibility-cuspidal-tori-existence-ricci-flow-surgery

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-incompressibility-cuspidal-tori-existence-ricci-flow-surgery
uses: []
```

# lemavoids

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemavoids
uses: []
```

# lem:kl-incompressibility-cuspidal-tori-existence-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-incompressibility-cuspidal-tori-existence-kappa-solutions
uses: []
```

# Hamlemma

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Hamlemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-hyperbolic-rigidity-stabilization-thick-part-monotonicity-thick-thin-geometry]]'
```

# lem:kl-incompressibility-cuspidal-tori-existence-diameter

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-incompressibility-cuspidal-tori-existence-diameter
uses: []
```

# lemsupport

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lemsupport
uses: []
```

# dereqn

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#dereqn
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-vanishing-noncollapsing]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-incompressibility-cuspidal-tori-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-incompressibility-cuspidal-tori-existence-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-hyperbolic-rigidity-stabilization-thick-part-monotonicity-thick-thin-geometry]]'
```

# eqninitial

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eqninitial
uses: []
```

# eqnbdyterm

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eqnbdyterm
uses: []
```

# evolve

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#evolve
uses: []
```

# II.7.4

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.7.4
uses: []
```

# thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry
uses: []
```

# thmII.7.4

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#thmII.7.4
uses: []
```

# rem:kl-thin-part-graph-manifold-estimates-thick-thin-geometry

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-thin-part-graph-manifold-estimates-thick-thin-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry]]'
```

# thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry-3

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry-3
uses: []
```

# thmII.7.4second

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#thmII.7.4second
uses: []
```

# rem:kl-thin-part-graph-manifold-estimates-noncollapsing

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-thin-part-graph-manifold-estimates-noncollapsing
uses: []
```

# rem:kl-thin-part-graph-manifold-structural-remark-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-thin-part-graph-manifold-structural-remark-thick-thin-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry-3]]'
```

# rem:kl-thin-part-graph-manifold-positivity-thick-thin-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-thin-part-graph-manifold-positivity-thick-thin-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry-3]]'
```

# rem:kl-thin-part-graph-manifold-existence-thick-thin-geometry

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-thin-part-graph-manifold-existence-thick-thin-geometry
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-i#thm:kl-no-local-collapsing-theorem-ii-existence-kappa-solutions]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry-3]]'
```

# prop:kl-thin-part-graph-manifold-thick-thin-geometry-proposition

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-thin-part-graph-manifold-thick-thin-geometry-proposition
uses: []
```

# thingraph

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#thingraph
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#cor:kl-double-sided-curvature-bound-thick-part-existence-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-canonical-neighborhoods-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-estimates-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-sectional-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-thin-part-graph-manifold-thick-thin-geometry-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#rem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-structural-remark-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry-3]]'
```

# lem:kl-thin-part-graph-manifold-thick-thin-geometry-lemma

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-thin-part-graph-manifold-thick-thin-geometry-lemma
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry-3]]'
```

# condition

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#condition
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#cor:kl-double-sided-curvature-bound-thick-part-existence-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-canonical-neighborhoods-lemma]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-curvature-bounds-from-priori-assumptions-estimates-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-locating-small-balls-whose-subballs-almost-euclidean-volume-existence-sectional-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#rem:kl-earlier-scalar-curvature-bounds-smaller-balls-from-lower-curvature-bound-structural-remark-scalar-curvature]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#thm:kl-thin-part-graph-manifold-existence-thick-thin-geometry-3]]'
```

# II.8

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#II.8
uses: []
```

# Rayleigh

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Rayleigh
uses: []
```

# ll

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#ll
uses: []
```

# test

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#test
uses: []
```

# yamabe

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#yamabe
uses: []
```

# testt

```qprint
kind: theorem
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#testt
uses: []
```

# prop:kl-alternative-proof-cusp-incompressibility-characterization-graph-manifolds

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-alternative-proof-cusp-incompressibility-characterization-graph-manifolds
uses: []
```

# propYamabe

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#propYamabe
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-double-sided-curvature-bound-thick-part-compactness-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-double-sided-curvature-bound-thick-part-compactness-thick-thin-geometry]]'
```

# prop:kl-alternative-proof-cusp-incompressibility-characterization-graph-manifolds-2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#prop:kl-alternative-proof-cusp-incompressibility-characterization-graph-manifolds-2
uses: []
```

# propII.8.2

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#propII.8.2
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-alternative-proof-cusp-incompressibility-estimates-spectral-geometry]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-alternative-proof-cusp-incompressibility-positivity-entropy]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-double-sided-curvature-bound-thick-part-compactness-ricci-flow-surgery]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-establishing-noncollapsing-presence-surgery-vanishing-noncollapsing]]'
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#prop:kl-statement-existence-theorem-ricci-flow-surgery-monotonicity-kappa-solutions]]'
```

# lem:kl-alternative-proof-cusp-incompressibility-estimates-spectral-geometry

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-alternative-proof-cusp-incompressibility-estimates-spectral-geometry
uses: []
```

# newprop1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#newprop1
uses: []
```

# eig1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eig1
uses: []
```

# eig2

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eig2
uses: []
```

# lem:kl-alternative-proof-cusp-incompressibility-positivity-entropy

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#lem:kl-alternative-proof-cusp-incompressibility-positivity-entropy
uses:
- '[[references/KleinerLott/blueprint/src/chapters/part-ii#lem:kl-alternative-proof-cusp-incompressibility-estimates-spectral-geometry]]'
```

# newprop2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#newprop2
uses: []
```

# eig3

```qprint
kind: proof
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#eig3
uses: []
```

# part1

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#part1
uses: []
```

# Hf

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#Hf
uses: []
```

# part2

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#part2
uses: []
```

# bound11

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#bound11
uses: []
```

# bound12

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#bound12
uses: []
```

# rem:kl-alternative-proof-cusp-incompressibility-positivity-scalar-curvature

```qprint
kind: other
status: not_started
tex: references/KleinerLott/blueprint/src/chapters/part-ii.tex#rem:kl-alternative-proof-cusp-incompressibility-positivity-scalar-curvature
uses: []
```
