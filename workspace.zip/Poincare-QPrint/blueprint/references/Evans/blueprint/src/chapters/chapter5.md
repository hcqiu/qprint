# sec:holder-spaces

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:holder-spaces
uses: []
```

# def:holder-seminorm-sup-norm

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:holder-seminorm-sup-norm
uses: []
```

# def:holder-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:holder-space
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:holder-seminorm-sup-norm]]'
```

# thm:holder-space-banach

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:holder-space-banach
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:holder-space]]'
```

# sec:sobolev-spaces

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:sobolev-spaces
uses: []
```

# def:weak-partial-derivative

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:weak-partial-derivative
uses: []
```

# lem:weak-derivative-uniqueness

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#lem:weak-derivative-uniqueness
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:weak-partial-derivative]]'
```

# ex:weak-derivative-piecewise-linear-example

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#ex:weak-derivative-piecewise-linear-example
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:weak-partial-derivative]]'
```

# ex:weak-derivative-nonexistence-example

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#ex:weak-derivative-nonexistence-example
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:weak-partial-derivative]]'
```

# def:sobolev-space-wkp

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:sobolev-space-wkp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:weak-partial-derivative]]'
```

# rem:hk-notation-identification

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:hk-notation-identification
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
```

# def:sobolev-norm

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:sobolev-norm
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
```

# def:sobolev-convergence

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:sobolev-convergence
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-norm]]'
```

# def:sobolev-space-zero-boundary

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:sobolev-space-zero-boundary
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-convergence]]'
```

# ex:power-singularity-sobolev-membership

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#ex:power-singularity-sobolev-membership
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:weak-partial-derivative]]'
```

# ex:dense-singularities-unbounded-sobolev

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#ex:dense-singularities-unbounded-sobolev
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#ex:power-singularity-sobolev-membership]]'
```

# thm:weak-derivative-properties

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:weak-derivative-properties
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
```

# thm:sobolev-space-banach

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:sobolev-space-banach
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-norm]]'
```

# sec:sobolev-approximation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:sobolev-approximation
uses: []
```

# thm:local-smooth-approximation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:local-smooth-approximation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-convergence]]'
```

# thm:global-smooth-approximation-interior

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:global-smooth-approximation-interior
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:weak-derivative-properties]]'
```

# rem:approximation-not-up-to-boundary

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:approximation-not-up-to-boundary
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:global-smooth-approximation-interior]]'
```

# thm:global-smooth-approximation-boundary

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:global-smooth-approximation-boundary
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:local-smooth-approximation]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:weak-derivative-properties]]'
```

# sec:sobolev-extensions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:sobolev-extensions
uses: []
```

# thm:sobolev-extension-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:sobolev-extension-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:global-smooth-approximation-boundary]]'
```

# def:extension-of-sobolev-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:extension-of-sobolev-function
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-extension-theorem]]'
```

# rem:extension-higher-order-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:extension-higher-order-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-extension-theorem]]'
```

# sec:sobolev-traces

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:sobolev-traces
uses: []
```

# thm:trace-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:trace-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:global-smooth-approximation-boundary]]'
```

# def:trace-operator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:trace-operator
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:trace-theorem]]'
```

# thm:trace-zero-characterization

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:trace-zero-characterization
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-zero-boundary]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:trace-theorem]]'
```

# sec:sobolev-inequalities

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:sobolev-inequalities
uses: []
```

# def:sobolev-conjugate-exponent

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:sobolev-conjugate-exponent
uses: []
```

# thm:gagliardo-nirenberg-sobolev-inequality

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:gagliardo-nirenberg-sobolev-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-conjugate-exponent]]'
```

# thm:sobolev-embedding-w1p-subcritical

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:sobolev-embedding-w1p-subcritical
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:gagliardo-nirenberg-sobolev-inequality]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-extension-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:local-smooth-approximation]]'
```

# thm:poincare-w01p-subcritical

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:poincare-w01p-subcritical
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-zero-boundary]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:gagliardo-nirenberg-sobolev-inequality]]'
```

# rem:poincare-w01p-terminology

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:poincare-w01p-terminology
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:poincare-w01p-subcritical]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-embedding-w1p-subcritical]]'
```

# rem:borderline-case-p-equals-n

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:borderline-case-p-equals-n
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:poincare-w01p-subcritical]]'
```

# thm:morreys-inequality

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:morreys-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:holder-seminorm-sup-norm]]'
```

# rem:morrey-estimate-on-ball

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:morrey-estimate-on-ball
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:morreys-inequality]]'
```

# def:version-of-a-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:version-of-a-function
uses: []
```

# thm:sobolev-embedding-w1p-supercritical

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:sobolev-embedding-w1p-supercritical
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:version-of-a-function]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:morreys-inequality]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-extension-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:local-smooth-approximation]]'
```

# rem:identify-continuous-version

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:identify-continuous-version
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-embedding-w1p-supercritical]]'
```

# thm:general-sobolev-inequalities

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:general-sobolev-inequalities
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:gagliardo-nirenberg-sobolev-inequality]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:morreys-inequality]]'
```

# rem:general-sobolev-fourier-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:general-sobolev-fourier-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:general-sobolev-inequalities]]'
```

# sec:sobolev-compactness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:sobolev-compactness
uses: []
```

# def:compact-embedding

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:compact-embedding
uses: []
```

# thm:rellich-kondrachov

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:rellich-kondrachov
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:compact-embedding]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-embedding-w1p-subcritical]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-extension-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:local-smooth-approximation]]'
```

# rem:compact-embedding-lp-all-p

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:compact-embedding-lp-all-p
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:rellich-kondrachov]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-embedding-w1p-subcritical]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:morreys-inequality]]'
```

# sec:sobolev-additional-topics

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:sobolev-additional-topics
uses: []
```

# thm:poincares-inequality-connected

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:poincares-inequality-connected
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:rellich-kondrachov]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
```

# thm:poincares-inequality-ball

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:poincares-inequality-ball
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:poincares-inequality-connected]]'
```

# rem:bmo-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:bmo-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:poincares-inequality-ball]]'
```

# def:difference-quotients

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:difference-quotients
uses: []
```

# thm:difference-quotients-weak-derivatives

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:difference-quotients-weak-derivatives
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:difference-quotients]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
```

# rem:difference-quotient-p1-fails

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:difference-quotient-p1-fails
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:difference-quotients-weak-derivatives]]'
```

# rem:difference-quotient-half-ball-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:difference-quotient-half-ball-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:difference-quotients-weak-derivatives]]'
```

# thm:characterization-w1infty-lipschitz

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:characterization-w1infty-lipschitz
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-extension-theorem]]'
```

# rem:local-lipschitz-w1infty-loc-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#rem:local-lipschitz-w1infty-loc-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:characterization-w1infty-lipschitz]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-embedding-w1p-supercritical]]'
```

# def:differentiability-at-a-point

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:differentiability-at-a-point
uses: []
```

# thm:differentiability-almost-everywhere

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:differentiability-almost-everywhere
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:differentiability-at-a-point]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:morreys-inequality]]'
```

# thm:rademachers-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:rademachers-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:differentiability-almost-everywhere]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:characterization-w1infty-lipschitz]]'
```

# thm:characterization-hk-fourier-transform

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:characterization-hk-fourier-transform
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#rem:hk-notation-identification]]'
```

# def:fractional-sobolev-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:fractional-sobolev-space
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:characterization-hk-fourier-transform]]'
```

# sec:other-spaces-of-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:other-spaces-of-functions
uses: []
```

# def:dual-space-h-minus-1

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:dual-space-h-minus-1
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-zero-boundary]]'
```

# def:norm-on-h-minus-1

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:norm-on-h-minus-1
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:dual-space-h-minus-1]]'
```

# thm:characterization-h-minus-1

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:characterization-h-minus-1
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:norm-on-h-minus-1]]'
```

# def:lp-time-banach-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:lp-time-banach-space
uses: []
```

# def:continuous-time-banach-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:continuous-time-banach-space
uses: []
```

# def:weak-derivative-banach-valued

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:weak-derivative-banach-valued
uses: []
```

# def:sobolev-space-time-banach

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#def:sobolev-space-time-banach
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:lp-time-banach-space]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:weak-derivative-banach-valued]]'
```

# thm:calculus-abstract-space

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:calculus-abstract-space
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-time-banach]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:local-smooth-approximation]]'
```

# thm:more-calculus-h1-hminus1

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:more-calculus-h1-hminus1
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-time-banach]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:dual-space-h-minus-1]]'
```

# thm:mappings-into-better-spaces

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#thm:mappings-into-better-spaces
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-time-banach]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:sobolev-extension-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:difference-quotients-weak-derivatives]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:more-calculus-h1-hminus1]]'
```

# sec:sobolev-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter5.tex#sec:sobolev-references
uses: []
```
