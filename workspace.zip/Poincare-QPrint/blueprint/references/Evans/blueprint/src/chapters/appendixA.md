# sec:basic-notation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:basic-notation
uses: []
```

# sec:notation-for-matrices

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:notation-for-matrices
uses: []
```

# def:matrix-notation-basic

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#def:matrix-notation-basic
uses: []
```

# def:matrix-quadratic-form-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#def:matrix-quadratic-form-notation
uses: []
```

# sec:geometric-notation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:geometric-notation
uses: []
```

# def:geometric-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#def:geometric-notation
uses: []
```

# sec:notation-for-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:notation-for-functions
uses: []
```

# def:function-notation-basic

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#def:function-notation-basic
uses:
- '[[references/Evans/blueprint/src/chapters/appendixA#def:geometric-notation]]'
```

# sec:notation-for-derivatives

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:notation-for-derivatives
uses: []
```

# def:derivative-notation-multiindex

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#def:derivative-notation-multiindex
uses: []
```

# sec:function-spaces-notation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:function-spaces-notation
uses: []
```

# def:function-space-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#def:function-space-notation
uses:
- '[[references/Evans/blueprint/src/chapters/appendixA#def:derivative-notation-multiindex]]'
- '[[references/Evans/blueprint/src/chapters/appendixA#def:geometric-notation]]'
```

# sec:vector-valued-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:vector-valued-functions
uses: []
```

# def:vector-valued-function-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#def:vector-valued-function-notation
uses:
- '[[references/Evans/blueprint/src/chapters/appendixA#def:derivative-notation-multiindex]]'
- '[[references/Evans/blueprint/src/chapters/appendixA#def:function-notation-basic]]'
```

# rem:boldface-convention-sub-superscripts

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#rem:boldface-convention-sub-superscripts
uses:
- '[[references/Evans/blueprint/src/chapters/appendixA#def:vector-valued-function-notation]]'
```

# sec:notation-for-estimates

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:notation-for-estimates
uses: []
```

# rem:constant-notation-convention

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#rem:constant-notation-convention
uses: []
```

# def:big-oh-little-oh-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#def:big-oh-little-oh-notation
uses: []
```

# rem:big-oh-little-oh-implicit-limit

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#rem:big-oh-little-oh-implicit-limit
uses:
- '[[references/Evans/blueprint/src/chapters/appendixA#def:big-oh-little-oh-notation]]'
```

# sec:comments-about-notation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#sec:comments-about-notation
uses: []
```

# rem:gradient-notation-choice-du

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#rem:gradient-notation-choice-du
uses:
- '[[references/Evans/blueprint/src/chapters/appendixA#def:derivative-notation-multiindex]]'
```

# rem:domain-notation-choice-u

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixA.tex#rem:domain-notation-choice-u
uses:
- '[[references/Evans/blueprint/src/chapters/appendixA#def:geometric-notation]]'
```
