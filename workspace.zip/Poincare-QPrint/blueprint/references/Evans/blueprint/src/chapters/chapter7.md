# sec:second-order-parabolic-equations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#sec:second-order-parabolic-equations
uses: []
```

# def:uniform-parabolicity

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:uniform-parabolicity
uses: []
```

# rem:parabolic-operator-elliptic-fixed-time

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-operator-elliptic-fixed-time
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:uniform-parabolicity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:uniform-ellipticity]]'
```

# rem:motivation-weak-solution-parabolic

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:motivation-weak-solution-parabolic
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-time-banach]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:dual-space-h-minus-1]]'
```

# def:weak-solution-parabolic-bvp

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:weak-solution-parabolic-bvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#rem:motivation-weak-solution-parabolic]]'
```

# rem:weak-solution-parabolic-continuity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:weak-solution-parabolic-continuity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-parabolic-bvp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:more-calculus-h1-hminus1]]'
```

# thm:parabolic-galerkin-approximate-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-galerkin-approximate-solutions
uses: []
```

# thm:parabolic-energy-estimates

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-energy-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-galerkin-approximate-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:energy-estimates]]'
```

# thm:parabolic-existence-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-existence-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-galerkin-approximate-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-energy-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-parabolic-bvp]]'
```

# thm:parabolic-uniqueness-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-uniqueness-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-parabolic-bvp]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:energy-estimates]]'
```

# rem:parabolic-regularity-motivation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-regularity-motivation
uses: []
```

# thm:parabolic-improved-regularity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-improved-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-parabolic-bvp]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:boundary-h2-regularity]]'
```

# rem:parabolic-improved-regularity-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-improved-regularity-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-improved-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#rem:parabolic-regularity-motivation]]'
```

# rem:parabolic-regularity-symmetric-eigenfunctions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-regularity-symmetric-eigenfunctions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-improved-regularity]]'
```

# thm:parabolic-higher-regularity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-higher-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-improved-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:higher-boundary-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:mappings-into-better-spaces]]'
```

# rem:parabolic-compatibility-conditions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-compatibility-conditions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-higher-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:mappings-into-better-spaces]]'
```

# thm:parabolic-infinite-differentiability

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-infinite-differentiability
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-higher-regularity]]'
```

# rem:parabolic-interior-estimates

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-interior-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-infinite-differentiability]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:interior-h2-regularity]]'
```

# thm:parabolic-weak-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-weak-maximum-principle
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:uniform-parabolicity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:weak-maximum-principle-c-zero]]'
```

# rem:parabolic-subsolution-supersolution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-subsolution-supersolution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-weak-maximum-principle]]'
```

# thm:parabolic-weak-maximum-principle-c-nonneg

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-weak-maximum-principle-c-nonneg
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-weak-maximum-principle]]'
```

# rem:parabolic-weak-max-principle-abs-value

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-weak-max-principle-abs-value
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-weak-maximum-principle-c-nonneg]]'
```

# rem:parabolic-max-principle-negative-c

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-max-principle-negative-c
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-weak-maximum-principle-c-nonneg]]'
```

# thm:parabolic-harnack-inequality

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-harnack-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-weak-maximum-principle]]'
```

# thm:parabolic-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-strong-maximum-principle
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-weak-maximum-principle]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-harnack-inequality]]'
```

# rem:parabolic-infinite-propagation-speed

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-infinite-propagation-speed
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-strong-maximum-principle]]'
```

# thm:parabolic-strong-maximum-principle-c-nonneg

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-strong-maximum-principle-c-nonneg
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-strong-maximum-principle]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-weak-maximum-principle-c-nonneg]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-harnack-inequality]]'
```

# sec:second-order-hyperbolic-equations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#sec:second-order-hyperbolic-equations
uses: []
```

# def:uniform-hyperbolicity

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:uniform-hyperbolicity
uses: []
```

# rem:motivation-weak-solution-hyperbolic

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:motivation-weak-solution-hyperbolic
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#rem:motivation-weak-solution-parabolic]]'
```

# def:weak-solution-hyperbolic-bvp

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:weak-solution-hyperbolic-bvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#rem:motivation-weak-solution-hyperbolic]]'
```

# rem:weak-solution-hyperbolic-continuity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:weak-solution-hyperbolic-continuity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-hyperbolic-bvp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:calculus-abstract-space]]'
```

# thm:hyperbolic-galerkin-approximate-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-galerkin-approximate-solutions
uses: []
```

# thm:hyperbolic-energy-estimates

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-energy-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-galerkin-approximate-solutions]]'
```

# thm:hyperbolic-existence-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-existence-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-galerkin-approximate-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-energy-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-hyperbolic-bvp]]'
```

# rem:hyperbolic-existence-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:hyperbolic-existence-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-existence-weak-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-energy-estimates]]'
```

# thm:hyperbolic-uniqueness-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-uniqueness-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-hyperbolic-bvp]]'
```

# rem:hyperbolic-uniqueness-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:hyperbolic-uniqueness-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-uniqueness-weak-solution]]'
```

# rem:hyperbolic-regularity-motivation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:hyperbolic-regularity-motivation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-nonhomogeneous-duhamel]]'
```

# thm:hyperbolic-improved-regularity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-improved-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-hyperbolic-bvp]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-improved-regularity]]'
```

# rem:hyperbolic-improved-regularity-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:hyperbolic-improved-regularity-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-improved-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#rem:hyperbolic-regularity-motivation]]'
```

# rem:hyperbolic-symmetric-eigenfunctions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:hyperbolic-symmetric-eigenfunctions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-improved-regularity]]'
```

# thm:hyperbolic-higher-regularity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-higher-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-improved-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:mappings-into-better-spaces]]'
```

# rem:hyperbolic-higher-regularity-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:hyperbolic-higher-regularity-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-higher-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:mappings-into-better-spaces]]'
```

# thm:hyperbolic-infinite-differentiability

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-infinite-differentiability
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-higher-regularity]]'
```

# thm:hyperbolic-finite-propagation-speed

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-finite-propagation-speed
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:uniform-hyperbolicity]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-finite-propagation-speed]]'
```

# rem:hyperbolic-finite-propagation-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:hyperbolic-finite-propagation-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hyperbolic-finite-propagation-speed]]'
```

# sec:hyperbolic-systems-first-order-equations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#sec:hyperbolic-systems-first-order-equations
uses: []
```

# def:hyperbolic-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:hyperbolic-system
uses: []
```

# def:symmetric-strictly-hyperbolic-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:symmetric-strictly-hyperbolic-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:hyperbolic-system]]'
```

# rem:motivation-hyperbolicity-plane-wave

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:motivation-hyperbolicity-plane-wave
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:hyperbolic-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#def:traveling-wave-plane-wave]]'
```

# rem:symmetric-hyperbolic-general-systems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:symmetric-hyperbolic-general-systems
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:symmetric-strictly-hyperbolic-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#def:uniform-hyperbolicity]]'
```

# def:weak-solution-symmetric-hyperbolic-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:weak-solution-symmetric-hyperbolic-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#rem:symmetric-hyperbolic-general-systems]]'
```

# rem:weak-solution-symmetric-hyperbolic-continuity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:weak-solution-symmetric-hyperbolic-continuity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-symmetric-hyperbolic-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:calculus-abstract-space]]'
```

# thm:symmetric-hyperbolic-approximate-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:symmetric-hyperbolic-approximate-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# thm:symmetric-hyperbolic-energy-estimates

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:symmetric-hyperbolic-energy-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:symmetric-hyperbolic-approximate-solutions]]'
```

# thm:symmetric-hyperbolic-existence-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:symmetric-hyperbolic-existence-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:symmetric-hyperbolic-energy-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-symmetric-hyperbolic-system]]'
```

# thm:symmetric-hyperbolic-uniqueness-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:symmetric-hyperbolic-uniqueness-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:weak-solution-symmetric-hyperbolic-system]]'
```

# thm:constant-coefficient-hyperbolic-existence

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:constant-coefficient-hyperbolic-existence
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:fractional-sobolev-space]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#def:fourier-transform-l1]]'
```

# sec:semigroup-theory

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#sec:semigroup-theory
uses: []
```

# def:semigroup-contraction-semigroup

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:semigroup-contraction-semigroup
uses: []
```

# def:semigroup-generator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:semigroup-generator
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:semigroup-contraction-semigroup]]'
```

# thm:semigroup-differential-properties

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:semigroup-differential-properties
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:semigroup-generator]]'
```

# rem:semigroup-c1-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:semigroup-c1-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:semigroup-differential-properties]]'
```

# thm:semigroup-generator-properties

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:semigroup-generator-properties
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:semigroup-generator]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:semigroup-differential-properties]]'
```

# rem:closed-operator-definition

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:closed-operator-definition
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:semigroup-generator-properties]]'
```

# def:resolvent-set-operator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#def:resolvent-set-operator
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:semigroup-generator]]'
```

# thm:resolvent-operator-properties

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:resolvent-operator-properties
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:resolvent-set-operator]]'
```

# rem:resolvent-laplace-transform-semigroup

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:resolvent-laplace-transform-semigroup
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:resolvent-operator-properties]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:resolvent-laplace-transform]]'
```

# sec:generating-contraction-semigroups

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#sec:generating-contraction-semigroups
uses: []
```

# thm:hille-yosida-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hille-yosida-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#def:semigroup-contraction-semigroup]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#def:semigroup-generator]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:resolvent-operator-properties]]'
```

# rem:omega-contractive-semigroup

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:omega-contractive-semigroup
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hille-yosida-theorem]]'
```

# thm:parabolic-pde-as-semigroup

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:parabolic-pde-as-semigroup
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hille-yosida-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:energy-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:boundary-h2-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:first-existence-weak-solutions]]'
```

# rem:parabolic-semigroup-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#rem:parabolic-semigroup-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-pde-as-semigroup]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-existence-weak-solution]]'
```

# thm:hyperbolic-pde-as-semigroup

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#thm:hyperbolic-pde-as-semigroup
uses:
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:hille-yosida-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter7#thm:parabolic-pde-as-semigroup]]'
```

# sec:chapter7-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter7.tex#sec:chapter7-references
uses: []
```
