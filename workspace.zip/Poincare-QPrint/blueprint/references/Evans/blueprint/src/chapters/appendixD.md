# sec:linear-functional-analysis

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#sec:linear-functional-analysis
uses: []
```

# sec:banach-spaces

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#sec:banach-spaces
uses: []
```

# def:norm-normed-linear-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:norm-normed-linear-space
uses: []
```

# def:convergence-normed-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:convergence-normed-space
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:norm-normed-linear-space]]'
```

# def:cauchy-sequence-complete-banach-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:cauchy-sequence-complete-banach-space
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:norm-normed-linear-space]]'
```

# def:separable-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:separable-space
uses: []
```

# ex:banach-space-examples-lp-holder-sobolev

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#ex:banach-space-examples-lp-holder-sobolev
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:cauchy-sequence-complete-banach-space]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:holder-space]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-wkp]]'
```

# sec:hilbert-spaces

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#sec:hilbert-spaces
uses: []
```

# def:inner-product

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:inner-product
uses: []
```

# def:norm-from-inner-product

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:norm-from-inner-product
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:inner-product]]'
```

# lem:cauchy-schwarz-inequality-hilbert

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#lem:cauchy-schwarz-inequality-hilbert
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:cauchy-schwarz-inequality]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:inner-product]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:norm-from-inner-product]]'
```

# def:hilbert-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:hilbert-space
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:cauchy-sequence-complete-banach-space]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:inner-product]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:norm-from-inner-product]]'
```

# ex:l2-hilbert-space-example

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#ex:l2-hilbert-space-example
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:hilbert-space]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:inner-product]]'
```

# ex:h1-hilbert-space-example

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#ex:h1-hilbert-space-example
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:hilbert-space]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:inner-product]]'
```

# def:orthogonal-orthonormal-basis

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:orthogonal-orthonormal-basis
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:hilbert-space]]'
```

# def:orthogonal-complement-subspace

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:orthogonal-complement-subspace
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:orthogonal-orthonormal-basis]]'
```

# sec:bounded-linear-operators

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#sec:bounded-linear-operators
uses: []
```

# def:linear-operator-banach

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:linear-operator-banach
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:cauchy-sequence-complete-banach-space]]'
```

# def:bounded-linear-operator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:bounded-linear-operator
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:linear-operator-banach]]'
```

# def:closed-linear-operator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:closed-linear-operator
uses: []
```

# thm:closed-graph-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#thm:closed-graph-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:closed-linear-operator]]'
```

# def:resolvent-set-spectrum-appendix-d

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:resolvent-set-spectrum-appendix-d
uses: []
```

# rem:resolvent-inverse-bounded

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#rem:resolvent-inverse-bounded
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#thm:closed-graph-theorem]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:resolvent-set-spectrum-appendix-d]]'
```

# def:eigenvalue-eigenvector-appendix-d

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:eigenvalue-eigenvector-appendix-d
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:resolvent-set-spectrum-appendix-d]]'
```

# def:bounded-linear-functional-dual-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:bounded-linear-functional-dual-space
uses: []
```

# def:dual-pairing-reflexive-banach-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:dual-pairing-reflexive-banach-space
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:bounded-linear-functional-dual-space]]'
```

# thm:riesz-representation-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#thm:riesz-representation-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:hilbert-space]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:bounded-linear-functional-dual-space]]'
```

# def:adjoint-symmetric-operator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:adjoint-symmetric-operator
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#thm:riesz-representation-theorem]]'
```

# sec:weak-convergence-appendix-d

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#sec:weak-convergence-appendix-d
uses: []
```

# def:weak-convergence

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:weak-convergence
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:bounded-linear-functional-dual-space]]'
```

# rem:weak-convergence-basic-properties

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#rem:weak-convergence-basic-properties
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:weak-convergence]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:convergence-normed-space]]'
```

# thm:weak-compactness-reflexive-banach

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#thm:weak-compactness-reflexive-banach
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:weak-convergence]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:dual-pairing-reflexive-banach-space]]'
```

# thm:mazurs-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#thm:mazurs-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:weak-convergence]]'
```

# ex:weak-convergence-lp-duality

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#ex:weak-convergence-lp-duality
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:weak-convergence]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#thm:weak-compactness-reflexive-banach]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:dual-pairing-reflexive-banach-space]]'
```

# sec:compact-operators-fredholm-theory

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#sec:compact-operators-fredholm-theory
uses: []
```

# def:compact-linear-operator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#def:compact-linear-operator
uses: []
```

# rem:compact-operator-weak-to-strong-convergence

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#rem:compact-operator-weak-to-strong-convergence
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:compact-linear-operator]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:weak-convergence]]'
```

# thm:compactness-of-adjoint-operator

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#thm:compactness-of-adjoint-operator
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:compact-linear-operator]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:adjoint-symmetric-operator]]'
```

# thm:fredholm-alternative

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#thm:fredholm-alternative
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#thm:compactness-of-adjoint-operator]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:compact-linear-operator]]'
```

# rem:fredholm-alternative-dichotomy

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#rem:fredholm-alternative-dichotomy
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#thm:fredholm-alternative]]'
```

# thm:spectrum-of-compact-operator

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#thm:spectrum-of-compact-operator
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#thm:fredholm-alternative]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:resolvent-set-spectrum-appendix-d]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:eigenvalue-eigenvector-appendix-d]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:compact-linear-operator]]'
```

# sec:symmetric-operators

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#sec:symmetric-operators
uses: []
```

# lem:bounds-on-spectrum-symmetric-operator

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixD.tex#lem:bounds-on-spectrum-symmetric-operator
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:adjoint-symmetric-operator]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:resolvent-set-spectrum-appendix-d]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:lax-milgram-theorem]]'
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:cauchy-schwarz-inequality]]'
```
