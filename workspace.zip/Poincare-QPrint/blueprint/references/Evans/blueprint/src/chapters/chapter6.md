# sec:elliptic-equations-definitions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#sec:elliptic-equations-definitions
uses: []
```

# def:divergence-nondivergence-form

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#def:divergence-nondivergence-form
uses: []
```

# rem:elliptic-operator-form-conversion

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:elliptic-operator-form-conversion
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:divergence-nondivergence-form]]'
```

# def:uniform-ellipticity

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#def:uniform-ellipticity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:divergence-nondivergence-form]]'
```

# rem:elliptic-pde-physical-interpretation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:elliptic-pde-physical-interpretation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:uniform-ellipticity]]'
```

# def:bilinear-form-weak-solution-l2

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#def:bilinear-form-weak-solution-l2
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:divergence-nondivergence-form]]'
```

# rem:variational-formulation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:variational-formulation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:bilinear-form-weak-solution-l2]]'
```

# def:weak-solution-elliptic-bvp

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#def:weak-solution-elliptic-bvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:bilinear-form-weak-solution-l2]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:characterization-h-minus-1]]'
```

# rem:nonzero-boundary-weak-solution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:nonzero-boundary-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:weak-solution-elliptic-bvp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#def:trace-operator]]'
```

# sec:existence-of-weak-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#sec:existence-of-weak-solutions
uses: []
```

# thm:lax-milgram-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:lax-milgram-theorem
uses: []
```

# rem:lax-milgram-symmetric-case

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:lax-milgram-symmetric-case
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:lax-milgram-theorem]]'
```

# thm:energy-estimates

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:energy-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:bilinear-form-weak-solution-l2]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:uniform-ellipticity]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:poincare-w01p-subcritical]]'
```

# thm:first-existence-weak-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:first-existence-weak-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:lax-milgram-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:energy-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:bilinear-form-weak-solution-l2]]'
```

# rem:general-rhs-weak-solution-isomorphism

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:general-rhs-weak-solution-isomorphism
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:first-existence-weak-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:weak-solution-elliptic-bvp]]'
```

# ex:energy-estimates-gamma-zero-examples

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#ex:energy-estimates-gamma-zero-examples
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:energy-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:poincare-w01p-subcritical]]'
```

# def:formal-adjoint-operator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#def:formal-adjoint-operator
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:divergence-nondivergence-form]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:bilinear-form-weak-solution-l2]]'
```

# thm:second-existence-fredholm-alternative

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:second-existence-fredholm-alternative
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:first-existence-weak-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:formal-adjoint-operator]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:rellich-kondrachov]]'
```

# thm:third-existence-spectrum

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:third-existence-spectrum
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:second-existence-fredholm-alternative]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:energy-estimates]]'
```

# def:spectrum-of-operator

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#def:spectrum-of-operator
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:third-existence-spectrum]]'
```

# rem:eigenvalues-helmholtz-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:eigenvalues-helmholtz-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:spectrum-of-operator]]'
```

# thm:boundedness-of-inverse

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:boundedness-of-inverse
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:third-existence-spectrum]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:energy-estimates]]'
```

# rem:complex-valued-weak-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:complex-valued-weak-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:lax-milgram-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:second-existence-fredholm-alternative]]'
```

# sec:elliptic-regularity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#sec:elliptic-regularity
uses: []
```

# thm:interior-h2-regularity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:interior-h2-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:uniform-ellipticity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:weak-solution-elliptic-bvp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:difference-quotients-weak-derivatives]]'
```

# rem:interior-regularity-remarks

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:interior-regularity-remarks
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:interior-h2-regularity]]'
```

# thm:higher-interior-regularity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:higher-interior-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:interior-h2-regularity]]'
```

# thm:interior-infinite-differentiability

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:interior-infinite-differentiability
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:higher-interior-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:general-sobolev-inequalities]]'
```

# thm:boundary-h2-regularity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:boundary-h2-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:uniform-ellipticity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:weak-solution-elliptic-bvp]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:difference-quotients-weak-derivatives]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:interior-h2-regularity]]'
```

# rem:boundary-regularity-remarks

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:boundary-regularity-remarks
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:boundary-h2-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:boundedness-of-inverse]]'
```

# thm:higher-boundary-regularity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:higher-boundary-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:boundary-h2-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:higher-interior-regularity]]'
```

# rem:higher-boundary-regularity-simplified

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:higher-boundary-regularity-simplified
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:higher-boundary-regularity]]'
```

# thm:boundary-infinite-differentiability

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:boundary-infinite-differentiability
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:higher-boundary-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:general-sobolev-inequalities]]'
```

# sec:elliptic-maximum-principles

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#sec:elliptic-maximum-principles
uses: []
```

# thm:weak-maximum-principle-c-zero

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:weak-maximum-principle-c-zero
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:uniform-ellipticity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:divergence-nondivergence-form]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:boundary-h2-regularity]]'
```

# rem:subsolution-supersolution-terminology

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:subsolution-supersolution-terminology
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:weak-maximum-principle-c-zero]]'
```

# thm:weak-maximum-principle-c-nonneg

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:weak-maximum-principle-c-nonneg
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:weak-maximum-principle-c-zero]]'
```

# rem:weak-maximum-principle-absolute-value

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:weak-maximum-principle-absolute-value
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:weak-maximum-principle-c-nonneg]]'
```

# lem:hopfs-lemma

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#lem:hopfs-lemma
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:uniform-ellipticity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:weak-maximum-principle-c-zero]]'
```

# rem:hopfs-lemma-strict-inequality

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:hopfs-lemma-strict-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#lem:hopfs-lemma]]'
```

# thm:strong-maximum-principle-c-zero

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:strong-maximum-principle-c-zero
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#lem:hopfs-lemma]]'
```

# thm:strong-maximum-principle-c-nonneg

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:strong-maximum-principle-c-nonneg
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#lem:hopfs-lemma]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:strong-maximum-principle-c-zero]]'
```

# thm:harnacks-inequality-elliptic

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:harnacks-inequality-elliptic
uses: []
```

# sec:elliptic-eigenvalues

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#sec:elliptic-eigenvalues
uses: []
```

# thm:existence-eigenvalues-symmetric-operator

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:existence-eigenvalues-symmetric-operator
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:second-existence-fredholm-alternative]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:rellich-kondrachov]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:bilinear-form-weak-solution-l2]]'
```

# rem:eigenfunctions-smoothness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:eigenfunctions-smoothness
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:existence-eigenvalues-symmetric-operator]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:interior-infinite-differentiability]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:boundary-infinite-differentiability]]'
```

# def:principal-eigenvalue

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#def:principal-eigenvalue
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:existence-eigenvalues-symmetric-operator]]'
```

# thm:variational-principle-principal-eigenvalue

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:variational-principle-principal-eigenvalue
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:existence-eigenvalues-symmetric-operator]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#def:principal-eigenvalue]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:strong-maximum-principle-c-zero]]'
```

# rem:principal-eigenvalue-simple-rayleigh

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#rem:principal-eigenvalue-simple-rayleigh
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:variational-principle-principal-eigenvalue]]'
```

# thm:principal-eigenvalue-nonsymmetric-operator

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#thm:principal-eigenvalue-nonsymmetric-operator
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:strong-maximum-principle-c-nonneg]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#lem:hopfs-lemma]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:weak-maximum-principle-c-nonneg]]'
```

# sec:elliptic-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter6.tex#sec:elliptic-references
uses: []
```
