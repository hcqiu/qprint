# lem:heat-ball-parabolic-scaling

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:heat-ball-parabolic-scaling
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:heat-ball]]'
```

# lem:heat-convolution-bounded-initial-trace

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:heat-convolution-bounded-initial-trace
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:heat-convolution-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:integral-fundamental-solution-heat]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:heat-kernel-solves-heat-equation]]'
```

# lem:sourced-weak-radial-ode-identity

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:sourced-weak-radial-ode-identity
uses:
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:weak-green-identity-compact-test]]'
```

# lem:uniqueness-heat-bounded-domain-anisotropic

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:uniqueness-heat-bounded-domain-anisotropic
uses:
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:weak-maximum-principle-heat-anisotropic]]'
```

# lem:wave-cauchy-uniqueness-1d

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:wave-cauchy-uniqueness-1d
uses: []
```

# lem:wave-finite-propagation-1d

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:wave-finite-propagation-1d
uses: []
```

# lem:wave-spherical-mean-smoothness

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:wave-spherical-mean-smoothness
uses: []
```

# lem:wave-spherical-mean-time-derivative

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:wave-spherical-mean-time-derivative
uses:
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:wave-spherical-mean-smoothness]]'
```

# lem:weak-divergence-form-radial-equation

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:weak-divergence-form-radial-equation
uses:
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:sourced-weak-radial-ode-identity]]'
```

# lem:weak-green-identity-compact-test

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:weak-green-identity-compact-test
uses: []
```

# lem:weak-maximum-principle-heat-anisotropic

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:weak-maximum-principle-heat-anisotropic
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:parabolic-cylinder-heat-ball]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:parabolic-boundary-heat-ball]]'
```

# lem:weak-radial-ode-identity

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#lem:weak-radial-ode-identity
uses:
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:weak-green-identity-compact-test]]'
```

# thm:wave-1d-converse-representation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/formalization-support.tex#thm:wave-1d-converse-representation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:dalembert-initial-conditions]]'
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:wave-cauchy-uniqueness-1d]]'
```
