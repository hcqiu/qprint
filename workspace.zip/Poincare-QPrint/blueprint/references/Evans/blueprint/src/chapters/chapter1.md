# sec:pde-introduction

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:pde-introduction
uses: []
```

# def:kth-order-pde

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:kth-order-pde
uses: []
```

# def:linear-semilinear-quasilinear-fully-nonlinear

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:linear-semilinear-quasilinear-fully-nonlinear
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
```

# def:kth-order-system-pde

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:kth-order-system-pde
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
```

# def:system-linear-semilinear-quasilinear-fully-nonlinear

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:system-linear-semilinear-quasilinear-fully-nonlinear
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# def:non-square-linear-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:non-square-linear-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:system-linear-semilinear-quasilinear-fully-nonlinear]]'
```

# rem:pde-abbreviation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#rem:pde-abbreviation
uses: []
```

# sec:pde-examples

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:pde-examples
uses: []
```

# sec:single-pdes

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:single-pdes
uses: []
```

# sec:examples-linear-equations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:examples-linear-equations
uses: []
```

# ex:laplaces-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:laplaces-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:helmholtz-eigenvalue-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:helmholtz-eigenvalue-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:linear-transport-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:linear-transport-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:liouvilles-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:liouvilles-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:heat-diffusion-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:heat-diffusion-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:schrodingers-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:schrodingers-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:system-linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:kolmogorovs-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:kolmogorovs-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:fokker-planck-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:fokker-planck-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:wave-equation-example

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:wave-equation-example
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:telegraph-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:telegraph-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:general-wave-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:general-wave-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:airys-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:airys-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:beam-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:beam-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# sec:examples-nonlinear-equations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:examples-nonlinear-equations
uses: []
```

# ex:eikonal-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:eikonal-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:nonlinear-poisson-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:nonlinear-poisson-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:p-laplacian-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:p-laplacian-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:minimal-surface-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:minimal-surface-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:monge-ampere-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:monge-ampere-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:hamilton-jacobi-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:hamilton-jacobi-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:scalar-conservation-law

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:scalar-conservation-law
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:inviscid-burgers-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:inviscid-burgers-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#ex:scalar-conservation-law]]'
```

# ex:scalar-reaction-diffusion-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:scalar-reaction-diffusion-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:porous-medium-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:porous-medium-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:nonlinear-wave-equations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:nonlinear-wave-equations
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:kdv-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:kdv-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:linear-semilinear-quasilinear-fully-nonlinear]]'
```

# sec:systems-of-pdes

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:systems-of-pdes
uses: []
```

# sec:examples-linear-systems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:examples-linear-systems
uses: []
```

# ex:linear-elasticity-equilibrium

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:linear-elasticity-equilibrium
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:system-linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:linear-elasticity-evolution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:linear-elasticity-evolution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:system-linear-semilinear-quasilinear-fully-nonlinear]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#ex:linear-elasticity-equilibrium]]'
```

# ex:maxwells-equations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:maxwells-equations
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:non-square-linear-system]]'
```

# sec:examples-nonlinear-systems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:examples-nonlinear-systems
uses: []
```

# ex:system-conservation-laws

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:system-conservation-laws
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:system-linear-semilinear-quasilinear-fully-nonlinear]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#ex:scalar-conservation-law]]'
```

# ex:reaction-diffusion-system

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:reaction-diffusion-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:system-linear-semilinear-quasilinear-fully-nonlinear]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#ex:scalar-reaction-diffusion-equation]]'
```

# ex:euler-equations-incompressible-inviscid

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:euler-equations-incompressible-inviscid
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:system-linear-semilinear-quasilinear-fully-nonlinear]]'
```

# ex:navier-stokes-equations-incompressible-viscous

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:navier-stokes-equations-incompressible-viscous
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-system-pde]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:system-linear-semilinear-quasilinear-fully-nonlinear]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#ex:euler-equations-incompressible-inviscid]]'
```

# sec:strategies-studying-pde

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:strategies-studying-pde
uses: []
```

# sec:well-posed-classical-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:well-posed-classical-solutions
uses: []
```

# def:well-posed-problem

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:well-posed-problem
uses: []
```

# def:classical-solution

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:classical-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:kth-order-pde]]'
```

# sec:weak-solutions-regularity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:weak-solutions-regularity
uses: []
```

# sec:multiindex-calculus

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#sec:multiindex-calculus
uses: []
```

# ex:multinomial-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#ex:multinomial-theorem
uses: []
```

# def:partial-derivative

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:partial-derivative
uses: []
```

# def:multiindex-partial-derivative

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#def:multiindex-partial-derivative
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:partial-derivative]]'
```

# prop:clairaut-partial-commute

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#prop:clairaut-partial-commute
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:partial-derivative]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#def:multiindex-partial-derivative]]'
```

# prop:iterated-leibniz-one-axis

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#prop:iterated-leibniz-one-axis
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:partial-derivative]]'
```

# prop:leibniz-formula

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#prop:leibniz-formula
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:multiindex-partial-derivative]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#prop:clairaut-partial-commute]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#prop:iterated-leibniz-one-axis]]'
```

# prop:directional-derivative-multinomial

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#prop:directional-derivative-multinomial
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:multiindex-partial-derivative]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#prop:clairaut-partial-commute]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#ex:multinomial-theorem]]'
```

# prop:taylor-multiindex

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter1.tex#prop:taylor-multiindex
uses:
- '[[references/Evans/blueprint/src/chapters/chapter1#def:multiindex-partial-derivative]]'
- '[[references/Evans/blueprint/src/chapters/chapter1#prop:directional-derivative-multinomial]]'
```
