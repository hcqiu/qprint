# sec:calculus-of-variations-introduction

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:calculus-of-variations-introduction
uses: []
```

# sec:basic-ideas-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:basic-ideas-calculus-of-variations
uses: []
```

# sec:first-variation-euler-lagrange

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:first-variation-euler-lagrange
uses: []
```

# thm:euler-lagrange-equation-pde-minimizer

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:euler-lagrange-equation-pde-minimizer
uses: []
```

# ex:dirichlets-principle-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#ex:dirichlets-principle-calculus-of-variations
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:euler-lagrange-equation-pde-minimizer]]'
```

# ex:generalized-dirichlets-principle

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#ex:generalized-dirichlets-principle
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:euler-lagrange-equation-pde-minimizer]]'
```

# ex:nonlinear-poisson-equation-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#ex:nonlinear-poisson-equation-calculus-of-variations
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:euler-lagrange-equation-pde-minimizer]]'
```

# ex:minimal-surfaces-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#ex:minimal-surfaces-calculus-of-variations
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:euler-lagrange-equation-pde-minimizer]]'
```

# sec:second-variation-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:second-variation-calculus-of-variations
uses: []
```

# prop:second-variation-convexity-necessary-condition

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#prop:second-variation-convexity-necessary-condition
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:euler-lagrange-equation-pde-minimizer]]'
```

# sec:systems-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:systems-calculus-of-variations
uses: []
```

# thm:euler-lagrange-system-pde-minimizer

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:euler-lagrange-system-pde-minimizer
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:euler-lagrange-equation-pde-minimizer]]'
```

# def:null-lagrangian

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:null-lagrangian
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:euler-lagrange-system-pde-minimizer]]'
```

# thm:null-lagrangians-boundary-conditions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:null-lagrangians-boundary-conditions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:null-lagrangian]]'
```

# lem:cofactor-divergence-free

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#lem:cofactor-divergence-free
uses: []
```

# thm:determinant-null-lagrangian

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:determinant-null-lagrangian
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#lem:cofactor-divergence-free]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#def:null-lagrangian]]'
```

# thm:brouwer-fixed-point-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:brouwer-fixed-point-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:null-lagrangians-boundary-conditions]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:determinant-null-lagrangian]]'
```

# sec:existence-of-minimizers

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:existence-of-minimizers
uses: []
```

# sec:coercivity-lower-semicontinuity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:coercivity-lower-semicontinuity
uses: []
```

# def:coercivity-condition-lagrangian

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:coercivity-condition-lagrangian
uses: []
```

# def:admissible-class-sobolev-minimization

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:admissible-class-sobolev-minimization
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:coercivity-condition-lagrangian]]'
```

# def:minimizing-sequence-calculus-of-variations

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:minimizing-sequence-calculus-of-variations
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-sobolev-minimization]]'
```

# def:weakly-lower-semicontinuous-functional

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:weakly-lower-semicontinuous-functional
uses: []
```

# sec:convexity-lower-semicontinuity-existence

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:convexity-lower-semicontinuity-existence
uses: []
```

# thm:weak-lower-semicontinuity-convex-lagrangian

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:weak-lower-semicontinuity-convex-lagrangian
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#prop:second-variation-convexity-necessary-condition]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#def:weakly-lower-semicontinuous-functional]]'
```

# rem:weak-lower-semicontinuity-proof-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:weak-lower-semicontinuity-proof-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:weak-lower-semicontinuity-convex-lagrangian]]'
```

# thm:existence-minimizer-convex-coercive

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:existence-minimizer-convex-coercive
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:weak-lower-semicontinuity-convex-lagrangian]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#def:coercivity-condition-lagrangian]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-sobolev-minimization]]'
```

# thm:uniqueness-minimizer-uniformly-convex

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:uniqueness-minimizer-uniformly-convex
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:existence-minimizer-convex-coercive]]'
```

# sec:euler-lagrange-equation-weak-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:euler-lagrange-equation-weak-solutions
uses: []
```

# def:weak-solution-euler-lagrange-scalar

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:weak-solution-euler-lagrange-scalar
uses: []
```

# thm:weak-solution-euler-lagrange-scalar

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:weak-solution-euler-lagrange-scalar
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:weak-solution-euler-lagrange-scalar]]'
```

# rem:weak-solution-minimizer-joint-convexity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:weak-solution-minimizer-joint-convexity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:weak-solution-euler-lagrange-scalar]]'
```

# sec:systems-existence-minimizers

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:systems-existence-minimizers
uses: []
```

# def:admissible-class-systems

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:admissible-class-systems
uses: []
```

# thm:existence-minimizer-systems

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:existence-minimizer-systems
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-systems]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:existence-minimizer-convex-coercive]]'
```

# thm:uniqueness-minimizer-systems

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:uniqueness-minimizer-systems
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:existence-minimizer-systems]]'
```

# def:weak-solution-euler-lagrange-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:weak-solution-euler-lagrange-system
uses: []
```

# thm:weak-solution-euler-lagrange-system

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:weak-solution-euler-lagrange-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:weak-solution-euler-lagrange-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:weak-solution-euler-lagrange-scalar]]'
```

# lem:weak-continuity-of-determinants

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#lem:weak-continuity-of-determinants
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#lem:cofactor-divergence-free]]'
```

# def:polyconvex-lagrangian

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:polyconvex-lagrangian
uses: []
```

# thm:lower-semicontinuity-polyconvex

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:lower-semicontinuity-polyconvex
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:polyconvex-lagrangian]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#lem:weak-continuity-of-determinants]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:weak-lower-semicontinuity-convex-lagrangian]]'
```

# thm:existence-minimizer-polyconvex

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:existence-minimizer-polyconvex
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:lower-semicontinuity-polyconvex]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-systems]]'
```

# ex:polyconvexity-nonlinear-elasticity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#ex:polyconvexity-nonlinear-elasticity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:polyconvex-lagrangian]]'
```

# sec:regularity-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:regularity-calculus-of-variations
uses: []
```

# sec:second-derivative-estimates-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:second-derivative-estimates-calculus-of-variations
uses: []
```

# thm:second-derivatives-minimizers

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:second-derivatives-minimizers
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:uniform-ellipticity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:interior-h2-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:boundary-h2-regularity]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:difference-quotients-weak-derivatives]]'
```

# sec:higher-regularity-remarks

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:higher-regularity-remarks
uses: []
```

# sec:constraints-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:constraints-calculus-of-variations
uses: []
```

# sec:nonlinear-eigenvalue-problems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:nonlinear-eigenvalue-problems
uses: []
```

# def:admissible-class-nonlinear-eigenvalue

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:admissible-class-nonlinear-eigenvalue
uses: []
```

# thm:existence-constrained-minimizer-nonlinear-eigenvalue

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:existence-constrained-minimizer-nonlinear-eigenvalue
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-nonlinear-eigenvalue]]'
```

# thm:lagrange-multiplier-nonlinear-eigenvalue

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:lagrange-multiplier-nonlinear-eigenvalue
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:existence-constrained-minimizer-nonlinear-eigenvalue]]'
```

# rem:nonlinear-eigenvalue-lagrange-multiplier-interpretation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:nonlinear-eigenvalue-lagrange-multiplier-interpretation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:lagrange-multiplier-nonlinear-eigenvalue]]'
```

# sec:unilateral-constraints-variational-inequalities

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:unilateral-constraints-variational-inequalities
uses: []
```

# def:admissible-class-obstacle-problem

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:admissible-class-obstacle-problem
uses: []
```

# thm:existence-minimizer-obstacle-problem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:existence-minimizer-obstacle-problem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-obstacle-problem]]'
```

# thm:variational-inequality-characterization

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:variational-inequality-characterization
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:existence-minimizer-obstacle-problem]]'
```

# rem:obstacle-problem-free-boundary-interpretation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:obstacle-problem-free-boundary-interpretation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:variational-inequality-characterization]]'
```

# sec:harmonic-maps-pointwise-constraints

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:harmonic-maps-pointwise-constraints
uses: []
```

# thm:euler-lagrange-harmonic-maps

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:euler-lagrange-harmonic-maps
uses: []
```

# rem:harmonic-maps-lagrange-multiplier-function

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:harmonic-maps-lagrange-multiplier-function
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:euler-lagrange-harmonic-maps]]'
```

# sec:incompressibility-constraints

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:incompressibility-constraints
uses: []
```

# def:admissible-class-stokes-problem

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:admissible-class-stokes-problem
uses: []
```

# thm:pressure-lagrange-multiplier-stokes

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:pressure-lagrange-multiplier-stokes
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-stokes-problem]]'
```

# rem:stokes-problem-weak-formulation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:stokes-problem-weak-formulation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:pressure-lagrange-multiplier-stokes]]'
```

# def:admissible-class-incompressible-elasticity

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:admissible-class-incompressible-elasticity
uses: []
```

# thm:existence-minimizer-determinant-constraint

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:existence-minimizer-determinant-constraint
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-incompressible-elasticity]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#lem:weak-continuity-of-determinants]]'
```

# rem:incompressibility-euler-formula

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:incompressibility-euler-formula
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-stokes-problem]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#def:admissible-class-incompressible-elasticity]]'
```

# sec:critical-points-calculus-of-variations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:critical-points-calculus-of-variations
uses: []
```

# sec:mountain-pass-theorem-section

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:mountain-pass-theorem-section
uses: []
```

# def:frechet-derivative-hilbert-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:frechet-derivative-hilbert-space
uses: []
```

# def:c1-functional-class-hilbert

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:c1-functional-class-hilbert
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:frechet-derivative-hilbert-space]]'
```

# rem:lipschitz-derivative-simplification

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:lipschitz-derivative-simplification
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:c1-functional-class-hilbert]]'
```

# def:critical-point-critical-value

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:critical-point-critical-value
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:frechet-derivative-hilbert-space]]'
```

# def:palais-smale-condition

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#def:palais-smale-condition
uses: []
```

# thm:deformation-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:deformation-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#def:palais-smale-condition]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#def:critical-point-critical-value]]'
```

# thm:mountain-pass-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:mountain-pass-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:deformation-theorem]]'
```

# sec:semilinear-elliptic-application

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:semilinear-elliptic-application
uses: []
```

# rem:power-nonlinearity-semilinear-example

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#rem:power-nonlinearity-semilinear-example
uses: []
```

# thm:existence-nontrivial-solution-semilinear-elliptic

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#thm:existence-nontrivial-solution-semilinear-elliptic
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:mountain-pass-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:lax-milgram-theorem]]'
```

# sec:calculus-of-variations-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter8.tex#sec:calculus-of-variations-references
uses: []
```
