# thm:eigenvectors-compact-symmetric-operator

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:eigenvectors-compact-symmetric-operator
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:hilbert-space]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:separable-space]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:compact-linear-operator]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:adjoint-symmetric-operator]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:eigenvalue-eigenvector-appendix-d]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#thm:fredholm-alternative]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#thm:spectrum-of-compact-operator]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#lem:bounds-on-spectrum-symmetric-operator]]'
```

# sec:measure-theory

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#sec:measure-theory
uses: []
```

# sec:lebesgue-measure

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#sec:lebesgue-measure
uses: []
```

# def:sigma-algebra

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:sigma-algebra
uses: []
```

# thm:existence-lebesgue-measure

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:existence-lebesgue-measure
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:sigma-algebra]]'
```

# rem:lebesgue-measure-properties

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#rem:lebesgue-measure-properties
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#thm:existence-lebesgue-measure]]'
```

# def:almost-everywhere

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:almost-everywhere
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#thm:existence-lebesgue-measure]]'
```

# sec:measurable-functions-integration

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#sec:measurable-functions-integration
uses: []
```

# def:measurable-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:measurable-function
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:sigma-algebra]]'
```

# thm:egoroffs-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:egoroffs-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:measurable-function]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:almost-everywhere]]'
```

# def:summable-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:summable-function
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:measurable-function]]'
```

# rem:integrable-vs-summable-terminology

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#rem:integrable-vs-summable-terminology
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:summable-function]]'
```

# def:essential-supremum

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:essential-supremum
uses: []
```

# sec:convergence-theorems-for-integrals

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#sec:convergence-theorems-for-integrals
uses: []
```

# thm:fatous-lemma

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:fatous-lemma
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:summable-function]]'
```

# thm:monotone-convergence-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:monotone-convergence-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:summable-function]]'
```

# thm:dominated-convergence-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:dominated-convergence-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:summable-function]]'
```

# sec:differentiation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#sec:differentiation
uses: []
```

# thm:lebesgue-differentiation-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:lebesgue-differentiation-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:summable-function]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:almost-everywhere]]'
```

# rem:lebesgue-differentiation-lp

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#rem:lebesgue-differentiation-lp
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#thm:lebesgue-differentiation-theorem]]'
```

# sec:banach-space-valued-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#sec:banach-space-valued-functions
uses: []
```

# def:simple-function-banach-valued

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:simple-function-banach-valued
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:sigma-algebra]]'
```

# def:strongly-measurable-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:strongly-measurable-function
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:simple-function-banach-valued]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:almost-everywhere]]'
```

# def:weakly-measurable-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:weakly-measurable-function
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:measurable-function]]'
- '[[references/Evans/blueprint/src/chapters/appendixD#def:bounded-linear-functional-dual-space]]'
```

# def:almost-separably-valued

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:almost-separably-valued
uses:
- '[[references/Evans/blueprint/src/chapters/appendixD#def:separable-space]]'
```

# thm:pettis-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:pettis-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:strongly-measurable-function]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:weakly-measurable-function]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:almost-separably-valued]]'
```

# def:integral-of-simple-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:integral-of-simple-function
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:simple-function-banach-valued]]'
```

# def:summable-banach-valued-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:summable-banach-valued-function
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:integral-of-simple-function]]'
```

# def:bochner-integral

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#def:bochner-integral
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:summable-banach-valued-function]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:integral-of-simple-function]]'
```

# thm:bochner-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixE.tex#thm:bochner-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixE#def:strongly-measurable-function]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:summable-banach-valued-function]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:bochner-integral]]'
- '[[references/Evans/blueprint/src/chapters/appendixE#def:summable-function]]'
```
