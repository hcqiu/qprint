# sec:hj-introduction-viscosity-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#sec:hj-introduction-viscosity-solutions
uses: []
```

# rem:hj-viscosity-solution-motivation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#rem:hj-viscosity-solution-motivation
uses: []
```

# def:viscosity-solution-cauchy-problem

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#def:viscosity-solution-cauchy-problem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#rem:hj-viscosity-solution-motivation]]'
```

# rem:viscosity-solution-definition-emphasis

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#rem:viscosity-solution-definition-emphasis
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-cauchy-problem]]'
```

# prop:classical-solutions-are-viscosity-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#prop:classical-solutions-are-viscosity-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-cauchy-problem]]'
```

# lem:touching-by-c1-function

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#lem:touching-by-c1-function
uses: []
```

# thm:consistency-viscosity-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#thm:consistency-viscosity-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-cauchy-problem]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#lem:touching-by-c1-function]]'
```

# sec:hj-uniqueness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#sec:hj-uniqueness
uses: []
```

# def:viscosity-solution-finite-horizon

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#def:viscosity-solution-finite-horizon
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-cauchy-problem]]'
```

# lem:extrema-at-terminal-time

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#lem:extrema-at-terminal-time
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-finite-horizon]]'
```

# def:hamiltonian-lipschitz-condition

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#def:hamiltonian-lipschitz-condition
uses: []
```

# thm:uniqueness-viscosity-solution-hj

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#thm:uniqueness-viscosity-solution-hj
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-finite-horizon]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#lem:extrema-at-terminal-time]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#def:hamiltonian-lipschitz-condition]]'
```

# rem:doubling-variables-technique

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#rem:doubling-variables-technique
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#thm:uniqueness-viscosity-solution-hj]]'
```

# sec:hj-control-theory-dynamic-programming

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#sec:hj-control-theory-dynamic-programming
uses: []
```

# def:controlled-ode-admissible-controls

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#def:controlled-ode-admissible-controls
uses: []
```

# def:control-cost-functional

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#def:control-cost-functional
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:controlled-ode-admissible-controls]]'
```

# def:value-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#def:value-function
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:control-cost-functional]]'
```

# thm:dynamic-programming-optimality-conditions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#thm:dynamic-programming-optimality-conditions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:value-function]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#def:control-cost-functional]]'
```

# lem:value-function-estimates

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#lem:value-function-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:value-function]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#def:control-cost-functional]]'
```

# thm:value-function-solves-hjb-equation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#thm:value-function-solves-hjb-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#lem:value-function-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#thm:dynamic-programming-optimality-conditions]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#def:value-function]]'
```

# rem:hjb-hamiltonian-formula

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#rem:hjb-hamiltonian-formula
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#thm:value-function-solves-hjb-equation]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#def:hamiltonian-lipschitz-condition]]'
```

# def:viscosity-solution-terminal-value-problem

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#def:viscosity-solution-terminal-value-problem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-cauchy-problem]]'
```

# rem:terminal-value-time-reversal

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#rem:terminal-value-time-reversal
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-terminal-value-problem]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-cauchy-problem]]'
```

# rem:design-of-optimal-controls

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#rem:design-of-optimal-controls
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#thm:value-function-solves-hjb-equation]]'
```

# thm:hopf-lax-formula-viscosity-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#thm:hopf-lax-formula-viscosity-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter10#def:viscosity-solution-finite-horizon]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#thm:value-function-solves-hjb-equation]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:hopf-lax-formula]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#lem:hopf-lax-functional-identity]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:convex-duality-hamiltonian-lagrangian]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#lem:hopf-lax-lipschitz-continuity]]'
```

# sec:hj-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter10.tex#sec:hj-references
uses: []
```
