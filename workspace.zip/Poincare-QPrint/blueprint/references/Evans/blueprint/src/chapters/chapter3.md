# sec:complete-integrals-envelopes

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:complete-integrals-envelopes
uses: []
```

# sec:complete-integrals

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:complete-integrals
uses: []
```

# def:complete-integral

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:complete-integral
uses: []
```

# rem:complete-integral-independence

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:complete-integral-independence
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:complete-integral]]'
```

# ex:clairaut-complete-integral

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:clairaut-complete-integral
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:complete-integral]]'
```

# ex:eikonal-complete-integral

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:eikonal-complete-integral
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:complete-integral]]'
```

# ex:hamilton-jacobi-complete-integral

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:hamilton-jacobi-complete-integral
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:complete-integral]]'
```

# sec:envelopes-new-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:envelopes-new-solutions
uses: []
```

# def:envelope

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:envelope
uses: []
```

# thm:envelope-solves-pde

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:envelope-solves-pde
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:envelope]]'
```

# rem:envelope-tangency

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:envelope-tangency
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:envelope-solves-pde]]'
```

# ex:envelope-singular-integral

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:envelope-singular-integral
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:envelope-solves-pde]]'
```

# def:general-integral

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:general-integral
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:complete-integral]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:envelope]]'
```

# rem:general-integral-remarks

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:general-integral-remarks
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:general-integral]]'
```

# ex:eikonal-alternative-complete-integral

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:eikonal-alternative-complete-integral
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:general-integral]]'
```

# ex:hamilton-jacobi-envelope-example

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:hamilton-jacobi-envelope-example
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:general-integral]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#ex:hamilton-jacobi-complete-integral]]'
```

# sec:characteristics

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:characteristics
uses: []
```

# sec:characteristic-ode-derivation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:characteristic-ode-derivation
uses: []
```

# thm:characteristic-ode-structure

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:characteristic-ode-structure
uses: []
```

# rem:characteristic-ode-closure

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:characteristic-ode-closure
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:characteristic-ode-structure]]'
```

# sec:characteristics-examples

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:characteristics-examples
uses: []
```

# ex:linear-pde-quadrant-characteristics

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:linear-pde-quadrant-characteristics
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:characteristic-ode-structure]]'
```

# ex:semilinear-pde-halfspace-characteristics

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:semilinear-pde-halfspace-characteristics
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:characteristic-ode-structure]]'
```

# ex:fully-nonlinear-halfspace-characteristics

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:fully-nonlinear-halfspace-characteristics
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:characteristic-ode-structure]]'
```

# sec:characteristics-boundary-conditions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:characteristics-boundary-conditions
uses: []
```

# def:compatibility-conditions-admissible-triple

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:compatibility-conditions-admissible-triple
uses: []
```

# def:noncharacteristic-triple

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:noncharacteristic-triple
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:compatibility-conditions-admissible-triple]]'
```

# lem:noncharacteristic-boundary-conditions

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#lem:noncharacteristic-boundary-conditions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:noncharacteristic-triple]]'
```

# rem:noncharacteristic-condition-general

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:noncharacteristic-condition-general
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:noncharacteristic-triple]]'
```

# sec:characteristics-local-solution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:characteristics-local-solution
uses: []
```

# lem:local-invertibility-characteristics

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#lem:local-invertibility-characteristics
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:noncharacteristic-triple]]'
```

# thm:local-existence-characteristics

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:local-existence-characteristics
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#lem:local-invertibility-characteristics]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:compatibility-conditions-admissible-triple]]'
```

# sec:characteristics-applications

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:characteristics-applications
uses: []
```

# ex:linear-transport-characteristics-flow

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:linear-transport-characteristics-flow
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:local-existence-characteristics]]'
```

# ex:characteristics-conservation-laws

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:characteristics-conservation-laws
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:local-existence-characteristics]]'
```

# rem:implicit-formula-conservation-law

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:implicit-formula-conservation-law
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#ex:characteristics-conservation-laws]]'
```

# ex:characteristics-hamilton-jacobi

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:characteristics-hamilton-jacobi
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:characteristic-ode-structure]]'
```

# sec:hamilton-jacobi-intro

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:hamilton-jacobi-intro
uses: []
```

# sec:calculus-of-variations-hamiltons-ode

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:calculus-of-variations-hamiltons-ode
uses: []
```

# thm:euler-lagrange-equations

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:euler-lagrange-equations
uses: []
```

# rem:critical-point-vs-minimizer

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:critical-point-vs-minimizer
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:euler-lagrange-equations]]'
```

# ex:newtons-law-lagrangian

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:newtons-law-lagrangian
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:euler-lagrange-equations]]'
```

# def:hamiltonian-from-lagrangian

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:hamiltonian-from-lagrangian
uses: []
```

# ex:hamiltonian-newtons-law

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:hamiltonian-newtons-law
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:hamiltonian-from-lagrangian]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#ex:newtons-law-lagrangian]]'
```

# thm:hamiltons-ode-derivation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:hamiltons-ode-derivation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:euler-lagrange-equations]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:hamiltonian-from-lagrangian]]'
```

# rem:hamiltons-ode-system-structure

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:hamiltons-ode-system-structure
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hamiltons-ode-derivation]]'
```

# rem:arnold-mechanics-notation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:arnold-mechanics-notation
uses: []
```

# sec:legendre-transform-hopf-lax

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:legendre-transform-hopf-lax
uses: []
```

# def:legendre-transform

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:legendre-transform
uses: []
```

# thm:convex-duality-hamiltonian-lagrangian

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:convex-duality-hamiltonian-lagrangian
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:legendre-transform]]'
```

# rem:dual-convex-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:dual-convex-functions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:convex-duality-hamiltonian-lagrangian]]'
```

# thm:hopf-lax-formula-derivation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:hopf-lax-formula-derivation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:convex-duality-hamiltonian-lagrangian]]'
```

# def:hopf-lax-formula

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:hopf-lax-formula
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-derivation]]'
```

# lem:hopf-lax-functional-identity

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#lem:hopf-lax-functional-identity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-derivation]]'
```

# lem:hopf-lax-lipschitz-continuity

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#lem:hopf-lax-lipschitz-continuity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-derivation]]'
```

# thm:hopf-lax-solves-hj-equation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:hopf-lax-solves-hj-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-derivation]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#lem:hopf-lax-functional-identity]]'
```

# thm:hopf-lax-formula-as-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:hopf-lax-formula-as-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-solves-hj-equation]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#lem:hopf-lax-lipschitz-continuity]]'
```

# sec:hj-weak-solutions-uniqueness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:hj-weak-solutions-uniqueness
uses: []
```

# ex:nonuniqueness-weak-solutions-hj

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:nonuniqueness-weak-solutions-hj
uses: []
```

# lem:hopf-lax-semiconcavity-from-data

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#lem:hopf-lax-semiconcavity-from-data
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:semiconcave-function]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-derivation]]'
```

# def:semiconcave-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:semiconcave-function
uses: []
```

# rem:semiconcave-characterization

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:semiconcave-characterization
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:semiconcave-function]]'
```

# def:uniformly-convex-hamiltonian

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:uniformly-convex-hamiltonian
uses: []
```

# lem:hopf-lax-semiconcavity-uniform-convexity

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#lem:hopf-lax-semiconcavity-uniform-convexity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:uniformly-convex-hamiltonian]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-derivation]]'
```

# def:weak-solution-hamilton-jacobi

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:weak-solution-hamilton-jacobi
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:semiconcave-function]]'
```

# thm:uniqueness-weak-solutions-hj

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:uniqueness-weak-solutions-hj
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:weak-solution-hamilton-jacobi]]'
```

# thm:hopf-lax-formula-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:hopf-lax-formula-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#lem:hopf-lax-semiconcavity-from-data]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#lem:hopf-lax-semiconcavity-uniform-convexity]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:uniqueness-weak-solutions-hj]]'
```

# ex:hopf-lax-explicit-example-i

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:hopf-lax-explicit-example-i
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-weak-solution]]'
```

# ex:hopf-lax-explicit-example-ii

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:hopf-lax-explicit-example-ii
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-weak-solution]]'
```

# sec:conservation-laws-intro

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:conservation-laws-intro
uses: []
```

# sec:shocks-entropy-condition

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:shocks-entropy-condition
uses: []
```

# def:integral-solution-conservation-law

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:integral-solution-conservation-law
uses: []
```

# prop:rankine-hugoniot-condition

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#prop:rankine-hugoniot-condition
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:integral-solution-conservation-law]]'
```

# ex:burgers-shock-formation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:burgers-shock-formation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#prop:rankine-hugoniot-condition]]'
```

# ex:rarefaction-nonphysical-shock

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:rarefaction-nonphysical-shock
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#prop:rankine-hugoniot-condition]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:integral-solution-conservation-law]]'
```

# def:shock-entropy-condition

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:shock-entropy-condition
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#prop:rankine-hugoniot-condition]]'
```

# rem:entropy-condition-uniform-convexity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:entropy-condition-uniform-convexity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:shock-entropy-condition]]'
```

# ex:burgers-triangular-shock-wave

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:burgers-triangular-shock-wave
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:shock-entropy-condition]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#ex:burgers-shock-formation]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#ex:rarefaction-nonphysical-shock]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#prop:rankine-hugoniot-condition]]'
```

# sec:lax-oleinik-formula

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:lax-oleinik-formula
uses: []
```

# thm:lax-oleinik-formula

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:lax-oleinik-formula
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:legendre-transform]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:hopf-lax-formula-derivation]]'
```

# def:lax-oleinik-formula

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:lax-oleinik-formula
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:lax-oleinik-formula]]'
```

# thm:lax-oleinik-integral-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:lax-oleinik-integral-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:lax-oleinik-formula]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:integral-solution-conservation-law]]'
```

# sec:conservation-laws-entropy-uniqueness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:conservation-laws-entropy-uniqueness
uses: []
```

# lem:lax-oleinik-entropy-estimate

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#lem:lax-oleinik-entropy-estimate
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:lax-oleinik-formula]]'
```

# def:entropy-condition-inequality

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:entropy-condition-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#lem:lax-oleinik-entropy-estimate]]'
```

# rem:entropy-condition-consequences

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:entropy-condition-consequences
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:entropy-condition-inequality]]'
```

# def:entropy-solution-conservation-law

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:entropy-solution-conservation-law
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:entropy-condition-inequality]]'
```

# thm:uniqueness-entropy-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:uniqueness-entropy-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:entropy-solution-conservation-law]]'
```

# sec:riemann-problem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:riemann-problem
uses: []
```

# thm:riemann-problem-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:riemann-problem-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:shock-entropy-condition]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:uniqueness-entropy-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#prop:rankine-hugoniot-condition]]'
```

# rem:riemann-problem-shock-vs-rarefaction

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#rem:riemann-problem-shock-vs-rarefaction
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:riemann-problem-solution]]'
```

# sec:conservation-laws-long-time-behavior

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:conservation-laws-long-time-behavior
uses: []
```

# thm:asymptotics-sup-norm

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:asymptotics-sup-norm
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:lax-oleinik-formula]]'
```

# def:n-wave

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#def:n-wave
uses: []
```

# thm:asymptotics-l1-norm-n-wave

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#thm:asymptotics-l1-norm-n-wave
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:asymptotics-sup-norm]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:n-wave]]'
```

# ex:burgers-example-n-wave-specialization

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#ex:burgers-example-n-wave-specialization
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:n-wave]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#ex:burgers-triangular-shock-wave]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:asymptotics-l1-norm-n-wave]]'
```

# sec:ch3-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter3.tex#sec:ch3-references
uses: []
```
