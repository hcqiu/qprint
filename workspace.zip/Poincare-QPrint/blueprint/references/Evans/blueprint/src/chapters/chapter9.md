# sec:monotonicity-methods

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:monotonicity-methods
uses: []
```

# def:monotone-vector-field

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:monotone-vector-field
uses: []
```

# lem:zeros-of-a-vector-field

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#lem:zeros-of-a-vector-field
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:brouwer-fixed-point-theorem]]'
```

# thm:monotonicity-approximate-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:monotonicity-approximate-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#lem:zeros-of-a-vector-field]]'
```

# thm:monotonicity-energy-estimates

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:monotonicity-energy-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:monotonicity-approximate-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:poincares-inequality-connected]]'
```

# thm:monotonicity-existence-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:monotonicity-existence-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:monotonicity-approximate-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:monotonicity-energy-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:monotone-vector-field]]'
```

# rem:browder-minty-method

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:browder-minty-method
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:monotonicity-existence-weak-solution]]'
```

# thm:monotonicity-uniqueness-weak-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:monotonicity-uniqueness-weak-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:monotonicity-existence-weak-solution]]'
```

# rem:monotonicity-h2-regularity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:monotonicity-h2-regularity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:monotonicity-uniqueness-weak-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:interior-h2-regularity]]'
```

# sec:fixed-point-methods

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:fixed-point-methods
uses: []
```

# sec:banachs-fixed-point-theorem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:banachs-fixed-point-theorem
uses: []
```

# thm:banach-fixed-point-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:banach-fixed-point-theorem
uses: []
```

# def:strict-contraction

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:strict-contraction
uses: []
```

# ex:reaction-diffusion-banach-fixed-point

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#ex:reaction-diffusion-banach-fixed-point
uses:
- '[[references/Evans/blueprint/src/chapters/chapter5#def:sobolev-space-time-banach]]'
```

# def:weak-solution-reaction-diffusion-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:weak-solution-reaction-diffusion-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#ex:reaction-diffusion-banach-fixed-point]]'
- '[[references/Evans/blueprint/src/chapters/chapter5#thm:mappings-into-better-spaces]]'
```

# thm:reaction-diffusion-banach-existence

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:reaction-diffusion-banach-existence
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:banach-fixed-point-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:strict-contraction]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:weak-solution-reaction-diffusion-system]]'
```

# rem:reaction-diffusion-chemical-interpretation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:reaction-diffusion-chemical-interpretation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:reaction-diffusion-banach-existence]]'
```

# sec:schauder-schaefer-fixed-point-theorems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:schauder-schaefer-fixed-point-theorems
uses: []
```

# thm:schauders-fixed-point-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:schauders-fixed-point-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:brouwer-fixed-point-theorem]]'
```

# def:compact-mapping-banach-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:compact-mapping-banach-space
uses: []
```

# thm:schaefers-fixed-point-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:schaefers-fixed-point-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:schauders-fixed-point-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:compact-mapping-banach-space]]'
```

# rem:a-priori-estimates-method

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:a-priori-estimates-method
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:schaefers-fixed-point-theorem]]'
```

# ex:quasilinear-elliptic-schaefer

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#ex:quasilinear-elliptic-schaefer
uses: []
```

# thm:schaefer-quasilinear-existence

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:schaefer-quasilinear-existence
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:schaefers-fixed-point-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:compact-mapping-banach-space]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:second-derivatives-minimizers]]'
```

# rem:iteration-scheme-warning

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:iteration-scheme-warning
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:schaefer-quasilinear-existence]]'
```

# sec:subsolutions-supersolutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:subsolutions-supersolutions
uses: []
```

# def:weak-sub-supersolution

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:weak-sub-supersolution
uses: []
```

# rem:sub-supersolution-c2-case

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:sub-supersolution-c2-case
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:weak-sub-supersolution]]'
```

# thm:existence-between-sub-supersolutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:existence-between-sub-supersolutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:weak-sub-supersolution]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:first-existence-weak-solutions]]'
```

# sec:nonexistence

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:nonexistence
uses: []
```

# sec:blow-up

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:blow-up
uses: []
```

# thm:blowup-large-data

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:blowup-large-data
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#def:principal-eigenvalue]]'
```

# sec:derrick-pohozaev-identity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:derrick-pohozaev-identity
uses: []
```

# def:star-shaped-domain

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:star-shaped-domain
uses: []
```

# lem:normals-star-shaped-region

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#lem:normals-star-shaped-region
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:star-shaped-domain]]'
```

# thm:derrick-pohozaev-nonexistence

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:derrick-pohozaev-nonexistence
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:star-shaped-domain]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#lem:normals-star-shaped-region]]'
```

# rem:derrick-pohozaev-identity-name

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:derrick-pohozaev-identity-name
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:derrick-pohozaev-nonexistence]]'
```

# sec:geometric-properties-of-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:geometric-properties-of-solutions
uses: []
```

# sec:star-shaped-level-sets

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:star-shaped-level-sets
uses: []
```

# thm:star-shaped-level-sets

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:star-shaped-level-sets
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:star-shaped-domain]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#lem:normals-star-shaped-region]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:strong-maximum-principle-laplace]]'
```

# sec:radial-symmetry

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:radial-symmetry
uses: []
```

# sec:maximum-principles-radial-symmetry

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:maximum-principles-radial-symmetry
uses: []
```

# lem:hopf-lemma-refinement

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#lem:hopf-lemma-refinement
uses:
- '[[references/Evans/blueprint/src/chapters/chapter6#lem:hopfs-lemma]]'
- '[[references/Evans/blueprint/src/chapters/chapter6#thm:strong-maximum-principle-c-zero]]'
```

# lem:boundary-estimates-radial-symmetry

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#lem:boundary-estimates-radial-symmetry
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#lem:hopf-lemma-refinement]]'
```

# sec:moving-planes

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:moving-planes
uses: []
```

# def:moving-plane-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:moving-plane-notation
uses: []
```

# thm:radial-symmetry-positive-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:radial-symmetry-positive-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#lem:hopf-lemma-refinement]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#lem:boundary-estimates-radial-symmetry]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:moving-plane-notation]]'
```

# sec:gradient-flows

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:gradient-flows
uses: []
```

# sec:convex-functions-hilbert-spaces

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:convex-functions-hilbert-spaces
uses: []
```

# def:convex-function-hilbert-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:convex-function-hilbert-space
uses: []
```

# def:lower-semicontinuous-hilbert-functional

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:lower-semicontinuous-hilbert-functional
uses: []
```

# def:subdifferential-hilbert

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:subdifferential-hilbert
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:convex-function-hilbert-space]]'
```

# thm:properties-of-subdifferentials

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:properties-of-subdifferentials
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:subdifferential-hilbert]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:lower-semicontinuous-hilbert-functional]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:weak-lower-semicontinuity-convex-lagrangian]]'
```

# def:nonlinear-resolvent-yosida

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:nonlinear-resolvent-yosida
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:properties-of-subdifferentials]]'
```

# thm:properties-resolvent-yosida

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:properties-resolvent-yosida
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:nonlinear-resolvent-yosida]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:properties-of-subdifferentials]]'
```

# sec:subdifferentials-nonlinear-semigroups

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:subdifferentials-nonlinear-semigroups
uses: []
```

# rem:nonlinear-semigroup-notation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:nonlinear-semigroup-notation
uses: []
```

# def:nonlinear-contraction-semigroup

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#def:nonlinear-contraction-semigroup
uses: []
```

# thm:solution-of-gradient-flow

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:solution-of-gradient-flow
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:properties-resolvent-yosida]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:nonlinear-contraction-semigroup]]'
```

# rem:gradient-flow-semigroup-extension

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#rem:gradient-flow-semigroup-extension
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:solution-of-gradient-flow]]'
```

# sec:gradient-flow-applications

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:gradient-flow-applications
uses: []
```

# thm:characterization-subdifferential-uniformly-convex-lagrangian

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#thm:characterization-subdifferential-uniformly-convex-lagrangian
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#def:convex-function-hilbert-space]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:subdifferential-hilbert]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:weak-lower-semicontinuity-convex-lagrangian]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#def:monotone-vector-field]]'
- '[[references/Evans/blueprint/src/chapters/chapter8#thm:second-derivatives-minimizers]]'
```

# ex:quasilinear-parabolic-gradient-flow

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#ex:quasilinear-parabolic-gradient-flow
uses:
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:characterization-subdifferential-uniformly-convex-lagrangian]]'
- '[[references/Evans/blueprint/src/chapters/chapter9#thm:solution-of-gradient-flow]]'
```

# sec:references-ch9

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter9.tex#sec:references-ch9
uses: []
```
