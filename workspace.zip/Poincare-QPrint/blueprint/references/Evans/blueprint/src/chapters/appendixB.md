# sec:convex-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#sec:convex-functions
uses: []
```

# def:convex-function-rn

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#def:convex-function-rn
uses: []
```

# thm:supporting-hyperplanes

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#thm:supporting-hyperplanes
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#def:convex-function-rn]]'
```

# rem:supporting-hyperplane-remarks

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#rem:supporting-hyperplane-remarks
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#thm:supporting-hyperplanes]]'
```

# thm:jensens-inequality

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#thm:jensens-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#def:convex-function-rn]]'
- '[[references/Evans/blueprint/src/chapters/appendixB#thm:supporting-hyperplanes]]'
- '[[references/Evans/blueprint/src/chapters/appendixA#def:function-notation-basic]]'
```

# sec:elementary-inequalities

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#sec:elementary-inequalities
uses: []
```

# lem:cauchys-inequality

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:cauchys-inequality
uses: []
```

# lem:cauchys-inequality-epsilon

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:cauchys-inequality-epsilon
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:cauchys-inequality]]'
```

# lem:youngs-inequality

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:youngs-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#def:convex-function-rn]]'
```

# lem:youngs-inequality-epsilon

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:youngs-inequality-epsilon
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:youngs-inequality]]'
```

# lem:holders-inequality

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:holders-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:youngs-inequality]]'
```

# lem:minkowskis-inequality

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:minkowskis-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:holders-inequality]]'
```

# rem:discrete-holder-minkowski-inequalities

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#rem:discrete-holder-minkowski-inequalities
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:holders-inequality]]'
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:minkowskis-inequality]]'
```

# lem:general-holder-inequality

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:general-holder-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:holders-inequality]]'
```

# lem:interpolation-inequality-lp-norms

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:interpolation-inequality-lp-norms
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:holders-inequality]]'
```

# lem:cauchy-schwarz-inequality

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:cauchy-schwarz-inequality
uses: []
```

# rem:cauchy-schwarz-matrix-form

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#rem:cauchy-schwarz-matrix-form
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:cauchy-schwarz-inequality]]'
```

# lem:gronwalls-inequality-differential-form

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:gronwalls-inequality-differential-form
uses: []
```

# lem:gronwalls-inequality-integral-form

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixB.tex#lem:gronwalls-inequality-integral-form
uses:
- '[[references/Evans/blueprint/src/chapters/appendixB#lem:gronwalls-inequality-differential-form]]'
```
