# sec:conservation-laws-introduction

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:conservation-laws-introduction
uses: []
```

# ex:p-system-definition

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:p-system-definition
uses: []
```

# ex:euler-equations-1d-system

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:euler-equations-1d-system
uses: []
```

# ex:shallow-water-equations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:shallow-water-equations
uses: []
```

# sec:integral-solutions-systems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:integral-solutions-systems
uses: []
```

# def:integral-solution-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:integral-solution-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:integral-solution-conservation-law]]'
```

# prop:rankine-hugoniot-condition-system

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#prop:rankine-hugoniot-condition-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:integral-solution-system]]'
```

# sec:traveling-waves-hyperbolic-systems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:traveling-waves-hyperbolic-systems
uses: []
```

# def:strictly-hyperbolic-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:strictly-hyperbolic-system
uses: []
```

# def:eigenvalue-eigenvector-notation-hyperbolic

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:eigenvalue-eigenvector-notation-hyperbolic
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:strictly-hyperbolic-system]]'
```

# rem:eigenvector-orthogonality

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#rem:eigenvector-orthogonality
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:eigenvalue-eigenvector-notation-hyperbolic]]'
```

# thm:invariance-hyperbolicity-coordinate-change

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:invariance-hyperbolicity-coordinate-change
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:strictly-hyperbolic-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:eigenvalue-eigenvector-notation-hyperbolic]]'
```

# thm:smooth-dependence-eigenvalues-eigenvectors

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:smooth-dependence-eigenvalues-eigenvectors
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:strictly-hyperbolic-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:eigenvalue-eigenvector-notation-hyperbolic]]'
```

# rem:global-orientation-eigenspaces

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#rem:global-orientation-eigenspaces
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:smooth-dependence-eigenvalues-eigenvectors]]'
```

# ex:p-system-strict-hyperbolicity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:p-system-strict-hyperbolicity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#ex:p-system-definition]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:strictly-hyperbolic-system]]'
```

# ex:euler-equations-strict-hyperbolicity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:euler-equations-strict-hyperbolicity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#ex:euler-equations-1d-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:invariance-hyperbolicity-coordinate-change]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:strictly-hyperbolic-system]]'
```

# sec:riemanns-problem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:riemanns-problem
uses: []
```

# sec:simple-waves

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:simple-waves
uses: []
```

# def:rarefaction-curve

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:rarefaction-curve
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:eigenvalue-eigenvector-notation-hyperbolic]]'
```

# def:genuinely-nonlinear-linearly-degenerate

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:genuinely-nonlinear-linearly-degenerate
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:eigenvalue-eigenvector-notation-hyperbolic]]'
```

# sec:rarefaction-waves

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:rarefaction-waves
uses: []
```

# thm:existence-k-rarefaction-waves

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:existence-k-rarefaction-waves
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:genuinely-nonlinear-linearly-degenerate]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:rarefaction-curve]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:riemann-problem-solution]]'
```

# rem:k-rarefaction-wave-terminology

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#rem:k-rarefaction-wave-terminology
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:existence-k-rarefaction-waves]]'
```

# sec:shock-waves-contact-discontinuities

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:shock-waves-contact-discontinuities
uses: []
```

# def:shock-set

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:shock-set
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#prop:rankine-hugoniot-condition-system]]'
```

# thm:structure-of-shock-set

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:structure-of-shock-set
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:shock-set]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:smooth-dependence-eigenvalues-eigenvectors]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:eigenvalue-eigenvector-notation-hyperbolic]]'
```

# thm:linear-degeneracy-shock-rarefaction-coincide

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:linear-degeneracy-shock-rarefaction-coincide
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:structure-of-shock-set]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:rarefaction-curve]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:genuinely-nonlinear-linearly-degenerate]]'
```

# def:admissible-pair-lax-entropy-condition

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:admissible-pair-lax-entropy-condition
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:shock-set]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:structure-of-shock-set]]'
```

# def:shock-set-plus-minus

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:shock-set-plus-minus
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:shock-set]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:admissible-pair-lax-entropy-condition]]'
```

# sec:local-solution-riemanns-problem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:local-solution-riemanns-problem
uses: []
```

# def:t-curve

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:t-curve
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:rarefaction-curve]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:shock-set-plus-minus]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:genuinely-nonlinear-linearly-degenerate]]'
```

# thm:local-solution-riemann-problem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:local-solution-riemann-problem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:t-curve]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:existence-k-rarefaction-waves]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:admissible-pair-lax-entropy-condition]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:eigenvalue-eigenvector-notation-hyperbolic]]'
```

# sec:systems-two-conservation-laws

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:systems-two-conservation-laws
uses: []
```

# sec:riemann-invariants

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:riemann-invariants
uses: []
```

# def:riemann-invariant

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:riemann-invariant
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:eigenvalue-eigenvector-notation-hyperbolic]]'
```

# rem:riemann-invariants-mgt2-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#rem:riemann-invariants-mgt2-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:riemann-invariant]]'
```

# thm:conservation-laws-riemann-invariants

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:conservation-laws-riemann-invariants
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:riemann-invariant]]'
```

# rem:riemann-invariant-characteristic-curves

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#rem:riemann-invariant-characteristic-curves
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:conservation-laws-riemann-invariants]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:genuinely-nonlinear-linearly-degenerate]]'
```

# ex:barotropic-gas-dynamics-riemann-invariants

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:barotropic-gas-dynamics-riemann-invariants
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:riemann-invariant]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#ex:euler-equations-1d-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#rem:riemann-invariant-characteristic-curves]]'
```

# sec:nonexistence-smooth-solutions-systems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:nonexistence-smooth-solutions-systems
uses: []
```

# thm:riemann-invariants-blowup

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:riemann-invariants-blowup
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:riemann-invariant]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:conservation-laws-riemann-invariants]]'
```

# sec:entropy-criteria-systems

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:entropy-criteria-systems
uses: []
```

# sec:vanishing-viscosity-traveling-waves

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:vanishing-viscosity-traveling-waves
uses: []
```

# thm:existence-traveling-waves-genuinely-nonlinear

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:existence-traveling-waves-genuinely-nonlinear
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:genuinely-nonlinear-linearly-degenerate]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:shock-set]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:structure-of-shock-set]]'
```

# def:lax-entropy-criterion-general

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:lax-entropy-criterion-general
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:shock-set]]'
```

# ex:traveling-waves-p-system

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:traveling-waves-p-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#ex:p-system-definition]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#thm:existence-traveling-waves-genuinely-nonlinear]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:lax-entropy-criterion-general]]'
```

# sec:entropy-entropy-flux-pairs

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:entropy-entropy-flux-pairs
uses: []
```

# def:entropy-entropy-flux-pair-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:entropy-entropy-flux-pair-system
uses: []
```

# def:entropy-solution-system

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:entropy-solution-system
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:integral-solution-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:entropy-entropy-flux-pair-system]]'
```

# thm:entropy-vanishing-viscosity

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:entropy-vanishing-viscosity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:entropy-solution-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#def:entropy-entropy-flux-pair-system]]'
```

# ex:scalar-entropy-flux-existence

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:scalar-entropy-flux-existence
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:entropy-entropy-flux-pair-system]]'
```

# ex:p-system-entropy-pair

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#ex:p-system-entropy-pair
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:entropy-entropy-flux-pair-system]]'
- '[[references/Evans/blueprint/src/chapters/chapter11#ex:p-system-definition]]'
```

# sec:uniqueness-scalar-conservation-law-entropy

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:uniqueness-scalar-conservation-law-entropy
uses: []
```

# def:entropy-entropy-flux-pair-scalar

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:entropy-entropy-flux-pair-scalar
uses: []
```

# def:entropy-solution-scalar-new

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#def:entropy-solution-scalar-new
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:entropy-entropy-flux-pair-scalar]]'
```

# rem:entropy-solution-scalar-consistency

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#rem:entropy-solution-scalar-consistency
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:entropy-solution-scalar-new]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:integral-solution-conservation-law]]'
```

# thm:uniqueness-entropy-solutions-scalar-new

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#thm:uniqueness-entropy-solutions-scalar-new
uses:
- '[[references/Evans/blueprint/src/chapters/chapter11#def:entropy-solution-scalar-new]]'
- '[[references/Evans/blueprint/src/chapters/chapter10#thm:uniqueness-viscosity-solution-hj]]'
```

# sec:chapter11-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter11.tex#sec:chapter11-references
uses: []
```
