# sec:separation-of-variables

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:separation-of-variables
uses: []
```

# ex:heat-equation-separation-of-variables

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:heat-equation-separation-of-variables
uses: []
```

# def:eigenvalue-eigenfunction

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:eigenvalue-eigenfunction
uses: []
```

# rem:separation-of-variables-linearity-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:separation-of-variables-linearity-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:heat-equation-separation-of-variables]]'
```

# ex:porous-medium-separation-of-variables

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:porous-medium-separation-of-variables
uses: []
```

# rem:porous-medium-blowup-remark

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:porous-medium-blowup-remark
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:porous-medium-separation-of-variables]]'
```

# ex:hamilton-jacobi-additive-separation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:hamilton-jacobi-additive-separation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#ex:hamilton-jacobi-complete-integral]]'
```

# sec:similarity-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:similarity-solutions
uses: []
```

# sec:plane-traveling-waves-solitons

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:plane-traveling-waves-solitons
uses: []
```

# def:traveling-wave-plane-wave

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:traveling-wave-plane-wave
uses: []
```

# ex:exponential-plane-wave-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:exponential-plane-wave-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:traveling-wave-plane-wave]]'
```

# ex:kdv-soliton-traveling-wave

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:kdv-soliton-traveling-wave
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:traveling-wave-plane-wave]]'
```

# rem:kdv-complete-integrability

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:kdv-complete-integrability
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:kdv-soliton-traveling-wave]]'
```

# thm:bistable-traveling-wave-existence

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#thm:bistable-traveling-wave-existence
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:traveling-wave-plane-wave]]'
```

# rem:bistable-traveling-wave-velocity-uniqueness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:bistable-traveling-wave-velocity-uniqueness
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:bistable-traveling-wave-existence]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:kdv-soliton-traveling-wave]]'
```

# sec:similarity-under-scaling

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:similarity-under-scaling
uses: []
```

# ex:porous-medium-scaling-invariant-barenblatt

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:porous-medium-scaling-invariant-barenblatt
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# rem:porous-medium-finite-propagation-speed

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:porous-medium-finite-propagation-speed
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:porous-medium-scaling-invariant-barenblatt]]'
```

# sec:transform-methods

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:transform-methods
uses: []
```

# sec:fourier-transform

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:fourier-transform
uses: []
```

# def:fourier-transform-l1

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:fourier-transform-l1
uses: []
```

# thm:plancherel-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#thm:plancherel-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:fourier-transform-l1]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:bessel-potentials]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:integral-fundamental-solution-heat]]'
```

# def:fourier-transform-l2

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:fourier-transform-l2
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:plancherel-theorem]]'
```

# thm:fourier-transform-properties

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#thm:fourier-transform-properties
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:fourier-transform-l2]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:plancherel-theorem]]'
```

# ex:bessel-potentials

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:bessel-potentials
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:fourier-transform-properties]]'
```

# ex:fourier-transform-heat-fundamental-solution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:fourier-transform-heat-fundamental-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:fourier-transform-properties]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:bessel-potentials]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:heat-equation-initial-value-solution]]'
```

# ex:schrodinger-fundamental-solution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:schrodinger-fundamental-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:plancherel-theorem]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:fourier-transform-heat-fundamental-solution]]'
```

# rem:schrodinger-time-reversibility

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:schrodinger-time-reversibility
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:schrodinger-fundamental-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:backwards-uniqueness-heat-equation]]'
```

# ex:fourier-transform-wave-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:fourier-transform-wave-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:fourier-transform-properties]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:exponential-plane-wave-solutions]]'
```

# ex:telegraph-equation-fourier-transform

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:telegraph-equation-fourier-transform
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:fourier-transform-properties]]'
```

# sec:laplace-transform

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:laplace-transform
uses: []
```

# def:laplace-transform

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:laplace-transform
uses: []
```

# ex:resolvent-laplace-transform

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:resolvent-laplace-transform
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:laplace-transform]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:bessel-potentials]]'
```

# ex:wave-equation-from-heat-laplace-transform

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:wave-equation-from-heat-laplace-transform
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:laplace-transform]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-odd-dimensions-solution]]'
```

# sec:converting-nonlinear-into-linear-pde

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:converting-nonlinear-into-linear-pde
uses: []
```

# sec:hopf-cole-transformation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:hopf-cole-transformation
uses: []
```

# ex:hopf-cole-quadratic-nonlinearity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:hopf-cole-quadratic-nonlinearity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:fourier-transform-heat-fundamental-solution]]'
```

# ex:viscous-burgers-hopf-cole

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:viscous-burgers-hopf-cole
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:hopf-cole-quadratic-nonlinearity]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#def:integral-solution-conservation-law]]'
```

# sec:potential-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:potential-functions
uses: []
```

# ex:euler-equations-potential-function

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:euler-equations-potential-function
uses: []
```

# sec:hodograph-legendre-transforms

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:hodograph-legendre-transforms
uses: []
```

# ex:hodograph-transform-irrotational-flow

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:hodograph-transform-irrotational-flow
uses: []
```

# rem:hodograph-potential-simplification

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:hodograph-potential-simplification
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:hodograph-transform-irrotational-flow]]'
```

# ex:legendre-transform-minimal-surface

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:legendre-transform-minimal-surface
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#def:legendre-transform]]'
```

# rem:hodograph-legendre-practical-difficulty

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:hodograph-legendre-practical-difficulty
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:hodograph-transform-irrotational-flow]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:legendre-transform-minimal-surface]]'
```

# sec:asymptotics

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:asymptotics
uses: []
```

# sec:singular-perturbations

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:singular-perturbations
uses: []
```

# def:singular-perturbation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:singular-perturbation
uses: []
```

# ex:transport-small-diffusion-singular-perturbation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:transport-small-diffusion-singular-perturbation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:singular-perturbation]]'
```

# sec:laplaces-method

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:laplaces-method
uses: []
```

# ex:vanishing-viscosity-burgers

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:vanishing-viscosity-burgers
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:viscous-burgers-hopf-cole]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:lax-oleinik-formula]]'
```

# lem:laplace-method-asymptotics-lemma

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#lem:laplace-method-asymptotics-lemma
uses: []
```

# sec:geometric-optics-stationary-phase

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:geometric-optics-stationary-phase
uses: []
```

# ex:geometric-optics-oscillating-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:geometric-optics-oscillating-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:characteristic-ode-structure]]'
```

# ex:stationary-phase-wave-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:stationary-phase-wave-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:fourier-transform-wave-equation]]'
```

# lem:stationary-phase-linear-asymptotics

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#lem:stationary-phase-linear-asymptotics
uses: []
```

# lem:stationary-phase-quadratic-asymptotics

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#lem:stationary-phase-quadratic-asymptotics
uses: []
```

# lem:stationary-phase-changing-coordinates

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#lem:stationary-phase-changing-coordinates
uses: []
```

# prop:stationary-phase-asymptotic-formula

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#prop:stationary-phase-asymptotic-formula
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#lem:stationary-phase-linear-asymptotics]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#lem:stationary-phase-quadratic-asymptotics]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#lem:stationary-phase-changing-coordinates]]'
```

# ex:stationary-phase-wave-equation-continued

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:stationary-phase-wave-equation-continued
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:stationary-phase-wave-equation]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#prop:stationary-phase-asymptotic-formula]]'
```

# rem:optics-stationary-phase-connection

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:optics-stationary-phase-connection
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:geometric-optics-oscillating-solutions]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:stationary-phase-wave-equation-continued]]'
- '[[references/Evans/blueprint/src/chapters/chapter3#thm:characteristic-ode-structure]]'
```

# sec:homogenization

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:homogenization
uses: []
```

# ex:periodic-homogenization-elliptic

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:periodic-homogenization-elliptic
uses: []
```

# sec:power-series

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:power-series
uses: []
```

# sec:noncharacteristic-surfaces

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:noncharacteristic-surfaces
uses: []
```

# def:normal-derivative-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:normal-derivative-notation
uses: []
```

# def:cauchy-problem-cauchy-data

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:cauchy-problem-cauchy-data
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:normal-derivative-notation]]'
```

# def:noncharacteristic-plane-flat

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:noncharacteristic-plane-flat
uses: []
```

# def:noncharacteristic-surface

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:noncharacteristic-surface
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:cauchy-problem-cauchy-data]]'
```

# thm:cauchy-data-noncharacteristic-surfaces

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#thm:cauchy-data-noncharacteristic-surfaces
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:noncharacteristic-surface]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#def:cauchy-problem-cauchy-data]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#def:noncharacteristic-plane-flat]]'
```

# rem:noncharacteristic-condition-level-set

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:noncharacteristic-condition-level-set
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:noncharacteristic-surface]]'
```

# sec:real-analytic-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:real-analytic-functions
uses: []
```

# def:real-analytic-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:real-analytic-function
uses: []
```

# rem:real-analytic-function-remarks

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:real-analytic-function-remarks
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:real-analytic-function]]'
```

# ex:real-analytic-example-rational-function

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#ex:real-analytic-example-rational-function
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:real-analytic-function]]'
```

# def:power-series-majorizes

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#def:power-series-majorizes
uses: []
```

# lem:power-series-majorants

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#lem:power-series-majorants
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:power-series-majorizes]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#ex:real-analytic-example-rational-function]]'
```

# rem:vector-valued-power-series-notation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:vector-valued-power-series-notation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:power-series-majorizes]]'
```

# sec:cauchy-kovalevskaya-theorem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:cauchy-kovalevskaya-theorem
uses: []
```

# thm:cauchy-kovalevskaya

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#thm:cauchy-kovalevskaya
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#def:cauchy-problem-cauchy-data]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:cauchy-data-noncharacteristic-surfaces]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#lem:power-series-majorants]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#rem:vector-valued-power-series-notation]]'
- '[[references/Evans/blueprint/src/chapters/chapter4#def:real-analytic-function]]'
```

# rem:cauchy-kovalevskaya-fully-nonlinear

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#rem:cauchy-kovalevskaya-fully-nonlinear
uses:
- '[[references/Evans/blueprint/src/chapters/chapter4#thm:cauchy-kovalevskaya]]'
```

# sec:ch4-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter4.tex#sec:ch4-references
uses: []
```
