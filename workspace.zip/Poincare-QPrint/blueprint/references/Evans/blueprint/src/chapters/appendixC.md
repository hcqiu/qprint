# sec:calculus-facts

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#sec:calculus-facts
uses: []
```

# def:ck-boundary-regularity

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:ck-boundary-regularity
uses: []
```

# def:outward-normal-and-normal-derivative

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:outward-normal-and-normal-derivative
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:ck-boundary-regularity]]'
```

# thm:gauss-green-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:gauss-green-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:ck-boundary-regularity]]'
- '[[references/Evans/blueprint/src/chapters/appendixC#def:outward-normal-and-normal-derivative]]'
```

# thm:integration-by-parts-formula

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:integration-by-parts-formula
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#thm:gauss-green-theorem]]'
```

# thm:greens-formulas

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:greens-formulas
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#thm:integration-by-parts-formula]]'
- '[[references/Evans/blueprint/src/chapters/appendixC#def:outward-normal-and-normal-derivative]]'
```

# thm:polar-coordinates

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:polar-coordinates
uses: []
```

# thm:coarea-formula

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:coarea-formula
uses: []
```

# def:epsilon-interior-set-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:epsilon-interior-set-notation
uses: []
```

# def:standard-mollifier

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:standard-mollifier
uses: []
```

# def:mollification

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:mollification
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:standard-mollifier]]'
- '[[references/Evans/blueprint/src/chapters/appendixC#def:epsilon-interior-set-notation]]'
```

# thm:properties-of-mollifiers

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:properties-of-mollifiers
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:mollification]]'
- '[[references/Evans/blueprint/src/chapters/appendixC#def:standard-mollifier]]'
```

# def:gradient-matrix-df-square-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:gradient-matrix-df-square-notation
uses:
- '[[references/Evans/blueprint/src/chapters/appendixA#def:vector-valued-function-notation]]'
```

# def:jacobian-jf

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:jacobian-jf
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:gradient-matrix-df-square-notation]]'
```

# thm:inverse-function-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:inverse-function-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:jacobian-jf]]'
```

# def:xy-point-notation-rnm

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:xy-point-notation-rnm
uses: []
```

# def:gradient-matrix-df-rectangular-notation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:gradient-matrix-df-rectangular-notation
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:xy-point-notation-rnm]]'
```

# def:jacobian-jyf

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:jacobian-jyf
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:gradient-matrix-df-rectangular-notation]]'
```

# thm:implicit-function-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:implicit-function-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:jacobian-jyf]]'
```

# thm:arzela-ascoli-theorem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#thm:arzela-ascoli-theorem
uses:
- '[[references/Evans/blueprint/src/chapters/appendixC#def:uniform-equicontinuity]]'
```

# def:uniform-equicontinuity

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/appendixC.tex#def:uniform-equicontinuity
uses: []
```
