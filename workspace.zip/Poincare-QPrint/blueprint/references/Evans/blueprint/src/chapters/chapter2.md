# sec:transport-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:transport-equation
uses: []
```

# sec:transport-equation-initial-value-problem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:transport-equation-initial-value-problem
uses: []
```

# def:transport-explicit-solution

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:transport-explicit-solution
uses: []
```

# thm:transport-ivp-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:transport-ivp-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:transport-explicit-solution]]'
```

# thm:transport-initial-condition

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:transport-initial-condition
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:transport-explicit-solution]]'
```

# thm:transport-ivp-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:transport-ivp-uniqueness
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:transport-explicit-solution]]'
```

# rem:transport-equation-weak-solution-discontinuous-data

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:transport-equation-weak-solution-discontinuous-data
uses: []
```

# sec:transport-equation-nonhomogeneous-problem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:transport-equation-nonhomogeneous-problem
uses: []
```

# def:transport-nonhom-solution

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:transport-nonhom-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:transport-explicit-solution]]'
```

# thm:transport-nonhom-initial-condition

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:transport-nonhom-initial-condition
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:transport-nonhom-solution]]'
```

# thm:transport-nonhom-solves

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:transport-nonhom-solves
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:transport-nonhom-solution]]'
```

# rem:transport-equation-method-of-characteristics

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:transport-equation-method-of-characteristics
uses: []
```

# sec:laplaces-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplaces-equation
uses: []
```

# def:harmonic-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:harmonic-function
uses: []
```

# sec:laplace-fundamental-solution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-fundamental-solution
uses: []
```

# sec:laplace-fundamental-solution-derivation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-fundamental-solution-derivation
uses: []
```

# def:fundamental-solution-laplace

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:fundamental-solution-laplace
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:harmonic-function]]'
```

# lem:laplace-fundamental-solution-harmonic

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:laplace-fundamental-solution-harmonic
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-laplace]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:harmonic-function]]'
```

# sec:laplace-poissons-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-poissons-equation
uses: []
```

# thm:poisson-equation-solution-formula

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:poisson-equation-solution-formula
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-laplace]]'
```

# rem:poisson-equation-dirac-delta-notation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:poisson-equation-dirac-delta-notation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:poisson-equation-solution-formula]]'
```

# sec:laplace-mean-value-formulas

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-mean-value-formulas
uses: []
```

# thm:mean-value-formulas-laplace

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:mean-value-formulas-laplace
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:harmonic-function]]'
```

# thm:converse-mean-value-property-laplace

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:converse-mean-value-property-laplace
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:harmonic-function]]'
```

# thm:converse-mean-value-property-mvp

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:converse-mean-value-property-mvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:ball-mean-value-property]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:harmonic-function]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:harmonic-functions-smooth]]'
```

# sec:laplace-mean-value-consequences

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-mean-value-consequences
uses: []
```

# def:ball-mean-value-property

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:ball-mean-value-property
uses: []
```

# thm:strong-maximum-principle-mvp

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:strong-maximum-principle-mvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:ball-mean-value-property]]'
```

# thm:uniqueness-dirichlet-mvp

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:uniqueness-dirichlet-mvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:ball-mean-value-property]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:strong-maximum-principle-mvp]]'
```

# thm:harnack-local-mvp

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:harnack-local-mvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:ball-mean-value-property]]'
```

# thm:harnack-global-mvp

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:harnack-global-mvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:ball-mean-value-property]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:harnack-local-mvp]]'
```

# thm:liouville-mvp

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:liouville-mvp
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:ball-mean-value-property]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:harnack-local-mvp]]'
```

# sec:laplace-properties-harmonic-functions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-properties-harmonic-functions
uses: []
```

# sec:laplace-strong-maximum-principle

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-strong-maximum-principle
uses: []
```

# thm:strong-maximum-principle-laplace

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:strong-maximum-principle-laplace
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:mean-value-formulas-laplace]]'
```

# rem:strong-maximum-principle-positivity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:strong-maximum-principle-positivity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:strong-maximum-principle-laplace]]'
```

# thm:uniqueness-poisson-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:uniqueness-poisson-dirichlet
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:strong-maximum-principle-laplace]]'
```

# sec:laplace-regularity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-regularity
uses: []
```

# thm:harmonic-functions-smooth

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:harmonic-functions-smooth
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:ball-mean-value-property]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:mean-value-formulas-laplace]]'
```

# sec:laplace-local-estimates-derivatives

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-local-estimates-derivatives
uses: []
```

# thm:harmonic-function-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:harmonic-function-derivative-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:mean-value-formulas-laplace]]'
```

# sec:laplace-liouvilles-theorem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-liouvilles-theorem
uses: []
```

# thm:liouville-theorem-harmonic

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:liouville-theorem-harmonic
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:harmonic-function-derivative-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:liouville-mvp]]'
```

# thm:representation-formula-bounded-solutions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:representation-formula-bounded-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-laplace]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:liouville-theorem-harmonic]]'
```

# rem:representation-formula-n2-unbounded

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:representation-formula-n2-unbounded
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-laplace]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:representation-formula-bounded-solutions]]'
```

# sec:laplace-analyticity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-analyticity
uses: []
```

# thm:harmonic-functions-analytic

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:harmonic-functions-analytic
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:harmonic-function-derivative-estimates]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:harmonic-functions-smooth]]'
```

# sec:laplace-harnacks-inequality

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-harnacks-inequality
uses: []
```

# thm:harnacks-inequality

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:harnacks-inequality
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:mean-value-formulas-laplace]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:harnack-global-mvp]]'
```

# sec:laplace-greens-function

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-greens-function
uses: []
```

# sec:laplace-greens-function-derivation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-greens-function-derivation
uses: []
```

# def:greens-function

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:greens-function
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-laplace]]'
```

# thm:representation-formula-greens-function

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:representation-formula-greens-function
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:greens-function]]'
```

# rem:greens-function-dirac-delta

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:greens-function-dirac-delta
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:greens-function]]'
```

# thm:greens-function-symmetry

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:greens-function-symmetry
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:greens-function]]'
```

# sec:laplace-greens-function-half-space

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-greens-function-half-space
uses: []
```

# def:reflection-half-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:reflection-half-space
uses: []
```

# def:greens-function-half-space

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:greens-function-half-space
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:greens-function]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-laplace]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:reflection-half-space]]'
```

# thm:poissons-formula-half-space

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:poissons-formula-half-space
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:greens-function-half-space]]'
```

# sec:laplace-greens-function-ball

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-greens-function-ball
uses: []
```

# def:dual-point-unit-sphere

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:dual-point-unit-sphere
uses: []
```

# def:greens-function-ball

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:greens-function-ball
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:greens-function]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-laplace]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:dual-point-unit-sphere]]'
```

# thm:poissons-formula-ball

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:poissons-formula-ball
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:greens-function-ball]]'
```

# sec:laplace-energy-methods

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-energy-methods
uses: []
```

# sec:laplace-energy-uniqueness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-energy-uniqueness
uses: []
```

# thm:uniqueness-poisson-energy-method

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:uniqueness-poisson-energy-method
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:uniqueness-poisson-dirichlet]]'
```

# sec:laplace-dirichlets-principle

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:laplace-dirichlets-principle
uses: []
```

# thm:dirichlets-principle

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:dirichlets-principle
uses: []
```

# sec:heat-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-equation
uses: []
```

# sec:heat-fundamental-solution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-fundamental-solution
uses: []
```

# sec:heat-fundamental-solution-derivation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-fundamental-solution-derivation
uses: []
```

# def:fundamental-solution-heat-equation

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:fundamental-solution-heat-equation
uses: []
```

# lem:integral-fundamental-solution-heat

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:integral-fundamental-solution-heat
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# lem:heat-kernel-solves-heat-equation

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:heat-kernel-solves-heat-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# sec:heat-initial-value-problem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-initial-value-problem
uses: []
```

# thm:heat-equation-initial-value-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:heat-equation-initial-value-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:integral-fundamental-solution-heat]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:heat-convolution-smooth]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:heat-convolution-solves-heat]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:heat-convolution-attains-initial-data]]'
```

# def:heat-convolution-solution

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:heat-convolution-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# lem:heat-convolution-smooth

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:heat-convolution-smooth
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:heat-convolution-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# lem:heat-convolution-solves-heat

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:heat-convolution-solves-heat
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:heat-convolution-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:heat-kernel-solves-heat-equation]]'
```

# rem:heat-equation-infinite-propagation-speed

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:heat-equation-infinite-propagation-speed
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:heat-equation-initial-value-solution]]'
```

# lem:heat-infinite-propagation-speed

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:heat-infinite-propagation-speed
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:heat-convolution-solution]]'
```

# lem:heat-convolution-attains-initial-data

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:heat-convolution-attains-initial-data
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:heat-convolution-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:integral-fundamental-solution-heat]]'
```

# sec:heat-nonhomogeneous-problem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-nonhomogeneous-problem
uses: []
```

# thm:heat-equation-nonhomogeneous-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:heat-equation-nonhomogeneous-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# rem:heat-equation-duhamel-combined

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:heat-equation-duhamel-combined
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:heat-equation-initial-value-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:heat-equation-nonhomogeneous-solution]]'
```

# sec:heat-mean-value-formula

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-mean-value-formula
uses: []
```

# def:parabolic-cylinder-heat-ball

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:parabolic-cylinder-heat-ball
uses: []
```

# def:parabolic-boundary-heat-ball

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:parabolic-boundary-heat-ball
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:parabolic-cylinder-heat-ball]]'
```

# def:heat-ball

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:heat-ball
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# thm:mean-value-property-heat-equation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:mean-value-property-heat-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:parabolic-cylinder-heat-ball]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:heat-ball]]'
```

# sec:heat-properties-of-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-properties-of-solutions
uses: []
```

# sec:heat-strong-maximum-principle

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-strong-maximum-principle
uses: []
```

# thm:strong-maximum-principle-heat-equation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:strong-maximum-principle-heat-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:mean-value-property-heat-equation]]'
```

# rem:strong-maximum-principle-heat-time-intuition

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:strong-maximum-principle-heat-time-intuition
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:strong-maximum-principle-heat-equation]]'
```

# rem:strong-maximum-principle-heat-positivity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:strong-maximum-principle-heat-positivity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:strong-maximum-principle-heat-equation]]'
```

# thm:weak-maximum-principle-heat

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:weak-maximum-principle-heat
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:parabolic-cylinder-heat-ball]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#def:parabolic-boundary-heat-ball]]'
```

# thm:uniqueness-heat-bounded-domain

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:uniqueness-heat-bounded-domain
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:strong-maximum-principle-heat-equation]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:weak-maximum-principle-heat]]'
```

# def:comparison-kernel

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:comparison-kernel
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:fundamental-solution-heat-equation]]'
```

# lem:comparison-kernel-solves-heat

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:comparison-kernel-solves-heat
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:comparison-kernel]]'
```

# lem:comparison-function-solves-heat

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:comparison-function-solves-heat
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:comparison-kernel-solves-heat]]'
```

# thm:maximum-principle-heat-cauchy-problem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:maximum-principle-heat-cauchy-problem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:maximum-principle-heat-cauchy-problem-smalltime]]'
```

# thm:maximum-principle-heat-cauchy-problem-smalltime

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:maximum-principle-heat-cauchy-problem-smalltime
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:comparison-function-solves-heat]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:weak-maximum-principle-heat]]'
```

# thm:uniqueness-heat-cauchy-problem

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:uniqueness-heat-cauchy-problem
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:maximum-principle-heat-cauchy-problem]]'
```

# thm:uniqueness-heat-cauchy-problem-smalltime

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:uniqueness-heat-cauchy-problem-smalltime
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:maximum-principle-heat-cauchy-problem-smalltime]]'
```

# rem:heat-equation-nonphysical-solutions

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:heat-equation-nonphysical-solutions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:uniqueness-heat-cauchy-problem]]'
```

# sec:heat-regularity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-regularity
uses: []
```

# thm:heat-equation-smoothness

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:heat-equation-smoothness
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:heat-equation-nonhomogeneous-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:uniqueness-heat-cauchy-problem]]'
```

# sec:heat-local-estimates

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-local-estimates
uses: []
```

# thm:heat-equation-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:heat-equation-derivative-estimates
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:heat-equation-smoothness]]'
```

# rem:heat-equation-spatial-analyticity

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:heat-equation-spatial-analyticity
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:heat-equation-derivative-estimates]]'
```

# sec:heat-energy-methods

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-energy-methods
uses: []
```

# sec:heat-energy-uniqueness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-energy-uniqueness
uses: []
```

# thm:uniqueness-heat-energy-method

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:uniqueness-heat-energy-method
uses:
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:uniqueness-heat-bounded-domain-anisotropic]]'
```

# sec:heat-backwards-uniqueness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:heat-backwards-uniqueness
uses: []
```

# thm:backwards-uniqueness-heat-equation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:backwards-uniqueness-heat-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:uniqueness-heat-energy-method]]'
```

# sec:wave-equation

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-equation
uses: []
```

# sec:wave-solution-spherical-means

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-solution-spherical-means
uses: []
```

# sec:wave-dalembert-formula

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-dalembert-formula
uses: []
```

# def:dalembert-formula

```qprint
kind: definition
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#def:dalembert-formula
uses: []
```

# lem:second-order-chain-rule-linear-form

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:second-order-chain-rule-linear-form
uses: []
```

# thm:wave-equation-dalembert-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:wave-equation-dalembert-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:dalembert-formula]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:second-order-chain-rule-linear-form]]'
```

# thm:dalembert-initial-conditions

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:dalembert-initial-conditions
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#def:dalembert-formula]]'
```

# thm:wave-1d-general-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:wave-1d-general-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:second-order-chain-rule-linear-form]]'
```

# rem:wave-equation-general-solution-1d

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:wave-equation-general-solution-1d
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-dalembert-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-1d-general-solution]]'
```

# sec:wave-spherical-means

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-spherical-means
uses: []
```

# lem:euler-poisson-darboux-equation

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:euler-poisson-darboux-equation
uses:
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:wave-spherical-mean-smoothness]]'
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:wave-spherical-mean-time-derivative]]'
- '[[references/Evans/blueprint/src/chapters/formalization-support#lem:weak-divergence-form-radial-equation]]'
```

# sec:wave-kirchhoff-poisson-formulas

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-kirchhoff-poisson-formulas
uses: []
```

# sec:wave-solution-odd-n

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-solution-odd-n
uses: []
```

# lem:wave-equation-useful-identities

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:wave-equation-useful-identities
uses: []
```

# lem:transformed-spherical-mean-wave-equation

```qprint
kind: lemma
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#lem:transformed-spherical-mean-wave-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:euler-poisson-darboux-equation]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:wave-equation-useful-identities]]'
```

# thm:wave-equation-odd-dimensions-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:wave-equation-odd-dimensions-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#lem:transformed-spherical-mean-wave-equation]]'
```

# rem:wave-equation-odd-dimension-remarks

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:wave-equation-odd-dimension-remarks
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-odd-dimensions-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-dalembert-solution]]'
```

# sec:wave-solution-even-n

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-solution-even-n
uses: []
```

# thm:wave-equation-even-dimensions-solution

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:wave-equation-even-dimensions-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-odd-dimensions-solution]]'
```

# rem:huygens-principle

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:huygens-principle
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-odd-dimensions-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-even-dimensions-solution]]'
```

# sec:wave-nonhomogeneous-problem

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-nonhomogeneous-problem
uses: []
```

# thm:wave-equation-nonhomogeneous-duhamel

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:wave-equation-nonhomogeneous-duhamel
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-odd-dimensions-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-even-dimensions-solution]]'
```

# rem:wave-equation-general-nonhomogeneous-solution

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#rem:wave-equation-general-nonhomogeneous-solution
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-nonhomogeneous-duhamel]]'
```

# ex:wave-equation-nonhomogeneous-n1-n3

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#ex:wave-equation-nonhomogeneous-n1-n3
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-nonhomogeneous-duhamel]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:wave-equation-dalembert-solution]]'
```

# sec:wave-energy-methods

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-energy-methods
uses: []
```

# sec:wave-energy-uniqueness

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-energy-uniqueness
uses: []
```

# thm:uniqueness-wave-equation-energy-method

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:uniqueness-wave-equation-energy-method
uses: []
```

# sec:wave-domain-of-dependence

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:wave-domain-of-dependence
uses: []
```

# thm:wave-equation-finite-propagation-speed

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#thm:wave-equation-finite-propagation-speed
uses: []
```

# sec:transport-equation-constant-reaction

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:transport-equation-constant-reaction
uses: []
```

# ex:transport-reaction-equation

```qprint
kind: theorem
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#ex:transport-reaction-equation
uses:
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:transport-ivp-solution]]'
- '[[references/Evans/blueprint/src/chapters/chapter2#thm:transport-initial-condition]]'
```

# sec:chapter2-references

```qprint
kind: other
status: not_started
tex: references/Evans/blueprint/src/chapters/chapter2.tex#sec:chapter2-references
uses: []
```
