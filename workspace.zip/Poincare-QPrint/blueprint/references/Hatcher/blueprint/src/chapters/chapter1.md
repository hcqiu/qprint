# ex:borromean-rings-commutator

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:borromean-rings-commutator
uses: []
```

# sec:basic-constructions

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#sec:basic-constructions
uses: []
```

# def:path

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:path
uses: []
```

# def:homotopy-of-paths

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:homotopy-of-paths
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:path]]'
```

# ex:linear-homotopies-convex

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:linear-homotopies-convex
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:homotopy-of-paths]]'
```

# prop:homotopy-paths-equivalence-relation

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:homotopy-paths-equivalence-relation
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:homotopy-of-paths]]'
```

# def:path-composition

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:path-composition
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:path]]'
```

# def:loop-and-pi1-set

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:loop-and-pi1-set
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:path]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:homotopy-of-paths]]'
```

# prop:pi1-is-a-group

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:pi1-is-a-group
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:path-composition]]'
```

# ex:convex-set-trivial-pi1

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:convex-set-trivial-pi1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:linear-homotopies-convex]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
```

# def:change-of-basepoint-map

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:change-of-basepoint-map
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:path-composition]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
```

# prop:change-of-basepoint-isomorphism

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:change-of-basepoint-isomorphism
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:change-of-basepoint-map]]'
```

# def:simply-connected

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:simply-connected
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
```

# prop:simply-connected-iff-unique-path-class

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:simply-connected-iff-unique-path-class
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:simply-connected]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:homotopy-of-paths]]'
```

# thm:fundamental-group-of-circle

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:fundamental-group-of-circle
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:covering-space]]'
```

# def:covering-space

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:covering-space
uses: []
```

# thm:fundamental-theorem-of-algebra

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:fundamental-theorem-of-algebra
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:fundamental-group-of-circle]]'
```

# thm:brouwer-fixed-point-dim2

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:brouwer-fixed-point-dim2
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:fundamental-group-of-circle]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:retraction]]'
```

# thm:borsuk-ulam-dim2

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:borsuk-ulam-dim2
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:fundamental-group-of-circle]]'
```

# cor:sphere-three-closed-sets-antipodal

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#cor:sphere-three-closed-sets-antipodal
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:borsuk-ulam-dim2]]'
```

# prop:pi1-of-product-space

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:pi1-of-product-space
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
```

# def:induced-homomorphism

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:induced-homomorphism
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
```

# lem:loop-decomposition-open-cover

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#lem:loop-decomposition-open-cover
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
```

# prop:pi1-sphere-trivial-n-geq-2

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:pi1-sphere-trivial-n-geq-2
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:induced-homomorphism]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#lem:loop-decomposition-open-cover]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:convex-set-trivial-pi1]]'
```

# cor:r2-not-homeomorphic-rn

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#cor:r2-not-homeomorphic-rn
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:pi1-of-product-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:pi1-sphere-trivial-n-geq-2]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:fundamental-group-of-circle]]'
```

# prop:retract-induces-injective-pi1

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:retract-induces-injective-pi1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:induced-homomorphism]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:retraction]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:deformation-retraction]]'
```

# def:based-homotopy-equivalence

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:based-homotopy-equivalence
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy]]'
```

# prop:homotopy-equivalence-induces-pi1-iso

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:homotopy-equivalence-induces-pi1-iso
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:induced-homomorphism]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#lem:basepoint-change-homotopy]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-equivalence]]'
```

# lem:basepoint-change-homotopy

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#lem:basepoint-change-homotopy
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:change-of-basepoint-map]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:induced-homomorphism]]'
```

# sec:van-kampen-theorem

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#sec:van-kampen-theorem
uses: []
```

# def:free-product-of-groups

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:free-product-of-groups
uses: []
```

# def:free-group-basis-rank

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:free-group-basis-rank
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:free-product-of-groups]]'
```

# prop:free-product-universal-property

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:free-product-universal-property
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:free-product-of-groups]]'
```

# thm:van-kampen-theorem

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:van-kampen-theorem
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:free-product-universal-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#lem:loop-decomposition-open-cover]]'
- '[[references/Hatcher/blueprint/src/chapters/formalization-support#lem:van-kampen-rectangular-subdivision]]'
- '[[references/Hatcher/blueprint/src/chapters/formalization-support#lem:van-kampen-grid-cell-sweep]]'
```

# ex:wedge-sum-fundamental-group

```qprint
kind: proof
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:wedge-sum-fundamental-group
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:van-kampen-theorem]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:wedge-sum]]'
```

# ex:linking-of-circles-fundamental-groups

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:linking-of-circles-fundamental-groups
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:van-kampen-theorem]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:pi1-of-product-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:pi1-sphere-trivial-n-geq-2]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:borromean-rings-commutator]]'
```

# ex:torus-knot-complement-fundamental-group

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:torus-knot-complement-fundamental-group
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:van-kampen-theorem]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:mapping-cylinder]]'
```

# ex:shrinking-wedge-circles

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:shrinking-wedge-circles
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:fundamental-group-of-circle]]'
```

# prop:attaching-cells-pi1

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:attaching-cells-pi1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:van-kampen-theorem]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:pi1-sphere-trivial-n-geq-2]]'
```

# cor:genus-surfaces-distinct

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#cor:genus-surfaces-distinct
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:attaching-cells-pi1]]'
```

# cor:every-group-realized-as-pi1

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#cor:every-group-realized-as-pi1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:attaching-cells-pi1]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:wedge-sum-fundamental-group]]'
```

# ex:cyclic-group-complex-xg

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:cyclic-group-complex-xg
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#cor:every-group-realized-as-pi1]]'
```

# sec:covering-spaces

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#sec:covering-spaces
uses: []
```

# def:covering-space-sheets

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:covering-space-sheets
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:covering-space]]'
```

# def:lift-of-a-map

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:lift-of-a-map
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:covering-space]]'
```

# prop:covering-homotopy-property

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:covering-homotopy-property
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:covering-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:lift-of-a-map]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:fundamental-group-of-circle]]'
```

# prop:covering-map-pi1-injective

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:covering-map-pi1-injective
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-homotopy-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
```

# prop:covering-sheets-equals-index

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:covering-sheets-equals-index
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:covering-space-sheets]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-map-pi1-injective]]'
```

# prop:covering-lifting-criterion

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:covering-lifting-criterion
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-homotopy-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:lift-of-a-map]]'
```

# prop:covering-unique-lifting

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:covering-unique-lifting
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:lift-of-a-map]]'
```

# def:semilocally-simply-connected

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:semilocally-simply-connected
uses: []
```

# prop:universal-cover-construction

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:universal-cover-construction
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:semilocally-simply-connected]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:simply-connected-iff-unique-path-class]]'
```

# ex:xmn-universal-cover-construction

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:xmn-universal-cover-construction
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:torus-knot-complement-fundamental-group]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:covering-space]]'
```

# prop:covering-space-existence-for-subgroup

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:covering-space-existence-for-subgroup
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:universal-cover-construction]]'
```

# prop:covering-space-isomorphism-criterion

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:covering-space-isomorphism-criterion
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-lifting-criterion]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-unique-lifting]]'
```

# thm:covering-space-classification

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:covering-space-classification
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-space-existence-for-subgroup]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-space-isomorphism-criterion]]'
```

# def:universal-cover

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:universal-cover
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:covering-space-classification]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-lifting-criterion]]'
```

# def:deck-transformation-group

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:deck-transformation-group
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:covering-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-unique-lifting]]'
```

# def:normal-covering-space

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:normal-covering-space
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:deck-transformation-group]]'
```

# prop:normal-covering-deck-group

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:normal-covering-deck-group
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:normal-covering-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:covering-space-classification]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-lifting-criterion]]'
```

# def:group-action

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:group-action
uses: []
```

# def:orbit-space

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:orbit-space
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:group-action]]'
```

# prop:covering-space-action-quotient

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:covering-space-action-quotient
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:group-action]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:orbit-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:normal-covering-deck-group]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-unique-lifting]]'
```

# ex:genus-11-torus-covering

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:genus-11-torus-covering
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-space-action-quotient]]'
```

# ex:grid-symmetries-torus-klein-bottle

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:grid-symmetries-torus-klein-bottle
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-space-action-quotient]]'
```

# ex:real-projective-space-covering

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:real-projective-space-covering
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-space-action-quotient]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:pi1-sphere-trivial-n-geq-2]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#ex:real-projective-space-cw]]'
```

# ex:gmn-action-on-tree

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:gmn-action-on-tree
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:xmn-universal-cover-construction]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:torus-knot-complement-fundamental-group]]'
```

# def:cayley-graph-and-complex

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:cayley-graph-and-complex
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#cor:every-group-realized-as-pi1]]'
```

# ex:cayley-graph-free-group

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:cayley-graph-free-group
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:cayley-graph-and-complex]]'
```

# ex:cayley-complex-torus

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:cayley-complex-torus
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:cayley-graph-and-complex]]'
```

# ex:cayley-complex-cyclic-group

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:cayley-complex-cyclic-group
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:cayley-graph-and-complex]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:real-projective-space-covering]]'
```

# ex:cayley-complex-infinite-dihedral

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:cayley-complex-infinite-dihedral
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:cayley-graph-and-complex]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:free-product-of-groups]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:cayley-complex-cyclic-group]]'
```

# sec:graphs-and-free-groups

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#sec:graphs-and-free-groups
uses: []
```

# def:graph

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:graph
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# def:subgraph-and-tree

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:subgraph-and-tree
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:graph]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:contractible]]'
```

# prop:maximal-tree-exists

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:maximal-tree-exists
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:subgraph-and-tree]]'
```

# prop:fundamental-group-of-graph-is-free

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:fundamental-group-of-graph-is-free
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:maximal-tree-exists]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:wedge-sum-fundamental-group]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:quotient-by-contractible-hep-homotopy-equiv]]'
```

# lem:covering-space-of-graph-is-graph

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#lem:covering-space-of-graph-is-graph
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:graph]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-homotopy-property]]'
```

# thm:subgroup-of-free-group-is-free

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:subgroup-of-free-group-is-free
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-space-existence-for-subgroup]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-map-pi1-injective]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#lem:covering-space-of-graph-is-graph]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:fundamental-group-of-graph-is-free]]'
```

# def:edgepath

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:edgepath
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:graph]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:maximal-tree-exists]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#lem:covering-space-of-graph-is-graph]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:universal-cover]]'
```

# sec:kg1-spaces-graphs-of-groups

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#sec:kg1-spaces-graphs-of-groups
uses: []
```

# def:k-g-1-space

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:k-g-1-space
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:universal-cover]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:contractible]]'
```

# ex:graphs-are-kg1

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:graphs-are-kg1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:k-g-1-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:fundamental-group-of-graph-is-free]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#lem:covering-space-of-graph-is-graph]]'
```

# ex:knot-complement-in-s3-kg1

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:knot-complement-in-s3-kg1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:k-g-1-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:xmn-universal-cover-construction]]'
```

# ex:milnor-construction-eg-bg

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:milnor-construction-eg-bg
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:k-g-1-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:group-action]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-space-action-quotient]]'
```

# thm:kg1-unique-homotopy-type

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:kg1-unique-homotopy-type
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:k-g-1-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:homomorphism-to-kg1-realized-by-map]]'
```

# prop:homomorphism-to-kg1-realized-by-map

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#prop:homomorphism-to-kg1-realized-by-map
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:k-g-1-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:maximal-tree-exists]]'
```

# def:graph-of-groups

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#def:graph-of-groups
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:milnor-construction-eg-bg]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:mapping-cylinder]]'
```

# thm:graph-of-groups-is-kg1

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#thm:graph-of-groups-is-kg1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:graph-of-groups]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:k-g-1-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:covering-space-action-quotient]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#cor:hep-inclusion-homotopy-equiv-deformation-retract]]'
```

# ex:free-product-with-amalgamation

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:free-product-with-amalgamation
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:graph-of-groups-is-kg1]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:xmn-universal-cover-construction]]'
```

# ex:hnn-extension

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:hnn-extension
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:graph-of-groups-is-kg1]]'
```

# ex:closed-surfaces-are-kg1

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:closed-surfaces-are-kg1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:graph-of-groups-is-kg1]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#ex:graphs-are-kg1]]'
```

# ex:cube-graph-fundamental-group-free

```qprint
kind: proof
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:cube-graph-fundamental-group-free
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:van-kampen-theorem]]'
```

# ex:torus-fundamental-group

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter1.tex#ex:torus-fundamental-group
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#prop:pi1-of-product-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter1#thm:fundamental-group-of-circle]]'
```
