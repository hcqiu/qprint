# def:deformation-retraction

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:deformation-retraction
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:retraction]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-rel-a]]'
```

# def:mapping-cylinder

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:mapping-cylinder
uses: []
```

# def:homotopy

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:homotopy
uses: []
```

# def:homotopic-maps

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:homotopic-maps
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy]]'
```

# def:retraction

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:retraction
uses: []
```

# def:homotopy-rel-a

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:homotopy-rel-a
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy]]'
```

# def:homotopy-equivalence

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:homotopy-equivalence
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopic-maps]]'
```

# prop:deformation-retract-homotopy-equivalence

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#prop:deformation-retract-homotopy-equivalence
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:deformation-retraction]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-equivalence]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:retraction]]'
```

# def:contractible

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:contractible
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-equivalence]]'
```

# ex:house-with-two-rooms-contractible

```qprint
kind: proof
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:house-with-two-rooms-contractible
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:contractible]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:mapping-cylinder]]'
```

# sec:cell-complexes

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#sec:cell-complexes
uses: []
```

# def:cell-complex

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:cell-complex
uses: []
```

# def:dimension-cw-complex

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:dimension-cw-complex
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# ex:cw-graph

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:cw-graph
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# ex:house-two-rooms-euler-characteristic

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:house-two-rooms-euler-characteristic
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#ex:house-with-two-rooms-contractible]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:euler-characteristic-homology]]'
```

# ex:sphere-two-cells

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:sphere-two-cells
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# ex:real-projective-space-cw

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:real-projective-space-cw
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#ex:sphere-two-cells]]'
```

# ex:infinite-real-projective-space

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:infinite-real-projective-space
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#ex:real-projective-space-cw]]'
```

# ex:complex-projective-space-cw

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:complex-projective-space-cw
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# def:characteristic-map

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:characteristic-map
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# def:subcomplex

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:subcomplex
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# def:cw-pair

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:cw-pair
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:subcomplex]]'
```

# rem:closure-of-cell-not-always-subcomplex

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#rem:closure-of-cell-not-always-subcomplex
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:subcomplex]]'
```

# sec:operations-on-spaces

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#sec:operations-on-spaces
uses: []
```

# def:product-cw-structure

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:product-cw-structure
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# def:quotient-cw-structure

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:quotient-cw-structure
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cw-pair]]'
```

# def:suspension

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:suspension
uses: []
```

# def:cone

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:cone
uses: []
```

# def:join

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:join
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cone]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:suspension]]'
```

# def:simplex

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:simplex
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:join]]'
```

# def:wedge-sum

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:wedge-sum
uses: []
```

# def:smash-product

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:smash-product
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:wedge-sum]]'
```

# sec:two-criteria-homotopy-equivalence

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#sec:two-criteria-homotopy-equivalence
uses: []
```

# prop:collapsing-contractible-cw-subcomplex

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#prop:collapsing-contractible-cw-subcomplex
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cw-pair]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:contractible]]'
```

# def:attaching-space

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:attaching-space
uses: []
```

# def:mapping-cone

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:mapping-cone
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cone]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:attaching-space]]'
```

# prop:attaching-homotopic-maps-preview

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#prop:attaching-homotopic-maps-preview
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cw-pair]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:attaching-space]]'
```

# rem:attaching-homotopic-maps-sharper-version

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#rem:attaching-homotopic-maps-sharper-version
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:attaching-maps-homotopic-rel-x0]]'
```

# ex:quotient-contractible-subcomplex-mapping-cone

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:quotient-contractible-subcomplex-mapping-cone
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cw-pair]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:mapping-cone]]'
```

# ex:quotient-by-contractible-in-x

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:quotient-by-contractible-in-x
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#ex:quotient-contractible-subcomplex-mapping-cone]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:suspension]]'
```

# ex:reduced-suspension

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:reduced-suspension
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:suspension]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:smash-product]]'
```

# sec:homotopy-extension-property

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#sec:homotopy-extension-property
uses: []
```

# def:homotopy-extension-property

```qprint
kind: definition
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#def:homotopy-extension-property
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy]]'
```

# prop:hep-iff-retract

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#prop:hep-iff-retract
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-extension-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:retraction]]'
```

# lem:hep-cylinder-deformation-retract

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#lem:hep-cylinder-deformation-retract
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-extension-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:deformation-retraction]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:hep-iff-retract]]'
```

# ex:hep-fails-for-bad-subspace

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:hep-fails-for-bad-subspace
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:hep-iff-retract]]'
```

# ex:mapping-cylinder-neighborhood-hep

```qprint
kind: proof
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:mapping-cylinder-neighborhood-hep
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:mapping-cylinder]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:hep-iff-retract]]'
```

# prop:cw-pairs-have-hep

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#prop:cw-pairs-have-hep
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cw-pair]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-extension-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:deformation-retraction]]'
```

# prop:quotient-by-contractible-hep-homotopy-equiv

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#prop:quotient-by-contractible-hep-homotopy-equiv
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-extension-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:contractible]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-equivalence]]'
```

# lem:attach-homotopic-hep-rel

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#lem:attach-homotopic-hep-rel
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:attaching-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-extension-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#lem:hep-cylinder-deformation-retract]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-rel-a]]'
```

# prop:attaching-maps-homotopic-rel-x0

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#prop:attaching-maps-homotopic-rel-x0
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cw-pair]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:attaching-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:cw-pairs-have-hep]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#lem:attach-homotopic-hep-rel]]'
```

# lem:hep-product-interval

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#lem:hep-product-interval
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-extension-property]]'
```

# prop:hep-homotopy-equivalence-rel-a

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#prop:hep-homotopy-equivalence-rel-a
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-extension-property]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-equivalence]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#lem:hep-product-interval]]'
```

# cor:hep-inclusion-homotopy-equiv-deformation-retract

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#cor:hep-inclusion-homotopy-equiv-deformation-retract
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:hep-homotopy-equivalence-rel-a]]'
```

# lem:mapping-cylinder-pair-hep

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#lem:mapping-cylinder-pair-hep
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:mapping-cylinder]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-extension-property]]'
```

# cor:homotopy-equivalence-iff-deformation-retract-mapping-cylinder

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#cor:homotopy-equivalence-iff-deformation-retract-mapping-cylinder
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#cor:hep-inclusion-homotopy-equiv-deformation-retract]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:mapping-cylinder]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#lem:mapping-cylinder-pair-hep]]'
```

# ex:graphs-collapsing-homotopy-equivalent

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:graphs-collapsing-homotopy-equivalent
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:collapsing-contractible-cw-subcomplex]]'
```

# ex:necklace-attaching-spheres-circle

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:necklace-attaching-spheres-circle
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:attaching-homotopic-maps-preview]]'
```

# ex:sphere-two-points-identified

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:sphere-two-points-identified
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:collapsing-contractible-cw-subcomplex]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cw-pair]]'
```

# ex:sphere-two-points-identified-via-attaching

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:sphere-two-points-identified-via-attaching
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:attaching-homotopic-maps-preview]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:mapping-cone]]'
```

# ex:torus-meridional-disks-necklace

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter0.tex#ex:torus-meridional-disks-necklace
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:collapsing-contractible-cw-subcomplex]]'
```
