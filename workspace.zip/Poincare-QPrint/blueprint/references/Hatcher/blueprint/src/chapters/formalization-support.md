# lem:van-kampen-grid-cell-sweep

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/formalization-support.tex#lem:van-kampen-grid-cell-sweep
uses: []
```

# lem:van-kampen-rectangular-subdivision

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/formalization-support.tex#lem:van-kampen-rectangular-subdivision
uses: []
```

# rem:collapsing-contractible-cw-subcomplex-special-case

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/formalization-support.tex#rem:collapsing-contractible-cw-subcomplex-special-case
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:quotient-by-contractible-hep-homotopy-equiv]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:cw-pairs-have-hep]]'
```
