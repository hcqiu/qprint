# lem:boundary-composition-zero

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#lem:boundary-composition-zero
uses: []
```

# ex:simplicial-homology-circle

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:simplicial-homology-circle
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:boundary-composition-zero]]'
```

# ex:simplicial-homology-torus

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:simplicial-homology-torus
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:boundary-composition-zero]]'
```

# ex:simplicial-homology-rp2

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:simplicial-homology-rp2
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:boundary-composition-zero]]'
```

# ex:delta-complex-sn

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:delta-complex-sn
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:boundary-composition-zero]]'
```

# prop:homology-disjoint-union

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:homology-disjoint-union
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:boundary-composition-zero]]'
```

# prop:h0-path-connected

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:h0-path-connected
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:homology-disjoint-union]]'
```

# prop:homology-point

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:homology-point
uses: []
```

# prop:chain-map-induces-homology-homomorphism

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:chain-map-induces-homology-homomorphism
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:boundary-composition-zero]]'
```

# thm:homotopic-maps-induce-same-homology-map

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:homotopic-maps-induce-same-homology-map
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:chain-map-induces-homology-homomorphism]]'
```

# cor:homotopy-equivalence-induces-homology-isomorphism

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#cor:homotopy-equivalence-induces-homology-isomorphism
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy-equivalence]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:homotopic-maps-induce-same-homology-map]]'
```

# prop:chain-homotopic-maps-induce-same-homology-map

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:chain-homotopic-maps-induce-same-homology-map
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:chain-map-induces-homology-homomorphism]]'
```

# thm:excision

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:excision
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:deformation-retraction]]'
```

# cor:homology-spheres

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#cor:homology-spheres
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:excision]]'
```

# cor:non-retraction-disk-boundary

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#cor:non-retraction-disk-boundary
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#cor:homology-spheres]]'
```

# thm:long-exact-sequence-pair

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:long-exact-sequence-pair
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:boundary-composition-zero]]'
```

# ex:long-exact-sequence-disk-sphere

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:long-exact-sequence-disk-sphere
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:long-exact-sequence-pair]]'
```

# ex:reduced-homology-relative

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:reduced-homology-relative
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:long-exact-sequence-pair]]'
```

# prop:homotopic-maps-pairs

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:homotopic-maps-pairs
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:homotopy]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:homotopic-maps-induce-same-homology-map]]'
```

# thm:excision-general

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:excision-general
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:boundary-composition-zero]]'
```

# prop:inclusion-u-chains-homotopy-equivalence

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:inclusion-u-chains-homotopy-equivalence
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:chain-homotopic-maps-induce-same-homology-map]]'
```

# prop:good-pairs-absolute-homology

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:good-pairs-absolute-homology
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:excision-general]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:deformation-retraction]]'
```

# ex:cycles-spheres-disks

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:cycles-spheres-disks
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#cor:homology-spheres]]'
```

# cor:excision-cw-subcomplexes

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#cor:excision-cw-subcomplexes
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:excision-general]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cw-pair]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#prop:cw-pairs-have-hep]]'
```

# cor:wedge-sum-direct-sum-homology

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#cor:wedge-sum-direct-sum-homology
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:good-pairs-absolute-homology]]'
```

# thm:invariance-of-dimension

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:invariance-of-dimension
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:good-pairs-absolute-homology]]'
```

# thm:simplicial-singular-homology-isomorphic

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:simplicial-singular-homology-isomorphic
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:five-lemma]]'
```

# lem:five-lemma

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#lem:five-lemma
uses: []
```

# thm:tangent-vector-fields-spheres

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:tangent-vector-fields-spheres
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#cor:homology-spheres]]'
```

# prop:z2-acts-freely-even-spheres

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:z2-acts-freely-even-spheres
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:tangent-vector-fields-spheres]]'
```

# prop:local-degree-formula

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:local-degree-formula
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#cor:homology-spheres]]'
```

# ex:degree-reflection-antipodal

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:degree-reflection-antipodal
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#cor:homology-spheres]]'
```

# ex:degree-suspension

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:degree-suspension
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:suspension]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#cor:homology-spheres]]'
```

# prop:homology-cw-complexes

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:homology-cw-complexes
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# lem:homology-cw-skeleton-pairs

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#lem:homology-cw-skeleton-pairs
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```

# thm:cellular-singular-homology-isomorphic

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:cellular-singular-homology-isomorphic
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:homology-cw-complexes]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:homology-cw-skeleton-pairs]]'
```

# ex:cellular-homology-spheres

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:cellular-homology-spheres
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#ex:sphere-two-cells]]'
```

# ex:cellular-homology-surfaces

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:cellular-homology-surfaces
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
```

# ex:acyclic-space

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:acyclic-space
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
```

# ex:three-torus

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:three-torus
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
```

# ex:moore-spaces

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:moore-spaces
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
```

# ex:cellular-homology-cpn

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:cellular-homology-cpn
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#ex:complex-projective-space-cw]]'
```

# ex:cellular-homology-rpn

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:cellular-homology-rpn
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter0#ex:real-projective-space-cw]]'
```

# ex:lens-spaces

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:lens-spaces
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
```

# thm:euler-characteristic-homology

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:euler-characteristic-homology
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:dimension-cw-complex]]'
```

# lem:splitting-lemma

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#lem:splitting-lemma
uses: []
```

# prop:fundamental-group-kg1-torsionfree

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:fundamental-group-kg1-torsionfree
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:k-g-1-space]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#ex:lens-spaces]]'
```

# ex:mayer-vietoris-sphere

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:mayer-vietoris-sphere
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:excision-general]]'
```

# ex:mayer-vietoris-klein-bottle

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:mayer-vietoris-klein-bottle
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:excision-general]]'
```

# ex:homology-mapping-torus

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:homology-mapping-torus
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:excision-general]]'
```

# lem:homology-map-degree-m-coefficients

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#lem:homology-map-degree-m-coefficients
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#cor:homology-spheres]]'
```

# ex:homology-rpn-field-coefficients

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:homology-rpn-field-coefficients
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#ex:cellular-homology-rpn]]'
```

# ex:homology-moore-space-quotient

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:homology-moore-space-quotient
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#ex:moore-spaces]]'
```

# sec:formal-viewpoint

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#sec:formal-viewpoint
uses: []
```

# thm:hurewicz-dimension-1

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:hurewicz-dimension-1
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter1#def:loop-and-pi1-set]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:h0-path-connected]]'
```

# ex:h1-closed-orientable-surface

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:h1-closed-orientable-surface
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:hurewicz-dimension-1]]'
```

# prop:homology-sphere-complement-disk-sphere

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:homology-sphere-complement-disk-sphere
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:excision-general]]'
- '[[references/Hatcher/blueprint/src/chapters/chapter2#ex:mayer-vietoris-sphere]]'
```

# ex:alexander-horned-sphere

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:alexander-horned-sphere
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:homology-sphere-complement-disk-sphere]]'
```

# thm:invariance-of-domain-general

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:invariance-of-domain-general
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:homology-sphere-complement-disk-sphere]]'
```

# cor:embedding-compact-manifold-connected

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#cor:embedding-compact-manifold-connected
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:invariance-of-domain-general]]'
```

# thm:real-complex-division-algebras

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:real-complex-division-algebras
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:z2-acts-freely-even-spheres]]'
```

# prop:odd-map-odd-degree

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#prop:odd-map-odd-degree
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#cor:homology-spheres]]'
```

# cor:borsuk-ulam

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#cor:borsuk-ulam
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#prop:odd-map-odd-degree]]'
```

# thm:simplicial-approximation

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:simplicial-approximation
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#lem:star-intersections]]'
```

# lem:star-intersections

```qprint
kind: lemma
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#lem:star-intersections
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:simplex]]'
```

# thm:lefschetz-fixed-point

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:lefschetz-fixed-point
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:cellular-singular-homology-isomorphic]]'
```

# ex:lefschetz-surface-rotation

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#ex:lefschetz-surface-rotation
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter2#thm:lefschetz-fixed-point]]'
```

# thm:cw-homotopy-equivalent-simplicial

```qprint
kind: theorem
status: not_started
tex: references/Hatcher/blueprint/src/chapters/chapter2.tex#thm:cw-homotopy-equivalent-simplicial
uses:
- '[[references/Hatcher/blueprint/src/chapters/chapter0#def:cell-complex]]'
```
