# chap:geometric-notions

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/content.tex#chap:geometric-notions
uses: []
```

# chap:fundamental-group

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/content.tex#chap:fundamental-group
uses: []
```

# chap:homology

```qprint
kind: other
status: not_started
tex: references/Hatcher/blueprint/src/content.tex#chap:homology
uses: []
```
