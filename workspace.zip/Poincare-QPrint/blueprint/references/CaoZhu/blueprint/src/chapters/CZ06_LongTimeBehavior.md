# chap:cz-long-time-behavior

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#chap:cz-long-time-behavior
uses: []
```

# lem:cz-normalized-evolution-homogeneous-quantities

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-normalized-evolution-homogeneous-quantities
uses: []
```

# lem:cz-curvature-potential-density-evolution

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-curvature-potential-density-evolution
uses: []
```

# prop:cz-normalized-surface-flow-immortal

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#prop:cz-normalized-surface-flow-immortal
uses: []
```

# thm:cz-negative-euler-surface-convergence

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-negative-euler-surface-convergence
uses: []
```

# thm:cz-zero-euler-surface-convergence

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-zero-euler-surface-convergence
uses: []
```

# lem:cz-positive-euler-surface-harnack

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-positive-euler-surface-harnack
uses: []
```

# prop:cz-positive-euler-surface-curvature-bounds

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#prop:cz-positive-euler-surface-curvature-bounds
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#lem:cz-positive-euler-surface-harnack]]'
```

# lem:cz-tracefree-hessian-evolution

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-tracefree-hessian-evolution
uses: []
```

# prop:cz-tracefree-hessian-exponential-decay

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#prop:cz-tracefree-hessian-exponential-decay
uses: []
```

# prop:cz-compact-shrinking-surface-soliton-rigidity

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#prop:cz-compact-shrinking-surface-soliton-rigidity
uses: []
```

# thm:cz-positive-euler-surface-convergence

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-positive-euler-surface-convergence
uses: []
```

# thm:cz-three-manifold-positive-ricci-sphere

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-three-manifold-positive-ricci-sphere
uses: []
```

# thm:cz-four-manifold-positive-curvature-operator-sphere

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-four-manifold-positive-curvature-operator-sphere
uses: []
```

# thm:cz-nonnegative-curvature-low-dimensional-classification

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-nonnegative-curvature-low-dimensional-classification
uses: []
```

# lem:cz-three-dimensional-ricci-pinching-preserved

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-three-dimensional-ricci-pinching-preserved
uses: []
```

# prop:cz-three-dimensional-positive-ricci-asymptotic-roundness

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#prop:cz-three-dimensional-positive-ricci-asymptotic-roundness
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#lem:cz-three-dimensional-pinching-curvature-gradient]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#lem:cz-three-dimensional-ricci-pinching-preserved]]'
```

# prop:cz-four-dimensional-invariant-curvature-pinching-set

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#prop:cz-four-dimensional-invariant-curvature-pinching-set
uses: []
```

# cor:cz-four-dimensional-curvature-operator-roundness

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#cor:cz-four-dimensional-curvature-operator-roundness
uses: []
```

# rem:cz-differentiable-sphere-subsequential-convergence

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#rem:cz-differentiable-sphere-subsequential-convergence
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#thm:cz-three-manifold-positive-ricci-sphere]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#thm:cz-four-manifold-positive-curvature-operator-sphere]]'
```

# thm:cz-higher-dimensional-pointwise-pinched-sphere

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-higher-dimensional-pointwise-pinched-sphere
uses: []
```

# thm:cz-noncompact-three-manifold-ricci-pinching-flatness

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-noncompact-three-manifold-ricci-pinching-flatness
uses: []
```

# def:cz-nonsingular-normalized-ricci-flow

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#def:cz-nonsingular-normalized-ricci-flow
uses: []
```

# thm:cz-hamilton-ivey-pinching-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-hamilton-ivey-pinching-estimate
uses: []
```

# def:cz-collapsed-nonsingular-solution

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#def:cz-collapsed-nonsingular-solution
uses: []
```

# thm:cz-noncollapsing-nonsingular-flow-structure

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#thm:cz-noncollapsing-nonsingular-flow-structure
uses: []
```

# rem:cz-exceptional-long-time-region-geometry

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#rem:cz-exceptional-long-time-region-geometry
uses: []
```

# lem:cz-noncollapsing-limits-hyperbolic

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-noncollapsing-limits-hyperbolic
uses: []
```

# lem:cz-finite-volume-hyperbolic-embedding-stability

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-finite-volume-hyperbolic-embedding-stability
uses: []
```

# lem:cz-concave-boundary-metric-perturbations

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-concave-boundary-metric-perturbations
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#lem:cz-hyperbolic-cusp-length-bounded]]'
```

# lem:cz-three-dimensional-pinching-curvature-gradient

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-three-dimensional-pinching-curvature-gradient
uses: []
```

# lem:cz-hyperbolic-cusp-length-bounded

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior.tex#lem:cz-hyperbolic-cusp-length-bounded
uses: []
```
