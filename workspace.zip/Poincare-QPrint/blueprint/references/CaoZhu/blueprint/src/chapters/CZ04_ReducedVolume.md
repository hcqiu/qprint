# chap:cz-reduced-volume

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#chap:cz-reduced-volume
uses: []
```

# prop:cz-space-time-curvature-and-the-liyauhamilton-quadratic

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#prop:cz-space-time-curvature-and-the-liyauhamilton-quadratic
uses: []
```

# cor:cz-space-time-ricci-flatness-modulo-inverse-dimension

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#cor:cz-space-time-ricci-flatness-modulo-inverse-dimension
uses: []
```

# lem:cz-first-variation-of-l-length

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#lem:cz-first-variation-of-l-length
uses: []
```

# lem:cz-second-variation-of-l-length

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#lem:cz-second-variation-of-l-length
uses: []
```

# prop:cz-l-jacobi-comparison-inequality

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#prop:cz-l-jacobi-comparison-inequality
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume#lem:cz-second-variation-of-l-length]]'
```

# cor:cz-distributional-comparison-for-reduced-distance

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#cor:cz-distributional-comparison-for-reduced-distance
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume#prop:cz-l-jacobi-comparison-inequality]]'
```

# lem:cz-identities-for-liyauperelman-distance

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#lem:cz-identities-for-liyauperelman-distance
uses: []
```

# cor:cz-conjugate-heat-inequality-for-reduced-density

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#cor:cz-conjugate-heat-inequality-for-reduced-density
uses: []
```

# thm:cz-perelmans-reduced-jacobian-comparison

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#thm:cz-perelmans-reduced-jacobian-comparison
uses: []
```

# thm:cz-monotonicity-of-reduced-volume

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#thm:cz-monotonicity-of-reduced-volume
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#thm:cz-global-curvature-derivative-estimates]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume#thm:cz-perelmans-reduced-jacobian-comparison]]'
```

# def:cz-kappa-noncollapsing-at-a-scale

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#def:cz-kappa-noncollapsing-at-a-scale
uses: []
```

# thm:cz-no-local-collapsing-on-a-finite-time-interval

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#thm:cz-no-local-collapsing-on-a-finite-time-interval
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#thm:cz-local-curvature-derivative-estimates]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume#thm:cz-perelmans-reduced-jacobian-comparison]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume#cor:cz-conjugate-heat-inequality-for-reduced-density]]'
```

# thm:cz-scale-local-no-collapsing

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#thm:cz-scale-local-no-collapsing
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#cor:cz-mu-monotonicity-and-shrinking-breathers]]'
```

# lem:cz-distance-distortion-under-ricci-flow

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#lem:cz-distance-distortion-under-ricci-flow
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume#prop:cz-l-jacobi-comparison-inequality]]'
```

# thm:cz-no-local-collapsing-for-complete-flows

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume.tex#thm:cz-no-local-collapsing-for-complete-flows
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume#thm:cz-no-local-collapsing-on-a-finite-time-interval]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ04_ReducedVolume#lem:cz-distance-distortion-under-ricci-flow]]'
```
