# chap:cz-evolution-equations

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#chap:cz-evolution-equations
uses: []
```

# prop:cz-compact-steady-and-expanding-gradient-solitons-are-einstein

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#prop:cz-compact-steady-and-expanding-gradient-solitons-are-einstein
uses: []
```

# lem:cz-strict-parabolicity-of-the-deturck-modified-flow

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#lem:cz-strict-parabolicity-of-the-deturck-modified-flow
uses: []
```

# thm:cz-short-time-existence-and-uniqueness-on-compact-manifolds

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#thm:cz-short-time-existence-and-uniqueness-on-compact-manifolds
uses: []
```

# thm:cz-short-time-existence-on-complete-noncompact-manifolds

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#thm:cz-short-time-existence-on-complete-noncompact-manifolds
uses: []
```

# thm:cz-bounded-curvature-uniqueness-on-complete-noncompact-manifolds

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#thm:cz-bounded-curvature-uniqueness-on-complete-noncompact-manifolds
uses: []
```

# prop:cz-evolution-of-the-riemann-curvature-tensor

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#prop:cz-evolution-of-the-riemann-curvature-tensor
uses: []
```

# cor:cz-evolution-of-the-ricci-tensor

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#cor:cz-evolution-of-the-ricci-tensor
uses: []
```

# cor:cz-evolution-of-scalar-curvature

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#cor:cz-evolution-of-scalar-curvature
uses: []
```

# prop:cz-evolution-of-the-curvature-operator

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#prop:cz-evolution-of-the-curvature-operator
uses: []
```

# thm:cz-global-curvature-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#thm:cz-global-curvature-derivative-estimates
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#prop:cz-evolution-of-the-riemann-curvature-tensor]]'
```

# thm:cz-local-curvature-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#thm:cz-local-curvature-derivative-estimates
uses: []
```

# prop:cz-cutoff-barrier-is-a-strict-supersolution

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#prop:cz-cutoff-barrier-is-a-strict-supersolution
uses: []
```

# prop:cz-short-time-control-of-cutoff-derivatives

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#prop:cz-short-time-control-of-cutoff-derivatives
uses: []
```

# def:cz-ricci-breathers

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#def:cz-ricci-breathers
uses: []
```

# lem:cz-first-variation-of-perelmans-f-functional

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#lem:cz-first-variation-of-perelmans-f-functional
uses: []
```

# prop:cz-monotonicity-of-perelmans-f-functional

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#prop:cz-monotonicity-of-perelmans-f-functional
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#lem:cz-first-variation-of-perelmans-f-functional]]'
```

# cor:cz-lambda-monotonicity-and-steady-breathers

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#cor:cz-lambda-monotonicity-and-steady-breathers
uses: []
```

# cor:cz-scale-invariant-lambda-monotonicity-and-expanding-breathers

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#cor:cz-scale-invariant-lambda-monotonicity-and-expanding-breathers
uses: []
```

# prop:cz-steady-and-expanding-breathers-are-einstein

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#prop:cz-steady-and-expanding-breathers-are-einstein
uses: []
```

# lem:cz-first-variation-of-perelmans-w-functional

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#lem:cz-first-variation-of-perelmans-w-functional
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#lem:cz-first-variation-of-perelmans-f-functional]]'
```

# prop:cz-monotonicity-of-perelmans-w-functional

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#prop:cz-monotonicity-of-perelmans-w-functional
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#lem:cz-first-variation-of-perelmans-w-functional]]'
```

# cor:cz-mu-monotonicity-and-shrinking-breathers

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#cor:cz-mu-monotonicity-and-shrinking-breathers
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#prop:cz-monotonicity-of-perelmans-w-functional]]'
```

# rem:cz-examples-of-nontrivial-ricci-solitons

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations.tex#rem:cz-examples-of-nontrivial-ricci-solitons
uses: []
```
