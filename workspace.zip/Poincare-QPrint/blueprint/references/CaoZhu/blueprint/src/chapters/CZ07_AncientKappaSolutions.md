# chap:cz-ancient-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#chap:cz-ancient-kappa-solutions
uses: []
```

# prop:cz-neck-radius-lower-bound-at-infinity

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#prop:cz-neck-radius-lower-bound-at-infinity
uses: []
```

# prop:cz-pointed-limit-at-infinity-splits-line

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#prop:cz-pointed-limit-at-infinity-splits-line
uses: []
```

# lem:cz-infinite-ascr-point-selection

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#lem:cz-infinite-ascr-point-selection
uses: []
```

# lem:cz-unbounded-curvature-point-selection

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#lem:cz-unbounded-curvature-point-selection
uses: []
```

# thm:cz-ancient-kappa-asymptotic-shrinker

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#thm:cz-ancient-kappa-asymptotic-shrinker
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-reduced-distance-curvature-parabolic-annulus]]'
```

# thm:cz-two-dimensional-ancient-kappa-classification

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#thm:cz-two-dimensional-ancient-kappa-classification
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-ancient-kappa-asymptotic-shrinker]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-unbounded-curvature-point-selection]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-pointed-limit-at-infinity-splits-line]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#prop:cz-compact-shrinking-surface-soliton-rigidity]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#thm:cz-positive-euler-surface-convergence]]'
```

# lem:cz-ancient-solution-asymptotic-volume-ratio-zero

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#lem:cz-ancient-solution-asymptotic-volume-ratio-zero
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-two-dimensional-ancient-kappa-classification]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-infinite-ascr-point-selection]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-pointed-limit-at-infinity-splits-line]]'
```

# lem:cz-parabolic-point-picking-curvature-control

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#lem:cz-parabolic-point-picking-curvature-control
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-finite-parabolic-curvature-point-selection]]'
```

# thm:cz-local-volume-growth-curvature-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#thm:cz-local-volume-growth-curvature-estimate
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-parabolic-point-picking-curvature-control]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-ancient-solution-asymptotic-volume-ratio-zero]]'
```

# lem:cz-three-dimensional-shrinking-soliton-classification

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#lem:cz-three-dimensional-shrinking-soliton-classification
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#thm:cz-three-manifold-positive-ricci-sphere]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#rem:cz-differentiable-sphere-subsequential-convergence]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-pointed-limit-at-infinity-splits-line]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-two-dimensional-ancient-kappa-classification]]'
```

# prop:cz-ancient-three-dimensional-universal-noncollapsing

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#prop:cz-ancient-three-dimensional-universal-noncollapsing
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-three-dimensional-shrinking-soliton-classification]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-ancient-kappa-asymptotic-shrinker]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-unbounded-curvature-point-selection]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-pointed-limit-at-infinity-splits-line]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-neck-radius-lower-bound-at-infinity]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ06_LongTimeBehavior#prop:cz-three-dimensional-positive-ricci-asymptotic-roundness]]'
```

# thm:cz-ancient-kappa-elliptic-estimates

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#thm:cz-ancient-kappa-elliptic-estimates
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-local-volume-growth-curvature-estimate]]'
```

# cor:cz-ancient-kappa-solution-compactness

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#cor:cz-ancient-kappa-solution-compactness
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-ancient-kappa-elliptic-estimates]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-unbounded-curvature-point-selection]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-pointed-limit-at-infinity-splits-line]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-two-dimensional-ancient-kappa-classification]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-three-dimensional-shrinking-soliton-classification]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-neck-radius-lower-bound-at-infinity]]'
```

# cor:cz-noncompact-ancient-cap-neck-structure

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#cor:cz-noncompact-ancient-cap-neck-structure
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-three-dimensional-shrinking-soliton-classification]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-pointed-limit-at-infinity-splits-line]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-two-dimensional-ancient-kappa-classification]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#cor:cz-ancient-kappa-solution-compactness]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-ancient-three-dimensional-universal-noncollapsing]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-ancient-kappa-elliptic-estimates]]'
```

# thm:cz-ancient-kappa-canonical-neighborhoods

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#thm:cz-ancient-kappa-canonical-neighborhoods
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-two-dimensional-ancient-kappa-classification]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#lem:cz-three-dimensional-shrinking-soliton-classification]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#cor:cz-noncompact-ancient-cap-neck-structure]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#thm:cz-ancient-kappa-elliptic-estimates]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-ancient-three-dimensional-universal-noncollapsing]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#cor:cz-ancient-kappa-solution-compactness]]'
```

# lem:cz-reduced-distance-curvature-parabolic-annulus

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#lem:cz-reduced-distance-curvature-parabolic-annulus
uses: []
```

# lem:cz-finite-parabolic-curvature-point-selection

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions.tex#lem:cz-finite-parabolic-curvature-point-selection
uses: []
```
