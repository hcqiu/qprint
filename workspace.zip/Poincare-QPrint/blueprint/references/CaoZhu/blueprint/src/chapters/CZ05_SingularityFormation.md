# chap:cz-singularity-formation

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#chap:cz-singularity-formation
uses: []
```

# def:cz-pointed-smooth-convergence-of-riemannian-manifolds

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#def:cz-pointed-smooth-convergence-of-riemannian-manifolds
uses: []
```

# thm:cz-cheeger-type-pointed-compactness

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-cheeger-type-pointed-compactness
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation#cor:cz-injectivity-radius-from-local-curvature-scale]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation#prop:cz-local-metric-subsequence-convergence]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation#prop:cz-transition-isometry-subsequence-convergence]]'
```

# prop:cz-local-metric-subsequence-convergence

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#prop:cz-local-metric-subsequence-convergence
uses: []
```

# prop:cz-transition-isometry-subsequence-convergence

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#prop:cz-transition-isometry-subsequence-convergence
uses: []
```

# def:cz-pointed-convergence-of-evolving-manifolds

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#def:cz-pointed-convergence-of-evolving-manifolds
uses: []
```

# lem:cz-time-uniform-smooth-convergence-from-one-time-slice

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#lem:cz-time-uniform-smooth-convergence-from-one-time-slice
uses: []
```

# thm:cz-hamilton-compactness-for-ricci-flows

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-hamilton-compactness-for-ricci-flows
uses: []
```

# thm:cz-gromollmeyer-injectivity-radius-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-gromollmeyer-injectivity-radius-estimate
uses: []
```

# thm:cz-local-injectivity-radius-estimate-from-volume-and-curvature

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-local-injectivity-radius-estimate-from-volume-and-curvature
uses: []
```

# cor:cz-injectivity-radius-from-local-curvature-scale

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#cor:cz-injectivity-radius-from-local-curvature-scale
uses: []
```

# thm:cz-little-loop-lemma

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-little-loop-lemma
uses: []
```

# def:cz-almost-maximum-curvature-points

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#def:cz-almost-maximum-curvature-points
uses: []
```

# def:cz-injectivity-radius-condition-at-almost-maximum-points

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#def:cz-injectivity-radius-condition-at-almost-maximum-points
uses: []
```

# def:cz-singularity-types-for-maximal-ricci-flows

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#def:cz-singularity-types-for-maximal-ricci-flows
uses: []
```

# thm:cz-existence-of-dilation-limit-singularity-models

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-existence-of-dilation-limit-singularity-models
uses: []
```

# cor:cz-restricted-singularity-model-types-under-nonnegative-curvature

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#cor:cz-restricted-singularity-model-types-under-nonnegative-curvature
uses: []
```

# thm:cz-type-ii-models-with-positive-ricci-curvature-are-steady-solitons

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-type-ii-models-with-positive-ricci-curvature-are-steady-solitons
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples#thm:cz-matrix-liyauhamilton-estimate]]'
```

# rem:cz-noncompact-type-ii-models-and-steady-solitons

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#rem:cz-noncompact-type-ii-models-and-steady-solitons
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation#thm:cz-type-ii-models-with-positive-ricci-curvature-are-steady-solitons]]'
```

# thm:cz-kahler-type-ii-models-are-steady-solitons

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-kahler-type-ii-models-are-steady-solitons
uses: []
```

# thm:cz-compact-type-i-limits-are-shrinking-solitons

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-compact-type-i-limits-are-shrinking-solitons
uses: []
```

# lem:cz-scalar-curvature-identities-for-steady-gradient-solitons

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#lem:cz-scalar-curvature-identities-for-steady-gradient-solitons
uses: []
```

# thm:cz-asymptotic-scalar-curvature-of-positively-curved-steady-solitons

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-asymptotic-scalar-curvature-of-positively-curved-steady-solitons
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation#lem:cz-scalar-curvature-identities-for-steady-gradient-solitons]]'
```

# thm:cz-classification-of-two-dimensional-steady-solitons

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ05_SingularityFormation.tex#thm:cz-classification-of-two-dimensional-steady-solitons
uses: []
```
