# chap:cz-three-manifold-ricci-flow

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#chap:cz-three-manifold-ricci-flow
uses: []
```

# thm:cz-three-dimensional-singularity-structure

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-three-dimensional-singularity-structure
uses: []
```

# lem:cz-blowup-backward-parabolic-curvature-control

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-blowup-backward-parabolic-curvature-control
uses: []
```

# thm:cz-almost-euclidean-volume-curvature-control

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-almost-euclidean-volume-curvature-control
uses: []
```

# thm:cz-lower-volume-ratio-curvature-control

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-lower-volume-ratio-curvature-control
uses: []
```

# cor:cz-localized-volume-sectional-curvature-control

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#cor:cz-localized-volume-sectional-curvature-control
uses: []
```

# cor:cz-small-ball-pseudolocal-curvature-control

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#cor:cz-small-ball-pseudolocal-curvature-control
uses: []
```

# def:cz-ricci-flow-with-surgery

```qprint
kind: definition
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#def:cz-ricci-flow-with-surgery
uses: []
```

# lem:cz-cutoff-neck-existence-in-horns

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-cutoff-neck-existence-in-horns
uses: []
```

# prop:cz-asymptotically-cylindrical-standard-solution

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#prop:cz-asymptotically-cylindrical-standard-solution
uses: []
```

# lem:cz-surgery-preserves-hamilton-ivey-pinching

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-surgery-preserves-hamilton-ivey-pinching
uses: []
```

# lem:cz-standard-solution-canonical-neighborhoods

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-standard-solution-canonical-neighborhoods
uses: []
```

# prop:cz-standard-solution-late-time-ancient-model

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#prop:cz-standard-solution-late-time-ancient-model
uses: []
```

# prop:cz-standard-solution-early-time-cap-neck

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#prop:cz-standard-solution-early-time-cap-neck
uses: []
```

# lem:cz-surgery-stability-near-standard-cap

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-surgery-stability-near-standard-cap
uses: []
```

# cor:cz-surgery-cap-curves-large-reduced-length

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#cor:cz-surgery-cap-curves-large-reduced-length
uses: []
```

# prop:cz-canonical-neighborhood-induction-surgery

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#prop:cz-canonical-neighborhood-induction-surgery
uses: []
```

# lem:cz-surgery-noncollapsing-canonical-induction-step

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-surgery-noncollapsing-canonical-induction-step
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#prop:cz-canonical-neighborhood-induction-surgery]]'
```

# thm:cz-ricci-flow-surgery-long-time-existence

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-ricci-flow-surgery-long-time-existence
uses: []
```

# cor:cz-finite-extinction-topological-classification

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#cor:cz-finite-extinction-topological-classification
uses: []
```

# thm:cz-positive-isotropic-curvature-four-manifold-classification

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-positive-isotropic-curvature-four-manifold-classification
uses: []
```

# thm:cz-bounded-time-surgery-curvature-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-bounded-time-surgery-curvature-estimate
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#thm:cz-ricci-flow-surgery-long-time-existence]]'
```

# thm:cz-large-time-surgery-curvature-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-large-time-surgery-curvature-estimate
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#thm:cz-ricci-flow-surgery-long-time-existence]]'
```

# cor:cz-large-time-local-volume-canonical-neighborhoods

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#cor:cz-large-time-local-volume-canonical-neighborhoods
uses: []
```

# rem:cz-large-time-canonical-neighborhood-scope

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#rem:cz-large-time-canonical-neighborhood-scope
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#cor:cz-large-time-local-volume-canonical-neighborhoods]]'
```

# lem:cz-parabolic-blowdown-flatness

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-parabolic-blowdown-flatness
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#thm:cz-ricci-flow-surgery-long-time-existence]]'
```

# lem:cz-large-time-local-curvature-alternatives

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-large-time-local-curvature-alternatives
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#thm:cz-ricci-flow-surgery-long-time-existence]]'
```

# thm:cz-surgery-thick-thin-decomposition

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-surgery-thick-thin-decomposition
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#thm:cz-ricci-flow-surgery-long-time-existence]]'
```

# thm:cz-surgery-long-time-geometry

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-surgery-long-time-geometry
uses: []
```

# thm:cz-thurston-geometrization

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-thurston-geometrization
uses: []
```

# lem:cz-local-ancient-model-alternative

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-local-ancient-model-alternative
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ07_AncientKappaSolutions#prop:cz-neck-radius-lower-bound-at-infinity]]'
```

# lem:cz-standard-solution-spatial-curvature-comparison

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-standard-solution-spatial-curvature-comparison
uses: []
```

# lem:cz-standard-solution-maximal-time-curvature-blowup

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-standard-solution-maximal-time-curvature-blowup
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#lem:cz-standard-solution-spatial-curvature-comparison]]'
```

# lem:cz-surgery-cap-reduced-length-barrier

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-surgery-cap-reduced-length-barrier
uses: []
```

# lem:cz-rescaled-ball-backward-extension

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-rescaled-ball-backward-extension
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#lem:cz-surgery-stability-near-standard-cap]]'
```

# lem:cz-low-curvature-point-backward-extension

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-low-curvature-point-backward-extension
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#lem:cz-rescaled-ball-backward-extension]]'
```

# lem:cz-backward-control-or-capwise-comparability

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-backward-control-or-capwise-comparability
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#lem:cz-rescaled-ball-backward-extension]]'
```

# lem:cz-rescaled-balls-uniform-curvature-backward-existence

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-rescaled-balls-uniform-curvature-backward-existence
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#lem:cz-backward-control-or-capwise-comparability]]'
```

# lem:cz-extended-limit-uniform-spacetime-curvature

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-extended-limit-uniform-spacetime-curvature
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#lem:cz-backward-control-or-capwise-comparability]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#lem:cz-rescaled-balls-uniform-curvature-backward-existence]]'
```

# lem:cz-admissible-minimizer-reduced-length-bound

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#lem:cz-admissible-minimizer-reduced-length-bound
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization#lem:cz-surgery-cap-reduced-length-barrier]]'
```

# prop:cz-perelman-collapsing-graph-manifold-criterion

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#prop:cz-perelman-collapsing-graph-manifold-criterion
uses: []
```

# thm:cz-shioya-yamaguchi-closed-collapsing-graph-manifolds

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ08_ThreeManifoldSurgeryAndGeometrization.tex#thm:cz-shioya-yamaguchi-closed-collapsing-graph-manifolds
uses: []
```
