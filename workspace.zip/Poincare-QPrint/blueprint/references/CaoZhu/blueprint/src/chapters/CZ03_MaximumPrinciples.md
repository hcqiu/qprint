# chap:cz-maximum-principles

```qprint
kind: other
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#chap:cz-maximum-principles
uses: []
```

# lem:cz-proper-exhaustion-with-uniformly-bounded-derivatives

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#lem:cz-proper-exhaustion-with-uniformly-bounded-derivatives
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#thm:cz-global-curvature-derivative-estimates]]'
```

# prop:cz-preservation-of-nonnegative-scalar-curvature

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#prop:cz-preservation-of-nonnegative-scalar-curvature
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples#lem:cz-proper-exhaustion-with-uniformly-bounded-derivatives]]'
```

# lem:cz-tensor-maximum-principle-on-complete-manifolds

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#lem:cz-tensor-maximum-principle-on-complete-manifolds
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples#lem:cz-proper-exhaustion-with-uniformly-bounded-derivatives]]'
```

# prop:cz-preservation-of-nonnegative-curvature-operator

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#prop:cz-preservation-of-nonnegative-curvature-operator
uses: []
```

# prop:cz-preservation-of-holomorphic-bisectional-curvature

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#prop:cz-preservation-of-holomorphic-bisectional-curvature
uses: []
```

# thm:cz-strong-maximum-principle-for-symmetric-bilinear-forms

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-strong-maximum-principle-for-symmetric-bilinear-forms
uses: []
```

# thm:cz-parallel-invariance-of-the-curvature-operator-image

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-parallel-invariance-of-the-curvature-operator-image
uses: []
```

# thm:cz-advanced-maximum-principle-for-time-dependent-tensors

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-advanced-maximum-principle-for-time-dependent-tensors
uses: []
```

# lem:cz-vanishing-from-a-lipschitz-differential-inequality

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#lem:cz-vanishing-from-a-lipschitz-differential-inequality
uses: []
```

# lem:cz-derivative-of-a-fiberwise-supremum

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#lem:cz-derivative-of-a-fiberwise-supremum
uses: []
```

# lem:cz-invariance-criterion-for-closed-convex-sets

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#lem:cz-invariance-criterion-for-closed-convex-sets
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples#lem:cz-derivative-of-a-fiberwise-supremum]]'
- '[[references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples#lem:cz-vanishing-from-a-lipschitz-differential-inequality]]'
```

# thm:cz-maximum-principle-for-closed-fiberwise-convex-sets

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-maximum-principle-for-closed-fiberwise-convex-sets
uses: []
```

# thm:cz-hamiltonivey-curvature-pinching

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-hamiltonivey-curvature-pinching
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples#thm:cz-advanced-maximum-principle-for-time-dependent-tensors]]'
```

# thm:cz-liyau-differential-harnack-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-liyau-differential-harnack-estimate
uses: []
```

# thm:cz-surface-ricci-flow-differential-harnack-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-surface-ricci-flow-differential-harnack-estimate
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples#lem:cz-tensor-maximum-principle-on-complete-manifolds]]'
```

# cor:cz-surface-ricci-flow-integrated-harnack-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#cor:cz-surface-ricci-flow-integrated-harnack-estimate
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples#thm:cz-surface-ricci-flow-differential-harnack-estimate]]'
```

# thm:cz-matrix-liyauhamilton-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-matrix-liyauhamilton-estimate
uses: []
```

# cor:cz-trace-liyauhamilton-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#cor:cz-trace-liyauhamilton-estimate
uses: []
```

# cor:cz-rigidity-in-the-trace-harnack-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#cor:cz-rigidity-in-the-trace-harnack-estimate
uses:
- '[[references/CaoZhu/blueprint/src/chapters/CZ02_EvolutionEquations#thm:cz-local-curvature-derivative-estimates]]'
```

# cor:cz-integrated-scalar-curvature-harnack-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#cor:cz-integrated-scalar-curvature-harnack-estimate
uses: []
```

# cor:cz-scalar-curvature-monotonicity-for-ancient-solutions

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#cor:cz-scalar-curvature-monotonicity-for-ancient-solutions
uses: []
```

# thm:cz-kahlerricci-matrix-harnack-estimate

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#thm:cz-kahlerricci-matrix-harnack-estimate
uses: []
```

# cor:cz-kahlerricci-scalar-and-determinant-estimates

```qprint
kind: theorem
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#cor:cz-kahlerricci-scalar-and-determinant-estimates
uses: []
```

# lem:cz-gradient-estimate-for-conjugate-heat-equations

```qprint
kind: lemma
status: not_started
tex: references/CaoZhu/blueprint/src/chapters/CZ03_MaximumPrinciples.tex#lem:cz-gradient-estimate-for-conjugate-heat-equations
uses: []
```
