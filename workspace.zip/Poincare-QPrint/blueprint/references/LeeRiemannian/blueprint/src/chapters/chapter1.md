# def:rigid-motion

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#def:rigid-motion
uses: []
```

# lem:isometry-extension

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#lem:isometry-extension
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter1#def:rigid-motion]]'
```

# thm:side-side-side

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:side-side-side
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter1#def:rigid-motion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter1#lem:isometry-extension]]'
```

# thm:angle-sum-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:angle-sum-theorem
uses: []
```

# thm:circle-classification

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:circle-classification
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter1#def:rigid-motion]]'
```

# thm:circumference-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:circumference-theorem
uses: []
```

# thm:plane-curve-classification

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:plane-curve-classification
uses: []
```

# thm:total-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:total-curvature
uses: []
```

# thm:uniformization-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:uniformization-theorem
uses: []
```

# thm:gauss-bonnet-theorem-preview

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:gauss-bonnet-theorem-preview
uses: []
```

# thm:characterization-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:characterization-constant-curvature
uses: []
```

# thm:cartan-hadamard-preview

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:cartan-hadamard-preview
uses: []
```

# thm:myers

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter1.tex#thm:myers
uses: []
```
