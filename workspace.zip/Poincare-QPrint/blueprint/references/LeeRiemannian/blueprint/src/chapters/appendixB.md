# prop:multilinear-maps-tensor-isomorphism

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:multilinear-maps-tensor-isomorphism
uses: []
```

# lem:sum-sign-prod-det

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#lem:sum-sign-prod-det
uses: []
```

# lem:cauchy-binet

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#lem:cauchy-binet
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#lem:sum-sign-prod-det]]'
```

# lem:alternating-cauchy-binet

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#lem:alternating-cauchy-binet
uses: []
```

# lem:laplace-expansion-block

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#lem:laplace-expansion-block
uses: []
```

# lem:perm-block-collapse

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#lem:perm-block-collapse
uses: []
```

# lem:perm-extension-count

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#lem:perm-extension-count
uses: []
```

# lem:tensor-characterization-lemma

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#lem:tensor-characterization-lemma
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#prop:multilinear-maps-tensor-isomorphism]]'
```

# prop:tensor-pullback-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:tensor-pullback-properties
uses: []
```

# prop:pullback-computation-coordinates

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:pullback-computation-coordinates
uses:
- '[[#UNRESOLVED:chB:12.28]]'
```

# prop:lie-derivative-tensor-product-rule

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:lie-derivative-tensor-product-rule
uses:
- '[[#UNRESOLVED:chB:12.32]]'
```

# prop:invariant-tensor-characterization

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:invariant-tensor-characterization
uses:
- '[[#UNRESOLVED:chB:12.37]]'
```

# prop:exterior-differentiation-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:exterior-differentiation-properties
uses: []
```

# prop:exterior-derivative-one-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:exterior-derivative-one-form
uses: []
```

# prop:exterior-derivative-naturality

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:exterior-derivative-naturality
uses: []
```

# lem:poincare-lemma

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#lem:poincare-lemma
uses: []
```

# prop:orientation-determined-by-n-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:orientation-determined-by-n-form
uses: []
```

# prop:orientation-of-hypersurface

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:orientation-of-hypersurface
uses: []
```

# prop:induced-orientation-boundary

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:induced-orientation-boundary
uses: []
```

# prop:orientation-covering-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:orientation-covering-theorem
uses: []
```

# cor:simply-connected-orientable

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#cor:simply-connected-orientable
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#cor:coverings-simply-connected]]'
```

# prop:properties-integrals-forms

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#prop:properties-integrals-forms
uses: []
```

# thm:stokes-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#thm:stokes-theorem
uses:
- '[[#UNRESOLVED:ch16:16.11]]'
```

# cor:exact-integral-zero

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#cor:exact-integral-zero
uses:
- '[[#UNRESOLVED:ch16:16.13]]'
```

# exer:prove-multilinear-maps-isomorphism

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#exer:prove-multilinear-maps-isomorphism
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#prop:multilinear-maps-tensor-isomorphism]]'
```

# exer:smooth-tensor-field-criterion

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#exer:smooth-tensor-field-criterion
uses: []
```

# exer:tensor-bundle-smooth-vector-bundle

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#exer:tensor-bundle-smooth-vector-bundle
uses: []
```

# exer:trace-well-defined

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixB.tex#exer:trace-well-defined
uses: []
```
