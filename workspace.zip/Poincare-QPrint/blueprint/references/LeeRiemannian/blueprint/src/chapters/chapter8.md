# prop:second-fundamental-form-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:second-fundamental-form-properties
uses: []
```

# thm:gauss-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#thm:gauss-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prop:second-fundamental-form-properties]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#ex:tangential-connection-submanifold]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:tangential-connection-compatible-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:tangential-connection-symmetric]]'
```

# cor:gauss-formula-along-curve

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#cor:gauss-formula-along-curve
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#thm:gauss-formula]]'
```

# prop:weingarten-equation

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:weingarten-equation
uses: []
```

# thm:gauss-equation

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#thm:gauss-equation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:covariant-derivative-depends-on-curve]]'
```

# prop:normal-connection-well-defined

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:normal-connection-well-defined
uses: []
```

# thm:codazzi-equation

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#thm:codazzi-equation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#thm:gauss-equation]]'
```

# prop:geometric-interpretation-ii

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:geometric-interpretation-ii
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#cor:gauss-formula-along-curve]]'
```

# lem:symmetric-bilinear-form-unit-vectors

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#lem:symmetric-bilinear-form-unit-vectors
uses: []
```

# prop:totally-geodesic-equivalence

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:totally-geodesic-equivalence
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#thm:gauss-formula]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#lem:symmetric-bilinear-form-unit-vectors]]'
```

# thm:fundamental-equations-hypersurface

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#thm:fundamental-equations-hypersurface
uses: []
```

# lem:self-adjoint-eigenvector-extremum

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#lem:self-adjoint-eigenvector-extremum
uses: []
```

# prop:finite-dimensional-spectral-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:finite-dimensional-spectral-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#lem:self-adjoint-eigenvector-extremum]]'
```

# prop:semigeodesic-coordinates-second-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:semigeodesic-coordinates-second-form
uses: []
```

# thm:area-minimizing-zero-mean-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#thm:area-minimizing-zero-mean-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#ex:fermi-coordinates-hypersurface]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:minimizing-geodesic-unit-speed]]'
```

# thm:constant-mean-curvature-isoperimetric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#thm:constant-mean-curvature-isoperimetric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#thm:area-minimizing-zero-mean-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#thm:tubular-neighborhood]]'
```

# prop:osculating-circle

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:osculating-circle
uses: []
```

# prop:second-fundamental-form-coordinate-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:second-fundamental-form-coordinate-formula
uses: []
```

# prop:principal-curvatures-local-shape

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:principal-curvatures-local-shape
uses: []
```

# ex:shape-operators-spheres

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#ex:shape-operators-spheres
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:existence-local-defining-functions]]'
```

# thm:theorema-egregium

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#thm:theorema-egregium
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:curvature-tensor-dim-2]]'
```

# cor:riemann-two-manifold-curvatures

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#cor:riemann-two-manifold-curvatures
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:curvature-tensor-dim-2]]'
```

# prop:sectional-curvature-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:sectional-curvature-formula
uses: []
```

# prop:sectional-curvature-determines-curvature-tensor

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:sectional-curvature-determines-curvature-tensor
uses: []
```

# prop:geometric-interpretation-ricci-scalar-curvatures

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:geometric-interpretation-ricci-scalar-curvatures
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#lem:symmetric-bilinear-form-unit-vectors]]'
```

# lem:frame-homogeneous-constant-sectional-curvature

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#lem:frame-homogeneous-constant-sectional-curvature
uses: []
```

# thm:sectional-curvatures-model-spaces

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#thm:sectional-curvatures-model-spaces
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#ex:shape-operators-spheres]]'
```

# prop:constant-sectional-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:constant-sectional-curvature
uses: []
```

# prop:complex-projective-space-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:complex-projective-space-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:oneill-formula]]'
```

# prob:complex-projective-space-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:complex-projective-space-curvature
uses: []
```

# prop:curvature-operator

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prop:curvature-operator
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prop:complex-projective-space-curvature]]'
```

# prob:curvature-operator

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:curvature-operator
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:complex-projective-space-curvature]]'
```

# exer:codazzi-tensor-characterization

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#exer:codazzi-tensor-characterization
uses: []
```

# exer:connection-in-bundle

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#exer:connection-in-bundle
uses: []
```

# exer:constant-sectional-curvature-rp

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#exer:constant-sectional-curvature-rp
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:real-projective-space-metric]]'
```

# exer:lagrange-multiplier-eigenvector

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#exer:lagrange-multiplier-eigenvector
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:lagrange-multiplier-rule]]'
```

# exer:metric-scaling-sectional-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#exer:metric-scaling-sectional-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#thm:conformal-transformation-curvature]]'
```

# exer:osculating-circle-uniqueness

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#exer:osculating-circle-uniqueness
uses: []
```

# exer:plane-cylinder-isometric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#exer:plane-cylinder-isometric
uses: []
```

# exer:prove-normal-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#exer:prove-normal-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prop:normal-connection-well-defined]]'
```

# prob:associated-quadratic-form

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:associated-quadratic-form
uses: []
```

# prob:berger-metric-su2

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:berger-metric-su2
uses: []
```

# prob:catenoid-boundary-minimal

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:catenoid-boundary-minimal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:catenoid-minimal-surface]]'
```

# prob:catenoid-minimal-surface

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:catenoid-minimal-surface
uses: []
```

# prob:convex-hypersurface

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:convex-hypersurface
uses: []
```

# prob:curvature-tensors-constant-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:curvature-tensors-constant-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prop:constant-sectional-curvature]]'
```

# prob:einstein-sectional-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:einstein-sectional-curvature
uses: []
```

# prob:fubini-study-not-conformal-flat

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:fubini-study-not-conformal-flat
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:complex-projective-space-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:weyl-tensor-4d]]'
```

# prob:gauss-map

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:gauss-map
uses: []
```

# prob:geodesic-curvature-non-unit-speed-curve

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:geodesic-curvature-non-unit-speed-curve
uses: []
```

# prob:graph-submanifold-shape

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:graph-submanifold-shape
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:metrics-in-graph-coordinates]]'
```

# prob:homogeneous-isotropic-3-manifold

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:homogeneous-isotropic-3-manifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:complex-projective-space-curvature]]'
```

# prob:hyperbolic-constant-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:hyperbolic-constant-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#thm:sectional-curvatures-model-spaces]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#thm:gauss-equation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:lorentz-hypersurface-formulas]]'
```

# prob:hypersurface-defining-function

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:hypersurface-defining-function
uses: []
```

# prob:k-point-homogeneous-ch8

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:k-point-homogeneous-ch8
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prob:k-point-homogeneous]]'
```

# prob:k-points-hyperbolic-geodesic

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:k-points-hyperbolic-geodesic
uses: []
```

# prob:lie-group-bi-invariant-metric-ch8

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:lie-group-bi-invariant-metric-ch8
uses: []
```

# prob:lie-group-fixed-point-geodesic

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:lie-group-fixed-point-geodesic
uses: []
```

# prob:lie-group-isometric-action-dimension

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:lie-group-isometric-action-dimension
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:lie-group-dimension-bound]]'
```

# prob:lorentz-einstein-field-equation

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:lorentz-einstein-field-equation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:lorentz-hypersurface-formulas]]'
```

# prob:lorentz-hypersurface-formulas

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:lorentz-hypersurface-formulas
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#thm:fundamental-equations-hypersurface]]'
```

# prob:paraboloid-isotropic-one-point

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:paraboloid-isotropic-one-point
uses: []
```

# prob:product-metric-submanifolds

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:product-metric-submanifolds
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#exer:prove-lemma-2-11]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prob:product-metric-curvature]]'
```

# prob:ricci-curvature-without-basis

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:ricci-curvature-without-basis
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:associated-quadratic-form]]'
```

# prob:ricci-tensor-hypersurface

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:ricci-tensor-hypersurface
uses: []
```

# prob:riemannian-immersion-bounded-sectional-curvatures

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:riemannian-immersion-bounded-sectional-curvatures
uses: []
```

# prob:surface-affine-plane-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:surface-affine-plane-curvature
uses: []
```

# prob:surface-revolution-constant-gaussian-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:surface-revolution-constant-gaussian-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:local-uniqueness-constant-curvature]]'
```

# prob:surface-revolution-shape-principal-curvatures

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:surface-revolution-shape-principal-curvatures
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:surfaces-of-revolution]]'
```

# prob:weyl-tensor-4d

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:weyl-tensor-4d
uses: []
```

# prob:weyl-tensor-product-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter8.tex#prob:weyl-tensor-product-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prob:product-metric-curvature]]'
```
