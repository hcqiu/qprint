# eq:4.1

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#eq:4.1
uses: []
```

# eq:4.2

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#eq:4.2
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:normal-bundle]]'
```

# def:connection

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#def:connection
uses: []
```

# lem:connection-is-local-operator

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#lem:connection-is-local-operator
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#def:connection]]'
```

# prop:connection-restriction

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:connection-restriction
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#lem:connection-is-local-operator]]'
```

# prop:covariant-deriv-dependence-at-point

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:covariant-deriv-dependence-at-point
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#lem:connection-is-local-operator]]'
```

# prop:connection-coefficients-frame

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:connection-coefficients-frame
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#def:connection]]'
```

# prop:transformation-law-connection-coefficients

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:transformation-law-connection-coefficients
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#def:connection]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:connection-coefficients-frame]]'
```

# ex:euclidean-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#ex:euclidean-connection
uses: []
```

# ex:tangential-connection-submanifold

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#ex:tangential-connection-submanifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:normal-bundle]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#ex:euclidean-connection]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:extension-smooth-function]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:embedded-submanifold-covariant-derivative]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:adapted-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#exer:extension-smooth-function]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prob:embedded-submanifold-covariant-derivative]]'
```

# lem:connections-from-connection-coefficients

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#lem:connections-from-connection-coefficients
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:connection-coefficients-frame]]'
```

# prop:tangent-bundle-admits-connection

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:tangent-bundle-admits-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#lem:connections-from-connection-coefficients]]'
```

# prop:difference-tensor

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:difference-tensor
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#def:connection]]'
```

# thm:connections-affine-space

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#thm:connections-affine-space
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:difference-tensor]]'
```

# prop:connection-on-tensor-bundles

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:connection-on-tensor-bundles
uses: []
```

# eq:4.12

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#eq:4.12
uses: []
```

# eq:4.13

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#eq:4.13
uses: []
```

# prop:covariant-derivative-components

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:covariant-derivative-components
uses: []
```

# prop:total-covariant-derivative

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:total-covariant-derivative
uses: []
```

# prop:total-covariant-derivative-components

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:total-covariant-derivative-components
uses: []
```

# prop:second-covariant-derivative-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:second-covariant-derivative-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:connection-on-tensor-bundles]]'
```

# ex:covariant-hessian

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#ex:covariant-hessian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:second-covariant-derivative-formula]]'
```

# ex:figure-eight-curve

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#ex:figure-eight-curve
uses: []
```

# thm:covariant-derivative-along-curve

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#thm:covariant-derivative-along-curve
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#ex:figure-eight-curve]]'
```

# prop:covariant-derivative-depends-on-curve

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:covariant-derivative-depends-on-curve
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:covariant-deriv-dependence-at-point]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:covariant-derivative-along-curve]]'
```

# def:geodesic

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#def:geodesic
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:covariant-derivative-along-curve]]'
```

# thm:geodesic-existence-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#thm:geodesic-existence-uniqueness
uses: []
```

# cor:existence-of-maximal-geodesic

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#cor:existence-of-maximal-geodesic
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:geodesic-existence-uniqueness]]'
```

# thm:linear-ode-existence-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#thm:linear-ode-existence-uniqueness
uses: []
```

# thm:existence-uniqueness-parallel-transport

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#thm:existence-uniqueness-parallel-transport
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:covariant-derivative-along-curve]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:linear-ode-existence-uniqueness]]'
```

# cor:parallel-transport-piecewise-smooth-curves

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#cor:parallel-transport-piecewise-smooth-curves
uses: []
```

# thm:parallel-transport-determines-covariant-diff

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#thm:parallel-transport-determines-covariant-diff
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#cor:parallel-transport-piecewise-smooth-curves]]'
```

# cor:parallel-transport-determines-connection

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#cor:parallel-transport-determines-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:parallel-transport-determines-covariant-diff]]'
```

# prop:parallel-field-characterization

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:parallel-field-characterization
uses: []
```

# lem:pullback-connection

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#lem:pullback-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:pushforward-vector-field]]'
```

# prop:pullback-connection-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:pullback-connection-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#lem:pullback-connection]]'
```

# prop:embedded-submanifold-covariant-derivative

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:embedded-submanifold-covariant-derivative
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:tangent-space-submanifold]]'
```

# prob:embedded-submanifold-covariant-derivative

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:embedded-submanifold-covariant-derivative
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:tangent-space-submanifold]]'
```

# prop:torsion-tensor

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:torsion-tensor
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#ex:covariant-hessian]]'
```

# prop:connections-difference-tensor

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:connections-difference-tensor
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:torsion-tensor]]'
```

# prop:parallel-reparametrization

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prop:parallel-reparametrization
uses: []
```

# exer:complete-proof-lemma-4.10

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#exer:complete-proof-lemma-4.10
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#lem:connections-from-connection-coefficients]]'
```

# exer:connection-restriction-is-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#exer:connection-restriction-is-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:connection-restriction]]'
```

# exer:covariant-derivative-properties

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#exer:covariant-derivative-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:covariant-derivative-along-curve]]'
```

# exer:euclidean-geodesics

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#exer:euclidean-geodesics
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:connection-restriction]]'
```

# exer:lemma-4-1-comparison

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#exer:lemma-4-1-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#lem:connection-is-local-operator]]'
```

# exer:parallel-vector-field-euclidean-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#exer:parallel-vector-field-euclidean-connection
uses: []
```

# exer:prove-proposition-4-18

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#exer:prove-proposition-4-18
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:total-covariant-derivative-components]]'
```

# exer:tensor-product-covariant-derivative

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#exer:tensor-product-covariant-derivative
uses: []
```

# prob:characterizing-connections

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:characterizing-connections
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:connections-affine-space]]'
```

# prob:connection-1forms-cartan

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:connection-1forms-cartan
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prob:torsion-tensor]]'
```

# prob:connections-difference-tensor

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:connections-difference-tensor
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prob:torsion-tensor]]'
```

# prob:figure-eight-immersion

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:figure-eight-immersion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#ex:figure-eight-curve]]'
```

# prob:lie-derivative-not-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:lie-derivative-not-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:lie-derivative-equals-bracket]]'
```

# prob:lie-group-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:lie-group-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prob:torsion-tensor]]'
```

# prob:parallel-reparametrization

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:parallel-reparametrization
uses: []
```

# prob:parallel-tensor-fields

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:parallel-tensor-fields
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:parallel-field-characterization]]'
```

# prob:pullback-connections

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:pullback-connections
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:pullback-connection-properties]]'
```

# prob:tensor-field-formulas

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:tensor-field-formulas
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:covariant-derivative-components]]'
```

# prob:torsion-tensor

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:torsion-tensor
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#ex:covariant-hessian]]'
```

# prob:transformation-law-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:transformation-law-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:transformation-law-connection-coefficients]]'
```

# prob:vector-field-extendibility

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter4.tex#prob:vector-field-extendibility
uses: []
```
