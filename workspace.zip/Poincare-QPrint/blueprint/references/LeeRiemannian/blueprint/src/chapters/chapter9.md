# thm:rotation-index-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#thm:rotation-index-theorem
uses: []
```

# lem:rotation-index-plus-one

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#lem:rotation-index-plus-one
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:rotation-index-theorem]]'
```

# thm:gauss-bonnet-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#thm:gauss-bonnet-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:arc-length-integral]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:rotation-index-theorem]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#lem:rotation-index-plus-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:arc-length-integral]]'
```

# eq:covariant-frame-derivatives

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#eq:covariant-frame-derivatives
uses: []
```

# cor:angle-sum-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#cor:angle-sum-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
```

# cor:circumference-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#cor:circumference-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
```

# cor:total-curvature-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#cor:total-curvature-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
```

# thm:gauss-bonnet-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#thm:gauss-bonnet-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
```

# cor:gaussian-curvature-and-topology

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#cor:gaussian-curvature-and-topology
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-theorem]]'
```

# cor:curvature-determines-cover

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#cor:curvature-determines-cover
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#cor:gaussian-curvature-and-topology]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:compact-covering-finite-sheeted]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:fiber-cardinality-fundamental-group]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#exer:A.62]]'
```

# eq:chern-gauss-bonnet-4d

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#eq:chern-gauss-bonnet-4d
uses: []
```

# prob:angle-excess-formula

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:angle-excess-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
```

# prob:compact-lie-groups-isomorphic

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:compact-lie-groups-isomorphic
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:lie-group-bi-invariant-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-theorem]]'
```

# prob:cylinder-metric-gaussian-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:cylinder-metric-gaussian-curvature
uses: []
```

# prob:einstein-manifold-euler-characteristic

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:einstein-manifold-euler-characteristic
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#eq:chern-gauss-bonnet-4d]]'
```

# prob:embedded-submanifold-positive-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:embedded-submanifold-positive-curvature
uses: []
```

# prob:gauss-bonnet-sphere

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:gauss-bonnet-sphere
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
```

# prob:gauss-bonnet-torus

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:gauss-bonnet-torus
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-theorem]]'
```

# prob:gauss-bonnet-with-boundary

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:gauss-bonnet-with-boundary
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-theorem]]'
```

# prob:geodesic-polygons-negative-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:geodesic-polygons-negative-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
```

# prob:ideal-triangles-hyperbolic

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:ideal-triangles-hyperbolic
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter9#thm:gauss-bonnet-formula]]'
```

# prob:plane-curve-classification

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:plane-curve-classification
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter1#thm:plane-curve-classification]]'
```

# prob:similar-triangles-congruent

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:similar-triangles-congruent
uses: []
```

# prob:triangulation-2manifold

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter9.tex#prob:triangulation-2manifold
uses: []
```
