# lem:hessian-operator-properties

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#lem:hessian-operator-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prop:jacobi-field-hessian-equation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#lem:symmetric-bilinear-form-unit-vectors]]'
```

# prop:jacobi-field-hessian-equation

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prop:jacobi-field-hessian-equation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:jacobi-fields-vanishing-at-point]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:normal-jacobi-equivalent-conditions]]'
```

# prop:hessian-radial-distance-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prop:hessian-radial-distance-constant-curvature
uses: []
```

# thm:riccati-equation

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:riccati-equation
uses: []
```

# thm:riccati-comparison-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:riccati-comparison-theorem
uses: []
```

# thm:matrix-riccati-comparison

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:matrix-riccati-comparison
uses: []
```

# thm:hessian-comparison

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:hessian-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prop:hessian-radial-distance-constant-curvature]]'
```

# cor:principal-curvature-comparison

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#cor:principal-curvature-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:hessian-comparison]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prop:hessian-radial-distance-constant-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#lem:hessian-operator-properties]]'
```

# thm:jacobi-field-comparison

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:jacobi-field-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:jacobi-field-decomposition]]'
```

# thm:metric-comparison

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:metric-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:gauss-lemma]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:jacobi-field-tangent-vectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:jacobi-fields-vanishing-at-point]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:jacobi-constant-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:jacobi-field-comparison]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:polar-decomposition-integrals]]'
```

# thm:laplacian-comparison-1

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:laplacian-comparison-1
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:hessian-comparison]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prop:hessian-radial-distance-constant-curvature]]'
```

# thm:conjugate-point-comparison-I

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:conjugate-point-comparison-I
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:jacobi-field-comparison]]'
```

# lem:riemannian-volume-laplacian

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#lem:riemannian-volume-laplacian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:gradient-radial-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:coordinate-representations-divergence-laplacian]]'
```

# thm:gunther-volume-comparison

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:gunther-volume-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:laplacian-comparison-1]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#lem:riemannian-volume-laplacian]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:polar-decomposition-integrals]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:hessian-comparison]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prop:hessian-radial-distance-constant-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:bishop-gromov-volume-comparison]]'
```

# thm:laplacian-comparison-ii

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:laplacian-comparison-ii
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:laplacian-comparison-1]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:jacobi-field-decomposition]]'
```

# thm:conjugate-points-ricci-bounded

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:conjugate-points-ricci-bounded
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:laplacian-comparison-ii]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#lem:riemannian-volume-laplacian]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:jacobi-field-comparison]]'
```

# cor:injectivity-radius-ricci-bounded

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#cor:injectivity-radius-ricci-bounded
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:conjugate-points-ricci-bounded]]'
```

# cor:diameter-ricci-bounded

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#cor:diameter-ricci-bounded
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:conjugate-points-ricci-bounded]]'
```

# thm:bishop-gromov-volume-comparison

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#thm:bishop-gromov-volume-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:chengs-maximal-diameter]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:gunther-volume-comparison]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:laplacian-comparison-ii]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:cut-locus-properties]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:polar-decomposition-integrals]]'
```

# cor:ricci-volume-comparison

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#cor:ricci-volume-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:bishop-gromov-volume-comparison]]'
```

# prob:focal-points-hypersurface

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prob:focal-points-hypersurface
uses: []
```

# prob:focal-points-hypersurface-ii

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prob:focal-points-hypersurface-ii
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prob:transverse-jacobi-comparison]]'
```

# prob:hessian-polar-coordinates

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prob:hessian-polar-coordinates
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:semigeodesic-metric-christoffel]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#ex:polar-normal-coordinates]]'
```

# prob:injectivity-radius-comparison

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prob:injectivity-radius-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:distance-cut-locus]]'
```

# prob:jacobi-field-submanifold

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prob:jacobi-field-submanifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prop:jacobi-field-hessian-equation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:fermi-coordinates-radial-function]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:transverse-jacobi-field]]'
```

# prob:riccati-equation

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prob:riccati-equation
uses: []
```

# prob:transverse-jacobi-comparison

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter11.tex#prob:transverse-jacobi-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:jacobi-field-comparison]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prob:riccati-equation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#prob:jacobi-field-submanifold]]'
```
