# prop:topological-manifolds-locally-path-connected-compact

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:topological-manifolds-locally-path-connected-compact
uses: []
```

# prop:topological-manifolds-paracompact

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:topological-manifolds-paracompact
uses: []
```

# prop:continuous-open-closed-maps

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:continuous-open-closed-maps
uses: []
```

# lem:closed-map-lemma

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:closed-map-lemma
uses: []
```

# prop:proper-continuous-maps-closed

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:proper-continuous-maps-closed
uses: []
```

# prop:induced-homomorphisms

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:induced-homomorphisms
uses:
- '[[#UNRESOLVED:chB:7.24]]'
- '[[#UNRESOLVED:chB:7.26]]'
```

# prop:homotopy-invariance-fundamental-group

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:homotopy-invariance-fundamental-group
uses:
- '[[#UNRESOLVED:chB:7.40]]'
```

# prop:countable-basis-regular-coordinate-balls

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:countable-basis-regular-coordinate-balls
uses: []
```

# prop:existence-partitions-unity

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:existence-partitions-unity
uses: []
```

# prop:existence-smooth-bump-functions

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:existence-smooth-bump-functions
uses: []
```

# lem:vector-field-extension-point

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:vector-field-extension-point
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:existence-partitions-unity]]'
```

# thm:inverse-function-theorem-manifolds

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:inverse-function-theorem-manifolds
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:local-diffeomorphism-from-invertible-differential]]'
```

# lem:invertible-operators-open

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:invertible-operators-open
uses: []
```

# lem:smooth-local-inverse-on-open

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:smooth-local-inverse-on-open
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:invertible-operators-open]]'
```

# lem:local-diffeomorphism-from-invertible-differential

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:local-diffeomorphism-from-invertible-differential
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:smooth-local-inverse-on-open]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:invertible-operators-open]]'
```

# thm:rank-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:rank-theorem
uses: []
```

# thm:local-embedding-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:local-embedding-theorem
uses: []
```

# thm:local-section-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:local-section-theorem
uses: []
```

# lem:surjection-splits

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:surjection-splits
uses: []
```

# prop:local-section-euclidean

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:local-section-euclidean
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:surjection-splits]]'
```

# prop:slice-chart-euclidean

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:slice-chart-euclidean
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:surjection-splits]]'
```

# prop:local-section-manifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:local-section-manifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:local-section-euclidean]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:inverse-function-theorem-manifolds]]'
```

# prop:properties-of-submersions

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:properties-of-submersions
uses: []
```

# prop:uniqueness-smooth-quotients

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:uniqueness-smooth-quotients
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:linear-ode-existence-uniqueness]]'
```

# thm:global-rank-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:global-rank-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:connections-affine-space]]'
```

# prop:properly-embedded-closed

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:properly-embedded-closed
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:proper-continuous-maps-closed]]'
```

# prop:slice-coordinates

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:slice-coordinates
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:rank-theorem]]'
```

# prop:extension-smooth-function

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:extension-smooth-function
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:local-embedding-theorem]]'
```

# exer:extension-smooth-function

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:extension-smooth-function
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:local-embedding-theorem]]'
```

# thm:constant-rank-level-set

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:constant-rank-level-set
uses: []
```

# cor:submersion-level-set

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#cor:submersion-level-set
uses: []
```

# cor:regular-level-set

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#cor:regular-level-set
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:slice-chart-euclidean]]'
```

# lem:straighten-scalar-affine

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:straighten-scalar-affine
uses: []
```

# lem:adapted-chart-scalar-affine

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:adapted-chart-scalar-affine
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:straighten-scalar-affine]]'
```

# def:level-slice-chart

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#def:level-slice-chart
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:adapted-chart-scalar-affine]]'
```

# prop:regular-level-set-hypersurface-codim-one

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:regular-level-set-hypersurface-codim-one
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#def:level-slice-chart]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:adapted-chart-scalar-affine]]'
```

# prop:regular-level-set-inclusion-smooth

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:regular-level-set-inclusion-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-hypersurface-codim-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#def:level-slice-chart]]'
```

# prop:regular-level-set-tangent-kernel

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:regular-level-set-tangent-kernel
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-inclusion-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-hypersurface-codim-one]]'
```

# prop:existence-local-defining-functions

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:existence-local-defining-functions
uses: []
```

# prop:tangent-space-submanifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:tangent-space-submanifold
uses: []
```

# prop:lagrange-multiplier-rule

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:lagrange-multiplier-rule
uses: []
```

# prop:double-manifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:double-manifold
uses: []
```

# lem:vector-bundle-chart-lemma

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:vector-bundle-chart-lemma
uses: []
```

# lem:local-frame-criterion-for-smoothness

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:local-frame-criterion-for-smoothness
uses: []
```

# lem:local-frame-criterion-for-subbundles

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:local-frame-criterion-for-subbundles
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:vector-bundle-chart-lemma]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
```

# rem:subbundle-criterion-metric

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#rem:subbundle-criterion-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:local-frame-criterion-for-subbundles]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:vector-bundle-chart-lemma]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
```

# lem:pushforward-vector-field

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:pushforward-vector-field
uses: []
```

# lem:derivation-characterization

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:derivation-characterization
uses: []
```

# prop:lie-bracket-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:lie-bracket-properties
uses: []
```

# prop:naturality-of-lie-brackets

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:naturality-of-lie-brackets
uses:
- '[[#UNRESOLVED:ch8:30]]'
- '[[#UNRESOLVED:ch8:31]]'
```

# cor:brackets-vector-fields-tangent-to-submanifolds

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#cor:brackets-vector-fields-tangent-to-submanifolds
uses:
- '[[#UNRESOLVED:ch8:32]]'
```

# thm:fundamental-theorem-on-flows

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:fundamental-theorem-on-flows
uses: []
```

# lem:escape-lemma

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#lem:escape-lemma
uses: []
```

# prop:canonical-form-vector-field

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:canonical-form-vector-field
uses: []
```

# prop:lie-derivative-equals-bracket

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:lie-derivative-equals-bracket
uses: []
```

# prop:invariant-vector-field

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:invariant-vector-field
uses: []
```

# prop:canonical-commuting-fields

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:canonical-commuting-fields
uses: []
```

# prop:elementary-covering-maps

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:elementary-covering-maps
uses: []
```

# prop:covering-proper-finite-sheeted

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:covering-proper-finite-sheeted
uses: []
```

# ex:covering-n-torus

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#ex:covering-n-torus
uses: []
```

# prop:lifts-smooth-maps-smooth

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:lifts-smooth-maps-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:local-section-theorem]]'
```

# prop:lifting-properties-covering

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:lifting-properties-covering
uses: []
```

# thm:injectivity-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:injectivity-theorem
uses: []
```

# thm:lifting-criterion

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#thm:lifting-criterion
uses: []
```

# cor:lifting-maps-simply-connected

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#cor:lifting-maps-simply-connected
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:lifting-criterion]]'
```

# cor:covering-map-homeomorphism

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#cor:covering-map-homeomorphism
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:lifting-criterion]]'
```

# cor:coverings-simply-connected

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#cor:coverings-simply-connected
uses: []
```

# prop:universal-covering-manifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:universal-covering-manifold
uses: []
```

# prop:fiber-cardinality-fundamental-group

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:fiber-cardinality-fundamental-group
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:universal-covering-manifold]]'
```

# prop:compact-covering-finite-sheeted

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#prop:compact-covering-finite-sheeted
uses: []
```

# exer:A.62

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:A.62
uses: []
```

# exer:A.44

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:A.44
uses: []
```

# exer:differential-well-defined-functorial

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:differential-well-defined-functorial
uses: []
```

# exer:maximal-smooth-atlas

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:maximal-smooth-atlas
uses: []
```

# exer:path-homotopy-simply-connected

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:path-homotopy-simply-connected
uses: []
```

# exer:prove-lagrange-multiplier

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:prove-lagrange-multiplier
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:lagrange-multiplier-rule]]'
```

# exer:prove-prop-a50

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:prove-prop-a50
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:covering-proper-finite-sheeted]]'
```

# exer:smooth-section-extension

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:smooth-section-extension
uses: []
```

# exer:tangent-vector-field-on-submanifold

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixA.tex#exer:tangent-vector-field-on-submanifold
uses: []
```
