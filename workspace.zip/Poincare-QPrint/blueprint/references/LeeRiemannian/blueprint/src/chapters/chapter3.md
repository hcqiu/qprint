# prop:frame-homogeneous-manifolds

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:frame-homogeneous-manifolds
uses: []
```

# prop:frame-homogeneous-sphere

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:frame-homogeneous-sphere
uses: []
```

# prop:stereographic-conformal-diffeomorphism

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:stereographic-conformal-diffeomorphism
uses: []
```

# cor:sphere-round-metric-locally-conformally-flat

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#cor:sphere-round-metric-locally-conformally-flat
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:stereographic-conformal-diffeomorphism]]'
```

# thm:hyperbolic-space-models

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#thm:hyperbolic-space-models
uses: []
```

# eq:3.13a

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#eq:3.13a
uses: []
```

# eq:3.13b

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#eq:3.13b
uses: []
```

# cor:hyperbolic-locally-conformally-flat

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#cor:hyperbolic-locally-conformally-flat
uses: []
```

# prop:lorentz-group-transitive

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:lorentz-group-transitive
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:frame-homogeneous-sphere]]'
```

# lem:left-invariant-metrics-lie-group

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#lem:left-invariant-metrics-lie-group
uses: []
```

# prop:bi-invariant-metric-adjoint

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:bi-invariant-metric-adjoint
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#lem:left-invariant-metrics-lie-group]]'
```

# lem:invariant-inner-product-compact

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#lem:invariant-inner-product-compact
uses: []
```

# thm:existence-bi-invariant-metrics

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#thm:existence-bi-invariant-metrics
uses: []
```

# cor:compact-lie-group-bi-invariant-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#cor:compact-lie-group-bi-invariant-metric
uses: []
```

# ex:invariant-metrics-lie-groups

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#ex:invariant-metrics-lie-groups
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:n-torus-riemannian-submanifold]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#ex:adjoint-representations-lie-groups]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:berger-sphere]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:orthogonal-group-bi-invariant-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#thm:hyperbolic-space-models]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:berger-sphere]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:orthogonal-group-bi-invariant-metric]]'
```

# thm:existence-invariant-metrics-homogeneous-spaces

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#thm:existence-invariant-metrics-homogeneous-spaces
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#lem:invariant-inner-product-compact]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#thm:equivariant-rank-theorem]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:local-section-theorem]]'
```

# cor:invariant-metric-compact-isotropy

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#cor:invariant-metric-compact-isotropy
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#thm:existence-invariant-metrics-homogeneous-spaces]]'
```

# prop:covering-locally-homogeneous

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:covering-locally-homogeneous
uses: []
```

# thm:uniformization-compact-surfaces

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#thm:uniformization-compact-surfaces
uses: []
```

# lem:homogeneous-point-reflection-symmetric

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#lem:homogeneous-point-reflection-symmetric
uses: []
```

# ex:riemannian-symmetric-spaces

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#ex:riemannian-symmetric-spaces
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#lem:homogeneous-point-reflection-symmetric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:fubini-study-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:grassmann-stiefel-manifolds]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:fubini-study-metric-homogeneous]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:grassmannian-metric-homogeneous]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:grassmann-stiefel-manifolds]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:fubini-study-metric-homogeneous]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:grassmannian-metric-homogeneous]]'
```

# thm:pseudo-riemannian-signature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#thm:pseudo-riemannian-signature
uses: []
```

# thm:frame-homogeneous-pseudo-riemannian

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#thm:frame-homogeneous-pseudo-riemannian
uses: []
```

# prop:rp-n-frame-homogeneous

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:rp-n-frame-homogeneous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:real-projective-space-metric]]'
```

# prob:rp-n-frame-homogeneous

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:rp-n-frame-homogeneous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:real-projective-space-metric]]'
```

# prop:berger-sphere

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:berger-sphere
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#ex:invariant-metrics-lie-groups]]'
```

# prob:berger-sphere

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:berger-sphere
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#ex:invariant-metrics-lie-groups]]'
```

# prop:orthogonal-group-bi-invariant-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:orthogonal-group-bi-invariant-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#ex:invariant-metrics-lie-groups]]'
```

# prob:orthogonal-group-bi-invariant-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:orthogonal-group-bi-invariant-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#ex:invariant-metrics-lie-groups]]'
```

# prop:fubini-study-metric-homogeneous

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:fubini-study-metric-homogeneous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:fubini-study-metric]]'
```

# prob:fubini-study-metric-homogeneous

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:fubini-study-metric-homogeneous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:fubini-study-metric]]'
```

# prop:grassmannian-metric-homogeneous

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prop:grassmannian-metric-homogeneous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:grassmann-stiefel-manifolds]]'
```

# prob:grassmannian-metric-homogeneous

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:grassmannian-metric-homogeneous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:grassmann-stiefel-manifolds]]'
```

# exer:conformal-volume-forms

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#exer:conformal-volume-forms
uses: []
```

# exer:conformality-equivalence-relation

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#exer:conformality-equivalence-relation
uses: []
```

# exer:invariant-metrics-bijection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#exer:invariant-metrics-bijection
uses: []
```

# exer:prove-locally-homogeneous-covering

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#exer:prove-locally-homogeneous-covering
uses: []
```

# exer:prove-preceding-lemma

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#exer:prove-preceding-lemma
uses: []
```

# prob:compact-lie-group-volume-form-bi-invariant

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:compact-lie-group-volume-form-bi-invariant
uses: []
```

# prob:conformal-metrics

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:conformal-metrics
uses: []
```

# prob:diffeomorphism-pseudohyperbolic-pseudosphere

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:diffeomorphism-pseudohyperbolic-pseudosphere
uses: []
```

# prob:frame-homogeneity-pseudo-spaces

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:frame-homogeneity-pseudo-spaces
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#thm:frame-homogeneous-pseudo-riemannian]]'
```

# prob:heisenberg-group-metrics

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:heisenberg-group-metrics
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#ex:invariant-metrics-lie-groups]]'
```

# prob:homogeneous-isotropic-riemannian

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:homogeneous-isotropic-riemannian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:frame-homogeneous-manifolds]]'
```

# prob:hyperbolic-space-metrics

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:hyperbolic-space-metrics
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#ex:invariant-metrics-lie-groups]]'
```

# prob:isometric-action-e-n

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:isometric-action-e-n
uses: []
```

# prob:klein-bottle-flat-covering

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:klein-bottle-flat-covering
uses: []
```

# prob:lie-group-adjoint-representation

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:lie-group-adjoint-representation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#thm:existence-bi-invariant-metrics]]'
```

# prob:minkowski-hyperboloid

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:minkowski-hyperboloid
uses: []
```

# prob:no-riemannian-metric-invariant-lorentz

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:no-riemannian-metric-invariant-lorentz
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:minkowski-hyperboloid]]'
```

# prob:poincare-disk

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:poincare-disk
uses: []
```

# prob:pseudospheres-pseudo-riemannian

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:pseudospheres-pseudo-riemannian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#thm:pseudo-riemannian-signature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#thm:hyperbolic-space-models]]'
```

# prob:riemannian-quotients-conjugate-subgroups

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:riemannian-quotients-conjugate-subgroups
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-quotient-metric]]'
```

# prob:sl2r-upper-half-plane

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:sl2r-upper-half-plane
uses: []
```

# prob:sol-group-metrics

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:sol-group-metrics
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:heisenberg-group-metrics]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#ex:invariant-metrics-lie-groups]]'
```

# prob:sphere-hyperbolic-scaling

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:sphere-hyperbolic-scaling
uses: []
```

# prob:theorem-3-7-proof

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:theorem-3-7-proof
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#thm:hyperbolic-space-models]]'
```

# prob:universal-anti-de-sitter

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter3.tex#prob:universal-anti-de-sitter
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:diffeomorphism-pseudohyperbolic-pseudosphere]]'
```
