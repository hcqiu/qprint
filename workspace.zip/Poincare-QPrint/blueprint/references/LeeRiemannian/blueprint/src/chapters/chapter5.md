# prop:tangential-covariant-derivative-projection

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:tangential-covariant-derivative-projection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:adapted-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:connection-on-tensor-bundles]]'
```

# cor:geodesic-submanifold-acceleration

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#cor:geodesic-submanifold-acceleration
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#ex:euclidean-connection]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:tangential-covariant-derivative-projection]]'
```

# prop:geodesic-pseudo-euclidean-submanifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:geodesic-pseudo-euclidean-submanifold
uses: []
```

# prop:characterizations-of-metric-connections

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:characterizations-of-metric-connections
uses: []
```

# cor:metric-connection-norm-geodesic

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#cor:metric-connection-norm-geodesic
uses: []
```

# prop:tangential-connection-compatible-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:tangential-connection-compatible-metric
uses: []
```

# prop:tangential-connection-symmetric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:tangential-connection-symmetric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:naturality-of-lie-brackets]]'
```

# thm:fundamental-theorem-riemannian-geometry

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#thm:fundamental-theorem-riemannian-geometry
uses: []
```

# cor:formulas-levi-civita-connection

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#cor:formulas-levi-civita-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:torsion-tensor]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:characterizations-of-metric-connections]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prob:torsion-tensor]]'
```

# prop:levi-civita-on-euclidean-and-submanifolds

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:levi-civita-on-euclidean-and-submanifolds
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:tangential-connection-compatible-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:tangential-connection-symmetric]]'
```

# prop:naturality-levi-civita

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:naturality-levi-civita
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#lem:pullback-connection]]'
```

# cor:naturality-geodesics

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#cor:naturality-geodesics
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:pullback-connection-properties]]'
```

# prop:levi-civita-tensor-compatibility

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:levi-civita-tensor-compatibility
uses: []
```

# prop:riemannian-volume-form-parallel

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:riemannian-volume-form-parallel
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:tangent-bundle-admits-connection]]'
```

# prop:musical-isomorphisms-commute

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:musical-isomorphisms-commute
uses: []
```

# lem:rescaling-lemma

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#lem:rescaling-lemma
uses: []
```

# prop:exponential-map-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:exponential-map-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:lie-group-bi-invariant-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:geodesic-existence-uniqueness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:lie-group-bi-invariant-metric]]'
```

# prop:naturality-exponential-map

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:naturality-exponential-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#cor:naturality-geodesics]]'
```

# prop:local-isometries-completely-determined

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:local-isometries-completely-determined
uses: []
```

# prop:uniqueness-normal-coordinates

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:uniqueness-normal-coordinates
uses: []
```

# prop:properties-normal-coordinates

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:properties-normal-coordinates
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:uniqueness-normal-coordinates]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:exponential-map-properties]]'
```

# thm:tubular-neighborhood

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#thm:tubular-neighborhood
uses: []
```

# prop:fermi-coordinates-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:fermi-coordinates-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:properties-normal-coordinates]]'
```

# prop:maximal-geodesic-sphere

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:maximal-geodesic-sphere
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#cor:geodesic-submanifold-acceleration]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#cor:metric-connection-norm-geodesic]]'
```

# prop:geodesics-hyperbolic-spaces

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:geodesics-hyperbolic-spaces
uses: []
```

# thm:hyperbolic-geodesically-complete

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#thm:hyperbolic-geodesically-complete
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:levi-civita-on-euclidean-and-submanifolds]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#cor:geodesic-submanifold-acceleration]]'
```

# ex:real-projective-plane-elliptic-geometry

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#ex:real-projective-plane-elliptic-geometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:real-projective-space-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:rp-n-frame-homogeneous]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:rp-n-frame-homogeneous]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:elliptic-geometry-hilbert]]'
```

# prop:lie-group-bi-invariant-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:lie-group-bi-invariant-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:bi-invariant-metric-adjoint]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:evaluation-map-lie-algebra-isomorphism]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:properties-of-lie-group-exponential-map]]'
```

# prob:lie-group-bi-invariant-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:lie-group-bi-invariant-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prop:bi-invariant-metric-adjoint]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:evaluation-map-lie-algebra-isomorphism]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:properties-of-lie-group-exponential-map]]'
```

# prop:model-manifolds-isometric-actions

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:model-manifolds-isometric-actions
uses: []
```

# prob:model-manifolds-isometric-actions

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:model-manifolds-isometric-actions
uses: []
```

# prop:exterior-derivative-covariant-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prop:exterior-derivative-covariant-formula
uses: []
```

# prob:exterior-derivative-covariant-formula

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:exterior-derivative-covariant-formula
uses: []
```

# exer:hilbert-axioms-euclidean-plane

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#exer:hilbert-axioms-euclidean-plane
uses: []
```

# exer:prove-corollary-5-6

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#exer:prove-corollary-5-6
uses: []
```

# exer:prove-geodesic-pseudo-euclidean-submanifold

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#exer:prove-geodesic-pseudo-euclidean-submanifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:geodesic-pseudo-euclidean-submanifold]]'
```

# exer:prove-proposition-5-20

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#exer:prove-proposition-5-20
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:naturality-exponential-map]]'
```

# prob:christoffel-symbols-surface-revolution

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:christoffel-symbols-surface-revolution
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:surfaces-of-revolution]]'
```

# prob:connection-forms-compatibility

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:connection-forms-compatibility
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prob:connection-1forms-cartan]]'
```

# prob:divergence-laplacian-formulas

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:divergence-laplacian-formulas
uses: []
```

# prob:divergence-tensor-fields

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:divergence-tensor-fields
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:divergence-laplacian-formulas]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:divergence-theorem]]'
```

# prob:eigenfunction-laplacian-inequality

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:eigenfunction-laplacian-inequality
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:eigenvalues]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:harmonic-functions]]'
```

# prob:elliptic-geometry-hilbert

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:elliptic-geometry-hilbert
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#ex:real-projective-plane-elliptic-geometry]]'
```

# prob:fermi-coordinates

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:fermi-coordinates
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:fermi-coordinates-properties]]'
```

# prob:geodesics-product-warped-metrics

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:geodesics-product-warped-metrics
uses: []
```

# prob:geodesic-warped-product

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:geodesic-warped-product
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:warped-products]]'
```

# prob:holonomy-group

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:holonomy-group
uses: []
```

# prob:hyperbolic-geometry-hilbert-axioms

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:hyperbolic-geometry-hilbert-axioms
uses: []
```

# prob:killing-vector-field

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:killing-vector-field
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#prop:invariant-tensor-characterization]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#prop:lie-derivative-tensor-product-rule]]'
```

# prob:lie-group-dimension-bound

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:lie-group-dimension-bound
uses: []
```

# prob:local-isometry-determined-point

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:local-isometry-determined-point
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:local-isometries-completely-determined]]'
```

# prob:metric-connections-difference-tensor

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:metric-connections-difference-tensor
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:difference-tensor]]'
```

# prob:nonsymmetric-euclidean-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:nonsymmetric-euclidean-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prob:connections-difference-tensor]]'
```

# prob:normal-coordinates-chart

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:normal-coordinates-chart
uses: []
```

# prob:orthonormal-frame-zero-covariant-derivative

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:orthonormal-frame-zero-covariant-derivative
uses: []
```

# prob:parallel-vector-fields

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:parallel-vector-fields
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:surfaces-of-revolution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:christoffel-symbols-surface-revolution]]'
```

# prob:riemannian-submersion-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:riemannian-submersion-connection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:horizontal-vector-field-properties]]'
```

# prob:tubular-neighborhood-normal-bundle

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter5.tex#prob:tubular-neighborhood-normal-bundle
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#thm:tubular-neighborhood]]'
```
