# lem:uniqueness-analytic-continuation

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#lem:uniqueness-analytic-continuation
uses: []
```

# thm:monodromy-theorem-local-isometries

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:monodromy-theorem-local-isometries
uses: []
```

# cor:global-isometry-from-local-simply-connected

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:global-isometry-from-local-simply-connected
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:monodromy-theorem-local-isometries]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:completeness-of-covering-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#cor:coverings-simply-connected]]'
```

# thm:killing-hopf

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:killing-hopf
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:local-uniqueness-constant-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#cor:global-isometry-from-local-simply-connected]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:small-geodesic-ball-convex]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:model-manifolds-isometric-actions]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:model-manifolds-isometric-actions]]'
```

# cor:characterization-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:characterization-constant-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:killing-hopf]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:covering-automorphisms-discrete-lie-group]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#cor:isometric-to-quotient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:model-manifolds-isometric-actions]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:discrete-subgroups-dimension-zero]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:isometry-group-acts-properly]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-quotient-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:complete-iff-covering-complete]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:model-manifolds-isometric-actions]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prob:isometry-group-acts-properly]]'
```

# thm:parallel-riemann-curvature-implies-symmetry

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:parallel-riemann-curvature-implies-symmetry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:characterization-locally-symmetric-spaces]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#cor:global-isometry-from-local-simply-connected]]'
```

# cor:symmetric-space-equivalence

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:symmetric-space-equivalence
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:characterization-locally-symmetric-spaces]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:parallel-riemann-curvature-implies-symmetry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:complete-iff-covering-complete]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:covering-automorphisms-discrete-lie-group]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#cor:isometric-to-quotient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-quotient-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:symmetric-space-parallel-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prob:symmetric-space-parallel-curvature]]'
```

# thm:cartan-hadamard

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:cartan-hadamard
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter11#thm:conjugate-point-comparison-I]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:critical-points-conjugate]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:exponential-map-defined-implies-complete]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:completeness-of-covering-map]]'
```

# prop:basic-properties-cartan-hadamard

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prop:basic-properties-cartan-hadamard
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:radial-distance-well-defined]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:radial-geodesic-unique-minimizer]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:radial-distance-riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:geodesic-ball-metric-ball]]'
```

# prop:geodesic-triangle-inequalities

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prop:geodesic-triangle-inequalities
uses: []
```

# cor:no-simply-connected-compact-nonpositive

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:no-simply-connected-compact-nonpositive
uses: []
```

# cor:product-manifolds-nonpositive

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:product-manifolds-nonpositive
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#cor:simply-connected-orientable]]'
```

# ex:positive-curvature-on-product-spheres

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#ex:positive-curvature-on-product-spheres
uses: []
```

# cor:nonpositive-implies-aspherical

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:nonpositive-implies-aspherical
uses: []
```

# lem:geodesic-convexity-distance-squared

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#lem:geodesic-convexity-distance-squared
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#prop:basic-properties-cartan-hadamard]]'
```

# lem:unique-minimal-enclosing-ball

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#lem:unique-minimal-enclosing-ball
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#lem:geodesic-convexity-distance-squared]]'
```

# thm:cartans-fixed-point

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:cartans-fixed-point
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#lem:unique-minimal-enclosing-ball]]'
```

# cor:cartans-torsion-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:cartans-torsion-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:cartans-fixed-point]]'
```

# thm:preissman-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:preissman-theorem
uses: []
```

# ex:axial-isometries

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#ex:axial-isometries
uses: []
```

# lem:covering-automorphism-axis

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#lem:covering-automorphism-axis
uses: []
```

# lem:unique-axis-cartan-hadamard

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#lem:unique-axis-cartan-hadamard
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#prop:geodesic-triangle-inequalities]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:round-metric-distance-sphere]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prob:round-metric-distance-sphere]]'
```

# cor:no-product-negative-sectional-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:no-product-negative-sectional-curvature
uses: []
```

# thm:myers-positive-ricci-geometric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:myers-positive-ricci-geometric
uses: []
```

# thm:myers-explicit-simply-connected-cover

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:myers-explicit-simply-connected-cover
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:myers-positive-ricci-geometric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:complete-iff-covering-complete]]'
```

# thm:myers-positive-ricci

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:myers-positive-ricci
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:myers-positive-ricci-geometric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:myers-explicit-simply-connected-cover]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:complete-iff-covering-complete]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:fiber-cardinality-fundamental-group]]'
```

# cor:positive-ricci-finite-fundamental-group

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:positive-ricci-finite-fundamental-group
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:unit-tangent-bundle-properties]]'
```

# cor:einstein-positive-scalar-curvature-compact

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:einstein-positive-scalar-curvature-compact
uses: []
```

# thm:chengs-maximal-diameter

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:chengs-maximal-diameter
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#cor:einstein-positive-scalar-curvature-compact]]'
```

# eq:12.2

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#eq:12.2
uses: []
```

# eq:12.3

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#eq:12.3
uses: []
```

# eq:12.4

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#eq:12.4
uses: []
```

# thm:milnor-polynomial-growth

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:milnor-polynomial-growth
uses: []
```

# cor:free-fund-group-no-ric-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:free-fund-group-no-ric-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:milnor-polynomial-growth]]'
```

# thm:synge-positive-sectional

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:synge-positive-sectional
uses: []
```

# cor:fundamental-groups-even-dimension

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#cor:fundamental-groups-even-dimension
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:synge-positive-sectional]]'
```

# thm:sphere-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:sphere-theorem
uses: []
```

# thm:soul-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:soul-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prop:complex-projective-space-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:complex-projective-space-curvature]]'
```

# thm:splitting-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:splitting-theorem
uses: []
```

# thm:hamilton-3-manifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:hamilton-3-manifold
uses: []
```

# thm:hamilton-4-manifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:hamilton-4-manifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prop:curvature-operator]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:curvature-operator]]'
```

# thm:bohm-wilking

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:bohm-wilking
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:killing-hopf]]'
```

# thm:differentiable-sphere-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#thm:differentiable-sphere-theorem
uses: []
```

# exer:paraboloid-positive-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#exer:paraboloid-positive-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:graph-submanifold-shape]]'
```

# exer:prove-corollary-12-30

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#exer:prove-corollary-12-30
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#cor:free-fund-group-no-ric-metric]]'
```

# prob:cartan-hadamard-generalization

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:cartan-hadamard-generalization
uses: []
```

# prob:classification-flat-tori

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:classification-flat-tori
uses: []
```

# prob:compact-euclidean-space-forms

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:compact-euclidean-space-forms
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:open-mobius-band]]'
```

# prob:complete-lines-sectional-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:complete-lines-sectional-curvature
uses: []
```

# prob:constant-sectional-curvature-immersion

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:constant-sectional-curvature-immersion
uses: []
```

# prob:fixed-points-orthogonal-map

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:fixed-points-orthogonal-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:real-projective-space-metric]]'
```

# prob:geodesic-uniqueness-nonpositive-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:geodesic-uniqueness-nonpositive-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:path-homotopy-contains-minimizing-geodesic]]'
```

# prob:lattices-flat-tori

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:lattices-flat-tori
uses: []
```

# prob:milnor-fundamental-group

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:milnor-fundamental-group
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#thm:milnor-polynomial-growth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:nonpositive-curvature-focal-points]]'
```

# prob:myers-scalar-counterexample

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:myers-scalar-counterexample
uses: []
```

# prob:no-negative-curvature-compact-products

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:no-negative-curvature-compact-products
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#cor:no-product-negative-sectional-curvature]]'
```

# prob:no-positive-negative-ricci

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:no-positive-negative-ricci
uses: []
```

# prob:triangle-inequalities-cartan-hadamard

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter12.tex#prob:triangle-inequalities-cartan-hadamard
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter12#prop:geodesic-triangle-inequalities]]'
```
