# prop:lie-group-homomorphism-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:lie-group-homomorphism-properties
uses: []
```

# ex:lie-group-examples

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#ex:lie-group-examples
uses: []
```

# prop:evaluation-map-lie-algebra-isomorphism

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:evaluation-map-lie-algebra-isomorphism
uses: []
```

# ex:lie-algebras

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#ex:lie-algebras
uses: []
```

# prop:induced-lie-algebra-homomorphism

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:induced-lie-algebra-homomorphism
uses: []
```

# prop:properties-of-induced-homomorphisms

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:properties-of-induced-homomorphisms
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:induced-lie-algebra-homomorphism]]'
```

# prop:properties-of-lie-group-exponential-map

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:properties-of-lie-group-exponential-map
uses: []
```

# thm:closed-subgroup-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#thm:closed-subgroup-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:properties-of-lie-group-exponential-map]]'
```

# prop:discrete-subgroups-dimension-zero

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:discrete-subgroups-dimension-zero
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#thm:closed-subgroup-theorem]]'
```

# ex:adjoint-representations-lie-groups

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#ex:adjoint-representations-lie-groups
uses: []
```

# prop:adjoint-induced-from-group

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:adjoint-induced-from-group
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#ex:adjoint-representations-lie-groups]]'
- '[[#UNRESOLVED:chC:20.27]]'
```

# ex:semidirect-products

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#ex:semidirect-products
uses: []
```

# thm:equivariant-rank-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#thm:equivariant-rank-theorem
uses:
- '[[#UNRESOLVED:chA:LeeSM.7.25]]'
```

# prop:proper-action-condition

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:proper-action-condition
uses: []
```

# cor:compact-lie-group-actions-proper

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#cor:compact-lie-group-actions-proper
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:proper-action-condition]]'
```

# thm:quotient-manifold-theorem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#thm:quotient-manifold-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:proper-action-condition]]'
```

# ex:real-projective-spaces

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#ex:real-projective-spaces
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:proper-action-condition]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#thm:quotient-manifold-theorem]]'
```

# ex:complex-projective-spaces

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#ex:complex-projective-spaces
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#ex:real-projective-spaces]]'
```

# prop:covering-automorphisms-discrete-lie-group

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:covering-automorphisms-discrete-lie-group
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#cor:compact-lie-group-actions-proper]]'
```

# prop:normal-covering-transitive-action

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:normal-covering-transitive-action
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:covering-automorphisms-discrete-lie-group]]'
```

# prop:automorphisms-universal-covering

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:automorphisms-universal-covering
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:normal-covering-transitive-action]]'
```

# prop:quotient-orbit-space-covering-map

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#prop:quotient-orbit-space-covering-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:covering-automorphisms-discrete-lie-group]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#thm:quotient-manifold-theorem]]'
```

# ex:universal-covering-projective-space

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#ex:universal-covering-projective-space
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#ex:real-projective-spaces]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:uniqueness-smooth-quotients]]'
```

# exer:semidirect-product-verification

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/appendixC.tex#exer:semidirect-product-verification
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#ex:semidirect-products]]'
```
