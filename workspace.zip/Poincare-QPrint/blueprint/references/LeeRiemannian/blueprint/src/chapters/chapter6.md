# def:one-parameter-family-of-curves

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#def:one-parameter-family-of-curves
uses: []
```

# def:variations-proper-variations

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#def:variations-proper-variations
uses: []
```

# lem:variation-field-existence

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:variation-field-existence
uses: []
```

# lem:symmetry-lemma

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:symmetry-lemma
uses: []
```

# thm:first-variation-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:first-variation-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:symmetry-lemma]]'
```

# thm:minimizing-geodesic-unit-speed

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:minimizing-geodesic-unit-speed
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:symmetry-lemma]]'
```

# cor:critical-point-geodesic

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:critical-point-geodesic
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:minimizing-geodesic-unit-speed]]'
```

# lem:minimizing-curves-locally-minimizing

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:minimizing-curves-locally-minimizing
uses: []
```

# lem:radial-distance-well-defined

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:radial-distance-well-defined
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:uniqueness-normal-coordinates]]'
```

# thm:gauss-lemma

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:gauss-lemma
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:properties-normal-coordinates]]'
```

# cor:gradient-radial-distance

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:gradient-radial-distance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gradient-characterization]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:gradient-characterization]]'
```

# prop:radial-geodesic-unique-minimizer

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prop:radial-geodesic-unique-minimizer
uses: []
```

# cor:radial-distance-riemannian-distance

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:radial-distance-riemannian-distance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:radial-geodesic-unique-minimizer]]'
```

# cor:geodesic-ball-metric-ball

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:geodesic-ball-metric-ball
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:radial-distance-riemannian-distance]]'
```

# lem:uniformly-normal-neighborhood

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:uniformly-normal-neighborhood
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:geodesic-ball-metric-ball]]'
```

# thm:locally-minimizing-geodesics

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:locally-minimizing-geodesics
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:radial-geodesic-unique-minimizer]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:uniformly-normal-neighborhood]]'
```

# lem:compact-injectivity-radius-positive

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:compact-injectivity-radius-positive
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:uniformly-normal-neighborhood]]'
```

# thm:small-geodesic-ball-convex

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:small-geodesic-ball-convex
uses: []
```

# lem:exponential-map-implies-completeness

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:exponential-map-implies-completeness
uses: []
```

# thm:hopf-rinow

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:hopf-rinow
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:exponential-map-implies-completeness]]'
```

# cor:exponential-map-defined-implies-complete

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:exponential-map-defined-implies-complete
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:exponential-map-implies-completeness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:hopf-rinow]]'
```

# cor:complete-implies-minimizing-geodesics

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:complete-implies-minimizing-geodesics
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:hopf-rinow]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:exponential-map-implies-completeness]]'
```

# cor:compact-implies-maximal-geodesics-defined

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:compact-implies-maximal-geodesics-defined
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:hopf-rinow]]'
```

# thm:completeness-of-covering-map

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:completeness-of-covering-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:lifting-properties-covering]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:exponential-map-defined-implies-complete]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:geodesic-ball-metric-ball]]'
```

# cor:complete-iff-covering-complete

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:complete-iff-covering-complete
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:completeness-of-covering-map]]'
```

# prop:path-homotopy-contains-minimizing-geodesic

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prop:path-homotopy-contains-minimizing-geodesic
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:complete-iff-covering-complete]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:complete-implies-minimizing-geodesics]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:lifting-properties-covering]]'
```

# prop:existence-closed-geodesics

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prop:existence-closed-geodesics
uses: []
```

# lem:distance-triangle-inequality-and-continuity

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:distance-triangle-inequality-and-continuity
uses: []
```

# thm:distance-to-subset-unit-gradient

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:distance-to-subset-unit-gradient
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:distance-triangle-inequality-and-continuity]]'
```

# thm:local-distance-geodesic-integral-curve

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:local-distance-geodesic-integral-curve
uses: []
```

# lem:local-distance-curve-arc-length

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#lem:local-distance-curve-arc-length
uses: []
```

# thm:smooth-local-distance-function

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:smooth-local-distance-function
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:radial-geodesic-unique-minimizer]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:local-distance-geodesic-integral-curve]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:local-distance-curve-arc-length]]'
```

# cor:local-distance-smooth-level-sets

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:local-distance-smooth-level-sets
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:smooth-local-distance-function]]'
```

# prop:fermi-coordinates-radial-function

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prop:fermi-coordinates-radial-function
uses: []
```

# thm:gauss-lemma-submanifolds

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:gauss-lemma-submanifolds
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:fermi-coordinates-radial-function]]'
```

# cor:distance-function-local-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:distance-function-local-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:gauss-lemma-submanifolds]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:small-geodesic-ball-convex]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:exponential-map-implies-completeness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gradient-characterization]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:fermi-coordinates-properties]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:smooth-local-distance-function]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:gradient-characterization]]'
```

# thm:tubular-neighborhood-metric-distance

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#thm:tubular-neighborhood-metric-distance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:fermi-coordinates-radial-function]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:local-distance-curve-arc-length]]'
```

# prop:characterizations-semigeodetic-coordinates

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prop:characterizations-semigeodetic-coordinates
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:local-distance-geodesic-integral-curve]]'
```

# cor:semigeodesic-metric-christoffel

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#cor:semigeodesic-metric-christoffel
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:characterizations-semigeodetic-coordinates]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:tangential-connection-compatible-metric]]'
```

# ex:fermi-coordinates-hypersurface

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#ex:fermi-coordinates-hypersurface
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#thm:tubular-neighborhood]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:small-geodesic-ball-convex]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:distance-function-local-properties]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:exponential-map-implies-completeness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:characterizations-semigeodetic-coordinates]]'
```

# ex:boundary-normal-coordinates

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#ex:boundary-normal-coordinates
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:double-manifold]]'
```

# ex:polar-normal-coordinates

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#ex:polar-normal-coordinates
uses: []
```

# ex:polar-fermi-coordinates

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#ex:polar-fermi-coordinates
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:fermi-coordinates-properties]]'
```

# prop:round-metric-distance-sphere

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prop:round-metric-distance-sphere
uses: []
```

# prob:round-metric-distance-sphere

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:round-metric-distance-sphere
uses: []
```

# prop:isometry-group-acts-properly

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prop:isometry-group-acts-properly
uses: []
```

# prob:isometry-group-acts-properly

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:isometry-group-acts-properly
uses: []
```

# exer:closed-geodesic-periodic-extension

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#exer:closed-geodesic-periodic-extension
uses: []
```

# exer:prove-distance-lemma

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#exer:prove-distance-lemma
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:distance-triangle-inequality-and-continuity]]'
```

# exer:prove-local-distance-corollary

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#exer:prove-local-distance-corollary
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#cor:local-distance-smooth-level-sets]]'
```

# exer:prove-minimizing-lemma

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#exer:prove-minimizing-lemma
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#lem:minimizing-curves-locally-minimizing]]'
```

# exer:trivial-free-homotopy-identity

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#exer:trivial-free-homotopy-identity
uses: []
```

# prob:closed-geodesic-free-homotopy

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:closed-geodesic-free-homotopy
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:existence-closed-geodesics]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:path-homotopy-contains-minimizing-geodesic]]'
```

# prob:compact-complete-characterization

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:compact-complete-characterization
uses: []
```

# prob:completeness-divergence

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:completeness-divergence
uses: []
```

# prob:connected-riemannian-1-manifold-structure

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:connected-riemannian-1-manifold-structure
uses: []
```

# prob:convexity-radius-continuous

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:convexity-radius-continuous
uses: []
```

# prob:distance-complete-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:distance-complete-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:distance-disconnected-riemannian]]'
```

# prob:distance-determines-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:distance-determines-metric
uses: []
```

# prob:distance-function-submersion

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:distance-function-submersion
uses: []
```

# prob:energy-functional

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:energy-functional
uses: []
```

# prob:extendible

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:extendible
uses: []
```

# prob:geodesic-ball-convexity

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:geodesic-ball-convexity
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:small-geodesic-ball-convex]]'
```

# prob:geodesic-completeness

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:geodesic-completeness
uses: []
```

# prob:geodesic-to-closed-subset

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:geodesic-to-closed-subset
uses: []
```

# prob:inj-radius-diffeomorphism

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:inj-radius-diffeomorphism
uses: []
```

# prob:k-point-homogeneous

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:k-point-homogeneous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prob:inj-radius-diffeomorphism]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prob:geodesic-completeness]]'
```

# prob:killing-vector-field-properties

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:killing-vector-field-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:killing-vector-field]]'
```

# prob:lie-group-exp-surjective

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:lie-group-exp-surjective
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:lie-group-bi-invariant-metric]]'
```

# prob:limit-isometry

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:limit-isometry
uses: []
```

# prob:manifold-boundary-complete

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:manifold-boundary-complete
uses: []
```

# prob:metric-isometry-characterization

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:metric-isometry-characterization
uses: []
```

# prob:exponential-distance-limit

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:exponential-distance-limit
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:isometry-invariance-riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:distance-preserving-map-linear-isometry]]'
```

# prob:onion-skin-geodesics

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:onion-skin-geodesics
uses: []
```

# prob:parallel-vector-field

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:parallel-vector-field
uses: []
```

# prob:poincare-ball-distance-formula

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:poincare-ball-distance-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:sphere-hyperbolic-scaling]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter3#prob:poincare-disk]]'
```

# prob:ray-definition

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:ray-definition
uses: []
```

# prob:smooth-function-equals-distance

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:smooth-function-equals-distance
uses: []
```

# prob:submanifold-distance-inequality

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:submanifold-distance-inequality
uses: []
```

# prob:symmetric-space-homogeneous

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:symmetric-space-homogeneous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prob:k-point-homogeneous]]'
```

# prob:tubular-neighborhood-volume

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:tubular-neighborhood-volume
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prob:volume-geodesic-ball]]'
```

# prob:volume-geodesic-ball

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter6.tex#prob:volume-geodesic-ball
uses: []
```
