# lem:polarization-identity

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:polarization-identity
uses: []
```

# prop:gram-schmidt

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:gram-schmidt
uses: []
```

# prop:inner-product-spaces-linearly-isometric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:inner-product-spaces-linearly-isometric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gram-schmidt]]'
```

# def:riemannian-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:riemannian-metric
uses: []
```

# lem:convex-inner-products

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:convex-inner-products
uses: []
```

# lem:posdef-coercive

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:posdef-coercive
uses: []
```

# prop:existence-riemannian-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:existence-riemannian-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:convex-inner-products]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:posdef-coercive]]'
```

# ex:euclidean-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:euclidean-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# def:metric-preserving

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:metric-preserving
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# def:isometry

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# lem:metric-preserving-immersion

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:metric-preserving-immersion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-immersion-metric]]'
```

# lem:isometry-symm

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:isometry-symm
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
```

# def:local-isometry

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:local-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# lem:metric-preserving-equidim-local-diffeomorphism

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:metric-preserving-equidim-local-diffeomorphism
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:metric-preserving-immersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:inverse-function-theorem-manifolds]]'
```

# prop:characterize-local-isometry

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:characterize-local-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:metric-preserving-equidim-local-diffeomorphism]]'
```

# lem:inner-product-vector-fields-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:inner-product-vector-fields-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# lem:length-vector-field-continuous

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:length-vector-field-continuous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-product-vector-fields-smooth]]'
```

# lem:length-vector-field-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:length-vector-field-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-product-vector-fields-smooth]]'
```

# prop:existence-orthonormal-frames

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:existence-orthonormal-frames
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gram-schmidt]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# rem:coordinate-frame-warning

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#rem:coordinate-frame-warning
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
```

# prop:unit-tangent-bundle-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:unit-tangent-bundle-properties
uses: []
```

# lem:pullback-immersion-metric

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pullback-immersion-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# def:induced-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:induced-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-immersion-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# ex:spheres

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:spheres
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:euclidean-metric]]'
```

# prop:adapted-orthonormal-frames

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:adapted-orthonormal-frames
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:partial-frame-extension]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pushforward-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-immersion-metric]]'
```

# lem:ordered-linear-extension

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:ordered-linear-extension
uses: []
```

# lem:open-linear-independence

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:open-linear-independence
uses: []
```

# lem:partial-frame-extension

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:partial-frame-extension
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ordered-linear-extension]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:open-linear-independence]]'
```

# lem:pushforward-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pushforward-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
```

# lem:ambient-tangent-bundle-riemannian

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:ambient-tangent-bundle-riemannian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-metric]]'
```

# prop:adapted-orthonormal-frames-immersed

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:adapted-orthonormal-frames-immersed
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:partial-frame-extension]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pushforward-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-immersion-metric]]'
```

# def:normal-space

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:normal-space
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
```

# lem:normal-space-orthonormal-frame

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:normal-space-orthonormal-frame
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:adapted-orthonormal-frames-immersed]]'
```

# prop:normal-bundle

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:normal-bundle
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-space-orthonormal-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:local-frame-criterion-for-subbundles]]'
```

# rem:normal-bundle-projections

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#rem:normal-bundle-projections
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:normal-bundle]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:local-embedding-theorem]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:local-frame-criterion-for-subbundles]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:adapted-orthonormal-frames-immersed]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-space-orthonormal-frame]]'
```

# prop:outward-pointing-normal

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:outward-pointing-normal
uses: []
```

# ex:metrics-in-graph-coordinates

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:metrics-in-graph-coordinates
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:euclidean-metric]]'
```

# ex:surfaces-of-revolution

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:surfaces-of-revolution
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:euclidean-metric]]'
```

# ex:n-torus-riemannian-submanifold

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:n-torus-riemannian-submanifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#ex:covering-n-torus]]'
```

# lem:smooth-tensor-field-add

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:smooth-tensor-field-add
uses: []
```

# lem:smooth-tensor-field-smul

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:smooth-tensor-field-smul
uses: []
```

# lem:product-form-positive-definite

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:product-form-positive-definite
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# def:product-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:product-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:product-form-positive-definite]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:smooth-tensor-field-add]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-immersion-metric]]'
```

# prop:product-metric-torus

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:product-metric-torus
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:product-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-metric]]'
```

# lem:warped-product-form-positive-definite

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:warped-product-form-positive-definite
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:product-form-positive-definite]]'
```

# def:warped-product

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:warped-product
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:product-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:warped-product-form-positive-definite]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:smooth-tensor-field-add]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:smooth-tensor-field-smul]]'
```

# prop:warped-product-constant-one

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:warped-product-constant-one
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:warped-product]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:product-metric]]'
```

# ex:warped-products

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:warped-products
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:surfaces-of-revolution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:warped-product]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:warped-product-constant-one]]'
- '[[#REF:ch2-3]]'
```

# prop:horizontal-vector-field-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:horizontal-vector-field-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:vertical-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:tangent-space-horizontal-vertical-splitting]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-projection-field-smooth]]'
```

# lem:pushforward-along-map-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pushforward-along-map-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion]]'
```

# lem:horizontal-lift-along-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:horizontal-lift-along-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-tangent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-smooth-in-data]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion]]'
```

# lem:horizontal-projection-field-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:horizontal-projection-field-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pushforward-along-map-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-along-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
```

# def:submersion

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:submersion
uses: []
```

# def:horizontal-lift-linear

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:horizontal-lift-linear
uses: []
```

# lem:horizontal-lift-linear-spec

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:horizontal-lift-linear-spec
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-linear]]'
```

# lem:horizontal-lift-smooth-in-data

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:horizontal-lift-smooth-in-data
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-linear]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-linear-spec]]'
```

# def:vertical-space

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:vertical-space
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion]]'
```

# def:horizontal-space

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:horizontal-space
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:vertical-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# def:horizontal-lift-tangent

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:horizontal-lift-tangent
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-linear]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion]]'
```

# lem:tangent-space-horizontal-vertical-splitting

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:tangent-space-horizontal-vertical-splitting
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:vertical-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-tangent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-linear-spec]]'
```

# prop:horizontal-lift-of-vector-field

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:horizontal-lift-of-vector-field
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-tangent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-linear-spec]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-smooth-in-data]]'
```

# prop:horizontal-lift-realizes-horizontal-vector

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:horizontal-lift-realizes-horizontal-vector
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-tangent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:horizontal-lift-of-vector-field]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:vector-field-extension-point]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-linear-spec]]'
```

# prop:horizontal-vector-field-not-lift

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:horizontal-vector-field-not-lift
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-tangent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:riemannian-submersions]]'
```

# ex:riemannian-submersions

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:riemannian-submersions
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:product-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:warped-product]]'
```

# def:riemannian-submersion

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:riemannian-submersion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# def:submersion-inner

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:submersion-inner
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-tangent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# lem:riemannian-submersion-inner-eq

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-submersion-inner-eq
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion-inner]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-linear-spec]]'
```

# prop:riemannian-submersion-metric-unique

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:riemannian-submersion-metric-unique
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-submersion-inner-eq]]'
```

# lem:mfderiv-smul-inv-smul

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:mfderiv-smul-inv-smul
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# lem:horizontal-space-smul

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:horizontal-space-smul
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:mfderiv-smul-inv-smul]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:vertical-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
```

# lem:submersion-inner-smul

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:submersion-inner-smul
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-space-smul]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion-inner]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-linear-spec]]'
```

# lem:submersion-inner-congr

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:submersion-inner-congr
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:submersion-inner-smul]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion-inner]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-space-smul]]'
```

# lem:horizontal-lift-in-coordinates-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:horizontal-lift-in-coordinates-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-smooth-in-data]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-tangent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-linear-spec]]'
```

# thm:group-action-riemannian-submersion

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#thm:group-action-riemannian-submersion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-submersion-metric-unique]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:submersion-inner-congr]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:local-section-manifold]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:bilinear-comp-of-family-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:horizontal-lift-in-coordinates-smooth]]'
- '[[#REF:ch2-6]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion-inner]]'
```

# cor:quotient-manifold-lie-group-riemannian-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#cor:quotient-manifold-lie-group-riemannian-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#thm:quotient-manifold-theorem]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#thm:group-action-riemannian-submersion]]'
```

# ex:fubini-study-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:fubini-study-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#ex:complex-projective-spaces]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#thm:local-section-theorem]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#thm:group-action-riemannian-submersion]]'
```

# def:smooth-covering-map

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:smooth-covering-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:elementary-covering-maps]]'
```

# def:covering-automorphism-group

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:covering-automorphism-group
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-covering-map]]'
```

# def:normal-covering-fibre-transitive

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:normal-covering-fibre-transitive
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:covering-automorphism-group]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:normal-covering-transitive-action]]'
```

# def:covering-automorphism-invariant-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:covering-automorphism-invariant-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:covering-automorphism-group]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
```

# def:riemannian-covering

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:riemannian-covering
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-covering-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
```

# lem:riemannian-covering-local-isometry

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-covering-local-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-covering]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-covering-map]]'
```

# prop:equidimensional-riemannian-submersion-local-isometry

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:equidimensional-riemannian-submersion-local-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:submersion]]'
```

# prop:riemannian-covering-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:riemannian-covering-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-covering-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:normal-covering-fibre-transitive]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:covering-automorphism-invariant-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-covering]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:elementary-covering-maps]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:normal-covering-transitive-action]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#thm:group-action-riemannian-submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:equidimensional-riemannian-submersion-local-isometry]]'
```

# prop:riemannian-quotient-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:riemannian-quotient-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:quotient-orbit-space-covering-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-covering-metric]]'
```

# cor:isometric-to-quotient

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#cor:isometric-to-quotient
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:covering-automorphisms-discrete-lie-group]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#prop:quotient-orbit-space-covering-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:uniqueness-smooth-quotients]]'
```

# ex:real-projective-space-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:real-projective-space-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixC#ex:universal-covering-projective-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-quotient-metric]]'
```

# ex:open-mobius-band

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#ex:open-mobius-band
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-quotient-metric]]'
- '[[#REF:ch2-8]]'
```

# def:flat-map

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:flat-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# lem:flat-bijective

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:flat-bijective
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:flat-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# def:sharp-map

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:sharp-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:flat-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:flat-bijective]]'
```

# def:gradient

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:gradient
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sharp-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# lem:gradient-characterization

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gradient-characterization
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sharp-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:flat-bijective]]'
```

# lem:gradient-orthogonal-kernel

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gradient-orthogonal-kernel
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-characterization]]'
```

# lem:gradient-eq-zero-iff

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gradient-eq-zero-iff
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-characterization]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:flat-bijective]]'
```

# lem:gradient-orthogonal-iff

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gradient-orthogonal-iff
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-characterization]]'
```

# def:regular-set

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:regular-set
uses: []
```

# lem:regular-set-eq-gradient-nonvanishing

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:regular-set-eq-gradient-nonvanishing
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:regular-set]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-eq-zero-iff]]'
```

# lem:mfderiv-nonvanishing-open

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:mfderiv-nonvanishing-open
uses: []
```

# lem:regular-set-open

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:regular-set-open
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:regular-set]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:mfderiv-nonvanishing-open]]'
```

# prop:gradient-normal-regular-level-set

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:gradient-normal-regular-level-set
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-hypersurface-codim-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-tangent-kernel]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-orthogonal-kernel]]'
```

# prop:tangent-space-regular-level-set-gradient-orthogonal

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:tangent-space-regular-level-set-gradient-orthogonal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-tangent-kernel]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-orthogonal-iff]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
```

# lem:opens-inclusion-differential

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:opens-inclusion-differential
uses: []
```

# lem:opens-restrict-differential

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:opens-restrict-differential
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:opens-inclusion-differential]]'
```

# lem:regular-restrict-regular-value

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:regular-restrict-regular-value
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:regular-set]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:regular-set-open]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:opens-restrict-differential]]'
```

# prop:regular-level-set-hypersurface

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:regular-level-set-hypersurface
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-hypersurface-codim-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:regular-set]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:regular-set-open]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:regular-restrict-regular-value]]'
```

# lem:regular-part-image

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:regular-part-image
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-level-set-hypersurface]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:regular-set]]'
```

# lem:regular-part-embedded

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:regular-part-embedded
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-level-set-hypersurface]]'
```

# lem:regular-part-inclusion-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:regular-part-inclusion-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-level-set-hypersurface]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-inclusion-smooth]]'
```

# lem:regular-part-inclusion-immersion

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:regular-part-inclusion-immersion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-level-set-hypersurface]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:opens-inclusion-differential]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-inclusion-smooth]]'
```

# lem:regular-part-tangent-kernel

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:regular-part-tangent-kernel
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-level-set-hypersurface]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-tangent-kernel]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:opens-restrict-differential]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:opens-inclusion-differential]]'
```

# prop:gradient-normal-regular-part

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:gradient-normal-regular-part
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-level-set-hypersurface]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:regular-part-tangent-kernel]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-orthogonal-kernel]]'
```

# lem:gradient-nonvanishing-regular-part

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gradient-nonvanishing-regular-part
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-level-set-hypersurface]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:regular-set-eq-gradient-nonvanishing]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
```

# prop:inverse-metric-ambiguity

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:inverse-metric-ambiguity
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:dual-coframe]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sharp-map]]'
```

# prop:orthonormal-frames-and-coframes

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:orthonormal-frames-and-coframes
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inverse-metric-ambiguity]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:dual-coframe]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sharp-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
```

# prop:inner-products-of-tensors

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:inner-products-of-tensors
uses: []
```

# def:smooth-orientation

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:smooth-orientation
uses: []
```

# lem:gram-schmidt-preserves-orientation

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gram-schmidt-preserves-orientation
uses: []
```

# prop:oriented-orthonormal-frames

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:oriented-orthonormal-frames
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-preserves-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# def:volume-form-pointwise

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:volume-form-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
```

# prop:volume-form-determinant

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:volume-form-determinant
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:oriented-orthonormal-frames]]'
```

# prop:volume-form-value-one

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:volume-form-value-one
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:oriented-orthonormal-frames]]'
```

# prop:volume-form-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:volume-form-uniqueness
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-value-one]]'
```

# lem:top-forms-proportional

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:top-forms-proportional
uses: []
```

# def:wedge-covectors

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:wedge-covectors
uses: []
```

# prop:volume-form-coframe

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:volume-form-coframe
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-determinant]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:oriented-orthonormal-frames]]'
```

# prop:volume-form-smooth

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:volume-form-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:oriented-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:top-forms-proportional]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-determinant]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-value-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-product-vector-fields-smooth]]'
```

# def:frame-matrix

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:frame-matrix
uses: []
```

# lem:frame-matrix-nonsingular

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:frame-matrix-nonsingular
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
```

# def:dual-coframe

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:dual-coframe
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:frame-matrix-nonsingular]]'
```

# lem:dual-coframe-duality

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:dual-coframe-duality
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:dual-coframe]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:frame-matrix-nonsingular]]'
```

# lem:volume-form-gram-determinant

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:volume-form-gram-determinant
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-preserves-orientation]]'
```

# prop:volume-form-frame-value

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:volume-form-frame-value
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:volume-form-gram-determinant]]'
```

# prop:volume-form-coordinate-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:volume-form-coordinate-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-frame-value]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:top-forms-proportional]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:dual-coframe-duality]]'
```

# prop:riemannian-volume-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:riemannian-volume-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-value-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-uniqueness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-determinant]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-coframe]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-coordinate-formula]]'
```

# def:pullback-alternating

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pullback-alternating
uses: []
```

# lem:orthonormal-pushforward

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:orthonormal-pushforward
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
```

# lem:push-basis

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:push-basis
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthonormal-pushforward]]'
```

# prop:isometry-preserves-volume-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:isometry-preserves-volume-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pullback-alternating]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-uniqueness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-value-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthonormal-pushforward]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:push-basis]]'
```

# def:interior-multiplication

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:interior-multiplication
uses: []
```

# def:unit-normal

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:unit-normal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:normal-space]]'
```

# lem:adapted-frame-cons-normal

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:adapted-frame-cons-normal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:normal-space]]'
```

# lem:adapted-frame-ambient-basis

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:adapted-frame-ambient-basis
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-frame-cons-normal]]'
```

# prop:hypersurface-volume-form-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-volume-form-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-frame-cons-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-frame-ambient-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-uniqueness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-value-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
```

# lem:nonvanishing-top-form-orientation

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:nonvanishing-top-form-orientation
uses: []
```

# def:induced-orientation

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:induced-orientation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nonvanishing-top-form-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-frame-ambient-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
```

# lem:induced-orientation-characterization

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:induced-orientation-characterization
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-frame-ambient-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nonvanishing-top-form-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-value-one]]'
```

# lem:top-form-eq-of-basis

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:top-form-eq-of-basis
uses: []
```

# prop:hypersurface-volume-form-induced

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-volume-form-induced
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:induced-orientation-characterization]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:top-form-eq-of-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-value-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
```

# lem:pullback-comp-section

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pullback-comp-section
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
```

# def:smooth-normal-at

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:smooth-normal-at
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
```

# def:smooth-unit-normal-field

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:smooth-unit-normal-field
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-normal-at]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:normal-space]]'
```

# lem:frame-neg-member

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:frame-neg-member
uses: []
```

# lem:adapted-frame-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:adapted-frame-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-normal-at]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pushforward-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
```

# lem:normal-restrict-frame-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:normal-restrict-frame-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-normal-at]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-frame-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:oriented-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-determinant]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:ambient-tangent-bundle-riemannian]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-comp-section]]'
```

# lem:normal-restrict-neg-member

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:normal-restrict-neg-member
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
```

# prop:hypersurface-orientable-of-normal

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-orientable-of-normal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-unit-normal-field]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-restrict-frame-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:frame-neg-member]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-restrict-neg-member]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nonvanishing-top-form-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-frame-ambient-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:induced-orientation-characterization]]'
```

# rem:hypersurface-orientation-dimension

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#rem:hypersurface-orientation-dimension
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-orientable-of-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-orientation]]'
```

# prop:hypersurface-volume-form-if

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-volume-form-if
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-orientable-of-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-induced]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-unit-normal-field]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
```

# lem:two-unit-normals

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:two-unit-normals
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-space-orthonormal-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
```

# lem:pointwise-unit-normal-span

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pointwise-unit-normal-span
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-space-orthonormal-frame]]'
```

# lem:normal-restrict-neg-normal

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:normal-restrict-neg-normal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
```

# lem:basis-realizing-orientation

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:basis-realizing-orientation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nonvanishing-top-form-orientation]]'
```

# def:oriented-unit-normal

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:oriented-unit-normal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nonvanishing-top-form-orientation]]'
```

# lem:oriented-unit-normal-iff-pos

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:oriented-unit-normal-iff-pos
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:oriented-unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nonvanishing-top-form-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-frame-ambient-basis]]'
```

# prop:existsunique-oriented-unit-normal

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:existsunique-oriented-unit-normal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:oriented-unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:two-unit-normals]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pointwise-unit-normal-span]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-restrict-neg-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:basis-realizing-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:oriented-unit-normal-iff-pos]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
```

# def:unit-normal-of-orientation

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:unit-normal-of-orientation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existsunique-oriented-unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:oriented-unit-normal]]'
```

# prop:unit-normal-of-orientation-smooth

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:unit-normal-of-orientation-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal-of-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-unit-normal-field]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-space-orthonormal-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-restrict-frame-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:oriented-unit-normal-iff-pos]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-restrict-neg-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existsunique-oriented-unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
```

# prop:hypersurface-volume-form-only-if

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-volume-form-only-if
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:unit-normal-of-orientation-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal-of-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-induced]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:oriented-unit-normal-iff-pos]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:basis-realizing-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-unit-normal-field]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
```

# prop:hypersurface-volume-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-volume-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-formula]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-induced]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-if]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-only-if]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-orientable-of-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:unit-normal-of-orientation-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-orientation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-unit-normal-field]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:unit-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:interior-multiplication]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:normal-space-orthonormal-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:induced-orientation-characterization]]'
```

# def:density-vector-space

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:density-vector-space
uses: []
```

# def:density-pointwise

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:density-pointwise
uses: []
```

# prop:density-abs-det

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:density-abs-det
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-pointwise]]'
```

# prop:density-value-one

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:density-value-one
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-abs-det]]'
```

# prop:density-transformation-law

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:density-transformation-law
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-abs-det]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-vector-space]]'
```

# prop:density-positive

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:density-positive
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-pointwise]]'
```

# prop:density-uniqueness-pointwise

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:density-uniqueness-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-vector-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-transformation-law]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-value-one]]'
```

# prop:density-eq-abs-volume-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:density-eq-abs-volume-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-determinant]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-abs-det]]'
```

# def:smooth-density

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:smooth-density
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-vector-space]]'
```

# def:riemannian-density-pointwise

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:riemannian-density-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# prop:density-smooth

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:density-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-density-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-positive]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-product-vector-fields-smooth]]'
```

# prop:riemannian-density

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:riemannian-density
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-density]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-density-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-transformation-law]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-value-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-uniqueness-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:density-positive]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
```

# prop:riemannian-density-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:riemannian-density-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-density]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-vector-space]]'
```

# prop:coordinate-representations-divergence-laplacian

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:coordinate-representations-divergence-laplacian
uses: []
```

# def:length-of-curve

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:length-of-curve
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# prop:length-additive

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:length-additive
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:length-of-curve]]'
```

# prop:length-reparam-invariant

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:length-reparam-invariant
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:length-of-curve]]'
```

# prop:length-isometry-invariant

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:length-isometry-invariant
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:length-of-curve]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
```

# prop:regular-curve-unit-speed-reparam

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:regular-curve-unit-speed-reparam
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:length-of-curve]]'
```

# prop:reparametrization-by-arc-length

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:reparametrization-by-arc-length
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-curve-unit-speed-reparam]]'
```

# prop:connected-manifold-admissible-curve

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:connected-manifold-admissible-curve
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-distance-finite]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
```

# def:riemannian-distance

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:riemannian-distance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:length-of-curve]]'
```

# rem:riemannian-distance-c1-vs-admissible

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#rem:riemannian-distance-c1-vs-admissible
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
```

# prop:connected-manifold-c1-curve

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:connected-manifold-c1-curve
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-distance-finite]]'
```

# lem:riemannian-distance-symm

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-distance-symm
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
```

# lem:riemannian-distance-triangle

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-distance-triangle
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
```

# lem:riemannian-distance-locally-small

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-distance-locally-small
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
```

# lem:riemannian-distance-small-implies-nearby

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-distance-small-implies-nearby
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
```

# prop:riemannian-distance-finite

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:riemannian-distance-finite
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-locally-small]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-symm]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-triangle]]'
```

# lem:metric-preserving-distance-le

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:metric-preserving-distance-le
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:length-isometry-invariant]]'
```

# prop:isometry-invariance-riemannian-distance

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:isometry-invariance-riemannian-distance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:metric-preserving-distance-le]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:isometry-symm]]'
```

# prop:euclidean-linear-isometry-distance

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:euclidean-linear-isometry-distance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:euclidean-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:isometry-invariance-riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:euclidean-riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:local-isometry-distance]]'
```

# lem:metric-energy-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:metric-energy-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# lem:norm-comparison-compact-core

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:norm-comparison-compact-core
uses: []
```

# lem:riemannian-euclidean-norm-comparison-flat

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-euclidean-norm-comparison-flat
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:norm-comparison-compact-core]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:metric-energy-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:euclidean-metric]]'
```

# lem:riemannian-euclidean-norm-comparison

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-euclidean-norm-comparison
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:euclidean-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:norm-comparison-compact-core]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:metric-energy-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-euclidean-norm-comparison-flat]]'
```

# lem:distance-comparison-neighborhood

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:distance-comparison-neighborhood
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-locally-small]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-small-implies-nearby]]'
```

# thm:riemannian-manifolds-metric-spaces

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#thm:riemannian-manifolds-metric-spaces
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-distance-finite]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-symm]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-triangle]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-locally-small]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-small-implies-nearby]]'
```

# lem:riemannian-metric-space-dist

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-metric-space-dist
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#thm:riemannian-manifolds-metric-spaces]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-distance-finite]]'
```

# thm:riemannian-distance-topology

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#thm:riemannian-distance-topology
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#thm:riemannian-manifolds-metric-spaces]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-locally-small]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:riemannian-distance-small-implies-nearby]]'
```

# prop:euclidean-riemannian-distance

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:euclidean-riemannian-distance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-distance]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:euclidean-metric]]'
```

# lem:euclidean-riemannian-distance-real

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:euclidean-riemannian-distance-real
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:euclidean-riemannian-distance]]'
```

# lem:nondegenerate-symmetric-bilinear

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:nondegenerate-symmetric-bilinear
uses: []
```

# prop:polarization-scalar-product

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:polarization-scalar-product
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:polarization-identity]]'
```

# lem:orthogonal-complement

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:orthogonal-complement
uses: []
```

# lem:orthogonal-complement-involution

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:orthogonal-complement-involution
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement]]'
```

# lem:nondegenerate-subspace

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:nondegenerate-subspace
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement-involution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement]]'
```

# lem:completion-nondegenerate-bases

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:completion-nondegenerate-bases
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-subspace]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:polarization-scalar-product]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#exer:polarization-scalar-product]]'
```

# prop:gram-schmidt-algorithm-scalar-products

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:gram-schmidt-algorithm-scalar-products
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# prop:symmetric-bilinear-orthogonal-basis

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:symmetric-bilinear-orthogonal-basis
uses: []
```

# prop:scalar-product-orthonormal-basis

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:scalar-product-orthonormal-basis
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:symmetric-bilinear-orthogonal-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# cor:scalar-product-signature-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#cor:scalar-product-signature-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:scalar-product-orthonormal-basis]]'
```

# prop:sylvesters-law-inertia

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:sylvesters-law-inertia
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#cor:scalar-product-signature-form]]'
```

# lem:radical-scalar-product-trivial

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:radical-scalar-product-trivial
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# cor:scalar-product-signature-sum

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#cor:scalar-product-signature-sum
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:radical-scalar-product-trivial]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:sylvesters-law-inertia]]'
```

# def:smooth-field-scalar-products

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:smooth-field-scalar-products
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# lem:pseudo-metric-fibre-scalar-product

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-metric-fibre-scalar-product
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-field-scalar-products]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# lem:pseudo-metric-pairing-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-metric-pairing-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-field-scalar-products]]'
```

# def:pseudo-riemannian-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pseudo-riemannian-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-field-scalar-products]]'
```

# prop:riemannian-is-pseudo-riemannian

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:riemannian-is-pseudo-riemannian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# def:pseudo-metric-signature-at

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pseudo-metric-signature-at
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-fibre-scalar-product]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#cor:scalar-product-signature-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:sylvesters-law-inertia]]'
```

# prop:pseudo-metric-signature-sum

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:pseudo-metric-signature-sum
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-signature-at]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-fibre-scalar-product]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#cor:scalar-product-signature-sum]]'
```

# def:pseudo-metric-has-signature

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pseudo-metric-has-signature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-signature-at]]'
```

# def:gram-schmidt-bilin

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:gram-schmidt-bilin
uses: []
```

# def:gram-schmidt-bilin-normed

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:gram-schmidt-bilin-normed
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gram-schmidt-bilin]]'
```

# lem:gram-schmidt-bilin-orthogonal-earlier

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gram-schmidt-bilin-orthogonal-earlier
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gram-schmidt-bilin]]'
```

# prop:gram-schmidt-bilin-spec

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:gram-schmidt-bilin-spec
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gram-schmidt-bilin]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-orthogonal-earlier]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# lem:gram-schmidt-bilin-nonvanishing

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gram-schmidt-bilin-nonvanishing
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gram-schmidt-bilin-spec]]'
```

# lem:gram-schmidt-bilin-orthogonal

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gram-schmidt-bilin-orthogonal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gram-schmidt-bilin-spec]]'
```

# lem:gram-schmidt-bilin-flag

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gram-schmidt-bilin-flag
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gram-schmidt-bilin-spec]]'
```

# lem:gram-schmidt-bilin-normalizer-ne-zero

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gram-schmidt-bilin-normalizer-ne-zero
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-nonvanishing]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gram-schmidt-bilin-normed]]'
```

# prop:gram-schmidt-bilin-orthonormal

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:gram-schmidt-bilin-orthonormal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gram-schmidt-bilin-normed]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-nonvanishing]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-orthogonal]]'
```

# lem:gram-schmidt-bilin-normed-flag

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gram-schmidt-bilin-normed-flag
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gram-schmidt-bilin-normed]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-flag]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-normalizer-ne-zero]]'
```

# cor:gram-schmidt-bilin-recovers

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#cor:gram-schmidt-bilin-recovers
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gram-schmidt-bilin-orthonormal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-normed-flag]]'
```

# lem:inv-sqrt-abs-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:inv-sqrt-abs-smooth
uses: []
```

# def:local-nondegenerate-family

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:local-nondegenerate-family
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-field-scalar-products]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-fibre-scalar-product]]'
```

# def:pseudo-gram-schmidt-frame

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pseudo-gram-schmidt-frame
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gram-schmidt-bilin]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gram-schmidt-bilin-normed]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-field-scalar-products]]'
```

# lem:pseudo-gram-schmidt-denominators

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-gram-schmidt-denominators
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-gram-schmidt-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-nonvanishing]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-fibre-scalar-product]]'
```

# prop:pseudo-gram-schmidt-frame-orthonormal

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:pseudo-gram-schmidt-frame-orthonormal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-gram-schmidt-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gram-schmidt-bilin-orthonormal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-fibre-scalar-product]]'
```

# lem:pseudo-gram-schmidt-frame-flag

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-gram-schmidt-frame-flag
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-gram-schmidt-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-schmidt-bilin-normed-flag]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-fibre-scalar-product]]'
```

# prop:pseudo-gram-schmidt-frame-aux-smooth

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:pseudo-gram-schmidt-frame-aux-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-gram-schmidt-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-pairing-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-gram-schmidt-denominators]]'
```

# prop:pseudo-gram-schmidt-frame-smooth

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:pseudo-gram-schmidt-frame-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:pseudo-gram-schmidt-frame-aux-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inv-sqrt-abs-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-pairing-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-gram-schmidt-denominators]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-gram-schmidt-frame]]'
```

# lem:nondegenerate-tuple-gram-matrix

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:nondegenerate-tuple-gram-matrix
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# lem:nondegenerate-tuple-leading-minors

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:nondegenerate-tuple-leading-minors
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-tuple-gram-matrix]]'
```

# lem:nondegenerate-tuple-independent

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:nondegenerate-tuple-independent
uses: []
```

# lem:nondegenerate-tuple-basis

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:nondegenerate-tuple-basis
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-tuple-independent]]'
```

# lem:orthonormal-tuple-nondegenerate

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:orthonormal-tuple-nondegenerate
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-tuple-leading-minors]]'
```

# lem:gram-det-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:gram-det-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-pairing-smooth]]'
```

# lem:open-nondegenerate-tuple

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:open-nondegenerate-tuple
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-tuple-leading-minors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gram-det-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-fibre-scalar-product]]'
```

# lem:sections-through-prescribed-basis

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:sections-through-prescribed-basis
uses: []
```

# prop:orthonormalize-nondegenerate-family

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:orthonormalize-nondegenerate-family
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-gram-schmidt-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:pseudo-gram-schmidt-frame-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:pseudo-gram-schmidt-frame-orthonormal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-gram-schmidt-frame-flag]]'
```

# prop:orthonormal-frames-pseudo-riemannian

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:orthonormal-frames-pseudo-riemannian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:completion-nondegenerate-bases]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:sections-through-prescribed-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:open-nondegenerate-tuple]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:orthonormalize-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-metric-fibre-scalar-product]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:orthonormal-frames-pseudo-riemannian]]'
```

# def:lorentz-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:lorentz-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-has-signature]]'
```

# lem:lorentz-form-pointwise

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:lorentz-form-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:sylvesters-law-inertia]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#cor:scalar-product-signature-sum]]'
```

# def:rank-one-distribution

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:rank-one-distribution
uses: []
```

# prop:rank-one-distribution-is-subbundle

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:rank-one-distribution-is-subbundle
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:rank-one-distribution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:local-frame-criterion-for-subbundles]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-riemannian-metric]]'
```

# def:tensor-product-one-forms

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:tensor-product-one-forms
uses: []
```

# lem:tensor-product-one-forms-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:tensor-product-one-forms-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:tensor-product-one-forms]]'
```

# def:sign-flipped-form

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:sign-flipped-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:tensor-product-one-forms]]'
```

# lem:sign-flipped-form-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:sign-flipped-form-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sign-flipped-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:tensor-product-one-forms-smooth]]'
```

# lem:two-unit-vectors-of-a-line

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:two-unit-vectors-of-a-line
uses: []
```

# lem:local-unit-section

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:local-unit-section
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:rank-one-distribution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
```

# prop:lorentz-metric-of-rank-one-distribution

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:lorentz-metric-of-rank-one-distribution
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:lorentz-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:rank-one-distribution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:lorentz-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sign-flipped-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:sign-flipped-form-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:two-unit-vectors-of-a-line]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:local-unit-section]]'
```

# def:simple-eigenpair

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:simple-eigenpair
uses: []
```

# def:eigen-linearisation

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:eigen-linearisation
uses: []
```

# lem:eigen-linearisation-injective

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:eigen-linearisation-injective
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:simple-eigenpair]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:eigen-linearisation]]'
```

# def:augmented-eigen-equation

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:augmented-eigen-equation
uses: []
```

# lem:augmented-eigen-equation-derivative

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:augmented-eigen-equation-derivative
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:augmented-eigen-equation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:eigen-linearisation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:simple-eigenpair]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:eigen-linearisation-injective]]'
```

# prop:smooth-eigen-selection

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:smooth-eigen-selection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:simple-eigenpair]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:augmented-eigen-equation]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:augmented-eigen-equation-derivative]]'
```

# lem:signature-and-eigenvalue-signs

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:signature-and-eigenvalue-signs
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#cor:scalar-product-signature-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:sylvesters-law-inertia]]'
```

# lem:simple-eigenpair-of-index-one

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:simple-eigenpair-of-index-one
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:signature-and-eigenvalue-signs]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:simple-eigenpair]]'
```

# prop:rank-one-distribution-of-lorentz-metric

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:rank-one-distribution-of-lorentz-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:lorentz-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:rank-one-distribution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:simple-eigenpair-of-index-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:smooth-eigen-selection]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
```

# thm:lorentz-metrics

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#thm:lorentz-metrics
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:lorentz-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:lorentz-metric-of-rank-one-distribution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:rank-one-distribution-of-lorentz-metric]]'
```

# lem:adapted-orthonormal-basis

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:adapted-orthonormal-basis
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:completion-nondegenerate-bases]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gram-schmidt-algorithm-scalar-products]]'
```

# lem:adapted-orthonormal-basis-line

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:adapted-orthonormal-basis-line
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-orthonormal-basis]]'
```

# lem:nondegenerate-line

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:nondegenerate-line
uses: []
```

# lem:hyperplane-nondegenerate

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:hyperplane-nondegenerate
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-subspace]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-line]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement]]'
```

# lem:orthonormal-tail-spans-orthogonal

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:orthonormal-tail-spans-orthogonal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement]]'
```

# lem:orthonormal-basis-orthogonal-complement

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:orthonormal-basis-orthogonal-complement
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthonormal-tail-spans-orthogonal]]'
```

# lem:orthogonal-complement-non-null-line-hyperplane

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:orthogonal-complement-non-null-line-hyperplane
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement]]'
```

# lem:orthogonal-complement-non-null-line-nondegenerate

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:orthogonal-complement-non-null-line-nondegenerate
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-subspace]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-orthonormal-basis-line]]'
```

# prop:hypersurface-signature-pointwise

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-signature-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:adapted-orthonormal-basis-line]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthonormal-basis-orthogonal-complement]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement-non-null-line-nondegenerate]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:sylvesters-law-inertia]]'
```

# lem:hyperplane-eq-complement-normal-line

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:hyperplane-eq-complement-normal-line
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement-involution]]'
```

# prop:hypersurface-signature-pointwise-hyperplane

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-signature-pointwise-hyperplane
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-signature-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hyperplane-eq-complement-normal-line]]'
```

# lem:pseudo-normal-space-eq-orthogonal

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-normal-space-eq-orthogonal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
```

# lem:hypersurface-tangent-hyperplane

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:hypersurface-tangent-hyperplane
uses: []
```

# lem:pseudo-normal-space-line

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-normal-space-line
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-normal-space-eq-orthogonal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hypersurface-tangent-hyperplane]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement]]'
```

# lem:line-sign-one-vector

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:line-sign-one-vector
uses: []
```

# lem:one-normal-decides-sign

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:one-normal-decides-sign
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-normal-space-line]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:line-sign-one-vector]]'
```

# lem:one-normal-decides-sign-neg

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:one-normal-decides-sign-neg
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-normal-space-line]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:line-sign-one-vector]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:one-normal-decides-sign]]'
```

# lem:exists-nonzero-normal

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:exists-nonzero-normal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-normal-space-line]]'
```

# lem:differential-isometry-tangent-range

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:differential-isometry-tangent-range
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-tensor-along-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-submanifold-immersion]]'
```

# lem:submanifold-signature-in-ambient-fibre

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:submanifold-signature-in-ambient-fibre
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-signature-at]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:differential-isometry-tangent-range]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:sylvesters-law-inertia]]'
```

# prop:pseudo-riemannian-hypersurface-nondegenerate

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:pseudo-riemannian-hypersurface-nondegenerate
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-normal-space-eq-orthogonal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hypersurface-tangent-hyperplane]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hyperplane-nondegenerate]]'
```

# prop:hypersurface-signature-at-a-point

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hypersurface-signature-at-a-point
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-has-signature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-tensor-along-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:submanifold-signature-in-ambient-fibre]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-signature-pointwise-hyperplane]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-normal-space-eq-orthogonal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hypersurface-tangent-hyperplane]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-submanifold-immersion]]'
```

# prop:pseudo-riemannian-hypersurface-signature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:pseudo-riemannian-hypersurface-signature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-has-signature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-tensor-along-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:exists-nonzero-normal]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-signature-at-a-point]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-submanifold-immersion]]'
```

# lem:pseudo-hypersurface-induced-tensor-nondegenerate

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-hypersurface-induced-tensor-nondegenerate
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-pullback-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:pseudo-riemannian-hypersurface-nondegenerate]]'
```

# cor:pseudo-riemannian-hypersurface-submanifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#cor:pseudo-riemannian-hypersurface-submanifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-has-signature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-induced-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-hypersurface-induced-tensor-nondegenerate]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-riemannian-submanifold-induced-tensor]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:pseudo-riemannian-hypersurface-signature]]'
```

# def:bilinear-gradient

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:bilinear-gradient
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# lem:bilinear-gradient-orthogonal-ker

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:bilinear-gradient-orthogonal-ker
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:bilinear-gradient]]'
```

# prop:embedding-criterion-pointwise

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:embedding-criterion-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:bilinear-gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:bilinear-gradient-orthogonal-ker]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-signature-pointwise-hyperplane]]'
```

# lem:embedding-criterion-nondegenerate-pointwise

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:embedding-criterion-nondegenerate-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:bilinear-gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:bilinear-gradient-orthogonal-ker]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hyperplane-eq-complement-normal-line]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthogonal-complement-non-null-line-nondegenerate]]'
```

# cor:pseudo-riemannian-embedding-criterion

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#cor:pseudo-riemannian-embedding-criterion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-has-signature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:embedding-criterion-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:bilinear-gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-hypersurface-codim-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:regular-level-set-tangent-kernel]]'
```

# lem:pullback-pseudo-metric-bundle

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pullback-pseudo-metric-bundle
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-field-scalar-products]]'
```

# def:induced-tensor-along-map

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:induced-tensor-along-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
```

# lem:pseudo-submanifold-immersion

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-submanifold-immersion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-tensor-along-map]]'
```

# lem:riemannian-submanifold-induced-tensor

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:riemannian-submanifold-induced-tensor
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-tensor-along-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-immersion-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-metric]]'
```

# def:bilinear-comp-of-family

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:bilinear-comp-of-family
uses: []
```

# lem:bilinear-comp-of-family-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:bilinear-comp-of-family-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:bilinear-comp-of-family]]'
```

# def:pullback-form-of-family

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pullback-form-of-family
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:bilinear-comp-of-family]]'
```

# lem:pullback-form-of-family-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pullback-form-of-family-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pullback-form-of-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:bilinear-comp-of-family-smooth]]'
```

# def:pseudo-pullback-form

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pseudo-pullback-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pullback-form-of-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
```

# lem:pseudo-pullback-form-symm

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-pullback-form-symm
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-pullback-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
```

# lem:pseudo-pullback-form-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-pullback-form-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-pullback-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-form-of-family-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-field-scalar-products]]'
```

# def:pseudo-induced-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pseudo-induced-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-pullback-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-pullback-form-symm]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-pullback-form-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:smooth-field-scalar-products]]'
```

# lem:pseudo-riemannian-submanifold-induced-tensor

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-riemannian-submanifold-induced-tensor
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-induced-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-pullback-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-tensor-along-map]]'
```

# lem:extend-nondegenerate-family

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:extend-nondegenerate-family
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:completion-nondegenerate-bases]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-tuple-independent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-tuple-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:sections-through-prescribed-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:open-nondegenerate-tuple]]'
```

# prop:pseudo-riemannian-adapted-frame

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:pseudo-riemannian-adapted-frame
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-tensor-along-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-pseudo-metric-bundle]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:orthonormal-frames-pseudo-riemannian]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:extend-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:orthonormalize-nondegenerate-family]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthonormal-tuple-nondegenerate]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-submanifold-immersion]]'
```

# def:pseudo-normal-space

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:pseudo-normal-space
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-pseudo-metric-bundle]]'
```

# lem:pseudo-normal-space-frame

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:pseudo-normal-space-frame
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:pseudo-riemannian-adapted-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthonormal-tuple-nondegenerate]]'
```

# cor:normal-bundle-pseudo-riemannian-submanifold

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#cor:normal-bundle-pseudo-riemannian-submanifold
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-normal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:pseudo-riemannian-adapted-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pseudo-normal-space-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#lem:local-frame-criterion-for-subbundles]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-riemannian-metric]]'
```

# prop:distance-preserving-map-linear-isometry

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:distance-preserving-map-linear-isometry
uses: []
```

# def:open-submanifold-metric

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:open-submanifold-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:mfderiv-open-inclusion]]'
```

# lem:mfderiv-open-inclusion

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:mfderiv-open-inclusion
uses: []
```

# lem:sphere-tangent-orthogonal-radius

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:sphere-tangent-orthogonal-radius
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:spheres]]'
```

# def:polar-map

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:polar-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:warped-product]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:spheres]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:open-submanifold-metric]]'
```

# lem:mfderiv-polar-map

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:mfderiv-polar-map
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:polar-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:mfderiv-open-inclusion]]'
```

# prop:warped-product-isometry

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:warped-product-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:warped-products]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:polar-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:mfderiv-polar-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:sphere-tangent-orthogonal-radius]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:open-submanifold-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:warped-product-constant-one]]'
```

# prop:grassmann-stiefel-manifolds

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:grassmann-stiefel-manifolds
uses: []
```

# prob:grassmann-stiefel-manifolds

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:grassmann-stiefel-manifolds
uses: []
```

# prop:gradient-characterization

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:gradient-characterization
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:regular-set]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-characterization]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:transversal-representative-eq-gradient]]'
```

# lem:transversal-representative-eq-gradient

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:transversal-representative-eq-gradient
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-characterization]]'
```

# def:inner-k-covectors

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:inner-k-covectors
uses: []
```

# lem:inner-k-covectors-posdef

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:inner-k-covectors-posdef
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
```

# lem:inner-k-covectors-wedge

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:inner-k-covectors-wedge
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#lem:alternating-cauchy-binet]]'
```

# lem:k-covector-wedge-expansion

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:k-covector-wedge-expansion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#lem:alternating-cauchy-binet]]'
```

# lem:span-wedge-covectors

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:span-wedge-covectors
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:k-covector-wedge-expansion]]'
```

# prop:inner-k-covectors-unique

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:inner-k-covectors-unique
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:span-wedge-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-k-covectors-wedge]]'
```

# prop:inner-k-covectors-frame-independent

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:inner-k-covectors-frame-independent
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-k-covectors-unique]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-k-covectors-wedge]]'
```

# def:fiber-metric-forms-pointwise

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:fiber-metric-forms-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-k-covectors-frame-independent]]'
```

# lem:fiber-metric-forms-inner-product

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:fiber-metric-forms-inner-product
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:fiber-metric-forms-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-k-covectors-posdef]]'
```

# lem:fiber-metric-forms-wedge

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:fiber-metric-forms-wedge
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:fiber-metric-forms-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-k-covectors-wedge]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sharp-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
```

# lem:fiber-metric-forms-unique-pointwise

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:fiber-metric-forms-unique-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:fiber-metric-forms-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-k-covectors-unique]]'
```

# lem:fiber-metric-forms-frame

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:fiber-metric-forms-frame
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:fiber-metric-forms-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-k-covectors-frame-independent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
```

# lem:form-field-applied-to-vector-fields-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:form-field-applied-to-vector-fields-smooth
uses: []
```

# lem:fiber-metric-forms-smooth

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:fiber-metric-forms-smooth
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:fiber-metric-forms-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:fiber-metric-forms-frame]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:form-field-applied-to-vector-fields-smooth]]'
```

# prop:fiber-metric-forms

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:fiber-metric-forms
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:fiber-metric-forms-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:fiber-metric-forms-inner-product]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:fiber-metric-forms-wedge]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:fiber-metric-forms-unique-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:fiber-metric-forms-smooth]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
```

# def:wedge-alternating-forms

```qprint
kind: definition
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#def:wedge-alternating-forms
uses: []
```

# lem:wedge-bilinear

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:wedge-bilinear
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-alternating-forms]]'
```

# lem:wedge-comm-sum

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:wedge-comm-sum
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-alternating-forms]]'
```

# lem:wedge-covectors-concat

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:wedge-covectors-concat
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-alternating-forms]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#lem:laplace-expansion-block]]'
```

# lem:hodge-scalar-identity

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:hodge-scalar-identity
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-alternating-forms]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-k-covectors-wedge]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#lem:perm-block-collapse]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#lem:perm-extension-count]]'
```

# prop:hodge-star-pointwise

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-pointwise
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hodge-scalar-identity]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:top-form-eq-of-basis]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-bilinear]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-comm-sum]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-k-covectors-posdef]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-k-covectors-frame-independent]]'
```

# prop:hodge-star-degree-zero

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-degree-zero
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-alternating-forms]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
```

# lem:hodge-star-reproducing

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:hodge-star-reproducing
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:k-covector-wedge-expansion]]'
```

# prop:hodge-star-isometry

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hodge-scalar-identity]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-comm-sum]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:k-covector-wedge-expansion]]'
```

# prop:hodge-star-involution

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-involution
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hodge-star-reproducing]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-comm-sum]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:k-covector-wedge-expansion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:top-form-eq-of-basis]]'
```

# prop:hodge-star-graded

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-graded
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-alternating-forms]]'
```

# lem:finrotate-pow-val

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:finrotate-pow-val
uses: []
```

# lem:blockswap-eq-rotate

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:blockswap-eq-rotate
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:finrotate-pow-val]]'
```

# prop:hodge-star-classical-involution

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-classical-involution
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-graded]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-involution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-covectors-sign]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:hodge-star-congr-smul]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:blockswap-eq-rotate]]'
```

# prop:hodge-star-operator

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-operator
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-graded]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-degree-zero]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-involution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-classical-involution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:fiber-metric-forms]]'
```

# lem:wedge-covectors-repeat-zero

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:wedge-covectors-repeat-zero
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
```

# prop:hodge-star-euclidean-single

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-euclidean-single
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-graded]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-covectors-sign]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-covectors-repeat-zero]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
```

# lem:wedge-covectors-sign

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:wedge-covectors-sign
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
```

# lem:hodge-star-congr-smul

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#lem:hodge-star-congr-smul
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
```

# prop:hodge-star-basis-wedge

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-basis-wedge
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-graded]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-covectors-sign]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:wedge-covectors-repeat-zero]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:wedge-covectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:inner-k-covectors]]'
```

# prop:hodge-star-two-involution

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-two-involution
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-classical-involution]]'
```

# prop:hodge-star-euclidean-pair

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:hodge-star-euclidean-pair
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-basis-wedge]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-two-involution]]'
```

# prop:self-dual-decomposition

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:self-dual-decomposition
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-two-involution]]'
```

# prop:self-dual-euclidean

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:self-dual-euclidean
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-euclidean-pair]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:self-dual-decomposition]]'
```

# prop:local-isometry-distance

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:local-isometry-distance
uses: []
```

# prop:arc-length-integral

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prop:arc-length-integral
uses: []
```

# prob:arc-length-integral

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:arc-length-integral
uses: []
```

# exer:characterize-local-isometry

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:characterize-local-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:local-isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:isometry]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:metric-preserving-equidim-local-diffeomorphism]]'
```

# exer:gram-schmidt-adapted-frame

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:gram-schmidt-adapted-frame
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:adapted-orthonormal-frames]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:slice-coordinates]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-orthonormal-frames]]'
```

# exer:horizontal-vector-field-not-lift

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:horizontal-vector-field-not-lift
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-space]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:horizontal-lift-tangent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:riemannian-submersions]]'
```

# exer:inverse-metric-ambiguity

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:inverse-metric-ambiguity
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:dual-coframe]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sharp-map]]'
```

# exer:isometry-preserves-volume-form

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:isometry-preserves-volume-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pullback-alternating]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:volume-form-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-uniqueness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:volume-form-value-one]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:orthonormal-pushforward]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:push-basis]]'
```

# exer:orthonormal-frames-and-coframes

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:orthonormal-frames-and-coframes
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#exer:inverse-metric-ambiguity]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:dual-coframe]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:sharp-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:frame-matrix]]'
```

# exer:orthonormal-frames-proposition

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:orthonormal-frames-proposition
uses: []
```

# exer:partition-unity-proof

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:partition-unity-proof
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:existence-riemannian-metric]]'
```

# exer:polarization-proof

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:polarization-proof
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:polarization-identity]]'
```

# exer:polarization-scalar-product

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:polarization-scalar-product
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#exer:polarization-proof]]'
```

# exer:preceding-lemma-nondegenerate

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:preceding-lemma-nondegenerate
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-subspace]]'
```

# exer:product-metric-torus

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:product-metric-torus
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:product-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:induced-metric]]'
```

# exer:product-pseudo-riemannian

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:product-pseudo-riemannian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-riemannian-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:pseudo-metric-has-signature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:product-metric]]'
```

# exer:prove-isometry-invariance

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:prove-isometry-invariance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:isometry-invariance-riemannian-distance]]'
```

# exer:prove-lemma-2-11

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:prove-lemma-2-11
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-immersion-metric]]'
```

# exer:prove-nondegenerate-equivalent

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:prove-nondegenerate-equivalent
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:nondegenerate-symmetric-bilinear]]'
```

# exer:prove-orthonormal-frames

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:prove-orthonormal-frames
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:orthonormal-frames-pseudo-riemannian]]'
```

# exer:prove-outward-normal

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:prove-outward-normal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#prop:induced-orientation-boundary]]'
```

# exer:prove-prop-247

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:prove-prop-247
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:length-additive]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:length-reparam-invariant]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:length-isometry-invariant]]'
```

# exer:riemannian-density-formula

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:riemannian-density-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-density]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:density-vector-space]]'
```

# exer:torus-covering

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:torus-covering
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:n-torus-riemannian-submanifold]]'
```

# exer:verify-surface-revolution-examples

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#exer:verify-surface-revolution-examples
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:metrics-in-graph-coordinates]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:surfaces-of-revolution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:n-torus-riemannian-submanifold]]'
```

# prob:codifferential-operator

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:codifferential-operator
uses: []
```

# prob:covering-volume-form

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:covering-volume-form
uses: []
```

# prob:curl-vector-field

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:curl-vector-field
uses: []
```

# prob:dirichlet-neumann-eigenvalues

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:dirichlet-neumann-eigenvalues
uses: []
```

# prob:dirichlet-principle

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:dirichlet-principle
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:divergence-theorem]]'
```

# prob:distance-disconnected-riemannian

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:distance-disconnected-riemannian
uses: []
```

# prob:distance-preserving-map-linear-isometry

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:distance-preserving-map-linear-isometry
uses: []
```

# prob:divergence-laplacian-formulas-ch2

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:divergence-laplacian-formulas-ch2
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:coordinate-representations-divergence-laplacian]]'
```

# prob:divergence-theorem

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:divergence-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#prop:orientation-covering-theorem]]'
```

# prob:eigenvalues

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:eigenvalues
uses: []
```

# prob:fiber-metric-exterior-powers

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:fiber-metric-exterior-powers
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:fiber-metric-forms]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-k-covectors-unique]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-k-covectors-frame-independent]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:inner-k-covectors-posdef]]'
```

# prob:gradient-characterization

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:gradient-characterization
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:gradient]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:regular-set]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-characterization]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:transversal-representative-eq-gradient]]'
```

# prob:gradient-orthogonal-level-sets

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:gradient-orthogonal-level-sets
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:regular-level-set-hypersurface]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:gradient-normal-regular-part]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:gradient-nonvanishing-regular-part]]'
```

# prob:harmonic-functions

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:harmonic-functions
uses: []
```

# prob:hodge-star-euclidean

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:hodge-star-euclidean
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-euclidean-single]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-euclidean-pair]]'
```

# prob:hodge-star-exterior-derivative

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:hodge-star-exterior-derivative
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:hodge-star-operator]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:curl-vector-field]]'
```

# prob:hodge-star-operator

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:hodge-star-operator
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-pointwise]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-graded]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-degree-zero]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-involution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hodge-star-classical-involution]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:fiber-metric-exterior-powers]]'
```

# prob:horizontal-vector-fields

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:horizontal-vector-fields
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:horizontal-lift-of-vector-field]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:horizontal-lift-realizes-horizontal-vector]]'
```

# prob:hypersurface-volume-form

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:hypersurface-volume-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-formula]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-if]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:hypersurface-volume-form-only-if]]'
```

# prob:inner-products-k-forms

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:inner-products-k-forms
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:fiber-metric-exterior-powers]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-products-of-tensors]]'
```

# prob:inner-products-tensor-bundles

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:inner-products-tensor-bundles
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:inner-products-of-tensors]]'
```

# prob:level-sets-pseudo-riemannian

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:level-sets-pseudo-riemannian
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#cor:pseudo-riemannian-embedding-criterion]]'
```

# prob:local-isometry-distance

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:local-isometry-distance
uses: []
```

# prob:lorentz-metric-existence

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:lorentz-metric-existence
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#thm:lorentz-metrics]]'
```

# prob:mobius-band-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:mobius-band-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:open-mobius-band]]'
```

# prob:riemannian-1-manifold-flat

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:riemannian-1-manifold-flat
uses: []
```

# prob:riemannian-metric-submersion

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:riemannian-metric-submersion
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#thm:group-action-riemannian-submersion]]'
```

# prob:riemannian-volume-form-existence

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:riemannian-volume-form-existence
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:riemannian-volume-form]]'
```

# prob:self-dual-anti-self-dual

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:self-dual-anti-self-dual
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:self-dual-decomposition]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:self-dual-euclidean]]'
```

# prob:surface-of-revolution-warped-product

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:surface-of-revolution-warped-product
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:warped-products]]'
```

# prob:sylvesters-law-inertia

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:sylvesters-law-inertia
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:sylvesters-law-inertia]]'
```

# prob:warped-product-isometry

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:warped-product-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:warped-products]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:polar-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:mfderiv-polar-map]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:sphere-tangent-orthogonal-radius]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:metric-preserving]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:open-submanifold-metric]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:warped-product-constant-one]]'
```

# prob:warped-product-volume-form

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter2.tex#prob:warped-product-volume-form
uses: []
```
