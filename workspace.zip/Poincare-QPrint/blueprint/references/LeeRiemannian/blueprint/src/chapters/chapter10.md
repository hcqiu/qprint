# thm:jacobi-equation

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#thm:jacobi-equation
uses: []
```

# prop:existence-uniqueness-jacobi-fields

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:existence-uniqueness-jacobi-fields
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:linear-ode-existence-uniqueness]]'
```

# cor:jacobi-space-dimension

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:jacobi-space-dimension
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:existence-uniqueness-jacobi-fields]]'
```

# prop:jacobi-field-variation-field

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:jacobi-field-variation-field
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:jacobi-equation]]'
```

# prop:local-isometry-invariance-jacobi-fields

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:local-isometry-invariance-jacobi-fields
uses: []
```

# prop:normal-jacobi-equivalent-conditions

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:normal-jacobi-equivalent-conditions
uses: []
```

# cor:jacobi-field-decomposition

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:jacobi-field-decomposition
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:jacobi-space-dimension]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:normal-jacobi-equivalent-conditions]]'
```

# lem:jacobi-field-variation

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#lem:jacobi-field-variation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:jacobi-field-variation-field]]'
```

# prop:jacobi-fields-vanishing-at-point

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:jacobi-fields-vanishing-at-point
uses: []
```

# cor:jacobi-field-tangent-vectors

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:jacobi-field-tangent-vectors
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:jacobi-fields-vanishing-at-point]]'
```

# prop:jacobi-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:jacobi-constant-curvature
uses: []
```

# lem:metric-relation-euclidean

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#lem:metric-relation-euclidean
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:warped-products]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:warped-product-isometry]]'
- '[[#UNRESOLVED:chA:2-4]]'
```

# thm:constant-curvature-normal-coords

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#thm:constant-curvature-normal-coords
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:minimizing-geodesic-unit-speed]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:jacobi-field-decomposition]]'
```

# cor:local-uniqueness-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:local-uniqueness-constant-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:constant-curvature-normal-coords]]'
```

# cor:constant-curvature-warped-products

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:constant-curvature-warped-products
uses: []
```

# cor:polar-decomposition-integrals

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:polar-decomposition-integrals
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:constant-curvature-warped-products]]'
```

# lem:locally-symmetric-cartan

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#lem:locally-symmetric-cartan
uses: []
```

# thm:characterization-locally-symmetric-spaces

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#thm:characterization-locally-symmetric-spaces
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:symmetric-space-parallel-curvature]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#lem:locally-symmetric-cartan]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prob:symmetric-space-parallel-curvature]]'
```

# prop:critical-points-conjugate

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:critical-points-conjugate
uses: []
```

# prop:two-point-boundary-problem

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:two-point-boundary-problem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:existence-uniqueness-jacobi-fields]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:jacobi-field-tangent-vectors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:critical-points-conjugate]]'
```

# thm:second-variation-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#thm:second-variation-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:first-variation-formula]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:curvature-commutator-failure]]'
```

# cor:second-variation-minimizing-geodesic

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:second-variation-minimizing-geodesic
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:second-variation-formula]]'
```

# prop:index-form-jacobi-equation

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:index-form-jacobi-equation
uses: []
```

# cor:jacobi-field-index-form

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:jacobi-field-index-form
uses: []
```

# thm:no-minimize-past-conjugate

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#thm:no-minimize-past-conjugate
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:minimizing-geodesic-unit-speed]]'
```

# lem:jacobi-field-constant-pairing

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#lem:jacobi-field-constant-pairing
uses: []
```

# thm:geodesic-without-conjugate-points

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#thm:geodesic-without-conjugate-points
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#lem:jacobi-field-constant-pairing]]'
```

# cor:conjugate-point-not-minimizing

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:conjugate-point-not-minimizing
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:no-minimize-past-conjugate]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:geodesic-without-conjugate-points]]'
```

# ex:cut-loci

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#ex:cut-loci
uses: []
```

# prop:properties-of-cut-times

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:properties-of-cut-times
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:no-minimize-past-conjugate]]'
```

# thm:cut-time-continuous

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#thm:cut-time-continuous
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:critical-points-conjugate]]'
```

# thm:cut-locus-properties

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#thm:cut-locus-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:cut-time-continuous]]'
```

# cor:compact-manifold-quotient

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#cor:compact-manifold-quotient
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:cut-locus-properties]]'
```

# prop:injectivity-radius-cut-locus

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:injectivity-radius-cut-locus
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:cut-locus-properties]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:radial-geodesic-unique-minimizer]]'
```

# prop:continuity-injectivity-radius

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prop:continuity-injectivity-radius
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:properties-of-cut-times]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#thm:cut-time-continuous]]'
```

# exer:prove-local-isometry-invariance

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#exer:prove-local-isometry-invariance
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:local-isometry-invariance-jacobi-fields]]'
```

# exer:verify-cut-loci-claims

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#exer:verify-cut-loci-claims
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#ex:cut-loci]]'
```

# prob:area-geodesic-disk

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:area-geodesic-disk
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:taylor-series-metric-tensor]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:associated-quadratic-form]]'
```

# prob:asymptotic-volume-geodesic-balls

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:asymptotic-volume-geodesic-balls
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:taylor-series-metric-tensor]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter8#prob:associated-quadratic-form]]'
```

# prob:cut-locus-flat-torus

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:cut-locus-flat-torus
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:n-torus-riemannian-submanifold]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#ex:n-torus-flat-metric]]'
```

# prob:cut-locus-homotopy-equivalence

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:cut-locus-homotopy-equivalence
uses: []
```

# prob:distance-cut-locus

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:distance-cut-locus
uses: []
```

# prob:focal-point-characterization

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:focal-point-characterization
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:transverse-jacobi-field]]'
```

# prob:frankel-geodesic-intersection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:frankel-geodesic-intersection
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:normal-variation-submanifolds]]'
```

# prob:injectivity-radius-exponential

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:injectivity-radius-exponential
uses: []
```

# prob:jacobi-fermi-transverse

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:jacobi-fermi-transverse
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:fermi-coordinates-properties]]'
```

# prob:jacobi-field-index-form

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:jacobi-field-index-form
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#cor:jacobi-field-index-form]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#thm:minimizing-geodesic-unit-speed]]'
```

# prob:jacobi-fields-constant-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:jacobi-fields-constant-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:jacobi-constant-curvature]]'
```

# prob:jacobi-semigeodetic-transverse

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:jacobi-semigeodetic-transverse
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prop:characterizations-semigeodetic-coordinates]]'
```

# prob:jacobi-warped-product

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:jacobi-warped-product
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:geodesic-warped-product]]'
```

# prob:killing-vector-jacobi-field

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:killing-vector-jacobi-field
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:killing-vector-field]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter6#prob:killing-vector-field-properties]]'
```

# prob:nonpositive-curvature-conjugate-points

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:nonpositive-curvature-conjugate-points
uses: []
```

# prob:nonpositive-curvature-focal-points

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:nonpositive-curvature-focal-points
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:nonpositive-curvature-conjugate-points]]'
```

# prob:normal-jacobi-minimizes-index

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:normal-jacobi-minimizes-index
uses: []
```

# prob:normal-variation-submanifolds

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:normal-variation-submanifolds
uses: []
```

# prob:tangent-vector-jacobi-normal-neighborhood

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:tangent-vector-jacobi-normal-neighborhood
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:jacobi-fermi-transverse]]'
```

# prob:taylor-series-metric-tensor

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:taylor-series-metric-tensor
uses: []
```

# prob:transverse-jacobi-field

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:transverse-jacobi-field
uses: []
```

# prob:two-point-boundary-problem

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:two-point-boundary-problem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prop:two-point-boundary-problem]]'
```

# prob:volume-euclidean-balls

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:volume-euclidean-balls
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter10#prob:volume-formula-spheres]]'
```

# prob:volume-formula-spheres

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter10.tex#prob:volume-formula-spheres
uses: []
```
