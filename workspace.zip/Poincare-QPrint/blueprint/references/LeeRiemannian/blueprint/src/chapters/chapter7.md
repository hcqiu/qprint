# ex:n-torus-flat-metric

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#ex:n-torus-flat-metric
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#ex:n-torus-riemannian-submanifold]]'
```

# prop:flat-manifold-levi-civita-flatness

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:flat-manifold-levi-civita-flatness
uses: []
```

# prop:curvature-multilinearity

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:curvature-multilinearity
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixB#lem:tensor-characterization-lemma]]'
```

# prop:curvature-tensor-components

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:curvature-tensor-components
uses: []
```

# prop:curvature-commutator-failure

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:curvature-commutator-failure
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:connection-on-tensor-bundles]]'
```

# prop:curvature-isometry-invariant

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:curvature-isometry-invariant
uses: []
```

# lem:parallel-vector-field-flatness

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#lem:parallel-vector-field-flatness
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:linear-ode-existence-uniqueness]]'
```

# thm:flatness-iff-zero-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#thm:flatness-iff-zero-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:flat-manifold-levi-civita-flatness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:parallel-vector-field-flatness]]'
```

# thm:curvature-endomorphism-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#thm:curvature-endomorphism-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#thm:linear-ode-existence-uniqueness]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:curvature-commutator-failure]]'
```

# prop:curvature-tensor-symmetries

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:curvature-tensor-symmetries
uses: []
```

# prop:differential-bianchi-identity

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:differential-bianchi-identity
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:properties-normal-coordinates]]'
```

# thm:ricci-identities

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#thm:ricci-identities
uses: []
```

# lem:ricci-symmetries

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#lem:ricci-symmetries
uses: []
```

# prop:ricci-tensor-decomposition

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:ricci-tensor-decomposition
uses: []
```

# prop:contracted-bianchi-identities

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:contracted-bianchi-identities
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:ricci-symmetries]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prop:connection-on-tensor-bundles]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:musical-isomorphisms-commute]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prop:exterior-derivative-covariant-formula]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:exterior-derivative-covariant-formula]]'
```

# prop:schur-lemma

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:schur-lemma
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:contracted-bianchi-identities]]'
```

# cor:einstein-zero-ricci

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#cor:einstein-zero-ricci
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:schur-lemma]]'
```

# prop:dim-algebraic-curvature-tensors

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:dim-algebraic-curvature-tensors
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:curvature-tensor-symmetries]]'
```

# lem:kulkarni-nomizu-properties

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#lem:kulkarni-nomizu-properties
uses: []
```

# prop:right-inverse-trace

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:right-inverse-trace
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:kulkarni-nomizu-properties]]'
```

# prop:weyl-decomposition

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:weyl-decomposition
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:right-inverse-trace]]'
```

# cor:curvature-space-dimensions

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#cor:curvature-space-dimensions
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:dim-algebraic-curvature-tensors]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:kulkarni-nomizu-properties]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:right-inverse-trace]]'
```

# cor:ricci-determines-curvature-dim3

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#cor:ricci-determines-curvature-dim3
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:curvature-space-dimensions]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:weyl-decomposition]]'
```

# cor:curvature-tensor-dim-2

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#cor:curvature-tensor-dim-2
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:curvature-space-dimensions]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:kulkarni-nomizu-properties]]'
```

# prop:ricci-decomposition

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:ricci-decomposition
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:curvature-tensor-dim-2]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:kulkarni-nomizu-properties]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:ricci-tensor-decomposition]]'
```

# prop:conformal-transformation-levi-civita

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:conformal-transformation-levi-civita
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#thm:fundamental-theorem-riemannian-geometry]]'
```

# thm:conformal-transformation-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#thm:conformal-transformation-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:conformal-transformation-levi-civita]]'
```

# cor:weyl-zero-locally-conformally-flat

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#cor:weyl-zero-locally-conformally-flat
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#thm:conformal-transformation-curvature]]'
```

# prop:trace-covariant-derivative-weyl

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:trace-covariant-derivative-weyl
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:contracted-bianchi-identities]]'
```

# cor:weyl-cotton-vanish-dimension-4

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#cor:weyl-cotton-vanish-dimension-4
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:trace-covariant-derivative-weyl]]'
```

# prop:conformal-invariance-cotton-dim3

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:conformal-invariance-cotton-dim3
uses: []
```

# cor:cotton-tensor-vanishes-conformally-flat

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#cor:cotton-tensor-vanishes-conformally-flat
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:conformal-invariance-cotton-dim3]]'
```

# thm:weyl-schouten

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#thm:weyl-schouten
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:weyl-zero-locally-conformally-flat]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:cotton-tensor-vanishes-conformally-flat]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:ricci-determines-curvature-dim3]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:weyl-cotton-vanish-dimension-4]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:overdetermined-covector-system]]'
```

# lem:overdetermined-covector-system

```qprint
kind: lemma
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#lem:overdetermined-covector-system
uses: []
```

# prop:symmetric-space-parallel-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:symmetric-space-parallel-curvature
uses: []
```

# prob:symmetric-space-parallel-curvature

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:symmetric-space-parallel-curvature
uses: []
```

# prop:product-metric-curvature

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:product-metric-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#lem:pullback-immersion-metric]]'
```

# prob:product-metric-curvature

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:product-metric-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#exer:prove-lemma-2-11]]'
```

# prop:oneill-formula

```qprint
kind: theorem
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prop:oneill-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#def:riemannian-submersion]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prop:horizontal-lift-of-vector-field]]'
```

# prob:oneill-formula

```qprint
kind: proof
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:oneill-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:riemannian-submersion-connection]]'
```

# exer:constructed-vector-field-smooth

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#exer:constructed-vector-field-smooth
uses: []
```

# exer:prove-cotton-tensor-vanishes

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#exer:prove-cotton-tensor-vanishes
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#cor:cotton-tensor-vanishes-conformally-flat]]'
```

# exer:prove-curvature-isometry

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#exer:prove-curvature-isometry
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:curvature-isometry-invariant]]'
```

# exer:ricci-symmetries-proof

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#exer:ricci-symmetries-proof
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:ricci-symmetries]]'
```

# prob:bochner-formula

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:bochner-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#exer:hilbert-axioms-euclidean-plane]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#thm:ricci-identities]]'
```

# prob:cartan-second-structure-equation

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:cartan-second-structure-equation
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter4#prob:connection-1forms-cartan]]'
```

# prob:conformal-laplacian-yamabe

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:conformal-laplacian-yamabe
uses: []
```

# prob:cotton-tensor-conformal

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:cotton-tensor-conformal
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:conformal-invariance-cotton-dim3]]'
```

# prob:curvature-coordinate-formula

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:curvature-coordinate-formula
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:curvature-tensor-components]]'
```

# prob:curvature-multilinearity-in-functions

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:curvature-multilinearity-in-functions
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prop:curvature-multilinearity]]'
```

# prob:flat-connection

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:flat-connection
uses: []
```

# prob:kulkarni-nomizu-properties

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:kulkarni-nomizu-properties
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#lem:kulkarni-nomizu-properties]]'
```

# prob:lichnerowicz-theorem

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:lichnerowicz-theorem
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter2#prob:harmonic-functions]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:eigenfunction-laplacian-inequality]]'
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter7#prob:bochner-formula]]'
```

# prob:lie-group-curvature

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:lie-group-curvature
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/chapter5#prob:lie-group-bi-invariant-metric]]'
```

# prob:pseudo-riemannian-2d

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:pseudo-riemannian-2d
uses:
- '[[references/LeeRiemannian/blueprint/src/chapters/appendixA#prop:canonical-form-vector-field]]'
```

# prob:ricci-in-normal-coordinates

```qprint
kind: other
status: not_started
tex: references/LeeRiemannian/blueprint/src/chapters/chapter7.tex#prob:ricci-in-normal-coordinates
uses: []
```
