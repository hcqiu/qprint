---
title: references/HanLinLectureNotes
---

## Blueprint

- [[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.md]]
- [[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.md]]
- [[references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.md]]
- [[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.md]]
- [[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.md]]
