# hanlin:weaksol-part2-local-boundedness

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-local-boundedness
uses: []
```

# hanlin:weaksol-part2-bounded-test-function

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-bounded-test-function
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-local-boundedness]]'
```

# hanlin:weaksol-part2-iteration-lemma

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-iteration-lemma
uses: []
```

# hanlin:weaksol-part2-high-integrability

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-high-integrability
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-local-boundedness]]'
```

# hanlin:weaksol-part2-homogeneous-subsolution

```qprint
kind: definition
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-homogeneous-subsolution
uses: []
```

# hanlin:weaksol-part2-convex-composition

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-convex-composition
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-homogeneous-subsolution]]'
```

# hanlin:weaksol-part2-positive-part-subsolution

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-positive-part-subsolution
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-convex-composition]]'
```

# hanlin:weaksol-part2-poincare-sobolev-zero-set

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-poincare-sobolev-zero-set
uses: []
```

# hanlin:weaksol-part2-density-theorem

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-density-theorem
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-local-boundedness]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-convex-composition]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-poincare-sobolev-zero-set]]'
```

# hanlin:weaksol-part2-oscillation-decay

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-oscillation-decay
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-density-theorem]]'
```

# hanlin:weaksol-part2-degiorgi-holder

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-degiorgi-holder
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-local-boundedness]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-oscillation-decay]]'
```

# hanlin:weaksol-part2-energy-decay

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-energy-decay
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-degiorgi-holder]]'
```

# hanlin:weaksol-part2-general-linear-holder

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-general-linear-holder
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i#hanlin:weaksol-part1-holder-sol]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-energy-decay]]'
```

# hanlin:weaksol-part2-scaled-local-boundedness

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-scaled-local-boundedness
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-local-boundedness]]'
```

# hanlin:weaksol-part2-weak-harnack

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-weak-harnack
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i#hanlin:weaksol-part1-john-nirenberg]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-local-boundedness]]'
```

# hanlin:weaksol-part2-moser-harnack

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-moser-harnack
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-scaled-local-boundedness]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-weak-harnack]]'
```

# hanlin:weaksol-part2-moser-holder

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-moser-holder
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-scaled-local-boundedness]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-moser-harnack]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-oscillation-iteration]]'
```

# hanlin:weaksol-part2-oscillation-iteration

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-oscillation-iteration
uses: []
```

# hanlin:weaksol-part2-liouville

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-liouville
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-moser-holder]]'
```

# hanlin:weaksol-part2-nonlinear-counterexample

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-nonlinear-counterexample
uses: []
```

# hanlin:weaksol-part2-nonlinear-harnack

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-nonlinear-harnack
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-scaled-local-boundedness]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-weak-harnack]]'
```

# hanlin:weaksol-part2-nonlinear-gradient-estimate

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-nonlinear-gradient-estimate
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-nonlinear-harnack]]'
```

# hanlin:weaksol-part2-nonlinear-holder

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-nonlinear-holder
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-moser-holder]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-nonlinear-harnack]]'
```

# hanlin:weaksol-part2-nonlinear-gradient-holder

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii.tex#hanlin:weaksol-part2-nonlinear-gradient-holder
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i#hanlin:weaksol-part1-campanato]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i#hanlin:weaksol-part1-lemma-3-4]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i#hanlin:weaksol-part1-harmonic-lemma]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i#hanlin:weaksol-part1-grad-holder]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-nonlinear-gradient-estimate]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch04-weak-solutions-part-ii#hanlin:weaksol-part2-nonlinear-holder]]'
```
