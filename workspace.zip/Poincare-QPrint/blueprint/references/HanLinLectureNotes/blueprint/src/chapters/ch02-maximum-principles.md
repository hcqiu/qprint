# hanlin:maxprin-section-2-1

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-section-2-1
uses: []
```

# hanlin:maxprin-lemma-2-1

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-lemma-2-1
uses: []
```

# hanlin:maxprin-remark-2-2

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-2
uses: []
```

# hanlin:maxprin-lemma-2-3

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-lemma-2-3
uses: []
```

# hanlin:maxprin-remark-2-4

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-4
uses: []
```

# hanlin:maxprin-example-2-5

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-example-2-5
uses: []
```

# hanlin:maxprin-theorem-2-6

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-6
uses: []
```

# hanlin:maxprin-remark-2-7

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-7
uses: []
```

# hanlin:maxprin-theorem-2-8

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-8
uses: []
```

# hanlin:maxprin-cor-2-9

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-cor-2-9
uses: []
```

# hanlin:maxprin-cor-2-10

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-cor-2-10
uses: []
```

# hanlin:maxprin-cor-2-11

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-cor-2-11
uses: []
```

# hanlin:maxprin-theorem-2-12

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-12
uses: []
```

# hanlin:maxprin-theorem-2-13

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-13
uses: []
```

# hanlin:maxprin-remark-2-14

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-14
uses: []
```

# hanlin:maxprin-prop-2-15

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-prop-2-15
uses: []
```

# hanlin:maxprin-remark-2-16

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-16
uses: []
```

# hanlin:maxprin-section-2-2

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-section-2-2
uses: []
```

# hanlin:poisson-lemma-2-17

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:poisson-lemma-2-17
uses: []
```

# hanlin:poisson-lemma-2-18

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:poisson-lemma-2-18
uses: []
```

# hanlin:maxprin-lemma-2-19

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-lemma-2-19
uses: []
```

# hanlin:maxprin-theorem-2-20

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-20
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-lemma-2-19]]'
```

# hanlin:maxprin-theorem-2-21

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-21
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-lemma-2-22]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-theorem-2-13]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-theorem-2-6]]'
```

# hanlin:maxprin-lemma-2-22

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-lemma-2-22
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-theorem-2-21]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-theorem-2-6]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-lemma-2-22]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-theorem-2-13]]'
```

# hanlin:maxprin-remark-2-23

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-23
uses: []
```

# hanlin:maxprin-section-2-3

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-section-2-3
uses: []
```

# hanlin:maxprin-theorem-2-24

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-24
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-cor-2-9]]'
```

# hanlin:maxprin-theorem-2-25

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-25
uses: []
```

# hanlin:maxprin-remark-2-26

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-26
uses: []
```

# hanlin:maxprin-section-2-4

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-section-2-4
uses: []
```

# hanlin:maxprin-theorem-2-27

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-27
uses: []
```

# hanlin:maxprin-prop-2-28

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-prop-2-28
uses: []
```

# hanlin:maxprin-prop-2-29

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-prop-2-29
uses: []
```

# hanlin:maxprin-section-2-5

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-section-2-5
uses: []
```

# hanlin:maxprin-theorem-2-30

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-30
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-lemma-2-33]]'
```

# hanlin:maxprin-remark-2-31

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-31
uses: []
```

# hanlin:maxprin-remark-2-32

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-32
uses: []
```

# hanlin:maxprin-lemma-2-33

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-lemma-2-33
uses: []
```

# hanlin:maxprin-remark-2-34

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-34
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-lemma-2-33]]'
```

# hanlin:maxprin-remark-2-35

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-remark-2-35
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-lemma-2-33]]'
```

# hanlin:maxprin-theorem-2-36

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-36
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles#hanlin:maxprin-lemma-2-33]]'
```

# hanlin:maxprin-example-2-37

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-example-2-37
uses: []
```

# hanlin:maxprin-cor-2-38

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-cor-2-38
uses: []
```

# hanlin:maxprin-theorem-2-39

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-39
uses: []
```

# hanlin:maxprin-cor-2-40

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-cor-2-40
uses: []
```

# hanlin:maxprin-cor-2-41

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-cor-2-41
uses: []
```

# hanlin:maxprin-theorem-2-42

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-42
uses: []
```

# hanlin:maxprin-section-2-6

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-section-2-6
uses: []
```

# hanlin:maxprin-theorem-2-43

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-theorem-2-43
uses: []
```

# hanlin:maxprin-lemma-2-44

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch02-maximum-principles.tex#hanlin:maxprin-lemma-2-44
uses: []
```
