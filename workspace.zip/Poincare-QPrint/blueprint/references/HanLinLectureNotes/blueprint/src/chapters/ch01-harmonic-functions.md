# hanlin:def-mean-value-properties

```qprint
kind: definition
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:def-mean-value-properties
uses: []
```

# hanlin:remark-mean-value-equivalent

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-mean-value-equivalent
uses: []
```

# hanlin:remark-mean-value-equivalent-forms

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-mean-value-equivalent-forms
uses: []
```

# hanlin:thm-mean-value-max

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-mean-value-max
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:def-mean-value-properties]]'
```

# hanlin:def-harmonic

```qprint
kind: definition
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:def-harmonic
uses: []
```

# hanlin:thm-harmonic-mean-value

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-harmonic-mean-value
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:def-mean-value-properties]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:def-harmonic]]'
```

# hanlin:remark-mvp-not-smooth

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-mvp-not-smooth
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-harmonic-mean-value]]'
```

# hanlin:thm-mean-value-harmonic

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-mean-value-harmonic
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:def-mean-value-properties]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-harmonic-mean-value]]'
```

# hanlin:remark-mvp-harmonic-smooth

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-mvp-harmonic-smooth
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-mean-value-max]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-harmonic-mean-value]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-mean-value-harmonic]]'
```

# hanlin:lemma-interior-gradient-1

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-interior-gradient-1
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-harmonic-mean-value]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-interior-gradient-2]]'
```

# hanlin:lemma-interior-gradient-2

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-interior-gradient-2
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-harmonic-mean-value]]'
```

# hanlin:corollary-liouville

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:corollary-liouville
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-interior-gradient-2]]'
```

# hanlin:lemma-higher-derivative-estimate

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-higher-derivative-estimate
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-interior-gradient-1]]'
```

# hanlin:thm-harmonic-analytic

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-harmonic-analytic
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-higher-derivative-estimate]]'
```

# hanlin:thm-harnack

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-harnack
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-harmonic-mean-value]]'
```

# hanlin:thm-distributional-harmonic

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-distributional-harmonic
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-mean-value-harmonic]]'
```

# hanlin:thm-green-identity

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-green-identity
uses: []
```

# hanlin:remark-green-identity

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-green-identity
uses: []
```

# hanlin:remark-local-green-gradient

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-local-green-gradient
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-green-identity]]'
```

# hanlin:lemma-green-symmetric

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-green-symmetric
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-green-identity]]'
```

# hanlin:prop-green-sign

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:prop-green-sign
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-mean-value-max]]'
```

# hanlin:thm-green-ball

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-green-ball
uses: []
```

# hanlin:cor-green-normal-derivative

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:cor-green-normal-derivative
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-green-ball]]'
```

# hanlin:thm-poisson-dirichlet

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-poisson-dirichlet
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:cor-green-normal-derivative]]'
```

# hanlin:remark-poisson-mean-value

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-poisson-mean-value
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-poisson-dirichlet]]'
```

# hanlin:lemma-harnack-ball

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-harnack-ball
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-poisson-dirichlet]]'
```

# hanlin:corollary-liouville-poisson

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:corollary-liouville-poisson
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-harnack-ball]]'
```

# hanlin:thm-removable-singularity

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-removable-singularity
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-mean-value-max]]'
```

# hanlin:thm-subharmonic-max

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-subharmonic-max
uses: []
```

# hanlin:corollary-comparison-principle

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:corollary-comparison-principle
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-subharmonic-max]]'
```

# hanlin:remark-maxprin-domain

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-maxprin-domain
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-subharmonic-max]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:corollary-comparison-principle]]'
```

# hanlin:thm-interior-gradient

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-interior-gradient
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-subharmonic-max]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-interior-gradient-1]]'
```

# hanlin:lemma-log-gradient

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-log-gradient
uses: []
```

# hanlin:corollary-harnack-ball

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:corollary-harnack-ball
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-log-gradient]]'
```

# hanlin:thm-hopf

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:thm-hopf
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-subharmonic-max]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:corollary-harnack-ball]]'
```

# hanlin:lemma-holder-boundary

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-holder-boundary
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:corollary-comparison-principle]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:thm-interior-gradient]]'
```

# hanlin:lemma-caccioppoli

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-caccioppoli
uses: []
```

# hanlin:cor-caccioppoli-balls

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:cor-caccioppoli-balls
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-caccioppoli]]'
```

# hanlin:cor-energy-decay

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:cor-energy-decay
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-caccioppoli]]'
```

# hanlin:remark-finite-energy-liouville

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-finite-energy-liouville
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:cor-energy-decay]]'
```

# hanlin:remark-iterated-energy-decay

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:remark-iterated-energy-decay
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-caccioppoli]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:cor-energy-decay]]'
```

# hanlin:lemma-constant-coeff-compactness

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions.tex#hanlin:lemma-constant-coeff-compactness
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:cor-caccioppoli-balls]]'
```
