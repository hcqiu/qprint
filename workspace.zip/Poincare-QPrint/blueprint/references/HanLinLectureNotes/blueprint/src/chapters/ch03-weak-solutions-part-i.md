# hanlin:weaksol-part1-campanato

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-campanato
uses: []
```

# hanlin:weaksol-part1-morrey

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-morrey
uses: []
```

# hanlin:weaksol-part1-lemma-3-3

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-lemma-3-3
uses: []
```

# hanlin:weaksol-part1-lemma-3-4

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-lemma-3-4
uses: []
```

# hanlin:weaksol-part1-john-nirenberg

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-john-nirenberg
uses: []
```

# hanlin:weaksol-part1-bmo

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-bmo
uses: []
```

# hanlin:weaksol-part1-cz

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-cz
uses: []
```

# hanlin:weaksol-part1-holder-sol

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-holder-sol
uses: []
```

# hanlin:weaksol-part1-harmonic-lemma

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-harmonic-lemma
uses: []
```

# hanlin:weaksol-part1-cor-3-10

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-cor-3-10
uses: []
```

# hanlin:weaksol-part1-grad-holder

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-grad-holder
uses: []
```

# hanlin:weaksol-part1-example-3-12

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i.tex#hanlin:weaksol-part1-example-3-12
uses: []
```
