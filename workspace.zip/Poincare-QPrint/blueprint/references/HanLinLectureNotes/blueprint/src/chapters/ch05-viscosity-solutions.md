# hanlin:ch05-def-5-1

```qprint
kind: definition
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-def-5-1
uses: []
```

# hanlin:ch05-rem-5-2

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-rem-5-2
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-def-5-1]]'
```

# hanlin:ch05-rem-5-3

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-rem-5-3
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-def-5-1]]'
```

# hanlin:ch05-def-5-4

```qprint
kind: definition
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-def-5-4
uses: []
```

# hanlin:ch05-rem-5-5

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-rem-5-5
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-def-5-4]]'
```

# hanlin:ch05-ex-5-6

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-ex-5-6
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-def-5-4]]'
```

# hanlin:ch05-lem-5-7

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-7
uses: []
```

# hanlin:ch05-thm-5-8

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-thm-5-8
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-def-5-4]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-7]]'
```

# hanlin:ch05-lem-5-9

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-9
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch03-weak-solutions-part-i#hanlin:weaksol-part1-cz]]'
```

# hanlin:ch05-thm-5-10

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-thm-5-10
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-12]]'
```

# hanlin:ch05-cor-5-11

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-cor-5-11
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-thm-5-10]]'
```

# hanlin:ch05-lem-5-12

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-12
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-13]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-14]]'
```

# hanlin:ch05-lem-5-13

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-13
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-def-5-4]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-thm-5-8]]'
```

# hanlin:ch05-lem-5-14

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-14
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-9]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-13]]'
```

# hanlin:ch05-lem-5-15

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-15
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-9]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-16]]'
```

# hanlin:ch05-lem-5-16

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-16
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-13]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-thm-5-8]]'
```

# hanlin:ch05-rem-5-17

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-rem-5-17
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-15]]'
```

# hanlin:ch05-lem-5-18

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-18
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-thm-5-8]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-cor-5-11]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch01-harmonic-functions#hanlin:lemma-holder-boundary]]'
```

# hanlin:ch05-def-5-19

```qprint
kind: definition
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-def-5-19
uses: []
```

# hanlin:ch05-thm-5-20

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-thm-5-20
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-def-5-19]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-18]]'
```

# hanlin:ch05-thm-5-21

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-thm-5-21
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-thm-5-20]]'
```

# hanlin:ch05-thm-5-22

```qprint
kind: theorem
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-thm-5-22
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-23]]'
```

# hanlin:ch05-lem-5-23

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-23
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-15]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-24]]'
```

# hanlin:ch05-lem-5-24

```qprint
kind: lemma
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-lem-5-24
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-15]]'
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-18]]'
```

# hanlin:ch05-rem-5-25

```qprint
kind: other
status: not_started
tex: references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions.tex#hanlin:ch05-rem-5-25
uses:
- '[[references/HanLinLectureNotes/blueprint/src/chapters/ch05-viscosity-solutions#hanlin:ch05-lem-5-24]]'
```
