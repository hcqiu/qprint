# ch:chow-ii-perelman-differential-harnack

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#ch:chow-ii-perelman-differential-harnack
uses: []
```

# def:chow-ii-ch16-heat-log-density

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#def:chow-ii-ch16-heat-log-density
uses: []
```

# thm:chow-ii-ch16-li-yau

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-li-yau
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-heat-log-density]]'
```

# thm:chow-ii-ch16-cheeger-yau

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-cheeger-yau
uses: []
```

# thm:chow-ii-ch16-heat-kernel-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-heat-kernel-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-heat-log-density]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#thm:chow-ii-ch16-cheeger-yau]]'
```

# def:chow-ii-ch16-linear-entropy

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#def:chow-ii-ch16-linear-entropy
uses: []
```

# thm:chow-ii-ch16-linear-entropy-formula

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-linear-entropy-formula
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-linear-entropy]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-heat-log-density]]'
```

# thm:chow-ii-ch16-heat-parametrix

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-heat-parametrix
uses: []
```

# def:chow-ii-ch16-avr

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#def:chow-ii-ch16-avr
uses: []
```

# thm:chow-ii-ch16-heat-upper-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-heat-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-avr]]'
```

# cor:chow-ii-ch16-heat-integrability

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#cor:chow-ii-ch16-heat-integrability
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#thm:chow-ii-ch16-heat-upper-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#thm:chow-ii-ch16-cheeger-yau]]'
```

# thm:chow-ii-ch16-hamilton-heat-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-hamilton-heat-estimates
uses: []
```

# thm:chow-ii-ch16-complete-heat-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-complete-heat-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#thm:chow-ii-ch16-linear-entropy-formula]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#cor:chow-ii-ch16-heat-integrability]]'
```

# cor:chow-ii-ch16-entropy-rigidity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#cor:chow-ii-ch16-entropy-rigidity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#thm:chow-ii-ch16-complete-heat-harnack]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#thm:chow-ii-ch16-linear-entropy-formula]]'
```

# def:chow-ii-ch16-euclidean-log-sobolev

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#def:chow-ii-ch16-euclidean-log-sobolev
uses: []
```

# thm:chow-ii-ch16-bakry-concordet-ledoux

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-bakry-concordet-ledoux
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-euclidean-log-sobolev]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#cor:chow-ii-ch16-entropy-rigidity]]'
```

# thm:chow-ii-ch16-entropy-avr

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-entropy-avr
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-avr]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-linear-entropy]]'
```

# def:chow-ii-ch16-heat-cutoff

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#def:chow-ii-ch16-heat-cutoff
uses: []
```

# thm:chow-ii-ch16-local-linear-entropy

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-local-linear-entropy
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-heat-cutoff]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#thm:chow-ii-ch16-complete-heat-harnack]]'
```

# def:chow-ii-ch16-adjoint-heat-kernel

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#def:chow-ii-ch16-adjoint-heat-kernel
uses: []
```

# thm:chow-ii-ch16-perelman-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-perelman-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-adjoint-heat-kernel]]'
```

# thm:chow-ii-ch16-adjoint-parametrix

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-adjoint-parametrix
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-adjoint-heat-kernel]]'
```

# lem:chow-ii-ch16-reduced-distance-subsolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#lem:chow-ii-ch16-reduced-distance-subsolution
uses: []
```

# lem:chow-ii-ch16-adjoint-dominates-reduced

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#lem:chow-ii-ch16-adjoint-dominates-reduced
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-adjoint-heat-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#lem:chow-ii-ch16-reduced-distance-subsolution]]'
```

# thm:chow-ii-ch16-reduced-distance-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-reduced-distance-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#def:chow-ii-ch16-adjoint-heat-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#lem:chow-ii-ch16-adjoint-dominates-reduced]]'
```

# thm:chow-ii-ch16-localized-perelman-entropy

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack.tex#thm:chow-ii-ch16-localized-perelman-entropy
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch16-perelman-differential-harnack#thm:chow-ii-ch16-perelman-harnack]]'
```
