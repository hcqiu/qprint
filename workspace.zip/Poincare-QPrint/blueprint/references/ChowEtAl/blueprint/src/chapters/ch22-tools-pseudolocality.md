# ch:chow-iii-tools-pseudolocality

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#ch:chow-iii-tools-pseudolocality
uses: []
```

# def:chow-iii-alpha-small-large-curvature

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#def:chow-iii-alpha-small-large-curvature
uses: []
```

# lem:chow-iii-large-curvature-local-control

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#lem:chow-iii-large-curvature-local-control
uses: []
```

# clm:chow-iii-point-picking-claim-one

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#clm:chow-iii-point-picking-claim-one
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#def:chow-iii-alpha-small-large-curvature]]'
```

# rem:chow-iii-point-picking-compactness

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#rem:chow-iii-point-picking-compactness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#clm:chow-iii-point-picking-claim-one]]'
```

# lem:chow-iii-point-picking-subset

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#lem:chow-iii-point-picking-subset
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#clm:chow-iii-point-picking-claim-one]]'
```

# clm:chow-iii-point-picking-claim-two

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#clm:chow-iii-point-picking-claim-two
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#clm:chow-iii-point-picking-claim-one]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#lem:chow-iii-point-picking-local-cylinder]]'
```

# lem:chow-iii-point-picking-local-cylinder

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#lem:chow-iii-point-picking-local-cylinder
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#clm:chow-iii-point-picking-claim-one]]'
```

# lem:chow-iii-heat-kernel-cheeger-gromov

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#lem:chow-iii-heat-kernel-cheeger-gromov
uses: []
```

# rem:chow-iii-heat-kernel-minimality

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#rem:chow-iii-heat-kernel-minimality
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#lem:chow-iii-heat-kernel-cheeger-gromov]]'
```

# lem:chow-iii-time-dependent-cutoff

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#lem:chow-iii-time-dependent-cutoff
uses: []
```

# lem:chow-iii-local-entropy-upper-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#lem:chow-iii-local-entropy-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#lem:chow-iii-time-dependent-cutoff]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#clm:chow-iii-point-picking-claim-two]]'
```

# def:chow-iii-log-sobolev

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#def:chow-iii-log-sobolev
uses: []
```

# thm:chow-iii-euclidean-log-sobolev

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#thm:chow-iii-euclidean-log-sobolev
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#def:chow-iii-log-sobolev]]'
```

# thm:chow-iii-log-sobolev-isoperimetric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#thm:chow-iii-log-sobolev-isoperimetric
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#thm:chow-iii-euclidean-log-sobolev]]'
```

# rem:chow-iii-log-sobolev-coarea

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#rem:chow-iii-log-sobolev-coarea
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#thm:chow-iii-log-sobolev-isoperimetric]]'
```

# thm:chow-iii-local-log-sobolev

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#thm:chow-iii-local-log-sobolev
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#thm:chow-iii-log-sobolev-isoperimetric]]'
```

# thm:chow-iii-backward-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#thm:chow-iii-backward-uniqueness
uses: []
```

# cor:chow-iii-isometry-group-preserved

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#cor:chow-iii-isometry-group-preserved
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#thm:chow-iii-backward-uniqueness]]'
```

# rem:chow-iii-canonical-surgery-criterion

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality.tex#rem:chow-iii-canonical-surgery-criterion
uses: []
```
