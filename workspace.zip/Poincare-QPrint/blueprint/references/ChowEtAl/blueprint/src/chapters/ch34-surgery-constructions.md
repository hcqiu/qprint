# ch:chow-iv-cmc-surfaces-harmonic-maps-ift

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#ch:chow-iv-cmc-surfaces-harmonic-maps-ift
uses: []
```

# prop:chow-iv-cmc-sweepout-almost-hyperbolic-cusp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#prop:chow-iv-cmc-sweepout-almost-hyperbolic-cusp
uses: []
```

# rem:chow-iv-cmc-fixed-area-smooth-dependence

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#rem:chow-iv-cmc-fixed-area-smooth-dependence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#prop:chow-iv-cmc-sweepout-almost-hyperbolic-cusp]]'
```

# clm:chow-iv-cmc-cusp-graphs-foliate

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#clm:chow-iv-cmc-cusp-graphs-foliate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#prop:chow-iv-cmc-sweepout-almost-hyperbolic-cusp]]'
```

# prop:chow-iv-cmc-spheres-almost-cylindrical-neck

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#prop:chow-iv-cmc-spheres-almost-cylindrical-neck
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#prop:chow-iv-cmc-sweepout-almost-hyperbolic-cusp]]'
```

# prop:chow-iv-harmonic-sphere-map-near-identity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#prop:chow-iv-harmonic-sphere-map-near-identity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-sphere-map-laplacian-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-sphere-maps-near-identity-parametrization]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-map-laplacian-killing-orthogonality]]'
```

# rem:chow-iv-sphere-map-laplacian-low-eigenspaces

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#rem:chow-iv-sphere-map-laplacian-low-eigenspaces
uses: []
```

# lem:chow-iv-sphere-map-laplacian-kernel

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-sphere-map-laplacian-kernel
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#rem:chow-iv-sphere-map-laplacian-low-eigenspaces]]'
```

# lem:chow-iv-sphere-maps-near-identity-parametrization

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-sphere-maps-near-identity-parametrization
uses: []
```

# lem:chow-iv-map-laplacian-killing-orthogonality

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-map-laplacian-killing-orthogonality
uses: []
```

# rem:chow-iv-harmonic-two-sphere-near-identity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#rem:chow-iv-harmonic-two-sphere-near-identity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-sphere-map-laplacian-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-sphere-maps-near-identity-parametrization]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-map-laplacian-killing-orthogonality]]'
```

# def:chow-iv-harmonic-map-normal-boundary-condition

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#def:chow-iv-harmonic-map-normal-boundary-condition
uses: []
```

# prop:chow-iv-harmonic-diffeomorphism-negative-ricci

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#prop:chow-iv-harmonic-diffeomorphism-negative-ricci
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#def:chow-iv-harmonic-map-normal-boundary-condition]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-linearized-harmonic-boundary-operator-invertible]]'
```

# lem:chow-iv-linearized-harmonic-boundary-weak-solution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-linearized-harmonic-boundary-weak-solution
uses: []
```

# lem:chow-iv-linearized-harmonic-boundary-regularity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-linearized-harmonic-boundary-regularity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-linearized-harmonic-boundary-weak-solution]]'
```

# lem:chow-iv-linearized-harmonic-boundary-schauder

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-linearized-harmonic-boundary-schauder
uses: []
```

# lem:chow-iv-linearized-harmonic-boundary-operator-invertible

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-linearized-harmonic-boundary-operator-invertible
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-linearized-harmonic-boundary-weak-solution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-linearized-harmonic-boundary-regularity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-linearized-harmonic-boundary-schauder]]'
```

# clm:chow-iv-harmonic-diffeomorphism-near-approximate-isometry

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#clm:chow-iv-harmonic-diffeomorphism-near-approximate-isometry
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#prop:chow-iv-harmonic-diffeomorphism-negative-ricci]]'
```

# lem:chow-iv-hypersurface-geometry-ambient-metric-stability

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-hypersurface-geometry-ambient-metric-stability
uses: []
```

# lem:chow-iv-hypersurface-intrinsic-curvature-stability

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#lem:chow-iv-hypersurface-intrinsic-curvature-stability
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-hypersurface-geometry-ambient-metric-stability]]'
```

# rem:chow-iv-hypersurface-geometry-higher-order-stability

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#rem:chow-iv-hypersurface-geometry-higher-order-stability
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-hypersurface-geometry-ambient-metric-stability]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-hypersurface-intrinsic-curvature-stability]]'
```

# thm:chow-iv-isometry-near-almost-isometry

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#thm:chow-iv-isometry-near-almost-isometry
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-hypersurface-geometry-ambient-metric-stability]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#lem:chow-iv-hypersurface-intrinsic-curvature-stability]]'
```

# rem:chow-iv-cmc-sweepout-foliation-question

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions.tex#rem:chow-iv-cmc-sweepout-foliation-question
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch34-surgery-constructions#prop:chow-iv-cmc-sweepout-almost-hyperbolic-cusp]]'
```
