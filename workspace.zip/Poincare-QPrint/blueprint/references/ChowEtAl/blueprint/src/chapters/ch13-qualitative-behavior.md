# ch:chow-ii-qualitative-behavior

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ch:chow-ii-qualitative-behavior
uses: []
```

# ex:chow-ii-nonnegative-scalar-preserved-attractive

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-nonnegative-scalar-preserved-attractive
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-scalar-wmp]]'
```

# ex:chow-ii-nonnegative-curvature-operator-preserved

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-nonnegative-curvature-operator-preserved
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-curvature-operator-preservation]]'
```

# ex:chow-ii-hamilton-ivey-attractiveness

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-hamilton-ivey-attractiveness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-hamilton-ivey]]'
```

# ex:chow-ii-two-nonnegative-curvature-preserved

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-two-nonnegative-curvature-preserved
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#prop:chow-ii-ricci-flow-preserves-two-nonnegative]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#thm:chow-ii-boehm-wilking-convergence]]'
```

# ex:chow-ii-bisectional-curvature-preserved

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-bisectional-curvature-preserved
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-system-wmp]]'
```

# ex:chow-ii-traceless-kahler-curvature-preserved

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-traceless-kahler-curvature-preserved
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-system-wmp]]'
```

# ex:chow-ii-orthogonal-bisectional-preserves-ricci

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-orthogonal-bisectional-preserves-ricci
uses: []
```

# ex:chow-ii-oneill-tensor-symmetries

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-oneill-tensor-symmetries
uses: []
```

# thm:chow-ii-oneill-curvature-formulas

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#thm:chow-ii-oneill-curvature-formulas
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#ex:chow-ii-oneill-tensor-symmetries]]'
```

# rem:chow-ii-submersion-increases-curvature

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#rem:chow-ii-submersion-increases-curvature
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#thm:chow-ii-oneill-curvature-formulas]]'
```

# rem:chow-ii-oneill-totally-geodesic-fibers

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#rem:chow-ii-oneill-totally-geodesic-fibers
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#thm:chow-ii-oneill-curvature-formulas]]'
```

# thm:chow-ii-persistent-nonnegative-sectional-splitting

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#thm:chow-ii-persistent-nonnegative-sectional-splitting
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:system-null-space-rigidity]]'
```

# cor:chow-ii-sectionally-nonnegative-quotient-counterexample

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#cor:chow-ii-sectionally-nonnegative-quotient-counterexample
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#thm:chow-ii-persistent-nonnegative-sectional-splitting]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#rem:chow-ii-oneill-totally-geodesic-fibers]]'
```

# rem:chow-ii-higher-tangent-bundle-counterexamples

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#rem:chow-ii-higher-tangent-bundle-counterexamples
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#thm:chow-ii-persistent-nonnegative-sectional-splitting]]'
```

# thm:chow-ii-kahler-ricci-nonnegative-counterexample

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#thm:chow-ii-kahler-ricci-nonnegative-counterexample
uses: []
```

# thm:chow-ii-bohm-wilking-ricci-sign-counterexample

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#thm:chow-ii-bohm-wilking-ricci-sign-counterexample
uses: []
```

# ex:chow-ii-flat-factorial-analyticity-criterion

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-flat-factorial-analyticity-criterion
uses: []
```

# prop:chow-ii-flat-heat-real-analyticity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#prop:chow-ii-flat-heat-real-analyticity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#ex:chow-ii-flat-factorial-analyticity-criterion]]'
```

# lem:chow-ii-normal-coordinate-analytic-atlas

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#lem:chow-ii-normal-coordinate-analytic-atlas
uses: []
```

# thm:chow-ii-ricci-flow-spatial-real-analyticity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#thm:chow-ii-ricci-flow-spatial-real-analyticity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-normal-coordinate-analytic-atlas]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-main-factorial-curvature-estimate]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-normal-coordinate-metric-derivatives]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#rem:chow-ii-noncompact-analyticity]]'
```

# lem:chow-ii-nabla-laplacian-commutator

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#lem:chow-ii-nabla-laplacian-commutator
uses: []
```

# rem:chow-ii-nabla-laplacian-bianchi-form

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#rem:chow-ii-nabla-laplacian-bianchi-form
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-nabla-laplacian-commutator]]'
```

# lem:chow-ii-higher-nabla-laplacian-commutator

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#lem:chow-ii-higher-nabla-laplacian-commutator
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-nabla-laplacian-commutator]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#rem:chow-ii-differentiable-contraction-count]]'
```

# rem:chow-ii-differentiable-contraction-count

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#rem:chow-ii-differentiable-contraction-count
uses: []
```

# lem:chow-ii-nabla-time-commutator

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#lem:chow-ii-nabla-time-commutator
uses: []
```

# cor:chow-ii-nabla-heat-commutator

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#cor:chow-ii-nabla-heat-commutator
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-higher-nabla-laplacian-commutator]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-nabla-time-commutator]]'
```

# lem:chow-ii-curvature-derivative-evolution-inequality

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#lem:chow-ii-curvature-derivative-evolution-inequality
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#cor:chow-ii-nabla-heat-commutator]]'
```

# lem:chow-ii-main-factorial-curvature-estimate

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#lem:chow-ii-main-factorial-curvature-estimate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-curvature-derivative-evolution-inequality]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:noncompact-scalar-pde-ode-comparison]]'
```

# ex:chow-ii-uhlenbeck-curvature-commutators

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#ex:chow-ii-uhlenbeck-curvature-commutators
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-main-factorial-curvature-estimate]]'
```

# lem:chow-ii-normal-coordinate-metric-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#lem:chow-ii-normal-coordinate-metric-derivatives
uses: []
```

# rem:chow-ii-noncompact-analyticity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#rem:chow-ii-noncompact-analyticity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-main-factorial-curvature-estimate]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior#lem:chow-ii-normal-coordinate-metric-derivatives]]'
```

# prob:chow-ii-kahler-ricci-attractive-cone

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch13-qualitative-behavior.tex#prob:chow-ii-kahler-ricci-attractive-cone
uses: []
```
