# chow-ii-ch10-weak-maximum-principles

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#chow-ii-ch10-weak-maximum-principles
uses: []
```

# def:chow-ii-semilinear-heat-operator

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-semilinear-heat-operator
uses: []
```

# thm:chow-ii-scalar-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-scalar-comparison
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-semilinear-heat-operator]]'
```

# thm:chow-ii-scalar-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-scalar-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-semilinear-heat-operator]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-scalar-comparison]]'
```

# thm:chow-ii-scalar-two-sided

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-scalar-two-sided
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-scalar-wmp]]'
```

# ex:chow-ii-ode-decay

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#ex:chow-ii-ode-decay
uses: []
```

# def:chow-ii-null-eigenvector

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-null-eigenvector
uses: []
```

# thm:chow-ii-two-tensor-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-two-tensor-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-null-eigenvector]]'
```

# rem:chow-ii-two-tensor-limitations

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#rem:chow-ii-two-tensor-limitations
uses: []
```

# def:chow-ii-bundle-heat-equation

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-bundle-heat-equation
uses: []
```

# def:chow-ii-parallel-invariant-set

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-parallel-invariant-set
uses: []
```

# lem:chow-ii-spectral-invariance

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#lem:chow-ii-spectral-invariance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-parallel-invariant-set]]'
```

# cor:chow-ii-nonnegative-tensor-cone

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#cor:chow-ii-nonnegative-tensor-cone
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#lem:chow-ii-spectral-invariance]]'
```

# thm:chow-ii-system-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-system-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-bundle-heat-equation]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-parallel-invariant-set]]'
```

# thm:chow-ii-curvature-operator-preservation

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-curvature-operator-preservation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-system-wmp]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#cor:chow-ii-nonnegative-tensor-cone]]'
```

# thm:chow-ii-time-dependent-system-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-time-dependent-system-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-bundle-heat-equation]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-system-wmp]]'
```

# thm:chow-ii-hamilton-ivey

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-hamilton-ivey
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-time-dependent-system-wmp]]'
```

# cor:chow-ii-hamilton-ivey-scaling

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#cor:chow-ii-hamilton-ivey-scaling
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-hamilton-ivey]]'
```

# cor:chow-ii-almost-nonnegative-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#cor:chow-ii-almost-nonnegative-curvature
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-hamilton-ivey]]'
```

# thm:chow-ii-system-avoidance-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-system-avoidance-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-bundle-heat-equation]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#prop:chow-ii-avoidance-ode]]'
```

# thm:chow-ii-necklike-points

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-necklike-points
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-system-avoidance-wmp]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#thm:chow-ii-hamilton-ivey]]'
```

# def:chow-ii-dini-derivatives

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-dini-derivatives
uses: []
```

# lem:chow-ii-dini-upper-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#lem:chow-ii-dini-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-dini-derivatives]]'
```

# cor:chow-ii-dini-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#cor:chow-ii-dini-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#lem:chow-ii-dini-upper-bound]]'
```

# lem:chow-ii-spatial-maximum-dini

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#lem:chow-ii-spatial-maximum-dini
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-dini-derivatives]]'
```

# cor:chow-ii-heat-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#cor:chow-ii-heat-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#lem:chow-ii-spatial-maximum-dini]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#cor:chow-ii-dini-monotonicity]]'
```

# thm:chow-ii-continuous-set-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-continuous-set-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#lem:chow-ii-spatial-maximum-dini]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#cor:chow-ii-dini-monotonicity]]'
```

# lem:chow-ii-nearest-point-separation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#lem:chow-ii-nearest-point-separation
uses: []
```

# def:chow-ii-tangent-support

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-tangent-support
uses: []
```

# lem:chow-ii-distance-support

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#lem:chow-ii-distance-support
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-tangent-support]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#lem:chow-ii-nearest-point-separation]]'
```

# prop:chow-ii-fixed-convex-ode

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#prop:chow-ii-fixed-convex-ode
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#lem:chow-ii-distance-support]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#cor:chow-ii-dini-monotonicity]]'
```

# def:chow-ii-forward-track-direction

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-forward-track-direction
uses: []
```

# lem:chow-ii-forward-directions-convex

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#lem:chow-ii-forward-directions-convex
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-forward-track-direction]]'
```

# prop:chow-ii-moving-convex-ode

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#prop:chow-ii-moving-convex-ode
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-forward-track-direction]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#lem:chow-ii-distance-support]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#cor:chow-ii-dini-monotonicity]]'
```

# prop:chow-ii-avoidance-ode

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#prop:chow-ii-avoidance-ode
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#prop:chow-ii-moving-convex-ode]]'
```

# prop:chow-ii-weighted-l2

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#prop:chow-ii-weighted-l2
uses: []
```

# cor:chow-ii-l2-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#cor:chow-ii-l2-uniqueness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#prop:chow-ii-weighted-l2]]'
```

# cor:chow-ii-exhaustion-energy

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#cor:chow-ii-exhaustion-energy
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#prop:chow-ii-weighted-l2]]'
```

# prop:chow-ii-dual-l2

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#prop:chow-ii-dual-l2
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#prop:chow-ii-weighted-l2]]'
```

# def:chow-ii-weak-heat-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-weak-heat-solution
uses: []
```

# def:chow-ii-weak-ibv-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#def:chow-ii-weak-ibv-solution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-weak-heat-solution]]'
```

# cor:chow-ii-weak-energy-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#cor:chow-ii-weak-energy-estimate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-weak-ibv-solution]]'
```

# thm:chow-ii-weak-solution-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-weak-solution-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#def:chow-ii-weak-ibv-solution]]'
```

# thm:chow-ii-elliptic-abp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-elliptic-abp
uses: []
```

# thm:chow-ii-parabolic-abp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#thm:chow-ii-parabolic-abp
uses: []
```

# prop:chow-ii-elementary-parabolic-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#prop:chow-ii-elementary-parabolic-wmp
uses: []
```

# prop:chow-ii-detruck-c0-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#prop:chow-ii-detruck-c0-estimate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles#prop:chow-ii-elementary-parabolic-wmp]]'
```

# rem:chow-ii-ch10-history

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch10-weak-maximum-principles.tex#rem:chow-ii-ch10-history
uses: []
```
