# app:chow-iii-elementary-metric-geometry

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#app:chow-iii-elementary-metric-geometry
uses: []
```

# rem:chow-iii-g1-scaling-metric-spaces

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g1-scaling-metric-spaces
uses: []
```

# rem:chow-iii-g2-quasi-metric

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g2-quasi-metric
uses: []
```

# prop:chow-iii-g3-pullback-metric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#prop:chow-iii-g3-pullback-metric
uses: []
```

# def:chow-iii-quasi-length-space

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-quasi-length-space
uses: []
```

# prop:chow-iii-g6-induced-metric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#prop:chow-iii-g6-induced-metric
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-quasi-length-space]]'
```

# prop:chow-iii-g7-length-induced-by-metric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#prop:chow-iii-g7-length-induced-by-metric
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#prop:chow-iii-g6-induced-metric]]'
```

# ex:chow-iii-g8-riemannian-length

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#ex:chow-iii-g8-riemannian-length
uses: []
```

# def:chow-iii-gromov-hausdorff-distance

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-gromov-hausdorff-distance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#prop:chow-iii-g7-length-induced-by-metric]]'
```

# rem:chow-iii-g9-gh-properties

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g9-gh-properties
uses: []
```

# def:chow-iii-g10-epsilon-isometry

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g10-epsilon-isometry
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-gromov-hausdorff-distance]]'
```

# rem:chow-iii-g11-approximation-continuity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g11-approximation-continuity
uses: []
```

# lem:chow-iii-g12-epsilon-isometry

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#lem:chow-iii-g12-epsilon-isometry
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g10-epsilon-isometry]]'
```

# rem:chow-iii-g13-correspondences

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g13-correspondences
uses: []
```

# def:chow-iii-g14-pointed-gh

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g14-pointed-gh
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-gromov-hausdorff-distance]]'
```

# lem:chow-iii-g15-pointed-epsilon

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#lem:chow-iii-g15-pointed-epsilon
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g14-pointed-gh]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#lem:chow-iii-g12-epsilon-isometry]]'
```

# def:chow-iii-g16-precompactness

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g16-precompactness
uses: []
```

# thm:chow-iii-g17-gromov-precompactness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g17-gromov-precompactness
uses: []
```

# thm:chow-iii-g18-total-boundedness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g18-total-boundedness
uses: []
```

# thm:chow-iii-g19-pointed-total-boundedness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g19-pointed-total-boundedness
uses: []
```

# def:chow-iii-g20-tangent-cone

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g20-tangent-cone
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g14-pointed-gh]]'
```

# prop:chow-iii-g23-g25-cone-rescaling

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#prop:chow-iii-g23-g25-cone-rescaling
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g20-tangent-cone]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g11-asymptotic-cone]]'
```

# ex:chow-iii-g24-g28-nonunique-cones

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#ex:chow-iii-g24-g28-nonunique-cones
uses: []
```

# def:chow-iii-g11-asymptotic-cone

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g11-asymptotic-cone
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g14-pointed-gh]]'
```

# ex:chow-iii-g26-g27-asymptotic-examples

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#ex:chow-iii-g26-g27-asymptotic-examples
uses: []
```

# def:chow-iii-g29-euclidean-cone

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g29-euclidean-cone
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g20-tangent-cone]]'
```

# prop:chow-iii-g30-g32-cone-metric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#prop:chow-iii-g30-g32-cone-metric
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g29-euclidean-cone]]'
```

# rem:chow-iii-g31-cone-motivation

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g31-cone-motivation
uses: []
```

# thm:chow-iii-g33-toponogov

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g33-toponogov
uses: []
```

# rem:chow-iii-g34-toponogov-variants

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g34-toponogov-variants
uses: []
```

# def:chow-iii-g35-g36-aleksandrov

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g35-g36-aleksandrov
uses: []
```

# thm:chow-iii-g37-globalization

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g37-globalization
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g35-g36-aleksandrov]]'
```

# def:chow-iii-g38-g39-angle

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g38-g39-angle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#thm:chow-iii-g37-globalization]]'
```

# thm:chow-iii-g40-g42-regularity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g40-g42-regularity
uses: []
```

# def:chow-iii-g41-strainers

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g41-strainers
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g35-g36-aleksandrov]]'
```

# thm:chow-iii-g43-g44-compactness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g43-g44-compactness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g35-g36-aleksandrov]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#thm:chow-iii-g17-gromov-precompactness]]'
```

# thm:chow-iii-g45-g46-splitting-diameter

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g45-g46-splitting-diameter
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g35-g36-aleksandrov]]'
```

# rem:chow-iii-g47-volume-comparison

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g47-volume-comparison
uses: []
```

# thm:chow-iii-g49-tangent-cone

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g49-tangent-cone
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g29-euclidean-cone]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#prop:chow-iii-g30-g32-cone-metric]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#thm:chow-iii-g40-g42-regularity]]'
```

# def:chow-iii-g50-exponential-cut-locus

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g50-exponential-cut-locus
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#thm:chow-iii-g49-tangent-cone]]'
```

# def:chow-iii-g51-stratification

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g51-stratification
uses: []
```

# thm:chow-iii-g52-aleksandrov-stratification

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g52-aleksandrov-stratification
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g51-stratification]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#thm:chow-iii-g49-tangent-cone]]'
```

# lem:chow-iii-g53-distance-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#lem:chow-iii-g53-distance-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g35-g36-aleksandrov]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g50-exponential-cut-locus]]'
```

# def:chow-iii-g54-g56-semi-concavity

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#def:chow-iii-g54-g56-semi-concavity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#lem:chow-iii-g53-distance-derivative]]'
```

# ex:chow-iii-g55-power-function

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#ex:chow-iii-g55-power-function
uses: []
```

# thm:chow-iii-g57-stability

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g57-stability
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#thm:chow-iii-g43-g44-compactness]]'
```

# rem:chow-iii-g58-stability-reference

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g58-stability-reference
uses: []
```

# cor:chow-iii-g59-small-balls

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#cor:chow-iii-g59-small-balls
uses: []
```

# thm:chow-iii-g60-regularity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#thm:chow-iii-g60-regularity
uses: []
```

# rem:chow-iii-g21-g22-tangent-questions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g21-g22-tangent-questions
uses: []
```

# rem:chow-iii-g48-riemannian-limits

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g48-riemannian-limits
uses: []
```

# rem:chow-iii-g61-further-convergence

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry.tex#rem:chow-iii-g61-further-convergence
uses: []
```
