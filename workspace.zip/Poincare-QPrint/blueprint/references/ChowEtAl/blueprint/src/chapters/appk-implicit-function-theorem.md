# app:chow-iv-appendix-k

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#app:chow-iv-appendix-k
uses: []
```

# thm:chow-iv-k1-lax-milgram-lions

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#thm:chow-iv-k1-lax-milgram-lions
uses: []
```

# lem:chow-iv-k2-contraction

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#lem:chow-iv-k2-contraction
uses: []
```

# thm:chow-iv-k3-banach-inverse-function

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#thm:chow-iv-k3-banach-inverse-function
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#lem:chow-iv-k2-contraction]]'
```

# thm:chow-iv-k4-banach-implicit-function

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#thm:chow-iv-k4-banach-implicit-function
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#thm:chow-iv-k3-banach-inverse-function]]'
```

# def:chow-iv-k5-map-banach-manifold

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#def:chow-iv-k5-map-banach-manifold
uses: []
```

# def:chow-iv-k6-ck-sections

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#def:chow-iv-k6-ck-sections
uses: []
```

# def:chow-iv-k7-holder-spaces

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#def:chow-iv-k7-holder-spaces
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#def:chow-iv-k6-ck-sections]]'
```

# def:chow-iv-k8-sobolev-spaces

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#def:chow-iv-k8-sobolev-spaces
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#def:chow-iv-k6-ck-sections]]'
```

# def:chow-iv-k9-hypersurface-closeness

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#def:chow-iv-k9-hypersurface-closeness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#def:chow-iv-k7-holder-spaces]]'
```

# def:chow-iv-k10-map-energy

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#def:chow-iv-k10-map-energy
uses: []
```

# lem:chow-iv-k11-map-laplacian-coordinates

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#lem:chow-iv-k11-map-laplacian-coordinates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#def:chow-iv-k10-map-energy]]'
```

# def:chow-iv-k12-harmonic-map

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#def:chow-iv-k12-harmonic-map
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#lem:chow-iv-k11-map-laplacian-coordinates]]'
```

# ex:chow-iv-k13-minimal-immersion

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#ex:chow-iv-k13-minimal-immersion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#def:chow-iv-k12-harmonic-map]]'
```

# lem:chow-iv-k14-first-variation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#lem:chow-iv-k14-first-variation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#def:chow-iv-k10-map-energy]]'
```

# lem:chow-iv-k15-second-variation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#lem:chow-iv-k15-second-variation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#lem:chow-iv-k14-first-variation]]'
```

# thm:chow-iv-k17-eells-sampson

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#thm:chow-iv-k17-eells-sampson
uses: []
```

# lem:chow-iv-k18-energy-density

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#lem:chow-iv-k18-energy-density
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#thm:chow-iv-k17-eells-sampson]]'
```

# rem:chow-iv-k-linearization-boundary

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#rem:chow-iv-k-linearization-boundary
uses: []
```

# prop:chow-iv-k19-harmonic-polynomial-decomposition

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#prop:chow-iv-k19-harmonic-polynomial-decomposition
uses: []
```

# prop:chow-iv-k20-function-spectrum-sphere

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#prop:chow-iv-k20-function-spectrum-sphere
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#prop:chow-iv-k19-harmonic-polynomial-decomposition]]'
```

# thm:chow-iv-k21-hodge-decomposition

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#thm:chow-iv-k21-hodge-decomposition
uses: []
```

# thm:chow-iv-k22-closed-eigenforms

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#thm:chow-iv-k22-closed-eigenforms
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#thm:chow-iv-k21-hodge-decomposition]]'
```

# thm:chow-iv-k23-coclosed-eigenforms

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#thm:chow-iv-k23-coclosed-eigenforms
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#thm:chow-iv-k22-closed-eigenforms]]'
```

# cor:chow-iv-k24-lowest-p-form-eigenvalue

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#cor:chow-iv-k24-lowest-p-form-eigenvalue
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#thm:chow-iv-k22-closed-eigenforms]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#thm:chow-iv-k23-coclosed-eigenforms]]'
```

# lem:chow-iv-k25-codifferential-sphere

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#lem:chow-iv-k25-codifferential-sphere
uses: []
```

# lem:chow-iv-k26-hodge-laplacian-sphere

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#lem:chow-iv-k26-hodge-laplacian-sphere
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#lem:chow-iv-k25-codifferential-sphere]]'
```

# lem:chow-iv-k27-homogeneous-closed-forms

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#lem:chow-iv-k27-homogeneous-closed-forms
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#lem:chow-iv-k26-hodge-laplacian-sphere]]'
```

# thm:chow-iv-k28-gallot-meyer

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#thm:chow-iv-k28-gallot-meyer
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#thm:chow-iv-k21-hodge-decomposition]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#cor:chow-iv-k24-lowest-p-form-eigenvalue]]'
```

# ex:chow-iv-k16-map-laplacian-linearization

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem.tex#ex:chow-iv-k16-map-laplacian-linearization
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appk-implicit-function-theorem#lem:chow-iv-k15-second-variation]]'
```
