# ch:chow-iii-perelmans-pseudolocality

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#ch:chow-iii-perelmans-pseudolocality
uses: []
```

# prop:chow-iii-euclidean-isoperimetric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#prop:chow-iii-euclidean-isoperimetric
uses: []
```

# thm:chow-iii-perelman-pseudolocality

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#thm:chow-iii-perelman-pseudolocality
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#prop:chow-iii-euclidean-isoperimetric]]'
```

# rem:chow-iii-pseudolocality-scales

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#rem:chow-iii-pseudolocality-scales
uses: []
```

# cor:chow-iii-interior-curvature-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#cor:chow-iii-interior-curvature-estimate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#thm:chow-iii-perelman-pseudolocality]]'
```

# rem:chow-iii-pseudolocality-scale-invariance

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#rem:chow-iii-pseudolocality-scale-invariance
uses: []
```

# ex:chow-iii-topping-incomplete-solution

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#ex:chow-iii-topping-incomplete-solution
uses: []
```

# thm:chow-iii-topping-counterexample

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#thm:chow-iii-topping-counterexample
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#ex:chow-iii-topping-incomplete-solution]]'
```

# rem:chow-iii-topping-products

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#rem:chow-iii-topping-products
uses: []
```

# thm:chow-iii-pseudolocality-unit-scale

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#thm:chow-iii-pseudolocality-unit-scale
uses: []
```

# rem:chow-iii-pseudolocality-parameter-monotonicity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#rem:chow-iii-pseudolocality-parameter-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#thm:chow-iii-pseudolocality-unit-scale]]'
```

# def:chow-iii-alpha-large-curvature

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#def:chow-iii-alpha-large-curvature
uses: []
```

# ctr:chow-iii-pseudolocality-counterstatement

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#ctr:chow-iii-pseudolocality-counterstatement
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#def:chow-iii-alpha-large-curvature]]'
```

# lem:chow-iii-adjusted-bad-sequence

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#lem:chow-iii-adjusted-bad-sequence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#ctr:chow-iii-pseudolocality-counterstatement]]'
```

# rem:chow-iii-adjusted-local-bound

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#rem:chow-iii-adjusted-local-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#lem:chow-iii-adjusted-bad-sequence]]'
```

# lem:chow-iii-well-chosen-points

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#lem:chow-iii-well-chosen-points
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#lem:chow-iii-adjusted-bad-sequence]]'
```

# def:chow-iii-adjoint-entropy-quantities

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#def:chow-iii-adjoint-entropy-quantities
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#lem:chow-iii-well-chosen-points]]'
```

# clm:chow-iii-uniform-negative-local-entropy

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#clm:chow-iii-uniform-negative-local-entropy
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#def:chow-iii-adjoint-entropy-quantities]]'
```

# lem:chow-iii-noncollapsed-entropy-limit

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#lem:chow-iii-noncollapsed-entropy-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#clm:chow-iii-uniform-negative-local-entropy]]'
```

# lem:chow-iii-collapsed-entropy-limit

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#lem:chow-iii-collapsed-entropy-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#clm:chow-iii-uniform-negative-local-entropy]]'
```

# lem:chow-iii-type-iii-curvature-gap

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#lem:chow-iii-type-iii-curvature-gap
uses: []
```

# rem:chow-iii-flat-limit-cover

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#rem:chow-iii-flat-limit-cover
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#lem:chow-iii-collapsed-entropy-limit]]'
```

# thm:chow-iii-pseudolocality-log-sobolev-contradiction

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#thm:chow-iii-pseudolocality-log-sobolev-contradiction
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#clm:chow-iii-uniform-negative-local-entropy]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#lem:chow-iii-noncollapsed-entropy-limit]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#lem:chow-iii-collapsed-entropy-limit]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#thm:chow-iii-pseudolocality-unit-scale]]'
```

# rem:chow-iii-pseudolocality-scalar-role

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#rem:chow-iii-pseudolocality-scalar-role
uses: []
```

# ex:chow-iii-entropy-rigidity-alternatives

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality.tex#ex:chow-iii-entropy-rigidity-alternatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch21-perelman-pseudolocality#lem:chow-iii-noncollapsed-entropy-limit]]'
```
