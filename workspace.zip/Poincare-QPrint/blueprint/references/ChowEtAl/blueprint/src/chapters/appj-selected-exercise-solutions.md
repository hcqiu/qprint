# app:chow-iii-selected-exercise-solutions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#app:chow-iii-selected-exercise-solutions
uses: []
```

# prop:chow-iii-appj-solution-22-2

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#prop:chow-iii-appj-solution-22-2
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#def:chow-iii-alpha-small-large-curvature]]'
```

# prop:chow-iii-appj-solution-22-5

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#prop:chow-iii-appj-solution-22-5
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#lem:chow-iii-point-picking-subset]]'
```

# prop:chow-iii-appj-solution-22-18

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#prop:chow-iii-appj-solution-22-18
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch22-tools-pseudolocality#thm:chow-iii-log-sobolev-isoperimetric]]'
```

# prop:chow-iii-appj-solution-25-7

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#prop:chow-iii-appj-solution-25-7
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#ex:chow-iii-rescaled-moser-cylinder-iteration]]'
```

# prop:chow-iii-appj-solution-g-3

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#prop:chow-iii-appj-solution-g-3
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#prop:chow-iii-g3-pullback-metric]]'
```

# ex:chow-iii-appj-solution-g-24

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#ex:chow-iii-appj-solution-g-24
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#ex:chow-iii-g24-g28-nonunique-cones]]'
```

# ex:chow-iii-appj-solution-h-44

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#ex:chow-iii-appj-solution-h-44
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#ex:chow-iii-h44-square-integral-curves]]'
```

# ex:chow-iii-appj-solution-i-14

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#ex:chow-iii-appj-solution-i-14
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i1-rays-busemann]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#def:chow-iii-g29-euclidean-cone]]'
```

# prop:chow-iii-appj-solution-i-38

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appj-selected-exercise-solutions.tex#prop:chow-iii-appj-solution-i-38
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i37-angle-decay]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appg-elementary-metric-geometry#thm:chow-iii-g33-toponogov]]'
```
