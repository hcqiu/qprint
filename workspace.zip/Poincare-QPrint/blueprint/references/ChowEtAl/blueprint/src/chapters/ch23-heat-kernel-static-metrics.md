# chow-iii-ch23-heat-kernel-static-metrics

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#chow-iii-ch23-heat-kernel-static-metrics
uses: []
```

# def:chow-iii-ch23-fundamental-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#def:chow-iii-ch23-fundamental-solution
uses: []
```

# rem:chow-iii-ch23-completeness

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#rem:chow-iii-ch23-completeness
uses: []
```

# thm:chow-iii-ch23-closed-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#thm:chow-iii-ch23-closed-heat-kernel
uses: []
```

# rem:chow-iii-ch23-properties-elsewhere

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#rem:chow-iii-ch23-properties-elsewhere
uses: []
```

# def:chow-iii-ch23-transplanted-kernel

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#def:chow-iii-ch23-transplanted-kernel
uses: []
```

# rem:chow-iii-ch23-finite-approximation

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#rem:chow-iii-ch23-finite-approximation
uses: []
```

# def:chow-iii-ch23-normal-jacobian

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#def:chow-iii-ch23-normal-jacobian
uses: []
```

# rem:chow-iii-ch23-gauss-lemma

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#rem:chow-iii-ch23-gauss-lemma
uses: []
```

# lem:chow-iii-ch23-recursive-odes

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-recursive-odes
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#def:chow-iii-ch23-normal-jacobian]]'
```

# rem:chow-iii-ch23-coefficients-independent

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#rem:chow-iii-ch23-coefficients-independent
uses: []
```

# lem:chow-iii-ch23-recursive-formula

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-recursive-formula
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-recursive-odes]]'
```

# lem:chow-iii-ch23-heat-error-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-heat-error-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-recursive-formula]]'
```

# def:chow-iii-ch23-parametrix

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#def:chow-iii-ch23-parametrix
uses: []
```

# prop:chow-iii-ch23-parametrix-existence

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#prop:chow-iii-ch23-parametrix-existence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#def:chow-iii-ch23-parametrix]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-heat-error-derivatives]]'
```

# ex:chow-iii-ch23-convolution-sum

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#ex:chow-iii-ch23-convolution-sum
uses: []
```

# lem:chow-iii-ch23-parametrix-error-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-parametrix-error-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#prop:chow-iii-ch23-parametrix-existence]]'
```

# def:chow-iii-ch23-space-time-convolution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#def:chow-iii-ch23-space-time-convolution
uses: []
```

# lem:chow-iii-ch23-parametrix-convolution-heat-operator

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-parametrix-convolution-heat-operator
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#def:chow-iii-ch23-space-time-convolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#prop:chow-iii-ch23-parametrix-existence]]'
```

# thm:chow-iii-ch23-parametrix-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#thm:chow-iii-ch23-parametrix-heat-kernel
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-parametrix-convolution-heat-operator]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#cor:chow-iii-ch23-convolution-series]]'
```

# thm:chow-iii-ch23-heat-kernel-expansion

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#thm:chow-iii-ch23-heat-kernel-expansion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#thm:chow-iii-ch23-parametrix-heat-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-convolution-estimates]]'
```

# ex:chow-iii-ch23-expansion-derivatives

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#ex:chow-iii-ch23-expansion-derivatives
uses: []
```

# lem:chow-iii-ch23-coefficient-structure

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-coefficient-structure
uses: []
```

# lem:chow-iii-ch23-convolution-estimates

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-convolution-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-coefficient-structure]]'
```

# cor:chow-iii-ch23-convolution-series

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#cor:chow-iii-ch23-convolution-series
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-convolution-estimates]]'
```

# ex:chow-iii-ch23-convolution-series-commutes

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#ex:chow-iii-ch23-convolution-series-commutes
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#cor:chow-iii-ch23-convolution-series]]'
```

# lem:chow-iii-ch23-convolution-series-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-convolution-series-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-parametrix-error-derivatives]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-convolution-estimates]]'
```

# lem:chow-iii-ch23-convolution-series-covariant

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-convolution-series-covariant
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-convolution-series-derivatives]]'
```

# lem:chow-iii-ch23-parametrix-integration-continuity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-parametrix-integration-continuity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#def:chow-iii-ch23-parametrix]]'
```

# lem:chow-iii-ch23-first-convolution-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-first-convolution-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-parametrix-integration-continuity]]'
```

# lem:chow-iii-ch23-second-convolution-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-second-convolution-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-first-convolution-derivative]]'
```

# cor:chow-iii-ch23-laplacian-convolution

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#cor:chow-iii-ch23-laplacian-convolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-second-convolution-derivative]]'
```

# lem:chow-iii-ch23-time-convolution-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-time-convolution-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-parametrix-integration-continuity]]'
```

# lem:chow-iii-ch23-volume-density-expansion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-volume-density-expansion
uses: []
```

# lem:chow-iii-ch23-distance-square-expansion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-distance-square-expansion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-volume-density-expansion]]'
```

# lem:chow-iii-ch23-leading-coefficient-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-leading-coefficient-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-volume-density-expansion]]'
```

# lem:chow-iii-ch23-phi-one-expansion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-phi-one-expansion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-recursive-formula]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-leading-coefficient-derivatives]]'
```

# rem:chow-iii-ch23-phi-two-diagonal

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#rem:chow-iii-ch23-phi-two-diagonal
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics#lem:chow-iii-ch23-recursive-formula]]'
```

# rem:chow-iii-ch23-static-entropy

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#rem:chow-iii-ch23-static-entropy
uses: []
```

# ex:chow-iii-ch23-gaussian-moments

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#ex:chow-iii-ch23-gaussian-moments
uses: []
```

# lem:chow-iii-ch23-determinant-expansion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-determinant-expansion
uses: []
```

# lem:chow-iii-ch23-fubini-noncompact

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-fubini-noncompact
uses: []
```

# rem:chow-iii-ch23-fubini-tail

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#rem:chow-iii-ch23-fubini-tail
uses: []
```

# lem:chow-iii-ch23-differentiation-under-integral

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#lem:chow-iii-ch23-differentiation-under-integral
uses: []
```

# ex:chow-iii-ch23-entropy-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch23-heat-kernel-static-metrics.tex#ex:chow-iii-ch23-entropy-problem
uses: []
```
