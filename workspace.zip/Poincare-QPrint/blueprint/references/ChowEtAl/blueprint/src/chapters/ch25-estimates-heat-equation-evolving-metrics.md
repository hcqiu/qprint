# ch:chow-iii-estimates-heat-equation-evolving-metrics

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#ch:chow-iii-estimates-heat-equation-evolving-metrics
uses: []
```

# def:chow-iii-parabolic-mean-value-inequality

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#def:chow-iii-parabolic-mean-value-inequality
uses: []
```

# thm:chow-iii-evolving-parabolic-mean-value

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#thm:chow-iii-evolving-parabolic-mean-value
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#lem:chow-iii-reverse-poincare]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#prop:chow-iii-local-sobolev-ball]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#lem:chow-iii-moser-cylinder-iteration]]'
```

# lem:chow-iii-reverse-poincare

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#lem:chow-iii-reverse-poincare
uses: []
```

# prop:chow-iii-local-sobolev-ball

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#prop:chow-iii-local-sobolev-ball
uses: []
```

# rem:chow-iii-two-dimensional-local-sobolev

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#rem:chow-iii-two-dimensional-local-sobolev
uses: []
```

# lem:chow-iii-moser-cylinder-iteration

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#lem:chow-iii-moser-cylinder-iteration
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#lem:chow-iii-reverse-poincare]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#prop:chow-iii-local-sobolev-ball]]'
```

# ex:chow-iii-rescaled-moser-cylinder-iteration

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#ex:chow-iii-rescaled-moser-cylinder-iteration
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#lem:chow-iii-moser-cylinder-iteration]]'
```

# thm:chow-iii-li-yau-evolving-metrics

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#thm:chow-iii-li-yau-evolving-metrics
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#cor:chow-iii-harnack-quantity-evolution-inequality]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:bounded-curvature-distance-like-function]]'
```

# thm:chow-iii-li-yau-ricci-flow

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#thm:chow-iii-li-yau-ricci-flow
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#cor:chow-iii-harnack-quantity-evolution-inequality]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-changing-distances]]'
```

# rem:chow-iii-li-yau-locality-ricci-flow

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#rem:chow-iii-li-yau-locality-ricci-flow
uses: []
```

# cor:chow-iii-classical-harnack-evolving-metrics

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#cor:chow-iii-classical-harnack-evolving-metrics
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#thm:chow-iii-li-yau-evolving-metrics]]'
```

# cor:chow-iii-classical-harnack-ricci-flow

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#cor:chow-iii-classical-harnack-ricci-flow
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#thm:chow-iii-li-yau-ricci-flow]]'
```

# rem:chow-iii-harnack-mean-value-adjoint-kernels

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#rem:chow-iii-harnack-mean-value-adjoint-kernels
uses: []
```

# rem:chow-iii-model-harnack-quantity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#rem:chow-iii-model-harnack-quantity
uses: []
```

# lem:chow-iii-harnack-quantity-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#lem:chow-iii-harnack-quantity-evolution
uses: []
```

# cor:chow-iii-harnack-quantity-evolution-inequality

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#cor:chow-iii-harnack-quantity-evolution-inequality
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#lem:chow-iii-harnack-quantity-evolution]]'
```

# ex:chow-iii-integrate-ricci-flow-gradient-estimate

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#ex:chow-iii-integrate-ricci-flow-gradient-estimate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics#thm:chow-iii-li-yau-ricci-flow]]'
```

# ex:chow-iii-local-li-yau-backward-ricci-flow

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch25-estimates-heat-equation-evolving-metrics.tex#ex:chow-iii-local-li-yau-backward-ricci-flow
uses: []
```
