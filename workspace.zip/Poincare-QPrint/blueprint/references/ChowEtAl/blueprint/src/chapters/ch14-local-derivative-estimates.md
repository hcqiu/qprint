# ch:chow-ii-local-derivative-estimates

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#ch:chow-ii-local-derivative-estimates
uses: []
```

# lem:chow-ii-ricci-bounds-metric-comparison

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-ricci-bounds-metric-comparison
uses: []
```

# rem:chow-ii-uniform-metric-equivalence

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#rem:chow-ii-uniform-metric-equivalence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#lem:chow-ii-ricci-bounds-metric-comparison]]'
```

# lem:chow-ii-cutoff-gradient-laplacian-estimates

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-cutoff-gradient-laplacian-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#lem:chow-ii-ricci-bounds-metric-comparison]]'
```

# lem:chow-ii-cutoff-bounded-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-cutoff-bounded-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#lem:chow-ii-cutoff-gradient-laplacian-estimates]]'
```

# thm:chow-ii-global-curvature-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#thm:chow-ii-global-curvature-derivative-estimates
uses: []
```

# lem:chow-ii-curvature-doubling-time

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-curvature-doubling-time
uses: []
```

# cor:chow-ii-derivative-estimates-initial-curvature-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#cor:chow-ii-derivative-estimates-initial-curvature-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-global-curvature-derivative-estimates]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#lem:chow-ii-curvature-doubling-time]]'
```

# rem:chow-ii-curvature-derivative-scaling

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#rem:chow-ii-curvature-derivative-scaling
uses: []
```

# rem:chow-ii-derivative-estimates-smoothing

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#rem:chow-ii-derivative-estimates-smoothing
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-global-curvature-derivative-estimates]]'
```

# thm:chow-ii-shi-local-first-derivative-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#thm:chow-ii-shi-local-first-derivative-estimate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#lem:chow-ii-cutoff-gradient-laplacian-estimates]]'
```

# rem:chow-ii-local-first-estimate-initial-data

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#rem:chow-ii-local-first-estimate-initial-data
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-shi-local-first-derivative-estimate]]'
```

# rem:chow-ii-shi-estimate-dimensionless-radius

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#rem:chow-ii-shi-estimate-dimensionless-radius
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-shi-local-first-derivative-estimate]]'
```

# thm:chow-ii-interior-first-derivative-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#thm:chow-ii-interior-first-derivative-estimate
uses: []
```

# thm:chow-ii-shi-local-higher-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#thm:chow-ii-shi-local-higher-derivative-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#lem:chow-ii-shi-higher-derivative-quantity]]'
```

# lem:chow-ii-shi-higher-derivative-quantity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-shi-higher-derivative-quantity
uses: []
```

# thm:chow-ii-shi-estimates-initial-derivative-bounds

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#thm:chow-ii-shi-estimates-initial-derivative-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#lem:chow-ii-modified-shi-derivative-quantity]]'
```

# rem:chow-ii-modified-shi-zero-order-case

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#rem:chow-ii-modified-shi-zero-order-case
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-shi-estimates-initial-derivative-bounds]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-shi-local-higher-derivative-estimates]]'
```

# lem:chow-ii-modified-shi-derivative-quantity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-modified-shi-derivative-quantity
uses: []
```

# thm:chow-ii-modified-cheeger-gromov-compactness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#thm:chow-ii-modified-cheeger-gromov-compactness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-shi-estimates-initial-derivative-bounds]]'
```

# rem:chow-ii-finite-regularity-compactness

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#rem:chow-ii-finite-regularity-compactness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-modified-cheeger-gromov-compactness]]'
```

# lem:chow-ii-existence-curvature-bumps

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-existence-curvature-bumps
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-interior-first-derivative-estimate]]'
```

# lem:chow-ii-instantaneous-local-derivative-bounds

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-instantaneous-local-derivative-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-interior-first-derivative-estimate]]'
```

# lem:chow-ii-local-heat-bernstein-estimate

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-local-heat-bernstein-estimate
uses: []
```

# ex:chow-ii-local-heat-higher-derivative-estimates

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#ex:chow-ii-local-heat-higher-derivative-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#lem:chow-ii-local-heat-bernstein-estimate]]'
```

# prop:chow-ii-local-ricci-flow-short-time-existence

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#prop:chow-ii-local-ricci-flow-short-time-existence
uses: []
```

# thm:chow-ii-local-ricci-flow-existence-time

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#thm:chow-ii-local-ricci-flow-existence-time
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#prop:chow-ii-local-ricci-flow-short-time-existence]]'
```

# lem:chow-ii-riemann-tensor-variation-formula

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates.tex#lem:chow-ii-riemann-tensor-variation-formula
uses: []
```
