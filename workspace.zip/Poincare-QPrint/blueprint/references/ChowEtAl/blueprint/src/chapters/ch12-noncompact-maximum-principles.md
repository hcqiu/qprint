# ch:noncompact-maximum-principles

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#ch:noncompact-maximum-principles
uses: []
```

# thm:euclidean-heat-wmp-exponential-quadratic-growth

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:euclidean-heat-wmp-exponential-quadratic-growth
uses: []
```

# rem:subtract-little-of-a-lot-barrier

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:subtract-little-of-a-lot-barrier
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:euclidean-heat-wmp-exponential-quadratic-growth]]'
```

# thm:euclidean-heat-uniqueness-exponential-quadratic-growth

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:euclidean-heat-uniqueness-exponential-quadratic-growth
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:euclidean-heat-wmp-exponential-quadratic-growth]]'
```

# thm:heat-nonuniqueness-slicewise-bounded

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:heat-nonuniqueness-slicewise-bounded
uses: []
```

# lem:ricci-flow-distance-like-function

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#lem:ricci-flow-distance-like-function
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:bounded-curvature-distance-like-function]]'
```

# rem:distance-like-hessian-lower-bound

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:distance-like-hessian-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:ricci-flow-distance-like-function]]'
```

# lem:general-metric-barrier-supersolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#lem:general-metric-barrier-supersolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:bounded-curvature-distance-like-function]]'
```

# lem:ricci-flow-barrier-supersolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#lem:ricci-flow-barrier-supersolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:ricci-flow-distance-like-function]]'
```

# thm:complete-manifold-scalar-wmp-barrier

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:complete-manifold-scalar-wmp-barrier
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:general-metric-barrier-supersolution]]'
```

# ex:wmp-integrable-time-coefficient

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#ex:wmp-integrable-time-coefficient
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:complete-manifold-scalar-wmp-barrier]]'
```

# prop:ricci-deturck-uniqueness-controlled-class

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#prop:ricci-deturck-uniqueness-controlled-class
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:complete-manifold-scalar-wmp-barrier]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#ex:wmp-integrable-time-coefficient]]'
```

# rem:wmp-integrable-time-singularity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:wmp-integrable-time-singularity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#ex:wmp-integrable-time-coefficient]]'
```

# thm:noncompact-scalar-pde-ode-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:noncompact-scalar-pde-ode-comparison
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:ricci-flow-barrier-supersolution]]'
```

# def:continuous-subharmonic-function

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#def:continuous-subharmonic-function
uses: []
```

# lem:absolute-value-harmonic-subsolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#lem:absolute-value-harmonic-subsolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#def:continuous-subharmonic-function]]'
```

# rem:minimum-superharmonic-functions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:minimum-superharmonic-functions
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:absolute-value-harmonic-subsolution]]'
```

# thm:static-weak-subsolution-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:static-weak-subsolution-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:evolving-metric-weak-subsolution-wmp]]'
```

# def:negative-quadratic-ricci-lower-bound

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#def:negative-quadratic-ricci-lower-bound
uses: []
```

# cor:bounded-weak-subsolution-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#cor:bounded-weak-subsolution-wmp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#def:negative-quadratic-ricci-lower-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:static-weak-subsolution-wmp]]'
```

# rem:li-yau-below-bounded-uniqueness

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:li-yau-below-bounded-uniqueness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#def:negative-quadratic-ricci-lower-bound]]'
```

# thm:evolving-metric-weak-subsolution-wmp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:evolving-metric-weak-subsolution-wmp
uses: []
```

# rem:evolving-wmp-positive-part

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:evolving-wmp-positive-part
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:evolving-metric-weak-subsolution-wmp]]'
```

# thm:l1-heat-subsolution-vanishing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:l1-heat-subsolution-vanishing
uses: []
```

# cor:l1-heat-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#cor:l1-heat-uniqueness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:absolute-value-harmonic-subsolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:l1-heat-subsolution-vanishing]]'
```

# thm:lp-heat-subsolution-vanishing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:lp-heat-subsolution-vanishing
uses: []
```

# lem:intrinsic-mollification-smooth

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#lem:intrinsic-mollification-smooth
uses: []
```

# lem:intrinsic-mollifier-derivative-convergence

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#lem:intrinsic-mollifier-derivative-convergence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:intrinsic-mollification-smooth]]'
```

# lem:bounded-curvature-distance-like-function

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#lem:bounded-curvature-distance-like-function
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:intrinsic-mollification-smooth]]'
```

# prop:noncompact-system-preserves-nonnegativity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#prop:noncompact-system-preserves-nonnegativity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:ricci-flow-barrier-supersolution]]'
```

# rem:system-wmp-closed-manifolds

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:system-wmp-closed-manifolds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#prop:noncompact-system-preserves-nonnegativity]]'
```

# thm:noncompact-two-tensor-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:noncompact-two-tensor-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#prop:noncompact-system-preserves-nonnegativity]]'
```

# thm:weinberger-hamilton-noncompact-systems

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:weinberger-hamilton-noncompact-systems
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:time-dependent-convex-set-maximum-principle]]'
```

# thm:time-dependent-convex-set-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:time-dependent-convex-set-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:ricci-flow-barrier-supersolution]]'
```

# rem:barrier-applied-to-distance-from-convex-set

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:barrier-applied-to-distance-from-convex-set
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:time-dependent-convex-set-maximum-principle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:ricci-flow-barrier-supersolution]]'
```

# thm:noncompact-system-avoidance-set-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:noncompact-system-avoidance-set-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:time-dependent-convex-set-maximum-principle]]'
```

# rem:maximum-principles-time-dependent-bundle-metric

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:maximum-principles-time-dependent-bundle-metric
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:noncompact-two-tensor-maximum-principle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:weinberger-hamilton-noncompact-systems]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:time-dependent-convex-set-maximum-principle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:noncompact-system-avoidance-set-maximum-principle]]'
```

# thm:manifold-parabolic-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:manifold-parabolic-strong-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:euclidean-parabolic-strong-maximum-principle]]'
```

# thm:euclidean-parabolic-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:euclidean-parabolic-strong-maximum-principle
uses: []
```

# cor:cylindrical-parabolic-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#cor:cylindrical-parabolic-strong-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:euclidean-parabolic-strong-maximum-principle]]'
```

# cor:ricci-flow-scalar-curvature-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#cor:ricci-flow-scalar-curvature-strong-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:manifold-parabolic-strong-maximum-principle]]'
```

# cor:euclidean-heat-mean-value-property

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#cor:euclidean-heat-mean-value-property
uses: []
```

# rem:divergence-form-mean-value-property

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:divergence-form-mean-value-property
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#cor:euclidean-heat-mean-value-property]]'
```

# cor:heat-mean-value-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#cor:heat-mean-value-strong-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#cor:euclidean-heat-mean-value-property]]'
```

# prop:system-strong-maximum-principle-positive-definite

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#prop:system-strong-maximum-principle-positive-definite
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:manifold-parabolic-strong-maximum-principle]]'
```

# rem:system-strong-maximum-principle-locality

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:system-strong-maximum-principle-locality
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#prop:system-strong-maximum-principle-positive-definite]]'
```

# prop:system-strong-maximum-principle-eigenvalue-sums

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#prop:system-strong-maximum-principle-eigenvalue-sums
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:manifold-parabolic-strong-maximum-principle]]'
```

# thm:system-null-space-rigidity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:system-null-space-rigidity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#prop:system-strong-maximum-principle-eigenvalue-sums]]'
```

# rem:null-space-infinitesimal-parallel-invariance

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:null-space-infinitesimal-parallel-invariance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:system-null-space-rigidity]]'
```

# rem:noncompact-ricci-flow-curvature-consequences

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:noncompact-ricci-flow-curvature-consequences
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:noncompact-two-tensor-maximum-principle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:weinberger-hamilton-noncompact-systems]]'
```

# thm:curvature-operator-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#thm:curvature-operator-strong-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#prop:system-strong-maximum-principle-positive-definite]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:system-null-space-rigidity]]'
```

# rem:curvature-operator-image-time-interval

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:curvature-operator-image-time-interval
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:curvature-operator-strong-maximum-principle]]'
```

# rem:kahler-ricci-positive-bisectional-curvature

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#rem:kahler-ricci-positive-bisectional-curvature
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#prop:system-strong-maximum-principle-positive-definite]]'
```

# ex:backward-time-convex-set-maximum-principle

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#ex:backward-time-convex-set-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:ricci-flow-barrier-supersolution]]'
```

# ex:construct-general-metric-barrier

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#ex:construct-general-metric-barrier
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#lem:general-metric-barrier-supersolution]]'
```

# ex:derive-lp-heat-energy-inequality

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles.tex#ex:derive-lp-heat-energy-inequality
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch12-noncompact-maximum-principles#thm:lp-heat-subsolution-vanishing]]'
```
