# ch:chow-iv-noncompact-gradient-ricci-solitons

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#ch:chow-iv-noncompact-gradient-ricci-solitons
uses: []
```

# def:chow-iv-grs-structure

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#def:chow-iv-grs-structure
uses: []
```

# def:chow-iv-weighted-operators

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#def:chow-iv-weighted-operators
uses: []
```

# thm:chow-iv-scalar-curvature-lower-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-scalar-curvature-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#def:chow-iv-weighted-operators]]'
```

# rem:chow-iv-scalar-lower-sharp

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-scalar-lower-sharp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-scalar-curvature-lower-bound]]'
```

# thm:chow-iv-gradient-potential-bounds

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-gradient-potential-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-scalar-curvature-lower-bound]]'
```

# rem:chow-iv-gradient-potential-sharp

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-gradient-potential-sharp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-gradient-potential-bounds]]'
```

# lem:chow-iv-vector-field-completeness

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#lem:chow-iv-vector-field-completeness
uses: []
```

# cor:chow-iv-gradient-complete

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#cor:chow-iv-gradient-complete
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-gradient-potential-bounds]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#lem:chow-iv-vector-field-completeness]]'
```

# prop:chow-iv-scalar-lower-equality

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#prop:chow-iv-scalar-lower-equality
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-scalar-curvature-lower-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#cor:chow-iv-gradient-complete]]'
```

# lem:chow-iv-hessian-characterizes-euclidean

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#lem:chow-iv-hessian-characterizes-euclidean
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#prop:chow-iv-scalar-lower-equality]]'
```

# cor:chow-iv-potential-bounds

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#cor:chow-iv-potential-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-gradient-potential-bounds]]'
```

# thm:chow-iv-potential-lower-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-potential-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#cor:chow-iv-potential-bounds]]'
```

# rem:chow-iv-potential-part-iii-comparison

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-potential-part-iii-comparison
uses: []
```

# cor:chow-iv-potential-minima-distance

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#cor:chow-iv-potential-minima-distance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-potential-lower-bound]]'
```

# lem:chow-iv-scalar-quadratic-upper

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#lem:chow-iv-scalar-quadratic-upper
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#cor:chow-iv-potential-bounds]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-scalar-curvature-lower-bound]]'
```

# cor:chow-iv-finite-topological-type

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#cor:chow-iv-finite-topological-type
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-potential-lower-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#lem:chow-iv-scalar-quadratic-upper]]'
```

# thm:chow-iv-four-dimensional-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-four-dimensional-curvature
uses: []
```

# lem:chow-iv-linear-net-scalar

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#lem:chow-iv-linear-net-scalar
uses: []
```

# prop:chow-iv-expander-curvature-decay

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#prop:chow-iv-expander-curvature-decay
uses: []
```

# thm:chow-iv-kahler-expander-rigidity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-kahler-expander-rigidity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#prop:chow-iv-expander-curvature-decay]]'
```

# cor:chow-iv-kahler-expander-nonexistence

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#cor:chow-iv-kahler-expander-nonexistence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#prop:chow-iv-expander-curvature-decay]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-kahler-expander-rigidity]]'
```

# thm:chow-iv-shrinker-quadratic-lower

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-shrinker-quadratic-lower
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#def:chow-iv-weighted-operators]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-potential-lower-bound]]'
```

# rem:chow-iv-shrinker-quadratic-sharp

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-shrinker-quadratic-sharp
uses: []
```

# thm:chow-iv-steady-exponential-lower

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-steady-exponential-lower
uses: []
```

# rem:chow-iv-cigar

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-cigar
uses: []
```

# def:chow-iv-avr

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#def:chow-iv-avr
uses: []
```

# prop:chow-iv-coarea

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#prop:chow-iv-coarea
uses: []
```

# lem:chow-iv-sublevel-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#lem:chow-iv-sublevel-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#prop:chow-iv-coarea]]'
```

# lem:chow-iv-sublevel-differential-identity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#lem:chow-iv-sublevel-differential-identity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#lem:chow-iv-sublevel-derivatives]]'
```

# thm:chow-iv-avr-exists

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-avr-exists
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#lem:chow-iv-sublevel-derivatives]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#lem:chow-iv-sublevel-differential-identity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#def:chow-iv-avr]]'
```

# prop:chow-iv-positive-avr

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#prop:chow-iv-positive-avr
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-avr-exists]]'
```

# cor:chow-iv-volume-lower-scalar

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#cor:chow-iv-volume-lower-scalar
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#prop:chow-iv-positive-avr]]'
```

# rem:chow-iv-cylinder-shrinkers

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-cylinder-shrinkers
uses: []
```

# thm:chow-iv-bakry-emery-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-bakry-emery-comparison
uses: []
```

# thm:chow-iv-euclidean-volume-growth

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-euclidean-volume-growth
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-bakry-emery-comparison]]'
```

# rem:chow-iv-volume-at-scalar-minimum

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-volume-at-scalar-minimum
uses: []
```

# def:chow-iv-shrinker-entropy

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#def:chow-iv-shrinker-entropy
uses: []
```

# thm:chow-iv-sharp-log-sobolev

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-sharp-log-sobolev
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#def:chow-iv-shrinker-entropy]]'
```

# rem:chow-iv-log-sobolev-closed

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-log-sobolev-closed
uses: []
```

# lem:chow-iv-fisher-entropy-dissipation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#lem:chow-iv-fisher-entropy-dissipation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#def:chow-iv-weighted-operators]]'
```

# rem:chow-iv-bakry-emery-method

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-bakry-emery-method
uses: []
```

# cor:chow-iv-shrinker-noncollapsing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#cor:chow-iv-shrinker-noncollapsing
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-sharp-log-sobolev]]'
```

# thm:chow-iv-shrinker-linear-growth

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-shrinker-linear-growth
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-sharp-log-sobolev]]'
```

# thm:chow-iv-asymptotic-cone-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-asymptotic-cone-uniqueness
uses: []
```

# thm:chow-iv-asymptotic-cone

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-asymptotic-cone
uses: []
```

# thm:chow-iv-positive-scalar-shrinker

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-positive-scalar-shrinker
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#cor:chow-iv-gradient-complete]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#prop:chow-iv-scalar-lower-equality]]'
```

# thm:chow-iv-nonnegative-ricci-avr-zero

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#thm:chow-iv-nonnegative-ricci-avr-zero
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-positive-scalar-shrinker]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#cor:chow-iv-volume-lower-scalar]]'
```

# rem:chow-iv-ricci-flat-positive-avr

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#rem:chow-iv-ricci-flat-positive-avr
uses: []
```

# conj:chow-iv-bounded-curvature-conjecture

```qprint
kind: conjecture
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#conj:chow-iv-bounded-curvature-conjecture
uses: []
```

# conj:chow-iv-elliptic-harnack

```qprint
kind: conjecture
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#conj:chow-iv-elliptic-harnack
uses: []
```

# ex:chow-iv-harnack-topology

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#ex:chow-iv-harnack-topology
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#conj:chow-iv-elliptic-harnack]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#cor:chow-iv-finite-topological-type]]'
```

# ex:chow-iv-radial-density-monotone

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#ex:chow-iv-radial-density-monotone
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#thm:chow-iv-euclidean-volume-growth]]'
```

# ex:chow-iv-second-radial-density

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#ex:chow-iv-second-radial-density
uses: []
```

# ex:chow-iv-weighted-conjugation

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#ex:chow-iv-weighted-conjugation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons#def:chow-iv-weighted-operators]]'
```

# prob:chow-iv-avr-one

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#prob:chow-iv-avr-one
uses: []
```

# prob:chow-iv-critical-growth

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#prob:chow-iv-critical-growth
uses: []
```

# prob:chow-iv-expander-potential

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#prob:chow-iv-expander-potential
uses: []
```

# prob:chow-iv-shrinker-splitting

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#prob:chow-iv-shrinker-splitting
uses: []
```

# ques:chow-iv-compact-factor

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#ques:chow-iv-compact-factor
uses: []
```

# ques:chow-iv-euclidean-growth-no-line

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#ques:chow-iv-euclidean-growth-no-line
uses: []
```

# ques:chow-iv-positive-avr-finite-ascr

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch27-noncompact-gradient-ricci-solitons.tex#ques:chow-iv-positive-avr-finite-ascr
uses: []
```
