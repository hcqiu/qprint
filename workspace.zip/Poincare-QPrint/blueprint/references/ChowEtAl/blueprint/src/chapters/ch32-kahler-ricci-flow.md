# ch:chow-iv-nonsingular-solutions-closed-three-manifolds

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#ch:chow-iv-nonsingular-solutions-closed-three-manifolds
uses: []
```

# def:chow-iv-nonsingular-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#def:chow-iv-nonsingular-solution
uses: []
```

# thm:chow-iv-nonsingular-geometric-decomposition

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#thm:chow-iv-nonsingular-geometric-decomposition
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#def:chow-iv-nonsingular-solution]]'
```

# def:chow-iv-sequential-collapse

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#def:chow-iv-sequential-collapse
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#def:chow-iv-nonsingular-solution]]'
```

# lem:chow-iv-minimum-scalar-curvature-monotonicity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#lem:chow-iv-minimum-scalar-curvature-monotonicity
uses: []
```

# def:chow-iv-pointed-cheeger-gromov-convergence-nrf

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#def:chow-iv-pointed-cheeger-gromov-convergence-nrf
uses: []
```

# thm:chow-iv-hamilton-compactness-nrf

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#thm:chow-iv-hamilton-compactness-nrf
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#def:chow-iv-pointed-cheeger-gromov-convergence-nrf]]'
```

# ex:chow-iv-average-scalar-curvature-pathologies

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#ex:chow-iv-average-scalar-curvature-pathologies
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#def:chow-iv-pointed-cheeger-gromov-convergence-nrf]]'
```

# rem:chow-iv-compactness-global-averages

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#rem:chow-iv-compactness-global-averages
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#ex:chow-iv-average-scalar-curvature-pathologies]]'
```

# def:chow-iv-nrf-limit-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#def:chow-iv-nrf-limit-solution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#def:chow-iv-sequential-collapse]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#thm:chow-iv-hamilton-compactness-nrf]]'
```

# lem:chow-iv-limit-nonnegative-curvature-criterion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#lem:chow-iv-limit-nonnegative-curvature-criterion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#def:chow-iv-nrf-limit-solution]]'
```

# rem:chow-iv-exclude-sphere-line-product

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#rem:chow-iv-exclude-sphere-line-product
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#lem:chow-iv-limit-nonnegative-curvature-criterion]]'
```

# prop:chow-iv-positive-case-spherical-space-form

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#prop:chow-iv-positive-case-spherical-space-form
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#lem:chow-iv-minimum-scalar-curvature-monotonicity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#lem:chow-iv-limit-nonnegative-curvature-criterion]]'
```

# prop:chow-iv-zero-case-flat-metric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#prop:chow-iv-zero-case-flat-metric
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#lem:chow-iv-limit-nonnegative-curvature-criterion]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#def:chow-iv-nrf-limit-solution]]'
```

# prop:chow-iv-negative-case-hyperbolic-limit

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow.tex#prop:chow-iv-negative-case-hyperbolic-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#lem:chow-iv-minimum-scalar-curvature-monotonicity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#def:chow-iv-nrf-limit-solution]]'
```
