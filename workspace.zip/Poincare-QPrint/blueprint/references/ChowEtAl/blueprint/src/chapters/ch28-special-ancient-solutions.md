# ch:chow-iv-special-ancient-solutions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#ch:chow-iv-special-ancient-solutions
uses: []
```

# thm:chow-iv-sharp-lower-scalar

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-sharp-lower-scalar
uses: []
```

# cor:chow-iv-ancient-nonnegative-scalar

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#cor:chow-iv-ancient-nonnegative-scalar
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#thm:chow-iv-sharp-lower-scalar]]'
```

# thm:chow-iv-ancient-3d-sectional

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-ancient-3d-sectional
uses: []
```

# thm:chow-iv-no-local-collapsing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-no-local-collapsing
uses: []
```

# def:chow-iv-finite-time-singularity-model

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#def:chow-iv-finite-time-singularity-model
uses: []
```

# thm:chow-iv-existence-singularity-models

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-existence-singularity-models
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#thm:chow-iv-no-local-collapsing]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#def:chow-iv-finite-time-singularity-model]]'
```

# thm:chow-iv-singularity-models-noncollapsed

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-singularity-models-noncollapsed
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#thm:chow-iv-no-local-collapsing]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#thm:chow-iv-existence-singularity-models]]'
```

# rem:chow-iv-noncompact-extension

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#rem:chow-iv-noncompact-extension
uses: []
```

# thm:chow-iv-compact-singularity-models

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-compact-singularity-models
uses: []
```

# lem:chow-iv-bounded-scalar-criterion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-bounded-scalar-criterion
uses: []
```

# def:chow-iv-kappa-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#def:chow-iv-kappa-solution
uses: []
```

# thm:chow-iv-3d-models-kappa

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-3d-models-kappa
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#def:chow-iv-kappa-solution]]'
```

# thm:chow-iv-canonical-neighborhood

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-canonical-neighborhood
uses: []
```

# thm:chow-iv-3d-models-all-scales

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-3d-models-all-scales
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#thm:chow-iv-canonical-neighborhood]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#thm:chow-iv-no-local-collapsing]]'
```

# thm:chow-iv-bryant-classification

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-bryant-classification
uses: []
```

# thm:chow-iv-asymptotic-shrinker

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-asymptotic-shrinker
uses: []
```

# thm:chow-iv-3d-asymptotic-cone

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-3d-asymptotic-cone
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#def:chow-iv-kappa-solution]]'
```

# def:chow-iv-volume-perimeter

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#def:chow-iv-volume-perimeter
uses: []
```

# thm:chow-iv-relative-isoperimetric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-relative-isoperimetric
uses: []
```

# def:chow-iv-width

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#def:chow-iv-width
uses: []
```

# lem:chow-iv-width-not-euclidean

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-width-not-euclidean
uses: []
```

# ex:chow-iv-cigar

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#ex:chow-iv-cigar
uses: []
```

# thm:chow-iv-finite-width-classification

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-finite-width-classification
uses: []
```

# lem:chow-iv-bochner-inequality

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-bochner-inequality
uses: []
```

# lem:chow-iv-asymptotically-cylindrical

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-asymptotically-cylindrical
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-width-not-euclidean]]'
```

# lem:chow-iv-curvature-derivatives-decay

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-curvature-derivatives-decay
uses: []
```

# lem:chow-iv-first-boundary-term

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-first-boundary-term
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-curvature-derivatives-decay]]'
```

# lem:chow-iv-schwarz-pick

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-schwarz-pick
uses: []
```

# lem:chow-iv-hyperbolic-cusp-barrier

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-hyperbolic-cusp-barrier
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-schwarz-pick]]'
```

# lem:chow-iv-conformal-factor-lower

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-conformal-factor-lower
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-hyperbolic-cusp-barrier]]'
```

# lem:chow-iv-conformal-factor-averages

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-conformal-factor-averages
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-conformal-factor-lower]]'
```

# lem:chow-iv-brezis-merle

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-brezis-merle
uses: []
```

# lem:chow-iv-conformal-factor-upper

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-conformal-factor-upper
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-brezis-merle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-conformal-factor-averages]]'
```

# lem:chow-iv-conformal-factor-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-conformal-factor-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-conformal-factor-lower]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-conformal-factor-upper]]'
```

# lem:chow-iv-pointwise-flat-cylinder

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-pointwise-flat-cylinder
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-conformal-factor-derivatives]]'
```

# lem:chow-iv-second-boundary-term

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#lem:chow-iv-second-boundary-term
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#lem:chow-iv-pointwise-flat-cylinder]]'
```

# thm:chow-iv-type-i-pco

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-type-i-pco
uses: []
```

# thm:chow-iv-3d-pinched-ricci

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#thm:chow-iv-3d-pinched-ricci
uses: []
```

# rem:chow-iv-asymptotic-cone-problems

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#rem:chow-iv-asymptotic-cone-problems
uses: []
```

# rem:chow-iv-linear-volume-growth

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#rem:chow-iv-linear-volume-growth
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions#thm:chow-iv-singularity-models-noncollapsed]]'
```

# rem:chow-iv-problem-28-3

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#rem:chow-iv-problem-28-3
uses: []
```

# rem:chow-iv-remove-kappa-condition

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#rem:chow-iv-remove-kappa-condition
uses: []
```

# rem:chow-iv-singularity-conjectures

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#rem:chow-iv-singularity-conjectures
uses: []
```

# rem:chow-iv-volume-growth-problems

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch28-special-ancient-solutions.tex#rem:chow-iv-volume-growth-problems
uses: []
```
