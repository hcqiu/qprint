# ch:chow-ii-geometric-analysis

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#ch:chow-ii-geometric-analysis
uses: []
```

# def:chow-ii-euclidean-green-function

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#def:chow-ii-euclidean-green-function
uses: []
```

# lem:chow-ii-euclidean-green-identities

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#lem:chow-ii-euclidean-green-identities
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#def:chow-ii-euclidean-green-function]]'
```

# thm:chow-ii-euclidean-green-fundamental

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-euclidean-green-fundamental
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#lem:chow-ii-euclidean-green-identities]]'
```

# thm:chow-ii-closed-manifold-green-function

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-closed-manifold-green-function
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#thm:chow-ii-euclidean-green-fundamental]]'
```

# lem:chow-ii-green-convolution-estimate

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#lem:chow-ii-green-convolution-estimate
uses: []
```

# thm:chow-ii-green-asymptotics

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-green-asymptotics
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#lem:chow-ii-green-convolution-estimate]]'
```

# thm:chow-ii-hopf-boundary-point

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-hopf-boundary-point
uses: []
```

# def:chow-ii-heat-fundamental-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#def:chow-ii-heat-fundamental-solution
uses: []
```

# lem:chow-ii-duhamel-closed

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#lem:chow-ii-duhamel-closed
uses: []
```

# thm:chow-ii-closed-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-closed-heat-kernel
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#def:chow-ii-heat-fundamental-solution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#lem:chow-ii-duhamel-closed]]'
```

# cor:chow-ii-heat-kernel-sup-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#cor:chow-ii-heat-kernel-sup-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#thm:chow-ii-closed-heat-kernel]]'
```

# def:chow-ii-dirichlet-heat-kernel

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#def:chow-ii-dirichlet-heat-kernel
uses: []
```

# lem:chow-ii-duhamel-boundary

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#lem:chow-ii-duhamel-boundary
uses: []
```

# thm:chow-ii-minimal-positive-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-minimal-positive-heat-kernel
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#def:chow-ii-dirichlet-heat-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#lem:chow-ii-duhamel-boundary]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#thm:chow-ii-hopf-boundary-point]]'
```

# thm:chow-ii-heat-kernel-uniqueness-lower-ricci

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-heat-kernel-uniqueness-lower-ricci
uses: []
```

# thm:chow-ii-cheeger-yau-heat-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-cheeger-yau-heat-comparison
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#thm:chow-ii-heat-kernel-uniqueness-lower-ricci]]'
```

# thm:chow-ii-heat-kernel-products

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-heat-kernel-products
uses: []
```

# thm:chow-ii-li-yau-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-li-yau-estimate
uses: []
```

# thm:chow-ii-path-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-path-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#thm:chow-ii-li-yau-estimate]]'
```

# thm:chow-ii-hamilton-gradient-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-hamilton-gradient-estimate
uses: []
```

# cor:chow-ii-heat-integral-pointwise

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#cor:chow-ii-heat-integral-pointwise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#thm:chow-ii-hamilton-gradient-estimate]]'
```

# cor:chow-ii-heat-gradient-integral

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#cor:chow-ii-heat-gradient-integral
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#cor:chow-ii-heat-integral-pointwise]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis#thm:chow-ii-hamilton-gradient-estimate]]'
```

# thm:chow-ii-heat-laplacian-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appe-geometric-analysis.tex#thm:chow-ii-heat-laplacian-estimate
uses: []
```
