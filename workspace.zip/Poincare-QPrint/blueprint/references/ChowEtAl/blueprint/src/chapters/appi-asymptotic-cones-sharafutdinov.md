# app:chow-iii-asymptotic-cones-sharafutdinov

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#app:chow-iii-asymptotic-cones-sharafutdinov
uses: []
```

# def:chow-iii-i1-rays-busemann

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i1-rays-busemann
uses: []
```

# lem:chow-iii-i2-i3-busemann-bounds

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i2-i3-busemann-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i1-rays-busemann]]'
```

# lem:chow-iii-i4-ray-angle

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i4-ray-angle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i1-rays-busemann]]'
```

# def:chow-iii-i5-halfspaces

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i5-halfspaces
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i1-rays-busemann]]'
```

# lem:chow-iii-i6-i9-halfspace-sublevels

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i6-i9-halfspace-sublevels
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i5-halfspaces]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i2-i3-busemann-bounds]]'
```

# ex:chow-iii-i10-i11-convexity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#ex:chow-iii-i10-i11-convexity
uses: []
```

# prop:chow-iii-i12-i17-busemann-convexity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#prop:chow-iii-i12-i17-busemann-convexity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i4-ray-angle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i6-i9-halfspace-sublevels]]'
```

# thm:chow-iii-i18-splitting

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#thm:chow-iii-i18-splitting
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#prop:chow-iii-i12-i17-busemann-convexity]]'
```

# def:chow-iii-i20-i21-soul

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i20-i21-soul
uses: []
```

# thm:chow-iii-i22-i23-soul

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#thm:chow-iii-i22-i23-soul
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i20-i21-soul]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#prop:chow-iii-i12-i17-busemann-convexity]]'
```

# thm:chow-iii-i24-i25-sharafutdinov

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#thm:chow-iii-i24-i25-sharafutdinov
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#prop:chow-iii-i12-i17-busemann-convexity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i20-i21-soul]]'
```

# def:chow-iii-i27-ideal-angle

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i27-ideal-angle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i1-rays-busemann]]'
```

# lem:chow-iii-i27-pseudometric

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i27-pseudometric
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i27-ideal-angle]]'
```

# thm:chow-iii-i26-asymptotic-cone

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#thm:chow-iii-i26-asymptotic-cone
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i27-pseudometric]]'
```

# def:chow-iii-i28-sphere-maps

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i28-sphere-maps
uses: []
```

# prop:chow-iii-i29-small-sphere-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#prop:chow-iii-i29-small-sphere-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i28-sphere-maps]]'
```

# def:chow-iii-i30-i31-gradient-regularity

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i30-i31-gradient-regularity
uses: []
```

# lem:chow-iii-i30-i33-regular-open

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i30-i33-regular-open
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i30-i31-gradient-regularity]]'
```

# lem:chow-iii-i34-i35-regular-characterization

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i34-i35-regular-characterization
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i30-i31-gradient-regularity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i30-i33-regular-open]]'
```

# lem:chow-iii-i37-angle-decay

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i37-angle-decay
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i30-i31-gradient-regularity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i34-i35-regular-characterization]]'
```

# def:chow-iii-i39-lipschitz-hypersurface

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i39-lipschitz-hypersurface
uses: []
```

# lem:chow-iii-i40-lipschitz-complete

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i40-lipschitz-complete
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i39-lipschitz-hypersurface]]'
```

# prop:chow-iii-i41-large-distance-spheres

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#prop:chow-iii-i41-large-distance-spheres
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i37-angle-decay]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i40-lipschitz-complete]]'
```

# lem:chow-iii-i42-tubular-projection

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i42-tubular-projection
uses: []
```

# thm:chow-iii-i44-approximate-busemann-feller

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#thm:chow-iii-i44-approximate-busemann-feller
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i42-tubular-projection]]'
```

# lem:chow-iii-i45-mollified-distance

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i45-mollified-distance
uses: []
```

# lem:chow-iii-i47-mollified-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i47-mollified-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i45-mollified-distance]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i37-angle-decay]]'
```

# ex:chow-iii-i46-i49-mollification

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#ex:chow-iii-i46-i49-mollification
uses: []
```

# clm:chow-iii-i50-large-sphere-maps

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#clm:chow-iii-i50-large-sphere-maps
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#prop:chow-iii-i29-small-sphere-monotonicity]]'
```

# def:chow-iii-i51-ray-equivalence

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i51-ray-equivalence
uses: []
```

# ex:chow-iii-i51-euclidean-boundary

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#ex:chow-iii-i51-euclidean-boundary
uses: []
```

# lem:chow-iii-i52-rays-at-basepoint

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i52-rays-at-basepoint
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i51-ray-equivalence]]'
```

# def:chow-iii-i53-ray-distance

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#def:chow-iii-i53-ray-distance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i51-ray-equivalence]]'
```

# lem:chow-iii-i53-ray-distance-well-defined

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#lem:chow-iii-i53-ray-distance-well-defined
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#def:chow-iii-i53-ray-distance]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i52-rays-at-basepoint]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#clm:chow-iii-i50-large-sphere-maps]]'
```

# clm:chow-iii-i54-points-at-infinity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#clm:chow-iii-i54-points-at-infinity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov#lem:chow-iii-i53-ray-distance-well-defined]]'
```

# rem:chow-iii-i55-tits-metric

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appi-asymptotic-cones-sharafutdinov.tex#rem:chow-iii-i55-tits-metric
uses: []
```
