# ch:chow-iv-type-i-singularities-ancient-solutions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#ch:chow-iv-type-i-singularities-ancient-solutions
uses: []
```

# def:chow-iv-type-a-singular-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#def:chow-iv-type-a-singular-solution
uses: []
```

# lem:chow-iv-shi-estimates-type-a

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-shi-estimates-type-a
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#def:chow-iv-type-a-singular-solution]]'
```

# def:chow-iv-reduced-distance-singular-time

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#def:chow-iv-reduced-distance-singular-time
uses: []
```

# lem:chow-iv-type-a-l-distance-upper-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-type-a-l-distance-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#def:chow-iv-type-a-singular-solution]]'
```

# cor:chow-iv-type-a-l-distance-compact-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#cor:chow-iv-type-a-l-distance-compact-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-a-l-distance-upper-bound]]'
```

# lem:chow-iv-type-a-l-distance-gradient-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-type-a-l-distance-gradient-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-shi-estimates-type-a]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-a-l-distance-upper-bound]]'
```

# lem:chow-iv-type-a-l-distance-time-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-type-a-l-distance-time-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-a-l-distance-gradient-bound]]'
```

# thm:chow-iv-singular-time-reduced-distance-limit

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-singular-time-reduced-distance-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#def:chow-iv-reduced-distance-singular-time]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#cor:chow-iv-type-a-l-distance-compact-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-a-l-distance-gradient-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-a-l-distance-time-bound]]'
```

# cor:chow-iv-type-a-singular-time-reduced-distance

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#cor:chow-iv-type-a-singular-time-reduced-distance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-singular-time-reduced-distance-limit]]'
```

# rem:chow-iv-strong-reduced-distance-gradient-convergence

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#rem:chow-iv-strong-reduced-distance-gradient-convergence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-singular-time-reduced-distance-limit]]'
```

# thm:chow-iv-singular-time-reduced-volume-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-singular-time-reduced-volume-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-singular-time-reduced-distance-limit]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#prop:chow-iv-limit-reduced-distance-estimates]]'
```

# cor:chow-iv-type-i-singular-time-reduced-volume

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#cor:chow-iv-type-i-singular-time-reduced-volume
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#cor:chow-iv-type-a-singular-time-reduced-distance]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-singular-time-reduced-volume-monotonicity]]'
```

# lem:chow-iv-type-i-reduced-distance-quadratic-upper-growth

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-type-i-reduced-distance-quadratic-upper-growth
uses: []
```

# cor:chow-iv-type-i-reduced-distance-derivative-bounds

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#cor:chow-iv-type-i-reduced-distance-derivative-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-i-reduced-distance-quadratic-upper-growth]]'
```

# lem:chow-iv-type-i-reduced-distance-lower-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-type-i-reduced-distance-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-i-reduced-distance-quadratic-upper-growth]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#cor:chow-iv-type-i-reduced-distance-derivative-bounds]]'
```

# prop:chow-iv-limit-reduced-distance-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#prop:chow-iv-limit-reduced-distance-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-i-reduced-distance-quadratic-upper-growth]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#cor:chow-iv-type-i-reduced-distance-derivative-bounds]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-i-reduced-distance-lower-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-singular-time-reduced-distance-limit]]'
```

# prop:chow-iv-fixed-basepoint-type-i-limits-shrinkers

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#prop:chow-iv-fixed-basepoint-type-i-limits-shrinkers
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#cor:chow-iv-type-i-singular-time-reduced-volume]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#prop:chow-iv-limit-reduced-distance-estimates]]'
```

# rem:chow-iv-flat-fixed-basepoint-type-i-limit

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#rem:chow-iv-flat-fixed-basepoint-type-i-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#prop:chow-iv-fixed-basepoint-type-i-limits-shrinkers]]'
```

# def:chow-iv-type-i-singular-point-set

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#def:chow-iv-type-i-singular-point-set
uses: []
```

# thm:chow-iv-type-i-singular-point-limits-nonflat

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-type-i-singular-point-limits-nonflat
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#def:chow-iv-type-i-singular-point-set]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#prop:chow-iv-fixed-basepoint-type-i-limits-shrinkers]]'
```

# thm:chow-iv-type-i-singular-scalar-curvature-unbounded

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-type-i-singular-scalar-curvature-unbounded
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-type-i-singular-point-limits-nonflat]]'
```

# def:chow-iv-singular-point-sets

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#def:chow-iv-singular-point-sets
uses: []
```

# thm:chow-iv-type-i-singular-point-sets-equal

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-type-i-singular-point-sets-equal
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#def:chow-iv-type-i-singular-point-set]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#def:chow-iv-singular-point-sets]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#prop:chow-iv-fixed-basepoint-type-i-limits-shrinkers]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-type-i-singular-point-limits-nonflat]]'
```

# cor:chow-iv-distinguish-type-i-singular-points

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#cor:chow-iv-distinguish-type-i-singular-points
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-type-i-singular-point-sets-equal]]'
```

# thm:chow-iv-singular-point-curvature-scale-limits-nonflat

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-singular-point-curvature-scale-limits-nonflat
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-type-i-singular-point-sets-equal]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-type-i-singular-point-limits-nonflat]]'
```

# lem:chow-iv-shrinker-canonical-form-characterization

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-shrinker-canonical-form-characterization
uses: []
```

# thm:chow-iv-type-i-ancient-asymptotic-shrinkers

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-type-i-ancient-asymptotic-shrinkers
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#cor:chow-iv-type-a-singular-time-reduced-distance]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#prop:chow-iv-limit-reduced-distance-estimates]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-shrinker-canonical-form-characterization]]'
```

# prop:chow-iv-shrinker-backward-limit-isometric

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#prop:chow-iv-shrinker-backward-limit-isometric
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-shrinker-canonical-form-characterization]]'
```

# thm:chow-iv-equal-asymptotic-shrinkers-rigidity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-equal-asymptotic-shrinkers-rigidity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-type-i-ancient-asymptotic-shrinkers]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#prop:chow-iv-shrinker-backward-limit-isometric]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#cor:chow-iv-type-i-singular-time-reduced-volume]]'
```

# thm:chow-iv-type-i-ancient-nonflat-backward-shrinker

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-type-i-ancient-nonflat-backward-shrinker
uses: []
```

# thm:chow-iv-three-dimensional-type-ii-asymptotic-shrinker

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-three-dimensional-type-ii-asymptotic-shrinker
uses: []
```

# lem:chow-iv-shrinker-vector-field-radial-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-shrinker-vector-field-radial-bound
uses: []
```

# lem:chow-iv-shrinker-vector-field-complete

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#lem:chow-iv-shrinker-vector-field-complete
uses: []
```

# thm:chow-iv-bounded-curvature-shrinker-gradient-noncollapsed

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#thm:chow-iv-bounded-curvature-shrinker-gradient-noncollapsed
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-shrinker-vector-field-radial-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-shrinker-vector-field-complete]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#thm:chow-iv-type-i-ancient-asymptotic-shrinkers]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#prop:chow-iv-shrinker-backward-limit-isometric]]'
```

# conj:chow-iv-type-a-nonflat-shrinker-model

```qprint
kind: conjecture
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#conj:chow-iv-type-a-nonflat-shrinker-model
uses: []
```

# conj:chow-iv-type-ii-ancient-backward-shrinker

```qprint
kind: conjecture
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#conj:chow-iv-type-ii-ancient-backward-shrinker
uses: []
```

# ex:chow-iv-explicit-l-distance-derivative-bounds

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#ex:chow-iv-explicit-l-distance-derivative-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-a-l-distance-gradient-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-a-l-distance-time-bound]]'
```

# ex:chow-iv-optimize-type-a-test-path

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#ex:chow-iv-optimize-type-a-test-path
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-type-a-l-distance-upper-bound]]'
```

# ex:chow-iv-shrinker-canonical-normalization

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#ex:chow-iv-shrinker-canonical-normalization
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-shrinker-canonical-form-characterization]]'
```

# ex:chow-iv-shrinker-vector-field-evolution

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow.tex#ex:chow-iv-shrinker-vector-field-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch30-three-dimensional-ricci-flow#lem:chow-iv-shrinker-vector-field-complete]]'
```
