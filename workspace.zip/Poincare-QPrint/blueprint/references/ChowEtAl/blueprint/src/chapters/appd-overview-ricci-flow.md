# app:chow-ii-overview-ricci-flow

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#app:chow-ii-overview-ricci-flow
uses: []
```

# thm:chow-ii-appd-short-time-existence-closed

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-short-time-existence-closed
uses: []
```

# thm:chow-ii-appd-short-time-existence-complete

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-short-time-existence-complete
uses: []
```

# thm:chow-ii-appd-uniqueness-complete

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-uniqueness-complete
uses: []
```

# thm:chow-ii-appd-long-time-existence-closed

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-long-time-existence-closed
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-short-time-existence-closed]]'
```

# thm:chow-ii-appd-long-time-existence-complete

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-long-time-existence-complete
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-short-time-existence-complete]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-uniqueness-complete]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-shi-local-higher-derivative-estimates]]'
```

# thm:chow-ii-appd-long-time-existence-ricci-blowup

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-long-time-existence-ricci-blowup
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-long-time-existence-closed]]'
```

# thm:chow-ii-appd-hamilton-positive-ricci-three-manifolds

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-hamilton-positive-ricci-three-manifolds
uses: []
```

# rem:chow-ii-appd-closed-surfaces

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#rem:chow-ii-appd-closed-surfaces
uses: []
```

# thm:chow-ii-appd-two-positive-curvature-convergence

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-two-positive-curvature-convergence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#thm:chow-ii-boehm-wilking-convergence]]'
```

# thm:chow-ii-appd-quarter-pinched-space-form

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-quarter-pinched-space-form
uses: []
```

# def:chow-ii-appd-curvature-operator-evolution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#def:chow-ii-appd-curvature-operator-evolution
uses: []
```

# def:chow-ii-appd-rotationally-symmetric-flow

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#def:chow-ii-appd-rotationally-symmetric-flow
uses: []
```

# thm:chow-ii-appd-neckpinch-existence

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-neckpinch-existence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-rotationally-symmetric-flow]]'
```

# thm:chow-ii-appd-neckpinch-asymptotics

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-neckpinch-asymptotics
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-neckpinch-existence]]'
```

# rem:chow-ii-appd-projective-neckpinch

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#rem:chow-ii-appd-projective-neckpinch
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-neckpinch-asymptotics]]'
```

# rem:chow-ii-appd-growing-neck-length

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#rem:chow-ii-appd-growing-neck-length
uses: []
```

# prop:chow-ii-appd-neckpinch-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#prop:chow-ii-appd-neckpinch-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-rotationally-symmetric-flow]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-neckpinch-existence]]'
```

# thm:chow-ii-appd-hamilton-ivey

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-hamilton-ivey
uses: []
```

# rem:chow-ii-appd-hamilton-ivey-noncompact

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#rem:chow-ii-appd-hamilton-ivey-noncompact
uses: []
```

# cor:chow-ii-appd-almost-nonnegative-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#cor:chow-ii-appd-almost-nonnegative-curvature
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-hamilton-ivey]]'
```

# lem:chow-ii-appd-ancient-three-dimensional-nonnegative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-ancient-three-dimensional-nonnegative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-hamilton-ivey]]'
```

# thm:chow-ii-appd-curvature-operator-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-curvature-operator-strong-maximum-principle
uses: []
```

# thm:chow-ii-appd-three-manifold-curvature-rigidity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-three-manifold-curvature-rigidity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-curvature-operator-strong-maximum-principle]]'
```

# thm:chow-ii-appd-global-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-global-derivative-estimates
uses: []
```

# thm:chow-ii-appd-local-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-local-derivative-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-shi-local-higher-derivative-estimates]]'
```

# thm:chow-ii-appd-modified-global-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-modified-global-derivative-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch14-local-derivative-estimates#thm:chow-ii-shi-estimates-initial-derivative-bounds]]'
```

# thm:chow-ii-appd-trace-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-trace-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#cor:chow-ii-trace-harnack-and-tr-monotonicity]]'
```

# thm:chow-ii-appd-matrix-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-matrix-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-hamilton-matrix-harnack]]'
```

# thm:chow-ii-appd-linear-trace-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-linear-trace-harnack
uses: []
```

# def:chow-ii-appd-perelman-energy-entropy

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#def:chow-ii-appd-perelman-energy-entropy
uses: []
```

# def:chow-ii-appd-perelman-invariants

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#def:chow-ii-appd-perelman-invariants
uses: []
```

# lem:chow-ii-appd-lambda-monotonicity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-lambda-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-energy-entropy]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
```

# lem:chow-ii-appd-no-steady-breathers

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-no-steady-breathers
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#lem:chow-ii-appd-lambda-monotonicity]]'
```

# lem:chow-ii-appd-normalized-lambda-monotonicity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-normalized-lambda-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#lem:chow-ii-appd-lambda-monotonicity]]'
```

# lem:chow-ii-appd-no-expanding-breathers

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-no-expanding-breathers
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#lem:chow-ii-appd-normalized-lambda-monotonicity]]'
```

# lem:chow-ii-appd-classical-entropy-monotonicity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-classical-entropy-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-energy-entropy]]'
```

# thm:chow-ii-appd-ricci-flow-compactness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-ricci-flow-compactness
uses: []
```

# rem:chow-ii-appd-compactness-without-injectivity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#rem:chow-ii-appd-compactness-without-injectivity
uses: []
```

# thm:chow-ii-appd-no-local-collapsing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-no-local-collapsing
uses: []
```

# thm:chow-ii-appd-improved-no-local-collapsing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-improved-no-local-collapsing
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-no-local-collapsing]]'
```

# lem:chow-ii-appd-mu-monotonicity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-mu-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-energy-entropy]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
```

# lem:chow-ii-appd-mu-cheeger-gromov

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-mu-cheeger-gromov
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
```

# thm:chow-ii-appd-shrinking-breathers

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-shrinking-breathers
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#lem:chow-ii-appd-mu-monotonicity]]'
```

# lem:chow-ii-appd-mu-large-tau

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-mu-large-tau
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
```

# lem:chow-ii-appd-mu-small-tau

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-mu-small-tau
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
```

# lem:chow-ii-appd-nu-monotonicity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#lem:chow-ii-appd-nu-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#lem:chow-ii-appd-mu-monotonicity]]'
```

# prop:chow-ii-appd-mu-controls-volume-ratios

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#prop:chow-ii-appd-mu-controls-volume-ratios
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
```

# prop:chow-ii-appd-bound-mu-local-geometry

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#prop:chow-ii-appd-bound-mu-local-geometry
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
```

# prop:chow-ii-appd-bound-volume-ratios-nu

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#prop:chow-ii-appd-bound-volume-ratios-nu
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#def:chow-ii-appd-perelman-invariants]]'
```

# cor:chow-ii-appd-obtaining-singularity-models

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#cor:chow-ii-appd-obtaining-singularity-models
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-ricci-flow-compactness]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-no-local-collapsing]]'
```

# cor:chow-ii-appd-cigar-not-singularity-model

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#cor:chow-ii-appd-cigar-not-singularity-model
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#cor:chow-ii-appd-obtaining-singularity-models]]'
```

# thm:chow-ii-appd-immortal-expanding-soliton

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#thm:chow-ii-appd-immortal-expanding-soliton
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-trace-harnack]]'
```

# prop:chow-ii-appd-embedded-epsilon-necks

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow.tex#prop:chow-ii-appd-embedded-epsilon-necks
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appd-overview-ricci-flow#thm:chow-ii-appd-neckpinch-asymptotics]]'
```
