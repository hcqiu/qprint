# ch:chow-iv-noncompact-hyperbolic-limits

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#ch:chow-iv-noncompact-hyperbolic-limits
uses: []
```

# def:chow-iv-cmc-boundary-conditions

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-cmc-boundary-conditions
uses: []
```

# def:chow-iv-stable-hyperbolic-limit

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-stable-hyperbolic-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-cmc-boundary-conditions]]'
```

# rem:chow-iv-stable-hyperbolic-limit-properties

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#rem:chow-iv-stable-hyperbolic-limit-properties
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-stable-hyperbolic-limit]]'
```

# def:chow-iv-immortal-almost-hyperbolic-piece

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-immortal-almost-hyperbolic-piece
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-cmc-boundary-conditions]]'
```

# prop:chow-iv-almost-hyperbolic-pieces-immortal

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-almost-hyperbolic-pieces-immortal
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-immortal-almost-hyperbolic-piece]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-harmonic-parametrizations]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-continue-harmonic-parametrizations]]'
```

# prop:chow-iv-stability-hyperbolic-limits

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-stability-hyperbolic-limits
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-stable-hyperbolic-limit]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-almost-hyperbolic-pieces-immortal]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#thm:chow-iv-minimal-cusp-limit-stable]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-almost-hyperbolic-pieces-disjoint]]'
```

# def:chow-iv-immortal-asymptotically-hyperbolic-piece

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-immortal-asymptotically-hyperbolic-piece
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-immortal-almost-hyperbolic-piece]]'
```

# prop:chow-iv-hyperbolic-collapsed-decomposition

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-hyperbolic-collapsed-decomposition
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-stability-hyperbolic-limits]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-almost-hyperbolic-pieces-disjoint]]'
```

# prop:chow-iv-hyperbolic-boundary-incompressible-summary

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-hyperbolic-boundary-incompressible-summary
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#thm:chow-iv-immortal-piece-boundary-incompressible]]'
```

# def:chow-iv-hypersurface-sweep-out

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-hypersurface-sweep-out
uses: []
```

# prop:chow-iv-cmc-sweepout-almost-cusp

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-cmc-sweepout-almost-cusp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-hypersurface-sweep-out]]'
```

# prop:chow-iv-harmonic-maps-near-identity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-harmonic-maps-near-identity
uses: []
```

# prop:chow-iv-harmonic-parametrizations

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-harmonic-parametrizations
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-cmc-boundary-conditions]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-cmc-sweepout-almost-cusp]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-harmonic-maps-near-identity]]'
```

# prop:chow-iv-continue-harmonic-parametrizations

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-continue-harmonic-parametrizations
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-cmc-sweepout-almost-cusp]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-harmonic-maps-near-identity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-harmonic-parametrizations]]'
```

# def:chow-iv-space-hyperbolic-limits

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-space-hyperbolic-limits
uses: []
```

# prop:chow-iv-minimal-cusp-pieces-immortal

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-minimal-cusp-pieces-immortal
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-space-hyperbolic-limits]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-continue-harmonic-parametrizations]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#cor:chow-iv-mostow-equivalences]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch32-kahler-ricci-flow#prop:chow-iv-negative-case-hyperbolic-limit]]'
```

# thm:chow-iv-minimal-cusp-limit-stable

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#thm:chow-iv-minimal-cusp-limit-stable
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-stable-hyperbolic-limit]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-minimal-cusp-pieces-immortal]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-small-flat-torus-in-cusp]]'
```

# lem:chow-iv-small-flat-torus-in-cusp

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-small-flat-torus-in-cusp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#cor:chow-iv-small-almost-flat-tori]]'
```

# lem:chow-iv-almost-hyperbolic-pieces-disjoint

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-almost-hyperbolic-pieces-disjoint
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-small-flat-torus-in-cusp]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#thm:chow-iv-finite-volume-ends-cusps]]'
```

# thm:chow-iv-immortal-piece-boundary-incompressible

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#thm:chow-iv-immortal-piece-boundary-incompressible
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-disk-class-almost-piece]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-compressible-torus-area-decay]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#lem:chow-iv-boundary-torus-incompressible]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#lem:chow-iv-separating-incompressible-surfaces]]'
```

# def:chow-iv-disk-class-almost-piece

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-disk-class-almost-piece
uses: []
```

# rem:chow-iv-disk-class-notation

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#rem:chow-iv-disk-class-notation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-disk-class-almost-piece]]'
```

# prop:chow-iv-compressible-torus-area-decay

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-compressible-torus-area-decay
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-disk-class-almost-piece]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#thm:chow-iv-meeks-yau]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-minimizing-disk-evolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-area-decay-short-boundary]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-minimizing-disk-boundary-small]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-area-decay-long-boundary]]'
```

# thm:chow-iv-meeks-yau

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#thm:chow-iv-meeks-yau
uses: []
```

# rem:chow-iv-relative-meeks-yau

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#rem:chow-iv-relative-meeks-yau
uses: []
```

# lem:chow-iv-minimizing-disk-first-variation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-minimizing-disk-first-variation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#thm:chow-iv-meeks-yau]]'
```

# lem:chow-iv-minimizing-disk-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-minimizing-disk-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-minimizing-disk-first-variation]]'
```

# lem:chow-iv-disk-torus-slice-transversality

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-disk-torus-slice-transversality
uses: []
```

# lem:chow-iv-area-decay-short-boundary

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-area-decay-short-boundary
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-minimizing-disk-evolution]]'
```

# def:chow-iv-almost-hyperbolic-cusp-region

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-almost-hyperbolic-cusp-region
uses: []
```

# def:chow-iv-almost-cusp-depth

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#def:chow-iv-almost-cusp-depth
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-almost-hyperbolic-cusp-region]]'
```

# rem:chow-iv-almost-cusps-arbitrary-depth

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#rem:chow-iv-almost-cusps-arbitrary-depth
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-almost-cusp-depth]]'
```

# lem:chow-iv-cusp-length-monotonicity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-cusp-length-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-disk-torus-slice-transversality]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#def:chow-iv-almost-cusp-depth]]'
```

# cor:chow-iv-cusp-length-by-swept-area

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#cor:chow-iv-cusp-length-by-swept-area
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-cusp-length-monotonicity]]'
```

# cor:chow-iv-area-almost-bounds-length

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#cor:chow-iv-area-almost-bounds-length
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#cor:chow-iv-cusp-length-by-swept-area]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#rem:chow-iv-almost-cusps-arbitrary-depth]]'
```

# lem:chow-iv-short-loop-deep-cusp

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-short-loop-deep-cusp
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#cor:chow-iv-area-almost-bounds-length]]'
```

# rem:chow-iv-short-loop-depth-requirement

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#rem:chow-iv-short-loop-depth-requirement
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-short-loop-deep-cusp]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#rem:chow-iv-almost-cusps-arbitrary-depth]]'
```

# lem:chow-iv-flat-torus-annulus-area

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-flat-torus-annulus-area
uses: []
```

# prop:chow-iv-minimizing-disk-boundary-small

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#prop:chow-iv-minimizing-disk-boundary-small
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-short-loop-deep-cusp]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-flat-torus-annulus-area]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#cor:chow-iv-area-almost-bounds-length]]'
```

# lem:chow-iv-area-decay-long-boundary

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#lem:chow-iv-area-decay-long-boundary
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#lem:chow-iv-minimizing-disk-evolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-minimizing-disk-boundary-small]]'
```

# ex:chow-iv-collapsed-complement-injectivity-zero

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods.tex#ex:chow-iv-collapsed-complement-injectivity-zero
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch33-surfaces-canonical-neighborhoods#prop:chow-iv-hyperbolic-collapsed-decomposition]]'
```
