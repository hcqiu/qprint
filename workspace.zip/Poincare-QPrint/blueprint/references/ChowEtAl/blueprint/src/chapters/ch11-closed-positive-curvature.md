# ch:chow-ii-closed-positive-curvature

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#ch:chow-ii-closed-positive-curvature
uses: []
```

# def:chow-ii-two-positive-curvature-operator

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-two-positive-curvature-operator
uses: []
```

# def:chow-ii-sharp-product

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-sharp-product
uses: []
```

# lem:chow-ii-sharp-product-intrinsic-formula

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-sharp-product-intrinsic-formula
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-sharp-product]]'
```

# def:chow-ii-two-nonnegative-algebraic-curvature

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-two-nonnegative-algebraic-curvature
uses: []
```

# def:chow-ii-geometrically-nonnegative-curvature

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-geometrically-nonnegative-curvature
uses: []
```

# lem:chow-ii-two-nonnegative-consequences

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-two-nonnegative-consequences
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-two-nonnegative-algebraic-curvature]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-geometrically-nonnegative-curvature]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-algebraic-ricci-contraction]]'
```

# lem:chow-ii-geometric-nonnegativity-defect

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-geometric-nonnegativity-defect
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-geometrically-nonnegative-curvature]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#thm:chow-ii-conjugation-defect-formula]]'
```

# prop:chow-ii-ode-preserves-two-nonnegative

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#prop:chow-ii-ode-preserves-two-nonnegative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-two-nonnegative-algebraic-curvature]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-sharp-product]]'
```

# prop:chow-ii-ricci-flow-preserves-two-nonnegative

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#prop:chow-ii-ricci-flow-preserves-two-nonnegative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#prop:chow-ii-curvature-operator-evolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#prop:chow-ii-ode-preserves-two-nonnegative]]'
```

# prop:chow-ii-strong-two-nonnegative-alternative

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#prop:chow-ii-strong-two-nonnegative-alternative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#prop:chow-ii-ricci-flow-preserves-two-nonnegative]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#prop:chow-ii-ode-preserves-two-nonnegative]]'
```

# prop:chow-ii-preserved-stretched-two-nonnegative-cones

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#prop:chow-ii-preserved-stretched-two-nonnegative-cones
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-linear-image-ode-cone-criterion]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-geometric-nonnegativity-defect]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#prop:chow-ii-ode-preserves-two-nonnegative]]'
```

# def:chow-ii-pinching-family

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-pinching-family
uses: []
```

# thm:chow-ii-pinching-family-nonnegative-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#thm:chow-ii-pinching-family-nonnegative-curvature
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-pinching-family]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#cor:chow-ii-conjugation-defect-eigenvalues]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-linear-image-ode-cone-criterion]]'
```

# cor:chow-ii-pinching-family-two-nonnegative

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#cor:chow-ii-pinching-family-two-nonnegative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#prop:chow-ii-preserved-stretched-two-nonnegative-cones]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#thm:chow-ii-pinching-family-nonnegative-curvature]]'
```

# def:chow-ii-pinching-set

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-pinching-set
uses: []
```

# thm:chow-ii-generalized-pinching-set

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#thm:chow-ii-generalized-pinching-set
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-pinching-family]]'
```

# thm:chow-ii-boehm-wilking-convergence

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#thm:chow-ii-boehm-wilking-convergence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-two-positive-curvature-operator]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#cor:chow-ii-pinching-family-two-nonnegative]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#thm:chow-ii-generalized-pinching-set]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#prop:chow-ii-ricci-flow-preserves-two-nonnegative]]'
```

# def:chow-ii-symmetric-endomorphism-wedge

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-symmetric-endomorphism-wedge
uses: []
```

# lem:chow-ii-symmetric-wedge-properties

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-symmetric-wedge-properties
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-symmetric-endomorphism-wedge]]'
```

# prop:chow-ii-two-tensor-decomposition

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#prop:chow-ii-two-tensor-decomposition
uses: []
```

# def:chow-ii-bianchi-map

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-bianchi-map
uses: []
```

# lem:chow-ii-bianchi-orthogonal-decomposition

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-bianchi-orthogonal-decomposition
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-bianchi-map]]'
```

# lem:chow-ii-wedge-satisfies-bianchi

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-wedge-satisfies-bianchi
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-bianchi-map]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-symmetric-endomorphism-wedge]]'
```

# def:chow-ii-algebraic-ricci-contraction

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-algebraic-ricci-contraction
uses: []
```

# lem:chow-ii-ricci-contraction-wedge

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-ricci-contraction-wedge
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-symmetric-endomorphism-wedge]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-algebraic-ricci-contraction]]'
```

# lem:chow-ii-wedge-embedding-ricci-adjoint

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-wedge-embedding-ricci-adjoint
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-ricci-contraction-wedge]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-wedge-satisfies-bianchi]]'
```

# lem:chow-ii-algebraic-curvature-decomposition

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-algebraic-curvature-decomposition
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-wedge-embedding-ricci-adjoint]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-algebraic-ricci-contraction]]'
```

# cor:chow-ii-trace-free-square-wedge-decomposition

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#cor:chow-ii-trace-free-square-wedge-decomposition
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-algebraic-curvature-decomposition]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-ricci-contraction-wedge]]'
```

# prop:chow-ii-curvature-operator-evolution

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#prop:chow-ii-curvature-operator-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-sharp-product]]'
```

# cor:chow-ii-curvature-quadratic-trace

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#cor:chow-ii-curvature-quadratic-trace
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-sharp-product]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-algebraic-ricci-contraction]]'
```

# def:chow-ii-ell-transformations

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-ell-transformations
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-algebraic-curvature-decomposition]]'
```

# def:chow-ii-conjugated-curvature-quadratic

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#def:chow-ii-conjugated-curvature-quadratic
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-ell-transformations]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-sharp-product]]'
```

# lem:chow-ii-linear-image-ode-cone-criterion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-linear-image-ode-cone-criterion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-conjugated-curvature-quadratic]]'
```

# lem:chow-ii-sharp-identity-formula

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-sharp-identity-formula
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-sharp-product]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-algebraic-ricci-contraction]]'
```

# lem:chow-ii-quadratic-zero-weyl

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#lem:chow-ii-quadratic-zero-weyl
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-sharp-identity-formula]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#cor:chow-ii-trace-free-square-wedge-decomposition]]'
```

# cor:chow-ii-zero-weyl-quadratic-components

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#cor:chow-ii-zero-weyl-quadratic-components
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-quadratic-zero-weyl]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-ricci-contraction-wedge]]'
```

# thm:chow-ii-conjugation-defect-formula

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#thm:chow-ii-conjugation-defect-formula
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-conjugated-curvature-quadratic]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#def:chow-ii-algebraic-ricci-contraction]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-sharp-identity-formula]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#lem:chow-ii-quadratic-zero-weyl]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#cor:chow-ii-trace-free-square-wedge-decomposition]]'
```

# cor:chow-ii-conjugation-defect-eigenvalues

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature.tex#cor:chow-ii-conjugation-defect-eigenvalues
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch11-closed-positive-curvature#thm:chow-ii-conjugation-defect-formula]]'
```
