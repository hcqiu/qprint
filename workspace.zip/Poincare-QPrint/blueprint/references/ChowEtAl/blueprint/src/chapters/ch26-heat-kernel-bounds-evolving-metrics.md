# ch:chow-iii-heat-kernel-bounds-evolving-metrics

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#ch:chow-iii-heat-kernel-bounds-evolving-metrics
uses: []
```

# lem:chow-iii-duhamel-evolving-closed

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-duhamel-evolving-closed
uses: []
```

# clm:chow-iii-duhamel-dirichlet-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-duhamel-dirichlet-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-duhamel-evolving-closed]]'
```

# lem:chow-iii-heat-adjoint-kernel-symmetry-closed

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-heat-adjoint-kernel-symmetry-closed
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-duhamel-evolving-closed]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-closed-evolving-heat-kernel]]'
```

# lem:chow-iii-heat-kernel-second-variables-adjoint

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-heat-kernel-second-variables-adjoint
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-heat-adjoint-kernel-symmetry-closed]]'
```

# lem:chow-iii-closed-heat-kernel-mass-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-closed-heat-kernel-mass-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-closed-evolving-heat-kernel]]'
```

# cor:chow-iii-closed-heat-kernel-mass-preservation

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#cor:chow-iii-closed-heat-kernel-mass-preservation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-closed-heat-kernel-mass-bound]]'
```

# lem:chow-iii-closed-heat-kernel-second-mass-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-closed-heat-kernel-second-mass-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-heat-kernel-second-variables-adjoint]]'
```

# lem:chow-iii-closed-heat-kernel-semigroup

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-closed-heat-kernel-semigroup
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-heat-kernel-second-variables-adjoint]]'
```

# lem:chow-iii-dirichlet-heat-adjoint-symmetry

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-dirichlet-heat-adjoint-symmetry
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#clm:chow-iii-duhamel-dirichlet-exercise]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-evolving-dirichlet-heat-kernel]]'
```

# lem:chow-iii-dirichlet-heat-kernel-mass-bounds

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-dirichlet-heat-kernel-mass-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-dirichlet-heat-adjoint-symmetry]]'
```

# clm:chow-iii-dirichlet-mass-lower-bound-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-dirichlet-mass-lower-bound-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-dirichlet-heat-kernel-mass-bounds]]'
```

# lem:chow-iii-dirichlet-heat-kernel-semigroup

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-dirichlet-heat-kernel-semigroup
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#clm:chow-iii-duhamel-dirichlet-exercise]]'
```

# lem:chow-iii-noncompact-heat-adjoint-symmetry

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-noncompact-heat-adjoint-symmetry
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-dirichlet-heat-adjoint-symmetry]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-noncompact-evolving-heat-kernel]]'
```

# lem:chow-iii-noncompact-heat-kernel-mass-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-noncompact-heat-kernel-mass-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-dirichlet-heat-kernel-mass-bounds]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-noncompact-heat-adjoint-symmetry]]'
```

# cor:chow-iii-noncompact-heat-kernel-mass-preservation

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#cor:chow-iii-noncompact-heat-kernel-mass-preservation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-noncompact-heat-kernel-mass-bound]]'
```

# lem:chow-iii-noncompact-heat-kernel-semigroup

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-noncompact-heat-kernel-semigroup
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-dirichlet-heat-kernel-semigroup]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-noncompact-evolving-heat-kernel]]'
```

# lem:chow-iii-rough-evolving-heat-kernel-upper-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-rough-evolving-heat-kernel-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-noncompact-heat-kernel-mass-bound]]'
```

# rem:chow-iii-rough-upper-bound-interpretation

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#rem:chow-iii-rough-upper-bound-interpretation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-rough-evolving-heat-kernel-upper-bound]]'
```

# clm:chow-iii-rough-dirichlet-upper-bound-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-rough-dirichlet-upper-bound-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-rough-evolving-heat-kernel-upper-bound]]'
```

# def:chow-iii-gamma-a-regular-function

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#def:chow-iii-gamma-a-regular-function
uses: []
```

# lem:chow-iii-weighted-l2-heat-estimate

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-weighted-l2-heat-estimate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#def:chow-iii-gamma-a-regular-function]]'
```

# rem:chow-iii-weighted-l2-point-source

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#rem:chow-iii-weighted-l2-point-source
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-weighted-l2-heat-estimate]]'
```

# lem:chow-iii-heat-kernel-average-gaussian-decay

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-heat-kernel-average-gaussian-decay
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-rough-evolving-heat-kernel-upper-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-weighted-l2-heat-estimate]]'
```

# clm:chow-iii-weighted-l2-delta-source-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-weighted-l2-delta-source-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-weighted-l2-heat-estimate]]'
```

# thm:chow-iii-evolving-heat-kernel-gaussian-upper-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-evolving-heat-kernel-gaussian-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-heat-kernel-average-gaussian-decay]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-noncompact-heat-kernel-semigroup]]'
```

# cor:chow-iii-evolving-heat-kernel-one-volume-upper-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#cor:chow-iii-evolving-heat-kernel-one-volume-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-rough-evolving-heat-kernel-upper-bound]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-evolving-heat-kernel-gaussian-upper-bound]]'
```

# clm:chow-iii-space-form-volume-absorption-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-space-form-volume-absorption-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#cor:chow-iii-evolving-heat-kernel-one-volume-upper-bound]]'
```

# lem:chow-iii-heat-kernel-mass-concentration

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-heat-kernel-mass-concentration
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#cor:chow-iii-evolving-heat-kernel-one-volume-upper-bound]]'
```

# cor:chow-iii-heat-kernel-local-mass-lower-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#cor:chow-iii-heat-kernel-local-mass-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-heat-kernel-mass-concentration]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-noncompact-heat-kernel-mass-bound]]'
```

# lem:chow-iii-evolving-heat-kernel-diagonal-lower-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-evolving-heat-kernel-diagonal-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#cor:chow-iii-heat-kernel-local-mass-lower-bound]]'
```

# thm:chow-iii-evolving-heat-kernel-gaussian-lower-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-evolving-heat-kernel-gaussian-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-evolving-heat-kernel-diagonal-lower-bound]]'
```

# thm:chow-iii-davies-double-integral-upper-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-davies-double-integral-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-noncompact-heat-kernel-semigroup]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-weighted-l2-heat-estimate]]'
```

# rem:chow-iii-davies-estimate-pointwise-use

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#rem:chow-iii-davies-estimate-pointwise-use
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-davies-double-integral-upper-bound]]'
```

# thm:chow-iii-euclidean-harmonic-mean-value-property

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-euclidean-harmonic-mean-value-property
uses: []
```

# clm:chow-iii-nonpositive-subharmonic-mean-value-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-nonpositive-subharmonic-mean-value-exercise
uses: []
```

# rem:chow-iii-nonnegative-ricci-euclidean-volume-bound

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#rem:chow-iii-nonnegative-ricci-euclidean-volume-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#clm:chow-iii-nonpositive-subharmonic-mean-value-exercise]]'
```

# clm:chow-iii-euclidean-heat-ball-normalization-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-euclidean-heat-ball-normalization-exercise
uses: []
```

# thm:chow-iii-euclidean-heat-mean-value-property

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-euclidean-heat-mean-value-property
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#clm:chow-iii-euclidean-heat-ball-normalization-exercise]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#lem:chow-iii-euclidean-heat-ball-average-stationary]]'
```

# lem:chow-iii-euclidean-heat-ball-average-stationary

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#lem:chow-iii-euclidean-heat-ball-average-stationary
uses: []
```

# thm:chow-iii-riemannian-heat-mean-value-property

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-riemannian-heat-mean-value-property
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#def:chow-iii-gamma-a-regular-function]]'
```

# thm:chow-iii-heat-sphere-mean-value-property

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-heat-sphere-mean-value-property
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-riemannian-heat-mean-value-property]]'
```

# clm:chow-iii-heat-sphere-coarea-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-heat-sphere-coarea-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-heat-sphere-mean-value-property]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-riemannian-heat-mean-value-property]]'
```

# thm:chow-iii-ricci-flow-local-mean-value-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-ricci-flow-local-mean-value-monotonicity
uses: []
```

# cor:chow-iii-ricci-flow-supersolution-mean-value

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#cor:chow-iii-ricci-flow-supersolution-mean-value
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-ricci-flow-local-mean-value-monotonicity]]'
```

# cor:chow-iii-ricci-flow-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#cor:chow-iii-ricci-flow-strong-maximum-principle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#cor:chow-iii-ricci-flow-supersolution-mean-value]]'
```

# thm:chow-iii-weak-parabolic-harnack-inequality

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-weak-parabolic-harnack-inequality
uses: []
```

# thm:chow-iii-weak-solution-parabolic-harnack-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#thm:chow-iii-weak-solution-parabolic-harnack-estimate
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-weak-parabolic-harnack-inequality]]'
```

# prop:chow-iii-distance-like-function-bounded-derivatives

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#prop:chow-iii-distance-like-function-bounded-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#cor:chow-iii-noncompact-heat-kernel-mass-preservation]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-weak-parabolic-harnack-inequality]]'
```

# rem:chow-iii-distance-like-function-higher-derivatives

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#rem:chow-iii-distance-like-function-higher-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#prop:chow-iii-distance-like-function-bounded-derivatives]]'
```

# rem:chow-iii-distance-like-heat-evolution-uniform-convergence

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#rem:chow-iii-distance-like-heat-evolution-uniform-convergence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#prop:chow-iii-distance-like-function-bounded-derivatives]]'
```

# rem:chow-iii-distance-like-small-time-tail

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#rem:chow-iii-distance-like-small-time-tail
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#rem:chow-iii-distance-like-heat-evolution-uniform-convergence]]'
```

# rem:chow-iii-geodesic-harmonic-coordinate-regularity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#rem:chow-iii-geodesic-harmonic-coordinate-regularity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#rem:chow-iii-distance-like-function-higher-derivatives]]'
```

# clm:chow-iii-ricci-flow-davies-estimate-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics.tex#clm:chow-iii-ricci-flow-davies-estimate-problem
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch26-heat-kernel-bounds-evolving-metrics#thm:chow-iii-davies-double-integral-upper-bound]]'
```
