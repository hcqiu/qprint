# app:chow-ii-frame-bundle-tensor-calculus

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#app:chow-ii-frame-bundle-tensor-calculus
uses: []
```

# def:chow-ii-frame-tensor-components

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#def:chow-ii-frame-tensor-components
uses: []
```

# def:chow-ii-vertical-frame-fields

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#def:chow-ii-vertical-frame-fields
uses: []
```

# lem:chow-ii-vertical-tensor-action

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#lem:chow-ii-vertical-tensor-action
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-frame-tensor-components]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-vertical-frame-fields]]'
```

# def:chow-ii-horizontal-frame-fields

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#def:chow-ii-horizontal-frame-fields
uses: []
```

# lem:chow-ii-horizontal-covariant-differentiation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#lem:chow-ii-horizontal-covariant-differentiation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-horizontal-frame-fields]]'
```

# lem:chow-ii-frame-bundle-commutators

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#lem:chow-ii-frame-bundle-commutators
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-horizontal-frame-fields]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-vertical-frame-fields]]'
```

# def:chow-ii-rotation-fields

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#def:chow-ii-rotation-fields
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-vertical-frame-fields]]'
```

# lem:chow-ii-orthonormal-frame-bundle

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#lem:chow-ii-orthonormal-frame-bundle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-horizontal-frame-fields]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-rotation-fields]]'
```

# def:chow-ii-frame-time-vector

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#def:chow-ii-frame-time-vector
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-vertical-frame-fields]]'
```

# lem:chow-ii-time-covariant-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#lem:chow-ii-time-covariant-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-frame-time-vector]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#lem:chow-ii-vertical-tensor-action]]'
```

# lem:chow-ii-frame-curvature-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#lem:chow-ii-frame-curvature-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-frame-time-vector]]'
```

# thm:chow-ii-frame-heat-commutators

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus.tex#thm:chow-ii-frame-heat-commutators
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#lem:chow-ii-orthonormal-frame-bundle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/appf-frame-bundle-tensor-calculus#def:chow-ii-frame-time-vector]]'
```
