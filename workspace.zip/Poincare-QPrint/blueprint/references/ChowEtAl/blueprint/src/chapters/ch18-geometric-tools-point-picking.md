# ch:chow-iii-geometric-tools-point-picking

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#ch:chow-iii-geometric-tools-point-picking
uses: []
```

# lem:chow-iii-forward-distance-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-forward-distance-derivative
uses: []
```

# cor:chow-iii-forward-distance-derivative-ricci-flow

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#cor:chow-iii-forward-distance-derivative-ricci-flow
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-forward-distance-derivative]]'
```

# lem:chow-iii-backward-distance-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-backward-distance-derivative
uses: []
```

# def:chow-iii-laplacian-upper-barrier

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#def:chow-iii-laplacian-upper-barrier
uses: []
```

# lem:chow-iii-distance-laplacian-upper-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-distance-laplacian-upper-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#def:chow-iii-laplacian-upper-barrier]]'
```

# thm:chow-iii-changing-distances

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#thm:chow-iii-changing-distances
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#cor:chow-iii-forward-distance-derivative-ricci-flow]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-backward-distance-derivative]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-distance-laplacian-upper-bound]]'
```

# prop:chow-iii-ricci-integral-stable-geodesic

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#prop:chow-iii-ricci-integral-stable-geodesic
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-distance-laplacian-upper-bound]]'
```

# rem:chow-iii-changing-distances-ancient-solutions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-changing-distances-ancient-solutions
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-changing-distances]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#prop:chow-iii-ricci-integral-stable-geodesic]]'
```

# thm:chow-iii-point-picking-infinite-ascr

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#thm:chow-iii-point-picking-infinite-ascr
uses: []
```

# rem:chow-iii-rescaled-point-picked-balls

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-rescaled-point-picked-balls
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-point-picking-infinite-ascr]]'
```

# prop:chow-iii-unbounded-curvature-point-picking-one

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#prop:chow-iii-unbounded-curvature-point-picking-one
uses: []
```

# prop:chow-iii-unbounded-curvature-point-picking-two

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#prop:chow-iii-unbounded-curvature-point-picking-two
uses: []
```

# rem:chow-iii-improved-point-picking-rescaling

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-improved-point-picking-rescaling
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#prop:chow-iii-unbounded-curvature-point-picking-two]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#rem:chow-iii-rescaled-point-picked-balls]]'
```

# lem:chow-iii-point-picking-unbounded-change

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-point-picking-unbounded-change
uses: []
```

# rem:chow-iii-unbounded-change-rescaled-balls

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-unbounded-change-rescaled-balls
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-point-picking-unbounded-change]]'
```

# thm:chow-iii-dimension-reduction-one

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#thm:chow-iii-dimension-reduction-one
uses: []
```

# rem:chow-iii-dimension-reduction-one-interpretation

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-dimension-reduction-one-interpretation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-dimension-reduction-one]]'
```

# thm:chow-iii-dimension-reduction-two

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#thm:chow-iii-dimension-reduction-two
uses: []
```

# rem:chow-iii-dimension-reduction-infinite-ascr

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-dimension-reduction-infinite-ascr
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-dimension-reduction-two]]'
```

# cor:chow-iii-dimension-reduction-kappa-solutions

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#cor:chow-iii-dimension-reduction-kappa-solutions
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-point-picking-infinite-ascr]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-dimension-reduction-two]]'
```

# rem:chow-iii-kappa-solution-harnack-ascr

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-kappa-solution-harnack-ascr
uses: []
```

# thm:chow-iii-finite-remote-curvature-bumps

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#thm:chow-iii-finite-remote-curvature-bumps
uses: []
```

# lem:chow-iii-spacetime-point-picking

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-spacetime-point-picking
uses: []
```

# prop:chow-iii-parabolic-cylinder-curvature-control

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#prop:chow-iii-parabolic-cylinder-curvature-control
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-spacetime-point-picking]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-changing-distances]]'
```

# def:chow-iii-embedded-epsilon-neck

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#def:chow-iii-embedded-epsilon-neck
uses: []
```

# rem:chow-iii-neck-quality-comparison

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-neck-quality-comparison
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#def:chow-iii-embedded-epsilon-neck]]'
```

# lem:chow-iii-neck-center-bounds-ball

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-neck-center-bounds-ball
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#def:chow-iii-embedded-epsilon-neck]]'
```

# lem:chow-iii-busemann-level-diameter-neck

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-busemann-level-diameter-neck
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-neck-center-bounds-ball]]'
```

# lem:chow-iii-busemann-attains-minimum

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-busemann-attains-minimum
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-busemann-level-diameter-neck]]'
```

# rem:chow-iii-busemann-minimum-neck-essential

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-busemann-minimum-neck-essential
uses: []
```

# prop:chow-iii-farther-necks-larger-radii

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#prop:chow-iii-farther-necks-larger-radii
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-busemann-level-diameter-neck]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-busemann-attains-minimum]]'
```

# def:chow-iii-weakly-kappa-noncollapsed

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#def:chow-iii-weakly-kappa-noncollapsed
uses: []
```

# rem:chow-iii-largest-curvature-controlled-scale

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-largest-curvature-controlled-scale
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#def:chow-iii-weakly-kappa-noncollapsed]]'
```

# thm:chow-iii-localized-no-local-collapsing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#thm:chow-iii-localized-no-local-collapsing
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#def:chow-iii-weakly-kappa-noncollapsed]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-localized-reduced-distance-control]]'
```

# rem:chow-iii-localized-noncollapsing-maximal-scale

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-localized-noncollapsing-maximal-scale
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-localized-no-local-collapsing]]'
```

# lem:chow-iii-localized-reduced-distance-control

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#lem:chow-iii-localized-reduced-distance-control
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-changing-distances]]'
```

# rem:chow-iii-localized-barrier-nonsmoothness

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#rem:chow-iii-localized-barrier-nonsmoothness
uses: []
```

# ex:chow-iii-distance-derivative-any-minimizer

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#ex:chow-iii-distance-derivative-any-minimizer
uses: []
```

# ex:chow-iii-general-point-picking

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#ex:chow-iii-general-point-picking
uses: []
```

# ex:chow-iii-smooth-schoenflies-four

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#ex:chow-iii-smooth-schoenflies-four
uses: []
```

# ex:chow-iii-trivial-limits-rescaling

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking.tex#ex:chow-iii-trivial-limits-rescaling
uses: []
```
