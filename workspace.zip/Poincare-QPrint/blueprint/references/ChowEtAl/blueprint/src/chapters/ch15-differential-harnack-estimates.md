# ch:chow-ii-differential-harnack-estimates

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#ch:chow-ii-differential-harnack-estimates
uses: []
```

# def:chow-ii-harnack-p-and-m-tensors

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#def:chow-ii-harnack-p-and-m-tensors
uses: []
```

# lem:chow-ii-soliton-harnack-identities

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-soliton-harnack-identities
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-harnack-p-and-m-tensors]]'
```

# def:chow-ii-hamilton-harnack-quadratic

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#def:chow-ii-hamilton-harnack-quadratic
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-harnack-p-and-m-tensors]]'
```

# lem:chow-ii-harnack-quadratic-expanding-soliton-nullity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-harnack-quadratic-expanding-soliton-nullity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-soliton-harnack-identities]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-hamilton-harnack-quadratic]]'
```

# thm:chow-ii-hamilton-matrix-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#thm:chow-ii-hamilton-matrix-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-hamilton-harnack-quadratic]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#prop:chow-ii-bilinear-form-maximum-principle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-harnack-quadratic-evolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-harnack-exhaustion-function]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-harnack-barrier-functions]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-perturbed-harnack-evolution]]'
```

# rem:chow-ii-harnack-open-initial-time

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-harnack-open-initial-time
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-hamilton-matrix-harnack]]'
```

# cor:chow-ii-trace-harnack-and-tr-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#cor:chow-ii-trace-harnack-and-tr-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-hamilton-matrix-harnack]]'
```

# cor:chow-ii-ancient-trace-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#cor:chow-ii-ancient-trace-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#cor:chow-ii-trace-harnack-and-tr-monotonicity]]'
```

# cor:chow-ii-scalar-curvature-spacetime-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#cor:chow-ii-scalar-curvature-spacetime-comparison
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#cor:chow-ii-trace-harnack-and-tr-monotonicity]]'
```

# cor:chow-ii-ancient-scalar-curvature-spacetime-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#cor:chow-ii-ancient-scalar-curvature-spacetime-comparison
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#cor:chow-ii-ancient-trace-harnack]]'
```

# prop:chow-ii-surface-trace-harnack-positive-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#prop:chow-ii-surface-trace-harnack-positive-curvature
uses: []
```

# rem:chow-ii-surface-trace-harnack-nonnegative-curvature

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-surface-trace-harnack-nonnegative-curvature
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#prop:chow-ii-surface-trace-harnack-positive-curvature]]'
```

# cor:chow-ii-surface-tr-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#cor:chow-ii-surface-tr-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#rem:chow-ii-surface-trace-harnack-nonnegative-curvature]]'
```

# prop:chow-ii-surface-matrix-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#prop:chow-ii-surface-matrix-harnack
uses: []
```

# rem:chow-ii-surface-matrix-harnack-consequences

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-surface-matrix-harnack-consequences
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#prop:chow-ii-surface-matrix-harnack]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#prop:chow-ii-surface-trace-harnack-positive-curvature]]'
```

# rem:chow-ii-surface-matrix-evolution-reference

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-surface-matrix-evolution-reference
uses: []
```

# prop:chow-ii-equivalent-surface-matrix-harnack-forms

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#prop:chow-ii-equivalent-surface-matrix-harnack-forms
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-hamilton-harnack-quadratic]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#prop:chow-ii-surface-matrix-harnack]]'
```

# prop:chow-ii-bilinear-form-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#prop:chow-ii-bilinear-form-maximum-principle
uses: []
```

# rem:chow-ii-bilinear-form-maximum-principle-comparison

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-bilinear-form-maximum-principle-comparison
uses: []
```

# thm:chow-ii-harnack-quadratic-evolution

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#thm:chow-ii-harnack-quadratic-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-hamilton-harnack-quadratic]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-evolution-of-p-tensor]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-evolution-of-m-tensor]]'
```

# rem:chow-ii-harnack-extension-soliton-motivation

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-harnack-extension-soliton-motivation
uses: []
```

# lem:chow-ii-evolution-of-p-tensor

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-evolution-of-p-tensor
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-harnack-p-and-m-tensors]]'
```

# lem:chow-ii-evolution-of-m-tensor

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-evolution-of-m-tensor
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-harnack-p-and-m-tensors]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-evolution-of-p-tensor]]'
```

# rem:chow-ii-m-evolution-equivalent-p-terms

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-m-evolution-equivalent-p-terms
uses: []
```

# ex:chow-ii-unconstrained-harnack-quadratic-evolution

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#ex:chow-ii-unconstrained-harnack-quadratic-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-harnack-quadratic-evolution]]'
```

# lem:chow-ii-harnack-exhaustion-function

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-harnack-exhaustion-function
uses: []
```

# lem:chow-ii-harnack-barrier-functions

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-harnack-barrier-functions
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-harnack-exhaustion-function]]'
```

# lem:chow-ii-perturbed-harnack-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-perturbed-harnack-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-harnack-quadratic-evolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-harnack-barrier-functions]]'
```

# thm:chow-ii-minimizing-harnack-two-tensor-evolution

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#thm:chow-ii-minimizing-harnack-two-tensor-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#def:chow-ii-hamilton-harnack-quadratic]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-evolution-of-p-tensor]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-evolution-of-m-tensor]]'
```

# rem:chow-ii-k-tensor-trace-is-z

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-k-tensor-trace-is-z
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-minimizing-harnack-two-tensor-evolution]]'
```

# prop:chow-ii-general-z-tensor-evolution

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#prop:chow-ii-general-z-tensor-evolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-minimizing-harnack-two-tensor-evolution]]'
```

# lem:chow-ii-z-reaction-sum-of-squares

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-z-reaction-sum-of-squares
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#prop:chow-ii-general-z-tensor-evolution]]'
```

# lem:chow-ii-characterization-minimizing-two-form

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-characterization-minimizing-two-form
uses: []
```

# rem:chow-ii-three-dimensional-k-term-lower-bound

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-three-dimensional-k-term-lower-bound
uses: []
```

# cor:chow-ii-three-dimensional-z-quadratic-evolution-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#cor:chow-ii-three-dimensional-z-quadratic-evolution-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-minimizing-harnack-two-tensor-evolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#rem:chow-ii-three-dimensional-k-term-lower-bound]]'
```

# thm:chow-ii-ancient-positive-curvature-maximizer-steady-soliton

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#thm:chow-ii-ancient-positive-curvature-maximizer-steady-soliton
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#cor:chow-ii-ancient-matrix-harnack]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-ancient-harnack-nullspace-propagation]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-nullspace-map-is-wedge-map]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-evolution-of-p-tensor]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-evolution-of-m-tensor]]'
```

# rem:chow-ii-shrinking-soliton-no-spacetime-r-maximum

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-shrinking-soliton-no-spacetime-r-maximum
uses: []
```

# cor:chow-ii-ancient-matrix-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#cor:chow-ii-ancient-matrix-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-hamilton-matrix-harnack]]'
```

# rem:chow-ii-alternative-ancient-rigidity-proof

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-alternative-ancient-rigidity-proof
uses: []
```

# lem:chow-ii-ancient-harnack-nullspace-propagation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-ancient-harnack-nullspace-propagation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#cor:chow-ii-ancient-matrix-harnack]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-harnack-exhaustion-function]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-harnack-barrier-functions]]'
```

# lem:chow-ii-nullspace-map-is-wedge-map

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#lem:chow-ii-nullspace-map-is-wedge-map
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#lem:chow-ii-ancient-harnack-nullspace-propagation]]'
```

# rem:chow-ii-ancient-rigidity-spacetime-splitting

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#rem:chow-ii-ancient-rigidity-spacetime-splitting
uses: []
```

# thm:chow-ii-pinched-noncompact-three-manifold-flat

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#thm:chow-ii-pinched-noncompact-three-manifold-flat
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-ancient-positive-curvature-maximizer-steady-soliton]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates#thm:chow-ii-odd-dimensional-positive-curvature-gap]]'
```

# thm:chow-ii-odd-dimensional-positive-curvature-gap

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#thm:chow-ii-odd-dimensional-positive-curvature-gap
uses: []
```

# thm:chow-ii-mean-curvature-flow-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#thm:chow-ii-mean-curvature-flow-harnack
uses: []
```

# ex:chow-ii-arbitrary-three-dimensional-matrix-harnack-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#ex:chow-ii-arbitrary-three-dimensional-matrix-harnack-problem
uses: []
```

# ex:chow-ii-complete-noncompact-mcf-harnack-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch15-differential-harnack-estimates.tex#ex:chow-ii-complete-noncompact-mcf-harnack-problem
uses: []
```
