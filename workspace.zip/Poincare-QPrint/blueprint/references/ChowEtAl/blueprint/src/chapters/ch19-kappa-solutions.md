# ch:chow-iii-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#ch:chow-iii-kappa-solutions
uses: []
```

# def:chow-iii-kappa-noncollapsed

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#def:chow-iii-kappa-noncollapsed
uses: []
```

# thm:chow-iii-no-local-collapsing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-no-local-collapsing
uses: []
```

# prop:chow-iii-cgt-injectivity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#prop:chow-iii-cgt-injectivity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-noncollapsed]]'
```

# thm:chow-iii-finite-time-model

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-finite-time-model
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-no-local-collapsing]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#prop:chow-iii-cgt-injectivity]]'
```

# def:chow-iii-kappa-solution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#def:chow-iii-kappa-solution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-noncollapsed]]'
```

# cor:chow-iii-3d-finite-time-model

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#cor:chow-iii-3d-finite-time-model
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-finite-time-model]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-solution]]'
```

# ex:chow-iii-cylinder-kappa

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#ex:chow-iii-cylinder-kappa
uses: []
```

# ex:chow-iii-bryant-soliton

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#ex:chow-iii-bryant-soliton
uses: []
```

# def:chow-iii-asymptotic-ratios

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#def:chow-iii-asymptotic-ratios
uses: []
```

# ex:chow-iii-avr-ascr-examples

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#ex:chow-iii-avr-ascr-examples
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-asymptotic-ratios]]'
```

# prop:chow-iii-avr-from-ascr

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#prop:chow-iii-avr-from-ascr
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-asymptotic-ratios]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-noncollapsed]]'
```

# thm:chow-iii-ascr-avr-time-invariance

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-ascr-avr-time-invariance
uses: []
```

# thm:chow-iii-infinite-ascr

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-infinite-ascr
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-asymptotic-ratios]]'
```

# def:chow-iii-kappa-harnack

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#def:chow-iii-kappa-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-solution]]'
```

# clm:chow-iii-entropy-kappa

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#clm:chow-iii-entropy-kappa
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-solution]]'
```

# thm:chow-iii-linear-entropy-volume

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-linear-entropy-volume
uses: []
```

# thm:chow-iii-perelman-sphere

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-perelman-sphere
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-solution]]'
```

# thm:chow-iii-compact-type-i

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-compact-type-i
uses: []
```

# lem:chow-iii-normalized-family-noncollapsed

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#lem:chow-iii-normalized-family-noncollapsed
uses: []
```

# prop:chow-iii-normalized-family-ancient

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#prop:chow-iii-normalized-family-ancient
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#lem:chow-iii-normalized-family-noncollapsed]]'
```

# prop:chow-iii-perelman-limit-properties

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#prop:chow-iii-perelman-limit-properties
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-perelman-sphere]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#prop:chow-iii-normalized-family-ancient]]'
```

# thm:chow-iii-2d-kappa

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-2d-kappa
uses: []
```

# cor:chow-iii-2d-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#cor:chow-iii-2d-harnack
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-2d-kappa]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-harnack]]'
```

# prop:chow-iii-3d-harnack-equivalence

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#prop:chow-iii-3d-harnack-equivalence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#cor:chow-iii-2d-harnack]]'
```

# def:chow-iii-reduced-distance

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#def:chow-iii-reduced-distance
uses: []
```

# lem:chow-iii-reduced-distance-two-point

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#lem:chow-iii-reduced-distance-two-point
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-reduced-distance]]'
```

# lem:chow-iii-large-neighborhood-estimates

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#lem:chow-iii-large-neighborhood-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-reduced-distance]]'
```

# def:chow-iii-reduced-volume-strong-collapse

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#def:chow-iii-reduced-volume-strong-collapse
uses: []
```

# thm:chow-iii-reduced-volume-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-reduced-volume-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-reduced-volume-strong-collapse]]'
```

# thm:chow-iii-weakened-no-local-collapsing

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-weakened-no-local-collapsing
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-reduced-volume-strong-collapse]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-reduced-volume-monotonicity]]'
```

# thm:chow-iii-asymptotic-shrinker

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-asymptotic-shrinker
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-solution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#lem:chow-iii-reduced-distance-two-point]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-reduced-volume-monotonicity]]'
```

# thm:chow-iii-no-3d-shrinker

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-no-3d-shrinker
uses: []
```

# thm:chow-iii-kappa-gap

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#thm:chow-iii-kappa-gap
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-asymptotic-shrinker]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-no-3d-shrinker]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-weakened-no-local-collapsing]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#lem:chow-iii-large-neighborhood-estimates]]'
```

# rem:chow-iii-kappa-gap-hypothesis

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions.tex#rem:chow-iii-kappa-gap-hypothesis
uses: []
```
