# ch:chow-iii-compactness-kappa-solutions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#ch:chow-iii-compactness-kappa-solutions
uses: []
```

# thm:chow-iii-kappa-harnack-ascr-avr

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#thm:chow-iii-kappa-harnack-ascr-avr
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-kappa-harnack]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#def:chow-iii-asymptotic-ratios]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-point-picking-infinite-ascr]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-dimension-reduction-one]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-2d-kappa]]'
```

# cor:chow-iii-ancient-bounded-nonnegative-avr-zero

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#cor:chow-iii-ancient-bounded-nonnegative-avr-zero
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-harnack-ascr-avr]]'
```

# rem:chow-iii-kahler-ancient-avr-zero

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#rem:chow-iii-kahler-ancient-avr-zero
uses: []
```

# prop:chow-iii-almost-ancient-large-scale-collapse

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#prop:chow-iii-almost-ancient-large-scale-collapse
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#cor:chow-iii-ancient-bounded-nonnegative-avr-zero]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#prop:chow-iii-cgt-injectivity]]'
```

# rem:chow-iii-almost-ancient-rescaling

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#rem:chow-iii-almost-ancient-rescaling
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#prop:chow-iii-almost-ancient-large-scale-collapse]]'
```

# prop:chow-iii-curvature-estimate-noncollapsed-balls

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#prop:chow-iii-curvature-estimate-noncollapsed-balls
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#prop:chow-iii-almost-ancient-large-scale-collapse]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#prop:chow-iii-parabolic-cylinder-curvature-control]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#thm:chow-iii-changing-distances]]'
```

# rem:chow-iii-curvature-estimate-time-independent

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#rem:chow-iii-curvature-estimate-time-independent
uses: []
```

# def:chow-iii-compact-modulo-scaling

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#def:chow-iii-compact-modulo-scaling
uses: []
```

# rem:chow-iii-ancient-positive-or-ricci-flat

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#rem:chow-iii-ancient-positive-or-ricci-flat
uses: []
```

# thm:chow-iii-kappa-harnack-compactness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#thm:chow-iii-kappa-harnack-compactness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#def:chow-iii-compact-modulo-scaling]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-harnack-ascr-avr]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#prop:chow-iii-almost-ancient-large-scale-collapse]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#prop:chow-iii-curvature-estimate-noncollapsed-balls]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#lem:chow-iii-bounded-curvature-bounded-distance]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#clm:chow-iii-unit-ball-volume-lower-bound]]'
```

# cor:chow-iii-3d-kappa-compactness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#cor:chow-iii-3d-kappa-compactness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-harnack-compactness]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#prop:chow-iii-3d-harnack-equivalence]]'
```

# cor:chow-iii-3d-kappa-improved-compactness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#cor:chow-iii-3d-kappa-improved-compactness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#cor:chow-iii-3d-kappa-compactness]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-kappa-gap]]'
```

# ex:chow-iii-model-kappa-pointed-limits

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#ex:chow-iii-model-kappa-pointed-limits
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#ex:chow-iii-bryant-soliton]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch19-kappa-solutions#thm:chow-iii-perelman-sphere]]'
```

# rem:chow-iii-kappa-compactness-no-conical-degeneration

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#rem:chow-iii-kappa-compactness-no-conical-degeneration
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-harnack-compactness]]'
```

# rem:chow-iii-rescaling-bounded-distance

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#rem:chow-iii-rescaling-bounded-distance
uses: []
```

# lem:chow-iii-bounded-curvature-bounded-distance

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#lem:chow-iii-bounded-curvature-bounded-distance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#prop:chow-iii-almost-ancient-large-scale-collapse]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch18-geometric-tools-point-picking#lem:chow-iii-point-picking-unbounded-change]]'
```

# clm:chow-iii-unit-ball-volume-lower-bound

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#clm:chow-iii-unit-ball-volume-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#prop:chow-iii-curvature-estimate-noncollapsed-balls]]'
```

# thm:chow-iii-kappa-scaled-derivative-estimates

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#thm:chow-iii-kappa-scaled-derivative-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-harnack-compactness]]'
```

# rem:chow-iii-kappa-all-derivative-estimates

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#rem:chow-iii-kappa-all-derivative-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-scaled-derivative-estimates]]'
```

# cor:chow-iii-3d-universal-scaled-derivatives

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#cor:chow-iii-3d-universal-scaled-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#cor:chow-iii-3d-kappa-improved-compactness]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-scaled-derivative-estimates]]'
```

# rem:chow-iii-cigar-scaled-derivative-failure

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#rem:chow-iii-cigar-scaled-derivative-failure
uses: []
```

# cor:chow-iii-kappa-quadratic-curvature-lower-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#cor:chow-iii-kappa-quadratic-curvature-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-scaled-derivative-estimates]]'
```

# cor:chow-iii-steady-soliton-flowline-curvature-lower-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#cor:chow-iii-steady-soliton-flowline-curvature-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions#thm:chow-iii-kappa-scaled-derivative-estimates]]'
```

# cor:chow-iii-3d-steady-soliton-curvature-upper-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#cor:chow-iii-3d-steady-soliton-curvature-upper-bound
uses: []
```

# conj:chow-iii-2d-ancient-classification

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#conj:chow-iii-2d-ancient-classification
uses: []
```

# conj:chow-iii-3d-positive-kappa-classification

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#conj:chow-iii-3d-positive-kappa-classification
uses: []
```

# prob:chow-iii-kappa-derivatives-infinite-ascr

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#prob:chow-iii-kappa-derivatives-infinite-ascr
uses: []
```

# prob:chow-iii-rotational-kappa-bryant

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch20-compactness-kappa-solutions.tex#prob:chow-iii-rotational-kappa-bryant
uses: []
```
