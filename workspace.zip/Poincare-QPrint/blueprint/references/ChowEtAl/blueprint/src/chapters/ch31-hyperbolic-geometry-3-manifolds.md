# ch:chow-iv-hyperbolic-geometry-3-manifolds

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ch:chow-iv-hyperbolic-geometry-3-manifolds
uses: []
```

# def:chow-iv-hyperbolic-models

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-hyperbolic-models
uses: []
```

# lem:chow-iv-hyperbolic-plane-isometries

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-hyperbolic-plane-isometries
uses: []
```

# ex:chow-iv-hyperbolic-plane-geodesics

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-hyperbolic-plane-geodesics
uses: []
```

# lem:chow-iv-inversion-hyperbolic-isometry

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-inversion-hyperbolic-isometry
uses: []
```

# lem:chow-iv-isometry-group-hyperbolic-space

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-isometry-group-hyperbolic-space
uses: []
```

# lem:chow-iv-upper-half-space-geodesics

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-upper-half-space-geodesics
uses: []
```

# def:chow-iv-isometry-types

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-isometry-types
uses: []
```

# ex:chow-iv-standard-isometry-types

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-standard-isometry-types
uses: []
```

# lem:chow-iv-trace-isometry-classification

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-trace-isometry-classification
uses: []
```

# def:chow-iv-nilpotent-group

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-nilpotent-group
uses: []
```

# lem:chow-iv-nilpotent-isometry-subgroups

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-nilpotent-isometry-subgroups
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#def:chow-iv-isometry-types]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#def:chow-iv-nilpotent-group]]'
```

# def:chow-iv-horoball

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-horoball
uses: []
```

# lem:chow-iv-hyperbolic-irreducible

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-hyperbolic-irreducible
uses: []
```

# thm:chow-iv-loop-theorem

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-loop-theorem
uses: []
```

# cor:chow-iv-compressible-boundary

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#cor:chow-iv-compressible-boundary
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#thm:chow-iv-loop-theorem]]'
```

# lem:chow-iv-simple-curve-primitive

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-simple-curve-primitive
uses: []
```

# rem:chow-iv-geodesic-primitivity

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#rem:chow-iv-geodesic-primitivity
uses: []
```

# lem:chow-iv-compressible-torus-kernel

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-compressible-torus-kernel
uses: []
```

# rem:chow-iv-compressible-torus-lens-space

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#rem:chow-iv-compressible-torus-lens-space
uses: []
```

# lem:chow-iv-boundary-h1-rank

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-boundary-h1-rank
uses: []
```

# lem:chow-iv-separating-incompressible-surfaces

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-separating-incompressible-surfaces
uses: []
```

# thm:chow-iv-seifert-van-kampen

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-seifert-van-kampen
uses: []
```

# lem:chow-iv-boundary-torus-incompressible

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-boundary-torus-incompressible
uses: []
```

# lem:chow-iv-embedded-torus-trichotomy

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-embedded-torus-trichotomy
uses: []
```

# ex:chow-iv-knotted-compressible-torus

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-knotted-compressible-torus
uses: []
```

# def:chow-iv-topological-hyperbolic-piece

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-topological-hyperbolic-piece
uses: []
```

# cor:chow-iv-hyperbolic-piece-incompressibility

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#cor:chow-iv-hyperbolic-piece-incompressibility
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#def:chow-iv-topological-hyperbolic-piece]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#lem:chow-iv-separating-incompressible-surfaces]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#lem:chow-iv-boundary-torus-incompressible]]'
```

# def:chow-iv-topological-end

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-topological-end
uses: []
```

# ex:chow-iv-cylinder-ends

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-cylinder-ends
uses: []
```

# def:chow-iv-hyperbolic-cusp

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-hyperbolic-cusp
uses: []
```

# thm:chow-iv-margulis-algebraic

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-margulis-algebraic
uses: []
```

# rem:chow-iv-margulis-three-dimensional

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#rem:chow-iv-margulis-three-dimensional
uses: []
```

# thm:chow-iv-margulis-local

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-margulis-local
uses: []
```

# def:chow-iv-thick-thin-parts

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-thick-thin-parts
uses: []
```

# ex:chow-iv-thick-thin-examples

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-thick-thin-examples
uses: []
```

# lem:chow-iv-thick-injectivity-radius

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-thick-injectivity-radius
uses: []
```

# lem:chow-iv-topological-ends-thin

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#lem:chow-iv-topological-ends-thin
uses: []
```

# thm:chow-iv-thin-part-structure

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-thin-part-structure
uses: []
```

# thm:chow-iv-finite-volume-ends-cusps

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-finite-volume-ends-cusps
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#lem:chow-iv-topological-ends-thin]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#thm:chow-iv-thin-part-structure]]'
```

# ex:chow-iv-margulis-tube-quotient

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-margulis-tube-quotient
uses: []
```

# thm:chow-iv-cusp-volume-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-cusp-volume-bound
uses: []
```

# cor:chow-iv-small-almost-flat-tori

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#cor:chow-iv-small-almost-flat-tori
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#thm:chow-iv-finite-volume-ends-cusps]]'
```

# rem:chow-iv-small-tori-application

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#rem:chow-iv-small-tori-application
uses: []
```

# thm:chow-iv-mostow-rigidity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-mostow-rigidity
uses: []
```

# cor:chow-iv-mostow-equivalences

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#cor:chow-iv-mostow-equivalences
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#thm:chow-iv-mostow-rigidity]]'
```

# cor:chow-iv-isometry-group

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#cor:chow-iv-isometry-group
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#thm:chow-iv-mostow-rigidity]]'
```

# def:chow-iv-foliation

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-foliation
uses: []
```

# def:chow-iv-seifert-fibered

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-seifert-fibered
uses: []
```

# def:chow-iv-graph-manifold

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#def:chow-iv-graph-manifold
uses: []
```

# thm:chow-iv-cheeger-gromov-graph-manifold

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#thm:chow-iv-cheeger-gromov-graph-manifold
uses: []
```

# ex:chow-iv-cusp-slices-umbilic

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-cusp-slices-umbilic
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#def:chow-iv-hyperbolic-cusp]]'
```

# ex:chow-iv-ends-cheeger-gromov

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-ends-cheeger-gromov
uses: []
```

# ex:chow-iv-hyperbolic-model-isometries

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds.tex#ex:chow-iv-hyperbolic-model-isometries
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch31-hyperbolic-geometry-3-manifolds#def:chow-iv-hyperbolic-models]]'
```
