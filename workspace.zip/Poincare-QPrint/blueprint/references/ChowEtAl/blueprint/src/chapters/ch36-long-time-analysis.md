# ch:chow-iv-type-ii-degenerate-neckpinches

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#ch:chow-iv-type-ii-degenerate-neckpinches
uses: []
```

# def:chow-iv-singularity-types

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-singularity-types
uses: []
```

# def:chow-iv-rotational-s3-metric

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-rotational-s3-metric
uses: []
```

# prop:chow-iv-numerical-deturck-equations

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#prop:chow-iv-numerical-deturck-equations
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-rotational-s3-metric]]'
```

# def:chow-iv-lambda-neckpinch-data

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-lambda-neckpinch-data
uses: []
```

# def:chow-iv-finite-difference-scheme

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-finite-difference-scheme
uses: []
```

# def:chow-iv-rotational-ricci-eigenvalues

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-rotational-ricci-eigenvalues
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-rotational-s3-metric]]'
```

# rem:chow-iv-numerical-phase-transition

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#rem:chow-iv-numerical-phase-transition
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-lambda-neckpinch-data]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-rotational-ricci-eigenvalues]]'
```

# def:chow-iv-primary-degenerate-neckpinch-ansatz

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-primary-degenerate-neckpinch-ansatz
uses: []
```

# def:chow-iv-rotational-flow-equations

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-rotational-flow-equations
uses: []
```

# def:chow-iv-parabolic-rescaling

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-parabolic-rescaling
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-primary-degenerate-neckpinch-ansatz]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-rotational-flow-equations]]'
```

# def:chow-iv-parabolic-linearization

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-parabolic-linearization
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-parabolic-rescaling]]'
```

# def:chow-iv-parabolic-leading-mode

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-parabolic-leading-mode
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-parabolic-linearization]]'
```

# def:chow-iv-intermediate-profile

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-intermediate-profile
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-parabolic-leading-mode]]'
```

# def:chow-iv-tip-bryant-profile

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-tip-bryant-profile
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-rotational-flow-equations]]'
```

# def:chow-iv-tip-ansatz

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-tip-ansatz
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-tip-bryant-profile]]'
```

# prop:chow-iv-outer-profile

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#prop:chow-iv-outer-profile
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-parabolic-leading-mode]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-intermediate-profile]]'
```

# prop:chow-iv-matched-parameters

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#prop:chow-iv-matched-parameters
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-parabolic-leading-mode]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-intermediate-profile]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-tip-ansatz]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#prop:chow-iv-outer-profile]]'
```

# def:chow-iv-wazewski-tubular-neighborhood

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#def:chow-iv-wazewski-tubular-neighborhood
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#prop:chow-iv-matched-parameters]]'
```

# thm:chow-iv-wazewski-degenerate-neckpinch

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#thm:chow-iv-wazewski-degenerate-neckpinch
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#def:chow-iv-wazewski-tubular-neighborhood]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#prop:chow-iv-matched-parameters]]'
```

# rem:chow-iv-degenerate-neckpinch-scope

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#rem:chow-iv-degenerate-neckpinch-scope
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis#thm:chow-iv-wazewski-degenerate-neckpinch]]'
```

# rem:chow-iv-type-ii-genericity-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch36-long-time-analysis.tex#rem:chow-iv-type-ii-genericity-problem
uses: []
```
