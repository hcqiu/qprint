# ch:chow-iv-compact-two-dimensional-ancient-solutions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#ch:chow-iv-compact-two-dimensional-ancient-solutions
uses: []
```

# thm:chow-iv-classification-ancient-two-sphere

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#thm:chow-iv-classification-ancient-two-sphere
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-q-vanishes-backward]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-q-zero-characterizes-king-rosenau]]'
```

# thm:chow-iv-two-dimensional-type-i-ii

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#thm:chow-iv-two-dimensional-type-i-ii
uses: []
```

# lem:chow-iv-characterization-king-rosenau

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-characterization-king-rosenau
uses: []
```

# lem:chow-iv-king-rosenau-pole-cigar-limit

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-king-rosenau-pole-cigar-limit
uses: []
```

# lem:chow-iv-king-rosenau-pointed-limits

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-king-rosenau-pointed-limits
uses: []
```

# lem:chow-iv-pressure-sobolev-holder

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-pressure-sobolev-holder
uses: []
```

# rem:chow-iv-pressure-soliton-potential

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#rem:chow-iv-pressure-soliton-potential
uses: []
```

# lem:chow-iv-pressure-gradient-regularity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-pressure-gradient-regularity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-pressure-sobolev-holder]]'
```

# rem:chow-iv-intrinsic-curvature-derivatives

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#rem:chow-iv-intrinsic-curvature-derivatives
uses: []
```

# lem:chow-iv-weighted-higher-pressure-estimates

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-weighted-higher-pressure-estimates
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-pressure-gradient-regularity]]'
```

# lem:chow-iv-weighted-pressure-hessian

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-weighted-pressure-hessian
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-weighted-higher-pressure-estimates]]'
```

# lem:chow-iv-backward-pressure-convergence

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-backward-pressure-convergence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-pressure-gradient-regularity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-weighted-higher-pressure-estimates]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-weighted-pressure-hessian]]'
```

# def:chow-iv-weak-stationary-pressure

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#def:chow-iv-weak-stationary-pressure
uses: []
```

# lem:chow-iv-backward-pressure-stationary

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-backward-pressure-stationary
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-backward-pressure-convergence]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#def:chow-iv-weak-stationary-pressure]]'
```

# prop:chow-iv-zero-backward-pressure-round

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-zero-backward-pressure-round
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-isoperimetric-rigidity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-radius-linear-time]]'
```

# ex:chow-iv-unit-sphere-isoperimetric-constant

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#ex:chow-iv-unit-sphere-isoperimetric-constant
uses: []
```

# lem:chow-iv-isoperimetric-minimizers

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-isoperimetric-minimizers
uses: []
```

# lem:chow-iv-isoperimetric-rigidity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-isoperimetric-rigidity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-isoperimetric-minimizers]]'
```

# lem:chow-iv-isoperimetric-ratio-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-isoperimetric-ratio-evolution
uses: []
```

# prop:chow-iv-isoperimetric-decay

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-isoperimetric-decay
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-isoperimetric-ratio-evolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-isoperimetric-rigidity]]'
```

# prop:chow-iv-isoperimetric-loop-bounds

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-isoperimetric-loop-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-isoperimetric-decay]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-isoperimetric-minimizers]]'
```

# lem:chow-iv-isoperimetric-region-areas

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-isoperimetric-region-areas
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-isoperimetric-loop-bounds]]'
```

# lem:chow-iv-asymptotic-cylinder-minimizing-loop

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-asymptotic-cylinder-minimizing-loop
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-isoperimetric-loop-bounds]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-isoperimetric-region-areas]]'
```

# lem:chow-iv-connected-distance-circles

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-connected-distance-circles
uses: []
```

# lem:chow-iv-distance-circles-near-neck-center

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-distance-circles-near-neck-center
uses: []
```

# lem:chow-iv-area-lower-bound-balls

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-area-lower-bound-balls
uses: []
```

# lem:chow-iv-polar-ball-area-time

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-polar-ball-area-time
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-connected-distance-circles]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-isoperimetric-region-areas]]'
```

# lem:chow-iv-radius-linear-time

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-radius-linear-time
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-area-lower-bound-balls]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-polar-ball-area-time]]'
```

# prop:chow-iv-plane-not-backward-pointwise-limit

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-plane-not-backward-pointwise-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-distance-circles-near-neck-center]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-radius-linear-time]]'
```

# lem:chow-iv-nonround-no-plane-limit

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-nonround-no-plane-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-plane-not-backward-pointwise-limit]]'
```

# lem:chow-iv-positive-circular-average-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-positive-circular-average-bound
uses: []
```

# lem:chow-iv-unbounded-conformal-factor-curvature-concentration

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-unbounded-conformal-factor-curvature-concentration
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-positive-circular-average-bound]]'
```

# rem:chow-iv-round-sphere-curvature-concentration

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#rem:chow-iv-round-sphere-curvature-concentration
uses: []
```

# lem:chow-iv-backward-pressure-at-most-two-zeros

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-backward-pressure-at-most-two-zeros
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-unbounded-conformal-factor-curvature-concentration]]'
```

# prop:chow-iv-backward-pressure-cylinder

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-backward-pressure-cylinder
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-zero-backward-pressure-round]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-backward-pressure-at-most-two-zeros]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-plane-not-backward-pointwise-limit]]'
```

# cor:chow-iv-angular-pressure-gradient-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#cor:chow-iv-angular-pressure-gradient-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-backward-pressure-cylinder]]'
```

# prop:chow-iv-poles-converge-to-cigars

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-poles-converge-to-cigars
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-backward-pressure-cylinder]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-nonround-no-plane-limit]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-rescaled-pressure-growth]]'
```

# lem:chow-iv-rescaled-pressure-growth

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-rescaled-pressure-growth
uses: []
```

# lem:chow-iv-trace-free-third-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-trace-free-third-derivative
uses: []
```

# rem:chow-iv-third-derivative-decomposition

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#rem:chow-iv-third-derivative-decomposition
uses: []
```

# prop:chow-iv-q-heat-subsolution

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-q-heat-subsolution
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-symmetrized-third-derivative-evolution]]'
```

# lem:chow-iv-symmetrized-third-derivative-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-symmetrized-third-derivative-evolution
uses: []
```

# prop:chow-iv-q-zero-characterizes-king-rosenau

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-q-zero-characterizes-king-rosenau
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-equivalence-q-euclidean-q]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-characterization-king-rosenau]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-backward-pressure-cylinder]]'
```

# ex:chow-iv-euclidean-q-expressions

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#ex:chow-iv-euclidean-q-expressions
uses: []
```

# lem:chow-iv-euclidean-q-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-euclidean-q-evolution
uses: []
```

# prop:chow-iv-q-vanishes-backward

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#prop:chow-iv-q-vanishes-backward
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-q-heat-subsolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-poles-converge-to-cigars]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#lem:chow-iv-equivalence-q-euclidean-q]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch29-solitons#prop:chow-iv-backward-pressure-cylinder]]'
```

# lem:chow-iv-equivalence-q-euclidean-q

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#lem:chow-iv-equivalence-q-euclidean-q
uses: []
```

# rem:chow-iv-completeness-positive-pressure-set

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#rem:chow-iv-completeness-positive-pressure-set
uses: []
```

# rem:chow-iv-q-alternative-formula

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#rem:chow-iv-q-alternative-formula
uses: []
```

# rem:chow-iv-q-vanishes-king-rosenau

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch29-solitons.tex#rem:chow-iv-q-vanishes-king-rosenau
uses: []
```
