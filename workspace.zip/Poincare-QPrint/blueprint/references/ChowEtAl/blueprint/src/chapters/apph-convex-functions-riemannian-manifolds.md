# app:chow-iii-convex-functions-riemannian-manifolds

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#app:chow-iii-convex-functions-riemannian-manifolds
uses: []
```

# prop:chow-iii-h2-rademacher

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#prop:chow-iii-h2-rademacher
uses: []
```

# lem:chow-iii-h3-lipschitz-ftc

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h3-lipschitz-ftc
uses: []
```

# rem:chow-iii-h4-extended-convex-extension

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h4-extended-convex-extension
uses: []
```

# prop:chow-iii-h5-convex-lipschitz

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#prop:chow-iii-h5-convex-lipschitz
uses: []
```

# lem:chow-iii-h6-convex-limits

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h6-convex-limits
uses: []
```

# def:chow-iii-h7-stolz-differentiability

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#def:chow-iii-h7-stolz-differentiability
uses: []
```

# lem:chow-iii-h8-projection-inequality

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h8-projection-inequality
uses: []
```

# prop:chow-iii-h9-projection-contraction

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#prop:chow-iii-h9-projection-contraction
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h8-projection-inequality]]'
```

# cor:chow-iii-h10-projection-length

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#cor:chow-iii-h10-projection-length
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#prop:chow-iii-h9-projection-contraction]]'
```

# def:chow-iii-h11-interior-tangent-cone

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#def:chow-iii-h11-interior-tangent-cone
uses: []
```

# rem:chow-iii-h12-tangent-cone-realization

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h12-tangent-cone-realization
uses: []
```

# lem:chow-iii-h13-tangent-cone-open

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h13-tangent-cone-open
uses: []
```

# rem:chow-iii-h14-convexity-variants

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h14-convexity-variants
uses: []
```

# lem:chow-iii-h15-minimal-geodesics-locally-convex

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h15-minimal-geodesics-locally-convex
uses: []
```

# rem:chow-iii-h16-locally-convex-length-space

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h16-locally-convex-length-space
uses: []
```

# prop:chow-iii-h17-aleksandrov-subset

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#prop:chow-iii-h17-aleksandrov-subset
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h15-minimal-geodesics-locally-convex]]'
```

# lem:chow-iii-h18-infinitesimal-convexity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h18-infinitesimal-convexity
uses: []
```

# cor:chow-iii-h19-interior-tangent-cone-convex

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#cor:chow-iii-h19-interior-tangent-cone-convex
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h18-infinitesimal-convexity]]'
```

# def:chow-iii-h20-convex-function

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#def:chow-iii-h20-convex-function
uses: []
```

# lem:chow-iii-h21-convex-locally-lipschitz

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h21-convex-locally-lipschitz
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#def:chow-iii-h20-convex-function]]'
```

# def:chow-iii-h22-directional-derivative

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#def:chow-iii-h22-directional-derivative
uses: []
```

# lem:chow-iii-h23-directional-homogeneity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h23-directional-homogeneity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#def:chow-iii-h22-directional-derivative]]'
```

# rem:chow-iii-h24-euclidean-difference-quotient

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h24-euclidean-difference-quotient
uses: []
```

# lem:chow-iii-h25-directional-properties

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h25-directional-properties
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#def:chow-iii-h22-directional-derivative]]'
```

# lem:chow-iii-h26-directional-convexity-usc

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h26-directional-convexity-usc
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h25-directional-properties]]'
```

# lem:chow-iii-h27-directional-sublinear

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h27-directional-sublinear
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h23-directional-homogeneity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h26-directional-convexity-usc]]'
```

# rem:chow-iii-h28-concave-directional-derivatives

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h28-concave-directional-derivatives
uses: []
```

# def:chow-iii-h29-generalized-gradient

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#def:chow-iii-h29-generalized-gradient
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h27-directional-sublinear]]'
```

# lem:chow-iii-h30-generalized-gradient-properties

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h30-generalized-gradient-properties
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#def:chow-iii-h29-generalized-gradient]]'
```

# lem:chow-iii-h31-critical-local-minimum

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h31-critical-local-minimum
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#def:chow-iii-h29-generalized-gradient]]'
```

# def:chow-iii-h32-Xzero

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#def:chow-iii-h32-Xzero
uses: []
```

# lem:chow-iii-h33-boundary-directional-extension

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h33-boundary-directional-extension
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#def:chow-iii-h32-Xzero]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h26-directional-convexity-usc]]'
```

# ex:chow-iii-h34-square-convex-function

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#ex:chow-iii-h34-square-convex-function
uses: []
```

# rem:chow-iii-h35-square-gradient

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h35-square-gradient
uses: []
```

# lem:chow-iii-h36-unique-generalized-gradient

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h36-unique-generalized-gradient
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h15-minimal-geodesics-locally-convex]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h33-boundary-directional-extension]]'
```

# lem:chow-iii-h37-directional-gradient-inequality

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h37-directional-gradient-inequality
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h36-unique-generalized-gradient]]'
```

# lem:chow-iii-h38-acute-angle

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h38-acute-angle
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h37-directional-gradient-inequality]]'
```

# lem:chow-iii-h39-convex-support-hessian

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h39-convex-support-hessian
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h37-directional-gradient-inequality]]'
```

# def:chow-iii-h40-right-tangent

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#def:chow-iii-h40-right-tangent
uses: []
```

# lem:chow-iii-h41-right-tangent-geodesics

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h41-right-tangent-geodesics
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#def:chow-iii-h40-right-tangent]]'
```

# rem:chow-iii-h42-right-tangent-uniqueness

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h42-right-tangent-uniqueness
uses: []
```

# def:chow-iii-h43-integral-curve

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#def:chow-iii-h43-integral-curve
uses: []
```

# ex:chow-iii-h44-square-integral-curves

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#ex:chow-iii-h44-square-integral-curves
uses: []
```

# lem:chow-iii-h45-integral-curve-level

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h45-integral-curve-level
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#def:chow-iii-h43-integral-curve]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h41-right-tangent-geodesics]]'
```

# rem:chow-iii-h47-model-example

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h47-model-example
uses: []
```

# lem:chow-iii-h48-integral-curve-concavity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h48-integral-curve-concavity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h45-integral-curve-level]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h37-directional-gradient-inequality]]'
```

# lem:chow-iii-h49-integral-curves-distance

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h49-integral-curves-distance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h15-minimal-geodesics-locally-convex]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h38-acute-angle]]'
```

# cor:chow-iii-h50-integral-curve-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#cor:chow-iii-h50-integral-curve-uniqueness
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h49-integral-curves-distance]]'
```

# rem:chow-iii-h51-square-distance-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h51-square-distance-exercise
uses: []
```

# lem:chow-iii-h52-integral-curve-to-point-distance

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h52-integral-curve-to-point-distance
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h45-integral-curve-level]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h38-acute-angle]]'
```

# prop:chow-iii-h53-maximal-integral-curve

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#prop:chow-iii-h53-maximal-integral-curve
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h52-integral-curve-to-point-distance]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h58-integral-curve-existence]]'
```

# lem:chow-iii-h54-distance-superlevel

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h54-distance-superlevel
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h36-unique-generalized-gradient]]'
```

# lem:chow-iii-h55-broken-geodesic-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h55-broken-geodesic-bound
uses: []
```

# cor:chow-iii-h56-broken-geodesic-limit

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#cor:chow-iii-h56-broken-geodesic-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h55-broken-geodesic-bound]]'
```

# lem:chow-iii-h57-limit-path-properties

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h57-limit-path-properties
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h54-distance-superlevel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h55-broken-geodesic-bound]]'
```

# lem:chow-iii-h58-integral-curve-existence

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#lem:chow-iii-h58-integral-curve-existence
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h41-right-tangent-geodesics]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h57-limit-path-properties]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h37-directional-gradient-inequality]]'
```

# thm:chow-iii-h59-sharafutdinov-retraction

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#thm:chow-iii-h59-sharafutdinov-retraction
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#prop:chow-iii-h53-maximal-integral-curve]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#cor:chow-iii-h50-integral-curve-uniqueness]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h52-integral-curve-to-point-distance]]'
- '[[references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds#lem:chow-iii-h49-integral-curves-distance]]'
```

# rem:chow-iii-h1-lipschitz-question

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h1-lipschitz-question
uses: []
```

# rem:chow-iii-h46-right-continuity-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/apph-convex-functions-riemannian-manifolds.tex#rem:chow-iii-h46-right-continuity-problem
uses: []
```
