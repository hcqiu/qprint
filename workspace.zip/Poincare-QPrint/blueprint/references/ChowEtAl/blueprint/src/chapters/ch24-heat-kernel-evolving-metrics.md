# ch:chow-iii-heat-kernel-evolving-metrics

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#ch:chow-iii-heat-kernel-evolving-metrics
uses: []
```

# def:chow-iii-evolving-heat-kernel

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#def:chow-iii-evolving-heat-kernel
uses: []
```

# thm:chow-iii-closed-evolving-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#thm:chow-iii-closed-evolving-heat-kernel
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#def:chow-iii-evolving-heat-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#prop:chow-iii-evolving-parametrix]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-convolution-derivatives]]'
```

# rem:chow-iii-changing-distance-parametrix

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#rem:chow-iii-changing-distance-parametrix
uses: []
```

# lem:chow-iii-parametrix-recursive-odes

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-parametrix-recursive-odes
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#rem:chow-iii-changing-distance-parametrix]]'
```

# rem:chow-iii-parametrix-coefficients-independent

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#rem:chow-iii-parametrix-coefficients-independent
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-recursive-odes]]'
```

# rem:chow-iii-parametrix-diagonal-recursion

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#rem:chow-iii-parametrix-diagonal-recursion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-recursive-odes]]'
```

# lem:chow-iii-changing-distance-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-changing-distance-bound
uses: []
```

# lem:chow-iii-approximate-kernel-error-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-approximate-kernel-error-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-recursive-odes]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-changing-distance-bound]]'
```

# def:chow-iii-evolving-parametrix

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#def:chow-iii-evolving-parametrix
uses: []
```

# prop:chow-iii-evolving-parametrix

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#prop:chow-iii-evolving-parametrix
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#def:chow-iii-evolving-parametrix]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-approximate-kernel-error-derivatives]]'
```

# lem:chow-iii-cutoff-parametrix-error-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-cutoff-parametrix-error-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#prop:chow-iii-evolving-parametrix]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-approximate-kernel-error-derivatives]]'
```

# def:chow-iii-space-time-convolution

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#def:chow-iii-space-time-convolution
uses: []
```

# rem:chow-iii-static-convolution

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#rem:chow-iii-static-convolution
uses: []
```

# lem:chow-iii-space-time-convolution-associative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-space-time-convolution-associative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#def:chow-iii-space-time-convolution]]'
```

# lem:chow-iii-parametrix-convolution-first-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-parametrix-convolution-first-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#def:chow-iii-space-time-convolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-cutoff-parametrix-error-derivatives]]'
```

# lem:chow-iii-parametrix-convolution-second-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-parametrix-convolution-second-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-convolution-first-derivative]]'
```

# lem:chow-iii-parametrix-convolution-time-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-parametrix-convolution-time-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#def:chow-iii-space-time-convolution]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-cutoff-parametrix-error-derivatives]]'
```

# lem:chow-iii-parametrix-convolution-derivatives

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-parametrix-convolution-derivatives
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-space-time-convolution-associative]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-convolution-first-derivative]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-convolution-second-derivative]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-convolution-time-derivative]]'
```

# thm:chow-iii-evolving-heat-kernel-expansion

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#thm:chow-iii-evolving-heat-kernel-expansion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-closed-evolving-heat-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-convolution-derivatives]]'
```

# lem:chow-iii-changing-distance-expansion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-changing-distance-expansion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-changing-distance-bound]]'
```

# rem:chow-iii-integrated-distance-expansion

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#rem:chow-iii-integrated-distance-expansion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-changing-distance-expansion]]'
```

# lem:chow-iii-psi-zero-expansion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-psi-zero-expansion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-recursive-odes]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-changing-distance-expansion]]'
```

# lem:chow-iii-psi-one-expansion

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-psi-one-expansion
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-recursive-odes]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-psi-zero-expansion]]'
```

# clm:chow-iii-heat-kernel-characterizes-ricci-flow

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#clm:chow-iii-heat-kernel-characterizes-ricci-flow
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-evolving-heat-kernel-expansion]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-psi-zero-expansion]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-psi-one-expansion]]'
```

# rem:chow-iii-cubic-over-time-error

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#rem:chow-iii-cubic-over-time-error
uses: []
```

# lem:chow-iii-adjoint-parametrix-ricci-asymptotics

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-adjoint-parametrix-ricci-asymptotics
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-psi-zero-expansion]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-psi-one-expansion]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#rem:chow-iii-cubic-over-time-error]]'
```

# thm:chow-iii-static-dirichlet-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#thm:chow-iii-static-dirichlet-heat-kernel
uses: []
```

# lem:chow-iii-evolving-dirichlet-problem

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-evolving-dirichlet-problem
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-closed-evolving-heat-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-boundary-jump-relation]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-normal-heat-kernel-derivative]]'
```

# thm:chow-iii-evolving-dirichlet-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#thm:chow-iii-evolving-dirichlet-heat-kernel
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-evolving-dirichlet-problem]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-closed-evolving-heat-kernel]]'
```

# lem:chow-iii-boundary-jump-relation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-boundary-jump-relation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-closed-evolving-heat-kernel]]'
```

# lem:chow-iii-normal-heat-kernel-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-normal-heat-kernel-derivative
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-evolving-heat-kernel-expansion]]'
```

# rem:chow-iii-first-boundary-kernel-integrable

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#rem:chow-iii-first-boundary-kernel-integrable
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-normal-heat-kernel-derivative]]'
```

# rem:chow-iii-normal-derivative-gaussian-bounds

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#rem:chow-iii-normal-derivative-gaussian-bounds
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-normal-heat-kernel-derivative]]'
```

# thm:chow-iii-noncompact-static-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#thm:chow-iii-noncompact-static-heat-kernel
uses: []
```

# thm:chow-iii-noncompact-evolving-heat-kernel

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#thm:chow-iii-noncompact-evolving-heat-kernel
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-evolving-dirichlet-heat-kernel]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-dirichlet-kernel-mass-bound]]'
```

# lem:chow-iii-dirichlet-kernel-mass-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#lem:chow-iii-dirichlet-kernel-mass-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#thm:chow-iii-evolving-dirichlet-heat-kernel]]'
```

# clm:chow-iii-boundary-jump-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#clm:chow-iii-boundary-jump-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-boundary-jump-relation]]'
```

# clm:chow-iii-error-derivative-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#clm:chow-iii-error-derivative-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-approximate-kernel-error-derivatives]]'
```

# clm:chow-iii-fundamental-solution-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#clm:chow-iii-fundamental-solution-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-parametrix-convolution-derivatives]]'
```

# clm:chow-iii-normal-derivative-exercise

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#clm:chow-iii-normal-derivative-exercise
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-normal-heat-kernel-derivative]]'
```

# clm:chow-iii-prove-ricci-flow-characterization

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics.tex#clm:chow-iii-prove-ricci-flow-characterization
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#clm:chow-iii-heat-kernel-characterizes-ricci-flow]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch24-heat-kernel-evolving-metrics#lem:chow-iii-adjoint-parametrix-ricci-asymptotics]]'
```
