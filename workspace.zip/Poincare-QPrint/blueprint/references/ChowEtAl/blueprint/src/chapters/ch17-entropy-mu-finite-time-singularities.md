# ch:chow-iii-entropy-mu-finite-time-singularities

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#ch:chow-iii-entropy-mu-finite-time-singularities
uses: []
```

# def:chow-iii-ch17-perelman-energy-lambda

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#def:chow-iii-ch17-perelman-energy-lambda
uses: []
```

# def:chow-iii-ch17-perelman-entropy-mu-nu

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#def:chow-iii-ch17-perelman-entropy-mu-nu
uses: []
```

# thm:chow-iii-ch17-entropy-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#thm:chow-iii-ch17-entropy-monotonicity
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#def:chow-iii-ch17-perelman-entropy-mu-nu]]'
```

# lem:chow-iii-ch17-entropy-minimizer-equation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-entropy-minimizer-equation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#def:chow-iii-ch17-perelman-entropy-mu-nu]]'
```

# lem:chow-iii-ch17-logarithmic-sobolev

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-logarithmic-sobolev
uses: []
```

# lem:chow-iii-ch17-sobolev-scaling

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-sobolev-scaling
uses: []
```

# lem:chow-iii-ch17-mu-upper-lambda-volume

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-mu-upper-lambda-volume
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#def:chow-iii-ch17-perelman-energy-lambda]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#def:chow-iii-ch17-perelman-entropy-mu-nu]]'
```

# cor:chow-iii-ch17-mu-upper-nonpositive-lambda

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#cor:chow-iii-ch17-mu-upper-nonpositive-lambda
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-mu-upper-lambda-volume]]'
```

# lem:chow-iii-ch17-mu-lower-log-sobolev

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-mu-lower-log-sobolev
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-logarithmic-sobolev]]'
```

# lem:chow-iii-ch17-mu-lower-lambda

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-mu-lower-lambda
uses: []
```

# rem:chow-iii-ch17-mu-lower-bound-scales

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-mu-lower-bound-scales
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-mu-lower-lambda]]'
```

# lem:chow-iii-ch17-volume-lower-nonpositive-lambda

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-volume-lower-nonpositive-lambda
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#cor:chow-iii-ch17-mu-upper-nonpositive-lambda]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-mu-lower-lambda]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#thm:chow-iii-ch17-entropy-monotonicity]]'
```

# rem:chow-iii-ch17-singularity-models

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-singularity-models
uses: []
```

# lem:chow-iii-ch17-model-noncompact-nonpositive-lambda

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-model-noncompact-nonpositive-lambda
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-volume-lower-nonpositive-lambda]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#rem:chow-iii-ch17-singularity-models]]'
```

# rem:chow-iii-ch17-noncompact-model-infinite-volume

```qprint
kind: proof
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-noncompact-model-infinite-volume
uses: []
```

# cor:chow-iii-ch17-compact-model-positive-lambda

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#cor:chow-iii-ch17-compact-model-positive-lambda
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-model-noncompact-nonpositive-lambda]]'
```

# thm:chow-iii-ch17-compact-model-shrinker

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#thm:chow-iii-ch17-compact-model-shrinker
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#cor:chow-iii-ch17-compact-model-positive-lambda]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-nu-continuity-positive-lambda]]'
```

# lem:chow-iii-ch17-nu-continuity-positive-lambda

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-nu-continuity-positive-lambda
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-mu-continuity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-mu-lower-lambda]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#prop:chow-iii-ch17-mu-small-scale-limit]]'
```

# lem:chow-iii-ch17-mu-continuity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-mu-continuity
uses: []
```

# cor:chow-iii-ch17-closed-three-model-round

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#cor:chow-iii-ch17-closed-three-model-round
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#thm:chow-iii-ch17-compact-model-shrinker]]'
```

# rem:chow-iii-ch17-compact-model-type-i-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-compact-model-type-i-problem
uses: []
```

# rem:chow-iii-ch17-compact-factor-shrinker

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-compact-factor-shrinker
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#thm:chow-iii-ch17-compact-model-shrinker]]'
```

# lem:chow-iii-ch17-mu-negative-small-scale

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-mu-negative-small-scale
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#thm:chow-iii-ch17-entropy-monotonicity]]'
```

# prop:chow-iii-ch17-mu-small-scale-limit

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#prop:chow-iii-ch17-mu-small-scale-limit
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-mu-negative-small-scale]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#prop:chow-iii-ch17-smooth-entropy-minimizer]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-weak-strong-maximum-principle]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-minimizer-maximum-lower-bound]]'
```

# rem:chow-iii-ch17-mu-small-scale-asymptotics-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-mu-small-scale-asymptotics-problem
uses: []
```

# lem:chow-iii-ch17-small-minimizer-nonconstant-nonunique

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-small-minimizer-nonconstant-nonunique
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-entropy-minimizer-equation]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#prop:chow-iii-ch17-mu-small-scale-limit]]'
```

# rem:chow-iii-ch17-homogeneous-minimizer-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-homogeneous-minimizer-problem
uses: []
```

# prop:chow-iii-ch17-smooth-entropy-minimizer

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#prop:chow-iii-ch17-smooth-entropy-minimizer
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-mu-lower-log-sobolev]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-log-entropy-continuity]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-weak-strong-maximum-principle]]'
```

# lem:chow-iii-ch17-log-entropy-continuity

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-log-entropy-continuity
uses: []
```

# lem:chow-iii-ch17-weak-strong-maximum-principle

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-weak-strong-maximum-principle
uses: []
```

# rem:chow-iii-ch17-weak-maximum-principle-scaling

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-weak-maximum-principle-scaling
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-weak-strong-maximum-principle]]'
```

# lem:chow-iii-ch17-minimizer-maximum-lower-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-minimizer-maximum-lower-bound
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-entropy-minimizer-equation]]'
```

# def:chow-iii-ch17-linear-trace-harnack

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#def:chow-iii-ch17-linear-trace-harnack
uses: []
```

# lem:chow-iii-ch17-modified-scalar-variation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-modified-scalar-variation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#def:chow-iii-ch17-linear-trace-harnack]]'
```

# lem:chow-iii-ch17-perelman-energy-first-variation

```qprint
kind: lemma
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#lem:chow-iii-ch17-perelman-energy-first-variation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-modified-scalar-variation]]'
```

# def:chow-iii-ch17-matrix-harnack-curvature-square

```qprint
kind: definition
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#def:chow-iii-ch17-matrix-harnack-curvature-square
uses: []
```

# thm:chow-iii-ch17-coupled-loop-variation

```qprint
kind: theorem
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#thm:chow-iii-ch17-coupled-loop-variation
uses:
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#lem:chow-iii-ch17-perelman-energy-first-variation]]'
- '[[references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities#def:chow-iii-ch17-matrix-harnack-curvature-square]]'
```

# rem:chow-iii-ch17-zeroth-loop-variation

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-zeroth-loop-variation
uses: []
```

# rem:chow-iii-ch17-guiding-principles-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-guiding-principles-problem
uses: []
```

# rem:chow-iii-ch17-higher-loop-problem

```qprint
kind: other
status: not_started
tex: references/ChowEtAl/blueprint/src/chapters/ch17-entropy-mu-finite-time-singularities.tex#rem:chow-iii-ch17-higher-loop-problem
uses: []
```
