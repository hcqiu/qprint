# ch03-lem-metric-inverse-evolves

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-metric-inverse-evolves
uses: []
```

# ch03-lem-connection-evolves

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-connection-evolves
uses: []
```

# ch03-lem-riemann-evolves

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-riemann-evolves
uses: []
```

# ch03-rem-riemann-alt-form

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-riemann-alt-form
uses: []
```

# ch03-lem-ricci-evolves

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-ricci-evolves
uses: []
```

# ch03-rem-lichnerowicz-laplacian

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-lichnerowicz-laplacian
uses: []
```

# ch03-lem-scalar-curvature-evolves

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-scalar-curvature-evolves
uses: []
```

# ch03-rem-scalar-curvature-invariant-form

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-scalar-curvature-invariant-form
uses: []
```

# ch03-lem-volume-element-evolves

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-volume-element-evolves
uses: []
```

# ch03-cor-total-scalar-curvature-evolves

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-cor-total-scalar-curvature-evolves
uses: []
```

# ch03-lem-length-evolves

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-length-evolves
uses: []
```

# ch03-rem-symbol-of-composition

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-symbol-of-composition
uses: []
```

# ch03-thm-short-time-existence

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-thm-short-time-existence
uses: []
```

# ch03-rem-lifetime-lower-bound

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-lifetime-lower-bound
uses: []
```

# ch03-lem-deTurck-flow-diffeomorphisms

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-deTurck-flow-diffeomorphisms
uses: []
```

# ch03-rem-noncompact-flow-failure

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-noncompact-flow-failure
uses: []
```

# ch03-lem-riemann-tensor-decomposition

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-riemann-tensor-decomposition
uses: []
```

# ch03-lem-harmonic-map-laplacian

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-harmonic-map-laplacian
uses: []
```

# ch03-cor-identity-harmonic-map

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-cor-identity-harmonic-map
uses: []
```

# ch03-cor-positive-ricci-identity-harmonic

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-cor-positive-ricci-identity-harmonic
uses: []
```

# ch03-rem-negative-ricci-target

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-negative-ricci-target
uses: []
```

# ch03-prop-cross-curvature-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-prop-cross-curvature-monotonicity
uses: []
```

# ch03-conj-cross-curvature-global-existence

```qprint
kind: conjecture
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-conj-cross-curvature-global-existence
uses: []
```

# ch03-rem-andrews-observation

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-andrews-observation
uses: []
```

# ch03-lem-deTurck-diffeomorphisms-harmonic-map

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-deTurck-diffeomorphisms-harmonic-map
uses: []
```

# ch03-def-harmonic-coordinates

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-def-harmonic-coordinates
uses: []
```

# ch03-thm-local-elliptic-solvability

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-thm-local-elliptic-solvability
uses: []
```

# ch03-cor-harmonic-coordinates-exist

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-cor-harmonic-coordinates-exist
uses: []
```

# ch03-lem-harmonic-coordinate-regularity

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-harmonic-coordinate-regularity
uses: []
```

# ch03-lem-ricci-in-harmonic-coordinates

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-lem-ricci-in-harmonic-coordinates
uses: []
```

# ch03-cor-ricci-flow-heat-equation

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-cor-ricci-flow-heat-equation
uses: []
```

# ch03-rem-harmonic-coordinate-caution

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-rem-harmonic-coordinate-caution
uses: []
```

# ch03-ex-cross-curvature-harmonic-map

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-ex-cross-curvature-harmonic-map
uses: []
```

# ch03-prob-cross-curvature-harmonic-map

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch03-short-time-existence.tex#ch03-prob-cross-curvature-harmonic-map
uses: []
```
