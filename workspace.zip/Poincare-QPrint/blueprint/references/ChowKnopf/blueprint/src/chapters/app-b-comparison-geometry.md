# appb-lem-gauss-lemma

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-gauss-lemma
uses: []
```

# appb-cor-gradient-radial-distance

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-gradient-radial-distance
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-gauss-lemma]]'
```

# appb-def-conjugate-point

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-conjugate-point
uses: []
```

# appb-def-conjugate-radius

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-conjugate-radius
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-conjugate-point]]'
```

# appb-rem-conjugate-radius-immersion

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-rem-conjugate-radius-immersion
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-conjugate-radius]]'
```

# appb-lem-limit-geodesic-2gon-conjugate

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-limit-geodesic-2gon-conjugate
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-conjugate-point]]'
```

# appb-rem-limit-failure-varying-manifolds

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-rem-limit-failure-varying-manifolds
uses: []
```

# appb-ex-collapsing-flat-tori

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-ex-collapsing-flat-tori
uses: []
```

# appb-ex-spherical-orbifold

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-ex-spherical-orbifold
uses: []
```

# appb-def-jacobi-field

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-jacobi-field
uses: []
```

# appb-lem-conjugate-differential-exp

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-conjugate-differential-exp
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-conjugate-point]]'
```

# appb-prop-jacobi-characterizes-conjugacy

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-prop-jacobi-characterizes-conjugacy
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-conjugate-point]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-jacobi-field]]'
```

# appb-lem-jacobi-equation

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-jacobi-equation
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-jacobi-field]]'
```

# appb-cor-jacobi-orthogonal-decomposition

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-jacobi-orthogonal-decomposition
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-jacobi-equation]]'
```

# appb-def-normal-bundle

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-normal-bundle
uses: []
```

# appb-def-focal-point

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-focal-point
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-normal-bundle]]'
```

# appb-thm-rauch-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-thm-rauch-comparison
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-jacobi-field]]'
```

# appb-cor-rauch-nonpositive-model

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-rauch-nonpositive-model
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-rauch-comparison]]'
```

# appb-cor-rauch-injectivity-radius

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-rauch-injectivity-radius
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-rauch-comparison]]'
```

# appb-thm-laplacian-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-thm-laplacian-comparison
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-cor-gradient-radial-distance]]'
```

# appb-cor-model-space-radial-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-model-space-radial-comparison
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-laplacian-comparison]]'
```

# appb-thm-toponogov-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-thm-toponogov-comparison
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-rauch-comparison]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-laplacian-comparison]]'
```

# appb-cor-angle-comparison

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-angle-comparison
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-toponogov-comparison]]'
```

# appb-lem-halfspace-totally-convex

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-halfspace-totally-convex
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-toponogov-comparison]]'
```

# appb-lem-halfspace-exhaustion

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-halfspace-exhaustion
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-halfspace-totally-convex]]'
```

# appb-lem-busemann-basic

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-busemann-basic
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-halfspace-exhaustion]]'
```

# appb-lem-compactness-geodesic-segments

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-compactness-geodesic-segments
uses: []
```

# appb-prop-nonconvexity-contradiction

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-prop-nonconvexity-contradiction
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-toponogov-comparison]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-halfspace-totally-convex]]'
```

# appb-def-shifted-ray

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-shifted-ray
uses: []
```

# appb-lem-shifted-ray-monotone

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-shifted-ray-monotone
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-shifted-ray]]'
```

# appb-lem-shifted-ray-distance

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-shifted-ray-distance
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-shifted-ray]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-shifted-ray-monotone]]'
```

# appb-def-busemann-sublevel

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-busemann-sublevel
uses: []
```

# appb-lem-busemann-sublevels

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-busemann-sublevels
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-busemann-sublevel]]'
```

# appb-cor-busemann-ball-containment

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-busemann-ball-containment
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-busemann-sublevels]]'
```

# appb-cor-busemann-exhaustion

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-busemann-exhaustion
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-busemann-sublevels]]'
```

# appb-prop-busemann-sublevel-compact-convex

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-prop-busemann-sublevel-compact-convex
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-busemann-sublevels]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-thm-toponogov-comparison]]'
```

# appb-cor-busemann-below

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-cor-busemann-below
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-prop-busemann-sublevel-compact-convex]]'
```

# appb-prop-busemann-level-sets-parallel

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-prop-busemann-level-sets-parallel
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-prop-busemann-sublevel-compact-convex]]'
```

# appb-thm-inj-radius-positive-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-thm-inj-radius-positive-curvature
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-prop-busemann-sublevel-compact-convex]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-prop-busemann-level-sets-parallel]]'
```

# appb-def-proper-geodesic-k-gon

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-proper-geodesic-k-gon
uses: []
```

# appb-def-geodesic-k-gon

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-def-geodesic-k-gon
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-proper-geodesic-k-gon]]'
```

# appb-lem-polygon-space-compact

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-polygon-space-compact
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-proper-geodesic-k-gon]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-geodesic-k-gon]]'
```

# appb-lem-minimizing-polygon-smooth

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-lem-minimizing-polygon-smooth
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-lem-polygon-space-compact]]'
```

# appb-ex-euclidean-sphere-focal-point

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-ex-euclidean-sphere-focal-point
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-focal-point]]'
```

# appb-ex-normal-bundle-codim-zero

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-ex-normal-bundle-codim-zero
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-normal-bundle]]'
```

# appb-ex-normal-bundle-point

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry.tex#appb-ex-normal-bundle-point
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-b-comparison-geometry#appb-def-normal-bundle]]'
```
