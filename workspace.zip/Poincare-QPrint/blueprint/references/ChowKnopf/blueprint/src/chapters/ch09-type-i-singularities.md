# ch09-rem-singularity-intuition

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-rem-singularity-intuition
uses: []
```

# ch09-rem-canonical-model-geometries

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-rem-canonical-model-geometries
uses: []
```

# ch09-rem-singularity-model-heuristics

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-rem-singularity-model-heuristics
uses: []
```

# ch09-lem-positive-sectional-curvature-preserved

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-positive-sectional-curvature-preserved
uses: []
```

# ch09-lem-positive-ricci-curvature-preserved

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-positive-ricci-curvature-preserved
uses: []
```

# ch09-thm-pinching-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-thm-pinching-estimate
uses: []
```

# ch09-lem-pinching-cone-convexity

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-pinching-cone-convexity
uses: []
```

# ch09-lem-omega-derivative

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-omega-derivative
uses: []
```

# ch09-cor-nonnegative-curvature-limits

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-cor-nonnegative-curvature-limits
uses: []
```

# ch09-def-type-i-essential-necklike

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-def-type-i-essential-necklike
uses: []
```

# ch09-thm-necklike-points-finite-time

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-thm-necklike-points-finite-time
uses: []
```

# ch09-lem-curvature-vs-scalar

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-curvature-vs-scalar
uses: []
```

# ch09-lem-modified-pinching-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-modified-pinching-evolution
uses: []
```

# ch09-lem-pinching-improves-away-from-necks

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-pinching-improves-away-from-necks
uses: []
```

# ch09-rem-alternate-boundedness-of-F

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-rem-alternate-boundedness-of-F
uses: []
```

# ch09-lem-ancient-nonnegative-scalar

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-ancient-nonnegative-scalar
uses: []
```

# ch09-rem-ancient-scalar-three-dimensional

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-rem-ancient-scalar-three-dimensional
uses: []
```

# ch09-lem-ancient-lower-blowup-rate

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-ancient-lower-blowup-rate
uses: []
```

# ch09-thm-necklike-points-ancient

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-thm-necklike-points-ancient
uses: []
```

# ch09-prop-lyh-trace-estimate

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-prop-lyh-trace-estimate
uses: []
```

# ch09-cor-tR-monotone

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-cor-tR-monotone
uses: []
```

# ch09-lem-ancient-type-i-surface-compact

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-lem-ancient-type-i-surface-compact
uses: []
```

# ch09-prop-type-i-surface-classification

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-prop-type-i-surface-classification
uses: []
```

# ch09-prop-type-ii-ancient-surface-limits

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-prop-type-ii-ancient-surface-limits
uses: []
```

# ch09-cor-ancient-surface-classification

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-cor-ancient-surface-classification
uses: []
```

# ch09-rem-notes-and-commentary

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch09-type-i-singularities.tex#ch09-rem-notes-and-commentary
uses: []
```
