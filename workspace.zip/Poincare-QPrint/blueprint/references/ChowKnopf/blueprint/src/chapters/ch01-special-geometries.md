# ch01-rem-manifolds-smooth-boundaryless

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-rem-manifolds-smooth-boundaryless
uses: []
```

# ch01-conj-elliptization

```qprint
kind: conjecture
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-conj-elliptization
uses: []
```

# ch01-conj-hyperbolization

```qprint
kind: conjecture
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-conj-hyperbolization
uses: []
```

# ch01-rem-poincare

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-rem-poincare
uses: []
```

# ch01-prop-singer

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-prop-singer
uses: []
```

# ch01-prop-homogeneous-complete

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-prop-homogeneous-complete
uses: []
```

# ch01-lem-model-geometry-to-homogeneous-space

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-lem-model-geometry-to-homogeneous-space
uses: []
```

# ch01-prop-isometry-group

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-prop-isometry-group
uses: []
```

# ch01-cor-unique-isometry

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-cor-unique-isometry
uses: []
```

# ch01-lem-isotropy-isomorphic

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-lem-isotropy-isomorphic
uses: []
```

# ch01-rem-model-geometry-ambiguity

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-rem-model-geometry-ambiguity
uses: []
```

# ch01-lem-unimodular-lie-group

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-lem-unimodular-lie-group
uses: []
```

# ch01-prop-classification-maximal-models

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-prop-classification-maximal-models
uses: []
```

# ch01-lem-curvature-offdiagonal

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-lem-curvature-offdiagonal
uses: []
```

# ch01-prop-su2-collapse

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-prop-su2-collapse
uses: []
```

# ch01-rem-round-sphere

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-rem-round-sphere
uses: []
```

# ch01-lem-common-time-interval

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-lem-common-time-interval
uses: []
```

# ch01-lem-collapse-discontinuity

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-lem-collapse-discontinuity
uses: []
```

# ch01-prop-nil

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-prop-nil
uses: []
```

# ch01-cor-nil-collapse

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-cor-nil-collapse
uses: []
```

# ch01-prop-sol

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-prop-sol
uses: []
```

# ch01-cor-sol-collapse

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-cor-sol-collapse
uses: []
```

# ch01-rem-hyperbolization-progress

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-rem-hyperbolization-progress
uses: []
```

# ch01-rem-seifert-equivalence

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch01-special-geometries.tex#ch01-rem-seifert-equivalence
uses: []
```
