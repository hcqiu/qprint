# ch02-rem-self-similar-solutions

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-self-similar-solutions
uses: []
```

# ch02-rem-gradient-solitons

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-gradient-solitons
uses: []
```

# ch02-ex-gaussian-soliton

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-ex-gaussian-soliton
uses: []
```

# ch02-lem-self-similar-solutions-and-solitons

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-self-similar-solutions-and-solitons
uses: []
```

# ch02-ex-cigar-soliton

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-ex-cigar-soliton
uses: []
```

# ch02-lem-cigars-unique

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-cigars-unique
uses: []
```

# ch02-rem-cigars-potential

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-cigars-potential
uses: []
```

# ch02-lem-cylinder-to-sphere

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-cylinder-to-sphere
uses: []
```

# ch02-lem-rosenau-sphere

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-rosenau-sphere
uses: []
```

# ch02-rem-rosenau-limit-cigar

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-rosenau-limit-cigar
uses: []
```

# ch02-lem-expanding-cone-soliton

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-expanding-cone-soliton
uses: []
```

# ch02-thm-neckpinch-rigorous

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-thm-neckpinch-rigorous
uses: []
```

# ch02-thm-neckpinch-asymptotics

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-thm-neckpinch-asymptotics
uses: []
```

# ch02-rem-single-point-pinching

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-single-point-pinching
uses: []
```

# ch02-rem-neckpinch-pde

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-neckpinch-pde
uses: []
```

# ch02-rem-neckpinch-curvatures

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-neckpinch-curvatures
uses: []
```

# ch02-prop-neckpinch-bounds

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-prop-neckpinch-bounds
uses: []
```

# ch02-lem-neckpinch-slope

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-slope
uses: []
```

# ch02-lem-neckpinch-a-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-a-evolution
uses: []
```

# ch02-cor-neckpinch-a-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-cor-neckpinch-a-bound
uses: []
```

# ch02-cor-neckpinch-curvature-radius

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-cor-neckpinch-curvature-radius
uses: []
```

# ch02-lem-neckpinch-L-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-L-evolution
uses: []
```

# ch02-cor-neckpinch-Lmin

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-cor-neckpinch-Lmin
uses: []
```

# ch02-lem-neckpinch-shrinking-radius

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-shrinking-radius
uses: []
```

# ch02-lem-neckpinch-lipschitz

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-lipschitz
uses: []
```

# ch02-cor-neckpinch-limit-profile

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-cor-neckpinch-limit-profile
uses: []
```

# ch02-prop-neckpinch-profile

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-prop-neckpinch-profile
uses: []
```

# ch02-lem-neckpinch-zeroes

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-zeroes
uses: []
```

# ch02-lem-neckpinch-neck-rate

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-neck-rate
uses: []
```

# ch02-lem-tensor-maximum-boundary

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-tensor-maximum-boundary
uses: []
```

# ch02-lem-neckpinch-concavity-polar-cap

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-concavity-polar-cap
uses: []
```

# ch02-lem-neckpinch-no-polar-singularity

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-no-polar-singularity
uses: []
```

# ch02-prop-neckpinch-typei-cylinder

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-prop-neckpinch-typei-cylinder
uses: []
```

# ch02-lem-neckpinch-typei-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-typei-bound
uses: []
```

# ch02-lem-neckpinch-F-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-F-evolution
uses: []
```

# ch02-lem-neckpinch-Fhat-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-Fhat-bound
uses: []
```

# ch02-lem-neckpinch-neck-profile-estimates

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-neck-profile-estimates
uses: []
```

# ch02-prop-neckpinch-happen

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-prop-neckpinch-happen
uses: []
```

# ch02-lem-neckpinch-bump-model

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-bump-model
uses: []
```

# ch02-lem-neckpinch-initial-family

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-neckpinch-initial-family
uses: []
```

# ch02-prop-single-point-pinching

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-prop-single-point-pinching
uses: []
```

# ch02-lem-single-point-subsolution

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-lem-single-point-subsolution
uses: []
```

# ch02-rem-cigar-negative-curvature-exercise

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-cigar-negative-curvature-exercise
uses: []
```

# ch02-rem-degenerate-neckpinch-picture

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-degenerate-neckpinch-picture
uses: []
```

# ch02-rem-rosenau-singularity-model

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-rosenau-singularity-model
uses: []
```

# ch02-rem-slowly-forming-meaning

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-slowly-forming-meaning
uses: []
```

# ch02-rem-typei-typeiia

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch02-special-limit-solutions.tex#ch02-rem-typei-typeiia
uses: []
```
