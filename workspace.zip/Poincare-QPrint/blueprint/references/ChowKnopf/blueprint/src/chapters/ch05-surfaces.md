# ch05-thm-conformal-scalar-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-thm-conformal-scalar-curvature
uses: []
```

# ch05-lem-laplacian-evolution

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-lem-laplacian-evolution
uses: []
```

# ch05-cor-area-form-evolution

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-area-form-evolution
uses: []
```

# ch05-cor-area-preservation

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-area-preservation
uses: []
```

# ch05-lem-scalar-curvature-evolution-surface

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-lem-scalar-curvature-evolution-surface
uses: []
```

# ch05-cor-curvature-potential-evolution

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-curvature-potential-evolution
uses: []
```

# ch05-lem-potential-normalization

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-lem-potential-normalization
uses: []
```

# ch05-def-normalized-flow

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-def-normalized-flow
uses: []
```

# ch05-def-ricci-potential

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-def-ricci-potential
uses: []
```

# ch05-lem-potential-equation

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-lem-potential-equation
uses: []
```

# ch05-rem-potential-normalization

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-rem-potential-normalization
uses: []
```

# ch05-cor-potential-time-evolution

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-potential-time-evolution
uses: []
```

# ch05-prop-curvature-bounds-nonpositive-average

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-curvature-bounds-nonpositive-average
uses: []
```

# ch05-prop-H-evolution

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-H-evolution
uses: []
```

# ch05-cor-upper-curvature-control

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-upper-curvature-control
uses: []
```

# ch05-prop-two-sided-curvature-control

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-two-sided-curvature-control
uses: []
```

# ch05-prop-long-time-existence-nonpositive

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-long-time-existence-nonpositive
uses: []
```

# ch05-prop-self-similar-solutions-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-self-similar-solutions-constant-curvature
uses: []
```

# ch05-prop-self-similar-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-self-similar-constant-curvature
uses: []
```

# ch05-thm-negative-average-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-thm-negative-average-curvature
uses: []
```

# ch05-thm-zero-average-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-thm-zero-average-curvature
uses: []
```

# ch05-prop-entropy-monotonicity

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-entropy-monotonicity
uses: []
```

# ch05-prop-positive-curvature-strategy

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-positive-curvature-strategy
uses: []
```

# ch05-lem-doubling-time

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-lem-doubling-time
uses: []
```

# ch05-cor-short-time-curvature-control

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-short-time-curvature-control
uses: []
```

# ch05-lem-gradient-control

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-lem-gradient-control
uses: []
```

# ch05-cor-curvature-decay-away-from-positivity

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-curvature-decay-away-from-positivity
uses: []
```

# ch05-prop-uniform-curvature-bound-positive

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-uniform-curvature-bound-positive
uses: []
```

# ch05-prop-diameter-bound-positive

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-diameter-bound-positive
uses: []
```

# ch05-cor-injectivity-radius-control

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-injectivity-radius-control
uses: []
```

# ch05-cor-differential-harnack

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-differential-harnack
uses: []
```

# ch05-prop-positive-curvature-lower-bound

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-positive-curvature-lower-bound
uses: []
```

# ch05-prop-modified-harnack-control

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-modified-harnack-control
uses: []
```

# ch05-lem-aux-lower-bound

```qprint
kind: lemma
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-lem-aux-lower-bound
uses: []
```

# ch05-prop-entropy-lower-bound-sign-changing

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-entropy-lower-bound-sign-changing
uses: []
```

# ch05-prop-eventual-positivity

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-prop-eventual-positivity
uses: []
```

# ch05-cor-exponential-convergence-positive

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-cor-exponential-convergence-positive
uses: []
```

# ch05-thm-positive-average-curvature

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-thm-positive-average-curvature
uses: []
```

# ch05-thm-main

```qprint
kind: theorem
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/ch05-surfaces.tex#ch05-thm-main
uses: []
```
