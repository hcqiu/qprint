# appa-def-component-representation

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-component-representation
uses: []
```

# appa-def-metric-dual-vector

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-metric-dual-vector
uses: []
```

# appa-def-metric-dual-covector

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-metric-dual-covector
uses: []
```

# appa-rem-index-raising-lowering

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-index-raising-lowering
uses: []
```

# appa-def-vector-action-on-function

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-vector-action-on-function
uses: []
```

# appa-def-levi-civita-covariant-derivative

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-levi-civita-covariant-derivative
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-vector-action-on-function]]'
```

# appa-rem-covariant-derivative-vector

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-covariant-derivative-vector
uses: []
```

# appa-def-covariant-derivative-vector

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-covariant-derivative-vector
uses: []
```

# appa-def-covariant-derivative-covector

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-covariant-derivative-covector
uses: []
```

# appa-def-covariant-derivative-general-tensor

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-covariant-derivative-general-tensor
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-covariant-derivative-vector]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-covariant-derivative-covector]]'
```

# appa-def-component-representation-covariant-derivative

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-component-representation-covariant-derivative
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-component-representation]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-covariant-derivative-general-tensor]]'
```

# appa-rem-abuse-notation-covariant-derivatives

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-abuse-notation-covariant-derivatives
uses: []
```

# appa-def-lie-derivative-vector

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-lie-derivative-vector
uses: []
```

# appa-def-lie-derivative-covector

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-lie-derivative-covector
uses: []
```

# appa-rem-lie-bracket-via-connection

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-lie-bracket-via-connection
uses: []
```

# appa-rem-lie-derivative-tensors

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-lie-derivative-tensors
uses: []
```

# appa-rem-lie-derivative-metric

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-lie-derivative-metric
uses: []
```

# appa-def-divergence-operator

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-divergence-operator
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-lie-derivative-vector]]'
```

# appa-def-formal-adjoint-divergence

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-formal-adjoint-divergence
uses: []
```

# appa-rem-extending-divergence-adjoint

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-extending-divergence-adjoint
uses: []
```

# appa-def-exterior-derivative

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-exterior-derivative
uses: []
```

# appa-rem-exterior-derivative-covariant-form

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-exterior-derivative-covariant-form
uses: []
```

# appa-def-formal-adjoint-exterior-derivative

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-formal-adjoint-exterior-derivative
uses: []
```

# appa-rem-adjoint-exterior-derivative-covariant-form

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-adjoint-exterior-derivative-covariant-form
uses: []
```

# appa-def-rough-laplacian

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-rough-laplacian
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-covariant-derivative-general-tensor]]'
```

# appa-def-rough-laplacian-components

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-rough-laplacian-components
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-component-representation]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-rough-laplacian]]'
```

# appa-def-hodge-de-rham-laplacian

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-hodge-de-rham-laplacian
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-exterior-derivative]]'
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-formal-adjoint-exterior-derivative]]'
```

# appa-rem-hodge-laplacian-components

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-hodge-laplacian-components
uses: []
```

# appa-def-lichnerowicz-laplacian

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-lichnerowicz-laplacian
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-rough-laplacian]]'
```

# appa-rem-lichnerowicz-laplacian-components

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-lichnerowicz-laplacian-components
uses: []
```

# appa-rem-lichnerowicz-hodge-comparison

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-lichnerowicz-hodge-comparison
uses: []
```

# appa-def-higher-covariant-derivatives

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-higher-covariant-derivatives
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-covariant-derivative-general-tensor]]'
```

# appa-rem-iterated-vs-nested-covariant-derivatives

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-iterated-vs-nested-covariant-derivatives
uses: []
```

# appa-def-riemann-curvature-via-covariant-derivatives

```qprint
kind: definition
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-def-riemann-curvature-via-covariant-derivatives
uses:
- '[[references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus#appa-def-higher-covariant-derivatives]]'
```

# appa-rem-curvature-commutator

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-curvature-commutator
uses: []
```

# appa-rem-curvature-coordinate-form

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-curvature-coordinate-form
uses: []
```

# appa-rem-ricci-identities

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-ricci-identities
uses: []
```

# appa-rem-commutator-general-tensors

```qprint
kind: other
status: not_started
tex: references/ChowKnopf/blueprint/src/chapters/app-a-ricci-calculus.tex#appa-rem-commutator-general-tensors
uses: []
```
