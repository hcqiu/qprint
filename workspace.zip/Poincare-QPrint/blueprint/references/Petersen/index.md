---
title: references/Petersen
---

## Blueprint

- [[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.md]]
- [[references/Petersen/blueprint/src/chapters/Ch02_Derivatives.md]]
- [[references/Petersen/blueprint/src/chapters/Ch03_Curvature.md]]
- [[references/Petersen/blueprint/src/chapters/Ch04_Examples.md]]
- [[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.md]]
- [[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.md]]
- [[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.md]]
- [[references/Petersen/blueprint/src/chapters/Ch08_KillingFields.md]]
- [[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.md]]
- [[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.md]]
- [[references/Petersen/blueprint/src/chapters/Ch11_Convergence.md]]
- [[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.md]]
- [[references/Petersen/blueprint/src/chapters/formalization-support.md]]
