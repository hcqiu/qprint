# chap:pet-examples

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#chap:pet-examples
uses: []
```

# prop:pet-ch4-curvature-operator-diagonal-bounds

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-curvature-operator-diagonal-bounds
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-curvature-operator-diagonal-bounds]]'
```

# prop:pet-ch4-triple-vanishing-diagonalizes-operator

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-triple-vanishing-diagonalizes-operator
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-triple-vanishing-diagonalizes-operator]]'
```

# prop:pet-ch4-ricci-diagonal-criterion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-ricci-diagonal-criterion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-ricci-diagonal-criterion]]'
```

# prop:pet-ch4-hess-r-euclidean

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-hess-r-euclidean
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hess-r-euclidean]]'
```

# prop:pet-ch4-euclidean-sphere-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-euclidean-sphere-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hess-r-euclidean]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-triple-vanishing-diagonalizes-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-euclidean-sphere-constant-curvature]]'
```

# def:pet-ch4-product-sphere-metric

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-product-sphere-metric
uses: []
```

# prop:pet-ch4-product-sphere-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-product-sphere-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-product-sphere-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-euclidean-sphere-constant-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-triple-vanishing-diagonalizes-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-product-sphere-curvature]]'
```

# rem:pet-ch4-product-sphere-ricci-einstein

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-product-sphere-ricci-einstein
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-product-sphere-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-curvature-operator-diagonal-bounds]]'
```

# prop:pet-ch4-hess-r-rotsym

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-hess-r-rotsym
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hess-r-rotsym]]'
```

# lem:pet-ch4-hess-r-derivatives

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#lem:pet-ch4-hess-r-derivatives
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hess-r-rotsym]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#lem:pet-ch4-hess-r-derivatives]]'
```

# prop:pet-ch4-rotsym-radial-jacobi

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-rotsym-radial-jacobi
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#lem:pet-ch4-hess-r-derivatives]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-rotsym-radial-jacobi]]'
```

# thm:pet-ch4-rotsym-curvature-operator

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#thm:pet-ch4-rotsym-curvature-operator
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-rotsym-radial-jacobi]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-triple-vanishing-diagonalizes-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-rotsym-curvature-operator]]'
```

# prop:pet-ch4-rotsym-ricci-scalar

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-rotsym-ricci-scalar
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-rotsym-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-rotsym-ricci-scalar]]'
```

# rem:pet-ch4-rotsym-dim2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-rotsym-dim2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-rotsym-ricci-scalar]]'
```

# prop:pet-ch4-snk-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-snk-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-rotsym-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-snk-constant-curvature]]'
```

# prop:pet-ch4-ricci-flat-rotsym

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-ricci-flat-rotsym
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-rotsym-ricci-scalar]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-ricci-flat-rotsym]]'
```

# def:pet-ch4-scalar-flat-ode

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-scalar-flat-ode
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-rotsym-ricci-scalar]]'
```

# prop:pet-ch4-scalar-flat-cases

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-scalar-flat-cases
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-scalar-flat-ode]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-scalar-flat-cases]]'
```

# ex:pet-ch4-scalar-flat-tautological-bundle

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#ex:pet-ch4-scalar-flat-tautological-bundle
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-scalar-flat-cases]]'
```

# rem:pet-ch4-scalar-flat-not-ricci-flat

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-scalar-flat-not-ricci-flat
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-scalar-flat-tautological-bundle]]'
```

# thm:pet-ch4-doubly-warped-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#thm:pet-ch4-doubly-warped-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-rotsym-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-product-sphere-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-triple-vanishing-diagonalizes-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-doubly-warped-curvature]]'
```

# prop:pet-ch4-doubly-warped-ricci

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-doubly-warped-ricci
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-doubly-warped-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-doubly-warped-ricci]]'
```

# def:pet-ch4-schwarzschild-construction

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-schwarzschild-construction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-doubly-warped-ricci]]'
```

# prop:pet-ch4-schwarzschild-reduces-scalar-flat

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-schwarzschild-reduces-scalar-flat
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-schwarzschild-construction]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-scalar-flat-ode]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-schwarzschild-reduces-scalar-flat]]'
```

# prop:pet-ch4-schwarzschild-ricci-flat

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-schwarzschild-ricci-flat
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-schwarzschild-reduces-scalar-flat]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-scalar-flat-cases]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-schwarzschild-ricci-flat]]'
```

# rem:pet-ch4-schwarzschild-physical

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-schwarzschild-physical
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-schwarzschild-ricci-flat]]'
```

# def:pet-ch4-warped-product-general

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-warped-product-general
uses: []
```

# def:pet-ch4-warping-potential-f

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-warping-potential-f
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warped-product-general]]'
```

# prop:pet-ch4-hess-f-conformal

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-hess-f-conformal
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warping-potential-f]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hess-r-rotsym]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hess-f-conformal]]'
```

# rem:pet-ch4-warped-product-canonical-form

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-warped-product-canonical-form
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hess-f-conformal]]'
```

# ex:pet-ch4-hess-f-space-forms

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#ex:pet-ch4-hess-f-space-forms
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hess-f-conformal]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-snk-constant-curvature]]'
```

# thm:pet-ch4-brinkmann-warped-product

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#thm:pet-ch4-brinkmann-warped-product
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warped-product-general]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-brinkmann-warped-product]]'
```

# thm:pet-ch4-brinkmann-critical-point

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#thm:pet-ch4-brinkmann-critical-point
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-brinkmann-warped-product]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-brinkmann-critical-point]]'
```

# cor:pet-ch4-brinkmann-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#cor:pet-ch4-brinkmann-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-brinkmann-critical-point]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-hess-f-space-forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#cor:pet-ch4-brinkmann-constant-curvature]]'
```

# rem:pet-ch4-transnormal-functions

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-transnormal-functions
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-brinkmann-warped-product]]'
```

# def:pet-ch4-conformal-change

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-conformal-change
uses: []
```

# def:pet-ch4-warped-product-conformal-forms

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-warped-product-conformal-forms
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-conformal-change]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warped-product-general]]'
```

# prop:pet-ch4-mercator-model

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-mercator-model
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warped-product-conformal-forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-snk-constant-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-mercator-model]]'
```

# prop:pet-ch4-sphere-stereographic-conformal

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-sphere-stereographic-conformal
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warped-product-conformal-forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-mercator-model]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-sphere-stereographic-conformal]]'
```

# prop:pet-ch4-poincare-disc-model

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-poincare-disc-model
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warped-product-conformal-forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-sphere-stereographic-conformal]]'
```

# def:pet-ch4-upper-half-space-model

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-upper-half-space-model
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warped-product-general]]'
```

# thm:pet-ch4-inversion-isometry

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#thm:pet-ch4-inversion-isometry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-poincare-disc-model]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-upper-half-space-model]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-inversion-isometry]]'
```

# rem:pet-ch4-riemann-model

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-riemann-model
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-conformal-change]]'
```

# prop:pet-ch4-riemann-poincare-isometric

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-riemann-poincare-isometric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#rem:pet-ch4-riemann-model]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-poincare-disc-model]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-riemann-poincare-isometric]]'
```

# prop:pet-ch4-conformal-smoothness-criterion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-conformal-smoothness-criterion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-warped-product-conformal-forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-conformal-smoothness-criterion]]'
```

# def:pet-ch4-left-invariant-metric-lie

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-left-invariant-metric-lie
uses: []
```

# prop:pet-ch4-left-translation-isometry

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-left-translation-isometry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-left-invariant-metric-lie]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-left-translation-isometry]]'
```

# def:pet-ch4-lie-algebra-exp

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-lie-algebra-exp
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-left-invariant-metric-lie]]'
```

# prop:pet-ch4-matrix-exp-integral-curve

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-matrix-exp-integral-curve
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-lie-algebra-exp]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-matrix-exp-integral-curve]]'
```

# rem:pet-ch4-flow-right-invariant-killing

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-flow-right-invariant-killing
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-left-translation-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-lie-algebra-exp]]'
```

# def:pet-ch4-adjoint-action

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-adjoint-action
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-lie-algebra-exp]]'
```

# prop:pet-ch4-adjoint-exp-relation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-adjoint-exp-relation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-adjoint-action]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-adjoint-exp-relation]]'
```

# prop:pet-ch4-biinvariant-criterion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-biinvariant-criterion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-adjoint-action]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-left-translation-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-biinvariant-criterion]]'
```

# prop:pet-ch4-biinvariant-curvature-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-biinvariant-curvature-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-biinvariant-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-adjoint-action]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-biinvariant-curvature-formula]]'
```

# rem:pet-ch4-biinvariant-nonneg-curvature

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-biinvariant-nonneg-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-biinvariant-curvature-formula]]'
```

# ex:pet-ch4-hyperbolic-lie-group

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#ex:pet-ch4-hyperbolic-lie-group
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-left-invariant-metric-lie]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-hyperbolic-lie-group]]'
```

# prop:pet-ch4-hyperbolic-lie-group-not-biinvariant

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-hyperbolic-lie-group-not-biinvariant
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-hyperbolic-lie-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-biinvariant-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hyperbolic-lie-group-not-biinvariant]]'
```

# rem:pet-ch4-lie-group-spheres-contrast

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-lie-group-spheres-contrast
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-hyperbolic-lie-group-not-biinvariant]]'
```

# ex:pet-ch4-general-berger-metric

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#ex:pet-ch4-general-berger-metric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-biinvariant-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-general-berger-metric]]'
```

# ex:pet-ch4-berger-sphere-curvature

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#ex:pet-ch4-berger-sphere-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-general-berger-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-berger-sphere-curvature]]'
```

# rem:pet-ch4-berger-limit

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-berger-limit
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-berger-sphere-curvature]]'
```

# prop:pet-ch4-berger-adjoint-action

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-berger-adjoint-action
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-general-berger-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-biinvariant-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-berger-adjoint-action]]'
```

# def:pet-ch4-vertical-horizontal-distribution

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-vertical-horizontal-distribution
uses: []
```

# prop:pet-ch4-submersion-basic-properties

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-submersion-basic-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-vertical-horizontal-distribution]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-submersion-basic-properties]]'
```

# def:pet-ch4-integrability-tensor

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-integrability-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-submersion-basic-properties]]'
```

# ex:pet-ch4-hopf-integrability

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#ex:pet-ch4-hopf-integrability
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-integrability-tensor]]'
```

# thm:pet-ch4-oneill-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#thm:pet-ch4-oneill-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-submersion-basic-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-integrability-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-oneill-formula]]'
```

# rem:pet-ch4-fiber-homogeneous-submersions

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-fiber-homogeneous-submersions
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-vertical-horizontal-distribution]]'
```

# prop:pet-ch4-group-action-submersion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-group-action-submersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#rem:pet-ch4-fiber-homogeneous-submersions]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-group-action-submersion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-adjoint-exp-relation]]'
```

# def:pet-ch4-cpn-submersion-setup

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-cpn-submersion-setup
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-group-action-submersion]]'
```

# prop:pet-ch4-cpn-integrability-tensor

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-cpn-integrability-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-cpn-submersion-setup]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-integrability-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-cpn-integrability-tensor]]'
```

# thm:pet-ch4-cpn-sectional-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#thm:pet-ch4-cpn-sectional-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-oneill-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-cpn-integrability-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-cpn-sectional-curvature]]'
```

# rem:pet-ch4-cpn-curvature-operator-eigenbasis

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-cpn-curvature-operator-eigenbasis
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-oneill-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-cpn-sectional-curvature]]'
```

# prop:pet-ch4-cpn-einstein

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-cpn-einstein
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-cpn-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-cpn-einstein]]'
```

# def:pet-ch4-berger-cheeger-construction

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#def:pet-ch4-berger-cheeger-construction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-left-invariant-metric-lie]]'
```

# prop:pet-ch4-berger-cheeger-horizontal-lift

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#prop:pet-ch4-berger-cheeger-horizontal-lift
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-berger-cheeger-construction]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-berger-cheeger-horizontal-lift]]'
```

# rem:pet-ch4-berger-cheeger-curvature-increase

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-berger-cheeger-curvature-increase
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-berger-cheeger-horizontal-lift]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-oneill-formula]]'
```

# rem:pet-ch4-ex-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-schwarzschild-ricci-flat]]'
```

# rem:pet-ch4-ex-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-berger-sphere-curvature]]'
```

# rem:pet-ch4-ex-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-cpn-submersion-setup]]'
```

# rem:pet-ch4-ex-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-brinkmann-warped-product]]'
```

# rem:pet-ch4-ex-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-brinkmann-warped-product]]'
```

# rem:pet-ch4-ex-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-brinkmann-warped-product]]'
```

# rem:pet-ch4-ex-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-integrability-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-submersion-basic-properties]]'
```

# rem:pet-ch4-ex-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#rem:pet-ch4-ex-7]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-oneill-formula]]'
```

# rem:pet-ch4-ex-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-9
uses: []
```

# rem:pet-ch4-ex-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-rotsym-curvature-operator]]'
```

# rem:pet-ch4-ex-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-rotsym-ricci-scalar]]'
```

# rem:pet-ch4-ex-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-rotsym-curvature-operator]]'
```

# rem:pet-ch4-ex-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-sphere-stereographic-conformal]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-poincare-disc-model]]'
```

# rem:pet-ch4-ex-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-14
uses: []
```

# rem:pet-ch4-ex-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-scalar-flat-tautological-bundle]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-schwarzschild-ricci-flat]]'
```

# rem:pet-ch4-ex-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-16
uses: []
```

# rem:pet-ch4-ex-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-snk-constant-curvature]]'
```

# rem:pet-ch4-ex-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-18
uses: []
```

# rem:pet-ch4-ex-19

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-19
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#rem:pet-ch4-ex-18]]'
```

# rem:pet-ch4-ex-20

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-20
uses: []
```

# rem:pet-ch4-ex-21

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-21
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#rem:pet-ch4-ex-19]]'
```

# rem:pet-ch4-ex-22

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-22
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#def:pet-ch4-left-invariant-metric-lie]]'
```

# rem:pet-ch4-ex-23

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-23
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-general-berger-metric]]'
```

# rem:pet-ch4-ex-24

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-24
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#rem:pet-ch4-ex-23]]'
```

# rem:pet-ch4-ex-25

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-25
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-scalar-flat-tautological-bundle]]'
```

# rem:pet-ch4-ex-26

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-26
uses: []
```

# rem:pet-ch4-ex-27

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-27
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-schwarzschild-ricci-flat]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#rem:pet-ch4-ex-23]]'
```

# rem:pet-ch4-ex-28

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch04_Examples.tex#rem:pet-ch4-ex-28
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#thm:pet-ch4-doubly-warped-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#ex:pet-ch4-general-berger-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch04_Examples#prop:pet-ch4-cpn-einstein]]'
```
