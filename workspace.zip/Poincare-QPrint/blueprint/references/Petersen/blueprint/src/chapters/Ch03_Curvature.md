# chap:pet-curvature

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#chap:pet-curvature
uses: []
```

# def:pet-ch3-curvature-tensor

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-curvature-tensor
uses: []
```

# lem:pet-ch3-curvature-tensor-tensorial

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#lem:pet-ch3-curvature-tensor-tensorial
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-curvature-tensor-tensorial]]'
```

# rem:pet-ch3-ricci-identity-derivation

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ricci-identity-derivation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-curvature-tensor-tensorial]]'
```

# def:pet-ch3-curvature-04-tensor

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-curvature-04-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
```

# prop:pet-ch3-curvature-symmetries

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-curvature-symmetries
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-04-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-symmetries]]'
```

# ex:pet-ch3-euclidean-flat

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#ex:pet-ch3-euclidean-flat
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
```

# def:pet-ch3-bivector-inner-product

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-bivector-inner-product
uses: []
```

# def:pet-ch3-bivector-skew-map

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-bivector-skew-map
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-bivector-inner-product]]'
```

# lem:pet-ch3-bivector-jacobi-identity

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#lem:pet-ch3-bivector-jacobi-identity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-bivector-skew-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-bivector-jacobi-identity]]'
```

# def:pet-ch3-curvature-operator

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-curvature-operator
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-04-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-bivector-inner-product]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-bivector-skew-map]]'
```

# def:pet-ch3-directional-curvature-operator

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-directional-curvature-operator
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-symmetries]]'
```

# def:pet-ch3-sectional-curvature

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-sectional-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-directional-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-bivector-inner-product]]'
```

# prop:pet-ch3-riemann-constant-curvature-equivalence

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-riemann-constant-curvature-equivalence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-symmetries]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-bivector-jacobi-identity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-riemann-constant-curvature-equivalence]]'
```

# def:pet-ch3-constant-curvature

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-riemann-constant-curvature-equivalence]]'
```

# def:pet-ch3-ricci-curvature

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-ricci-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
```

# def:pet-ch3-einstein-manifold

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-einstein-manifold
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
```

# prop:pet-ch3-ricci-sectional-relation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-ricci-sectional-relation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-ricci-sectional-relation]]'
```

# cor:pet-ch3-ricci-determines-sec-low-dim

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#cor:pet-ch3-ricci-determines-sec-low-dim
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-ricci-sectional-relation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-einstein-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-constant-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#cor:pet-ch3-ricci-determines-sec-low-dim]]'
```

# rem:pet-ch3-constant-curvature-einstein

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-constant-curvature-einstein
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-constant-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-einstein-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-ricci-sectional-relation]]'
```

# rem:pet-ch3-einstein-not-constant-curvature-examples

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-einstein-not-constant-curvature-examples
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-einstein-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-ricci-sectional-relation]]'
```

# def:pet-ch3-scalar-curvature

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-scalar-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-operator]]'
```

# rem:pet-ch3-scalar-curvature-formulas

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-scalar-curvature-formulas
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-scalar-curvature]]'
```

# notation:pet-ch3-divergence-adjoint

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#notation:pet-ch3-divergence-adjoint
uses: []
```

# prop:pet-ch3-contracted-bianchi

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-contracted-bianchi
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-scalar-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#notation:pet-ch3-divergence-adjoint]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-symmetries]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-contracted-bianchi]]'
```

# lem:pet-ch3-schur-lemma

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#lem:pet-ch3-schur-lemma
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-einstein-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-contracted-bianchi]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-riemann-constant-curvature-equivalence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-schur-lemma]]'
```

# cor:pet-ch3-einstein-ricci-scalar-characterization

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#cor:pet-ch3-einstein-ricci-scalar-characterization
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-einstein-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-scalar-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-schur-lemma]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#cor:pet-ch3-einstein-ricci-scalar-characterization]]'
```

# prop:pet-ch3-curvature-coordinate-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-curvature-coordinate-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-coordinate-formula]]'
```

# rem:pet-ch3-ricci-scalar-index-notation

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ricci-scalar-index-notation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-scalar-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-coordinate-formula]]'
```

# rem:pet-ch3-curvature-index-conventions

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-curvature-index-conventions
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-04-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-coordinate-formula]]'
```

# def:pet-ch3-hessian-square-notation

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-hessian-square-notation
uses: []
```

# def:pet-ch3-second-fundamental-form

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-second-fundamental-form
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-second-fundamental-form]]'
```

# prop:pet-ch3-normal-hessian-relation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-normal-hessian-relation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-second-fundamental-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-hessian-square-notation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-normal-hessian-relation]]'
```

# thm:pet-ch3-radial-curvature-equation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#thm:pet-ch3-radial-curvature-equation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-hessian-square-notation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-radial-curvature-equation]]'
```

# rem:pet-ch3-tangential-normal-decomposition

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-tangential-normal-decomposition
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-radial-curvature-equation]]'
```

# thm:pet-ch3-tangential-curvature-equation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#thm:pet-ch3-tangential-curvature-equation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-second-fundamental-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-tangential-normal-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-tangential-curvature-equation]]'
```

# thm:pet-ch3-normal-curvature-equation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#thm:pet-ch3-normal-curvature-equation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-tangential-curvature-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-normal-curvature-equation]]'
```

# rem:pet-ch3-curvature-equations-by-dimension

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-curvature-equations-by-dimension
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-radial-curvature-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-tangential-curvature-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-normal-curvature-equation]]'
```

# cor:pet-ch3-gauss-egregium

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#cor:pet-ch3-gauss-egregium
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-tangential-curvature-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#ex:pet-ch3-euclidean-flat]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#cor:pet-ch3-gauss-egregium]]'
```

# def:pet-ch3-distance-function

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-distance-function
uses: []
```

# ex:pet-ch3-distance-to-points

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#ex:pet-ch3-distance-to-points
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-distance-function]]'
```

# ex:pet-ch3-distance-to-submanifold

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#ex:pet-ch3-distance-to-submanifold
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-distance-function]]'
```

# lem:pet-ch3-distance-function-submersion

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#lem:pet-ch3-distance-function-submersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-distance-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-distance-function-submersion]]'
```

# def:pet-ch3-distance-function-notation

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-distance-function-notation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-distance-function-submersion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-second-fundamental-form]]'
```

# ex:pet-ch3-zero-shape-operator-hyperplane

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#ex:pet-ch3-zero-shape-operator-hyperplane
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-distance-function-notation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#ex:pet-ch3-zero-shape-operator-hyperplane]]'
```

# rem:pet-ch3-intrinsic-extrinsic

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-intrinsic-extrinsic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#ex:pet-ch3-zero-shape-operator-hyperplane]]'
```

# cor:pet-ch3-radial-equation-distance-function

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#cor:pet-ch3-radial-equation-distance-function
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-distance-function-notation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-radial-curvature-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-normal-hessian-relation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#cor:pet-ch3-radial-equation-distance-function]]'
```

# prop:pet-ch3-distance-function-curvature-equations

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-distance-function-curvature-equations
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#cor:pet-ch3-radial-equation-distance-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-radial-curvature-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-distance-function-curvature-equations]]'
```

# def:pet-ch3-jacobi-field

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-jacobi-field
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-distance-function-notation]]'
```

# rem:pet-ch3-jacobi-field-construction

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-jacobi-field-construction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-jacobi-field]]'
```

# lem:pet-ch3-jacobi-field-equivalent-equation

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#lem:pet-ch3-jacobi-field-equivalent-equation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-jacobi-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-jacobi-field-equivalent-equation]]'
```

# prop:pet-ch3-jacobi-second-order-equation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-jacobi-second-order-equation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-jacobi-field-equivalent-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#cor:pet-ch3-radial-equation-distance-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-directional-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-jacobi-second-order-equation]]'
```

# prop:pet-ch3-jacobi-field-curvature-equations

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-jacobi-field-curvature-equations
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-jacobi-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-distance-function-curvature-equations]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-jacobi-field-curvature-equations]]'
```

# rem:pet-ch3-jacobi-field-product-neighborhood

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-jacobi-field-product-neighborhood
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-jacobi-field-curvature-equations]]'
```

# lem:pet-ch3-jacobi-field-sectional-curvature-formula

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#lem:pet-ch3-jacobi-field-sectional-curvature-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-jacobi-field-product-neighborhood]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-jacobi-field-sectional-curvature-formula]]'
```

# ex:pet-ch3-two-dim-sectional-curvature-formula

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#ex:pet-ch3-two-dim-sectional-curvature-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-jacobi-field-sectional-curvature-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#ex:pet-ch3-two-dim-sectional-curvature-formula]]'
```

# def:pet-ch3-parallel-field

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-parallel-field
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-distance-function-notation]]'
```

# prop:pet-ch3-parallel-field-curvature-equation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#prop:pet-ch3-parallel-field-curvature-equation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-parallel-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-distance-function-curvature-equations]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-jacobi-field-sectional-curvature-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-parallel-field-curvature-equation]]'
```

# def:pet-ch3-conjugate-focal-point

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#def:pet-ch3-conjugate-focal-point
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-distance-function-curvature-equations]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-parallel-field-curvature-equation]]'
```

# rem:pet-ch3-conjugate-vs-focal-example

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-conjugate-vs-focal-example
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-conjugate-focal-point]]'
```

# rem:pet-ch3-external-force-internal-reaction

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-external-force-internal-reaction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-conjugate-focal-point]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-distance-function-curvature-equations]]'
```

# rem:pet-ch3-ex-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
```

# rem:pet-ch3-ex-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-hessian-square-notation]]'
```

# rem:pet-ch3-ex-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-hessian-square-notation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-radial-curvature-equation]]'
```

# rem:pet-ch3-ex-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-tangential-curvature-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-normal-curvature-equation]]'
```

# rem:pet-ch3-ex-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-symmetries]]'
```

# rem:pet-ch3-ex-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-constant-curvature]]'
```

# rem:pet-ch3-ex-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-scalar-curvature]]'
```

# rem:pet-ch3-ex-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-contracted-bianchi]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#notation:pet-ch3-divergence-adjoint]]'
```

# rem:pet-ch3-ex-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-1]]'
```

# rem:pet-ch3-ex-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-constant-curvature]]'
```

# rem:pet-ch3-ex-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-tangential-curvature-equation]]'
```

# rem:pet-ch3-ex-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-second-fundamental-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
```

# rem:pet-ch3-ex-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-second-fundamental-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-constant-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-10]]'
```

# rem:pet-ch3-ex-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-second-fundamental-form]]'
```

# rem:pet-ch3-ex-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
```

# rem:pet-ch3-ex-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-16
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-scalar-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#notation:pet-ch3-divergence-adjoint]]'
```

# rem:pet-ch3-ex-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-sectional-curvature]]'
```

# rem:pet-ch3-ex-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-18
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-scalar-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
```

# rem:pet-ch3-ex-19

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-19
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
```

# rem:pet-ch3-ex-20

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-20
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-coordinate-formula]]'
```

# rem:pet-ch3-ex-21

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-21
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-coordinate-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-tangential-curvature-equation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#thm:pet-ch3-normal-curvature-equation]]'
```

# rem:pet-ch3-ex-22

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-22
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-21]]'
```

# rem:pet-ch3-ex-23

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-23
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-symmetries]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-constant-curvature]]'
```

# rem:pet-ch3-ex-24

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-24
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-scalar-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-23]]'
```

# rem:pet-ch3-ex-25

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-25
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-24]]'
```

# rem:pet-ch3-ex-26

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-26
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-24]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#notation:pet-ch3-divergence-adjoint]]'
```

# rem:pet-ch3-ex-27

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-27
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
```

# rem:pet-ch3-ex-28

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-28
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
```

# rem:pet-ch3-ex-29

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-29
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#lem:pet-ch3-bivector-jacobi-identity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-symmetries]]'
```

# rem:pet-ch3-ex-30

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-30
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-29]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-operator]]'
```

# rem:pet-ch3-ex-31

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-31
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
```

# rem:pet-ch3-ex-32

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-32
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-31]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-operator]]'
```

# rem:pet-ch3-ex-33

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-33
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-32]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
```

# rem:pet-ch3-ex-34

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch03_Curvature.tex#rem:pet-ch3-ex-34
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-33]]'
```
