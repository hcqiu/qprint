# rem:pet-ch4-further-study

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/formalization-support.tex#rem:pet-ch4-further-study
uses: []
```
