# chap:pet-the-bochner-technique

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#chap:pet-the-bochner-technique
uses: []
```

# def:pet-ch9-de-rham-cohomology

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-de-rham-cohomology
uses: []
```

# rem:pet-ch9-poincare-duality

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-poincare-duality
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-de-rham-cohomology]]'
```

# def:pet-ch9-codifferential

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-codifferential
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-de-rham-cohomology]]'
```

# def:pet-ch9-hodge-laplacian

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-hodge-laplacian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codifferential]]'
```

# lem:pet-ch9-harmonic-iff-closed-coclosed

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#lem:pet-ch9-harmonic-iff-closed-coclosed
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-hodge-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-harmonic-iff-closed-coclosed]]'
```

# def:pet-ch9-hodge-cohomology

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-hodge-cohomology
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-hodge-laplacian]]'
```

# thm:pet-ch9-hodge-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-hodge-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-hodge-cohomology]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-harmonic-iff-closed-coclosed]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-de-rham-cohomology]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-hodge-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#rem:pet-ch9-exercise-9-6-4]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#rem:pet-ch9-exercise-9-6-5]]'
```

# prop:pet-ch9-vector-field-1form-duality

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#prop:pet-ch9-vector-field-1form-duality
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-de-rham-cohomology]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codifferential]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-vector-field-1form-duality]]'
```

# prop:pet-ch9-bochner-formula-1forms

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#prop:pet-ch9-bochner-formula-1forms
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-vector-field-1form-duality]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-bochner-formula-1forms]]'
```

# thm:pet-ch9-bochner-vanishing-1forms

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-bochner-vanishing-1forms
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-bochner-formula-1forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-bochner-vanishing-1forms]]'
```

# cor:pet-ch9-harmonic-1forms-vanish-positive-ricci

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#cor:pet-ch9-harmonic-1forms-vanish-positive-ricci
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-bochner-vanishing-1forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-harmonic-1forms-vanish-positive-ricci]]'
```

# cor:pet-ch9-betti1-bound-flat-torus

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#cor:pet-ch9-betti1-bound-flat-torus
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-bochner-vanishing-1forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-hodge-cohomology]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-betti1-bound-flat-torus]]'
```

# lem:pet-ch9-li-dimension-estimate

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#lem:pet-ch9-li-dimension-estimate
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-li-dimension-estimate]]'
```

# thm:pet-ch9-moser-iteration

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-moser-iteration
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-moser-iteration]]'
```

# lem:pet-ch9-kato-inequality

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#lem:pet-ch9-kato-inequality
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-kato-inequality]]'
```

# thm:pet-ch9-gromov-gallot-betti1-estimate

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-gromov-gallot-betti1-estimate
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-li-dimension-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-moser-iteration]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-kato-inequality]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-hodge-cohomology]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-bochner-formula-1forms]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-gromov-gallot-betti1-estimate]]'
```

# prop:pet-ch9-vanishing-connection-laplacian

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#prop:pet-ch9-vanishing-connection-laplacian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-vanishing-connection-laplacian]]'
```

# thm:pet-ch9-gallot-connection-laplacian-estimate

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-gallot-connection-laplacian-estimate
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-li-dimension-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-moser-iteration]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-kato-inequality]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-gallot-connection-laplacian-estimate]]'
```

# def:pet-ch9-weitzenbock-curvature-operator

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-weitzenbock-curvature-operator
uses: []
```

# def:pet-ch9-lichnerowicz-laplacian

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-lichnerowicz-laplacian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-weitzenbock-curvature-operator]]'
```

# conv:pet-ch9-so-metric-convention

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#conv:pet-ch9-so-metric-convention
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-weitzenbock-curvature-operator]]'
```

# lem:pet-ch9-ric-curvature-operator-formula

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#lem:pet-ch9-ric-curvature-operator-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#conv:pet-ch9-so-metric-convention]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-weitzenbock-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-lichnerowicz-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-ric-curvature-operator-formula]]'
```

# cor:pet-ch9-ric-nonneg-curvature-operator

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#cor:pet-ch9-ric-nonneg-curvature-operator
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-ric-curvature-operator-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-ric-nonneg-curvature-operator]]'
```

# thm:pet-ch9-lichnerowicz-dimension-estimate

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-lichnerowicz-dimension-estimate
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-ric-nonneg-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-gallot-connection-laplacian-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-vanishing-connection-laplacian]]'
```

# thm:pet-ch9-weitzenbock-hodge-laplacian

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-weitzenbock-hodge-laplacian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-hodge-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-weitzenbock-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-lichnerowicz-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-weitzenbock-hodge-laplacian]]'
```

# thm:pet-ch9-curvature-tensor-lichnerowicz

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-curvature-tensor-lichnerowicz
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-lichnerowicz-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-weitzenbock-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-curvature-tensor-lichnerowicz]]'
```

# def:pet-ch9-codazzi-exterior-derivative

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-codazzi-exterior-derivative
uses: []
```

# rem:pet-ch9-ricci-codazzi-identity

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-ricci-codazzi-identity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-exterior-derivative]]'
```

# thm:pet-ch9-symmetric-tensor-lichnerowicz-identity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-symmetric-tensor-lichnerowicz-identity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-exterior-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-weitzenbock-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-symmetric-tensor-lichnerowicz-identity]]'
```

# def:pet-ch9-codazzi-harmonic-tensor

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-codazzi-harmonic-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-exterior-derivative]]'
```

# prop:pet-ch9-harmonic-iff-codazzi-constant-trace

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#prop:pet-ch9-harmonic-iff-codazzi-constant-trace
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-harmonic-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-harmonic-iff-codazzi-constant-trace]]'
```

# cor:pet-ch9-ricci-harmonic-iff-curvature-harmonic

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#cor:pet-ch9-ricci-harmonic-iff-curvature-harmonic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-harmonic-iff-codazzi-constant-trace]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#rem:pet-ch9-ricci-codazzi-identity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-curvature-tensor-lichnerowicz]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-ricci-harmonic-iff-curvature-harmonic]]'
```

# thm:pet-ch9-nonneg-curvature-operator-parallel-forms

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-nonneg-curvature-operator-parallel-forms
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-weitzenbock-hodge-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-lichnerowicz-dimension-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-ric-nonneg-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-nonneg-curvature-operator-parallel-forms]]'
```

# ex:pet-ch9-cp2-connect-sum-nonneg-curvature

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#ex:pet-ch9-cp2-connect-sum-nonneg-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-nonneg-curvature-operator-parallel-forms]]'
```

# thm:pet-ch9-tachibana-parallel-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#thm:pet-ch9-tachibana-parallel-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-curvature-tensor-lichnerowicz]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-vanishing-connection-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#conv:pet-ch9-so-metric-convention]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-tachibana-parallel-curvature]]'
```

# def:pet-ch9-tensor-lambda2-valued

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-tensor-lambda2-valued
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#conv:pet-ch9-so-metric-convention]]'
```

# lem:pet-ch9-ric-curvature-operator-hat-formula

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#lem:pet-ch9-ric-curvature-operator-hat-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-tensor-lambda2-valued]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-weitzenbock-curvature-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-ric-curvature-operator-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-ric-curvature-operator-hat-formula]]'
```

# prop:pet-ch9-1form-hat-ricci

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#prop:pet-ch9-1form-hat-ricci
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-ric-curvature-operator-hat-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-tensor-lambda2-valued]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-1form-hat-ricci]]'
```

# rem:pet-ch9-pform-hat-formula

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-pform-hat-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-tensor-lambda2-valued]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-1form-hat-ricci]]'
```

# prop:pet-ch9-02tensor-hat-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#prop:pet-ch9-02tensor-hat-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-tensor-lambda2-valued]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-02tensor-hat-formula]]'
```

# def:pet-ch9-complex-sectional-curvature

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#def:pet-ch9-complex-sectional-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-02tensor-hat-formula]]'
```

# lem:pet-ch9-complex-sectional-curvature-real-formula

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#lem:pet-ch9-complex-sectional-curvature-real-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-complex-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-complex-sectional-curvature-real-formula]]'
```

# rem:pet-ch9-complex-sectional-curvature-special-cases

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-complex-sectional-curvature-special-cases
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#lem:pet-ch9-complex-sectional-curvature-real-formula]]'
```

# prop:pet-ch9-normal-tensor-nonneg-complex-sectional

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#prop:pet-ch9-normal-tensor-nonneg-complex-sectional
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-02tensor-hat-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-complex-sectional-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-normal-tensor-nonneg-complex-sectional]]'
```

# prop:pet-ch9-general-tensor-nonneg-complex-sectional

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#prop:pet-ch9-general-tensor-nonneg-complex-sectional
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-normal-tensor-nonneg-complex-sectional]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-general-tensor-nonneg-complex-sectional]]'
```

# rem:pet-ch9-exercise-9-6-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-betti1-bound-flat-torus]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-bochner-vanishing-1forms]]'
```

# rem:pet-ch9-exercise-9-6-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-vector-field-1form-duality]]'
```

# rem:pet-ch9-exercise-9-6-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codifferential]]'
```

# rem:pet-ch9-exercise-9-6-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-lichnerowicz-laplacian]]'
```

# rem:pet-ch9-exercise-9-6-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-lichnerowicz-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#rem:pet-ch9-exercise-9-6-4]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-ric-nonneg-curvature-operator]]'
```

# rem:pet-ch9-exercise-9-6-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-bochner-vanishing-1forms]]'
```

# rem:pet-ch9-exercise-9-6-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-lichnerowicz-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-weitzenbock-hodge-laplacian]]'
```

# rem:pet-ch9-exercise-9-6-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-bochner-formula-1forms]]'
```

# rem:pet-ch9-exercise-9-6-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-vanishing-connection-laplacian]]'
```

# rem:pet-ch9-exercise-9-6-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#conv:pet-ch9-so-metric-convention]]'
```

# rem:pet-ch9-exercise-9-6-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-harmonic-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-symmetric-tensor-lichnerowicz-identity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#prop:pet-ch9-vanishing-connection-laplacian]]'
```

# rem:pet-ch9-exercise-9-6-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-exterior-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#rem:pet-ch9-exercise-9-6-11]]'
```

# rem:pet-ch9-exercise-9-6-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#cor:pet-ch9-ricci-harmonic-iff-curvature-harmonic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-symmetric-tensor-lichnerowicz-identity]]'
```

# rem:pet-ch9-exercise-9-6-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#thm:pet-ch9-hodge-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-hodge-cohomology]]'
```

# rem:pet-ch9-exercise-9-6-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#rem:pet-ch9-poincare-duality]]'
```

# rem:pet-ch9-exercise-9-6-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-16
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-exterior-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-weitzenbock-curvature-operator]]'
```

# rem:pet-ch9-exercise-9-6-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#rem:pet-ch9-exercise-9-6-16]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-harmonic-tensor]]'
```

# rem:pet-ch9-exercise-9-6-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique.tex#rem:pet-ch9-exercise-9-6-18
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#rem:pet-ch9-exercise-9-6-17]]'
- '[[references/Petersen/blueprint/src/chapters/Ch09_TheBochnerTechnique#def:pet-ch9-codazzi-harmonic-tensor]]'
```
