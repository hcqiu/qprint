# chap:pet-convergence

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#chap:pet-convergence
uses: []
```

# def:pet-ch11-hausdorff-distance

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-hausdorff-distance
uses: []
```

# conv:pet-ch11-compact-proper-spaces

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#conv:pet-ch11-compact-proper-spaces
uses: []
```

# def:pet-ch11-gromov-hausdorff-distance

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-gromov-hausdorff-distance
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-hausdorff-distance]]'
```

# ex:pet-ch11-gh-distance-radius

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-gh-distance-radius
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
```

# ex:pet-ch11-gh-distance-diameter-bound

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-gh-distance-diameter-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
```

# prop:pet-ch11-gh-distance-zero-isometric

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#prop:pet-ch11-gh-distance-zero-isometric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-gh-distance-zero-isometric]]'
```

# rem:pet-ch11-gh-pseudo-metric-quotient

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-gh-pseudo-metric-quotient
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-gh-distance-zero-isometric]]'
```

# ex:pet-ch11-epsilon-dense-approximation

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-epsilon-dense-approximation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-hausdorff-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#ex:pet-ch11-epsilon-dense-approximation]]'
```

# ex:pet-ch11-finite-approximation-3eps

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-finite-approximation-3eps
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#ex:pet-ch11-epsilon-dense-approximation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#ex:pet-ch11-finite-approximation-3eps]]'
```

# ex:pet-ch11-lens-spaces-limit

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-lens-spaces-limit
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#ex:pet-ch11-finite-approximation-3eps]]'
```

# ex:pet-ch11-berger-spheres-limit

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-berger-spheres-limit
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#ex:pet-ch11-lens-spaces-limit]]'
```

# prop:pet-ch11-gh-space-separable-complete

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#prop:pet-ch11-gh-space-separable-complete
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#rem:pet-ch11-gh-pseudo-metric-quotient]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-gh-space-separable-complete]]'
```

# def:pet-ch11-pointed-gh-distance

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-pointed-gh-distance
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-hausdorff-distance]]'
```

# def:pet-ch11-pointed-gh-topology

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-pointed-gh-topology
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-pointed-gh-distance]]'
```

# def:pet-ch11-convergence-of-maps

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-convergence-of-maps
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-pointed-gh-topology]]'
```

# rem:pet-ch11-map-convergence-as-extension

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-map-convergence-as-extension
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-convergence-of-maps]]'
```

# def:pet-ch11-equicontinuous-family

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-equicontinuous-family
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-convergence-of-maps]]'
```

# lem:pet-ch11-arzela-ascoli-gh

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-arzela-ascoli-gh
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-equicontinuous-family]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-arzela-ascoli-gh]]'
```

# def:pet-ch11-capacity-covering-functions

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-capacity-covering-functions
uses: []
```

# lem:pet-ch11-cov-le-cap

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-cov-le-cap
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-capacity-covering-functions]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-cov-le-cap]]'
```

# lem:pet-ch11-gh-close-cov-cap-comparison

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-gh-close-cov-cap-comparison
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-capacity-covering-functions]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-gh-close-cov-cap-comparison]]'
```

# prop:pet-ch11-gromov-precompactness-criterion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#prop:pet-ch11-gromov-precompactness-criterion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-cov-le-cap]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-gh-close-cov-cap-comparison]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-gromov-precompactness-criterion]]'
```

# cor:pet-ch11-pointed-precompactness-criterion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-pointed-precompactness-criterion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-gromov-precompactness-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-pointed-gh-topology]]'
```

# def:pet-ch11-metric-doubling-condition

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-metric-doubling-condition
uses: []
```

# prop:pet-ch11-doubling-implies-precompact

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#prop:pet-ch11-doubling-implies-precompact
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-metric-doubling-condition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-gromov-precompactness-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-doubling-implies-precompact]]'
```

# cor:pet-ch11-ricci-diam-precompactness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-ricci-diam-precompactness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-doubling-implies-precompact]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-pointed-precompactness-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-ricci-diam-precompactness]]'
```

# def:pet-ch11-cm-norm

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-cm-norm
uses: []
```

# def:pet-ch11-holder-pseudonorm

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-holder-pseudonorm
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cm-norm]]'
```

# def:pet-ch11-holder-space

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-holder-space
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cm-norm]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-holder-pseudonorm]]'
```

# lem:pet-ch11-holder-space-banach-compact-inclusion

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-holder-space-banach-compact-inclusion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-holder-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-holder-space-banach-compact-inclusion]]'
```

# def:pet-ch11-elliptic-operator

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-elliptic-operator
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-holder-pseudonorm]]'
```

# thm:pet-ch11-schauder-estimates

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-schauder-estimates
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-elliptic-operator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-holder-space]]'
```

# rem:pet-ch11-divergence-form-laplace-beltrami

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-divergence-form-laplace-beltrami
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-elliptic-operator]]'
```

# cor:pet-ch11-higher-schauder-estimates

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-higher-schauder-estimates
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-schauder-estimates]]'
```

# thm:pet-ch11-dirichlet-problem-unique-solution

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-dirichlet-problem-unique-solution
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-schauder-estimates]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-dirichlet-problem-unique-solution]]'
```

# lem:pet-ch11-harmonic-coordinates-exist

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-harmonic-coordinates-exist
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-schauder-estimates]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#rem:pet-ch11-divergence-form-laplace-beltrami]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-harmonic-coordinates-exist]]'
```

# lem:pet-ch11-laplacian-ricci-harmonic-coords

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-laplacian-ricci-harmonic-coords
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-harmonic-coordinates-exist]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-laplacian-ricci-harmonic-coords]]'
```

# rem:pet-ch11-einstein-harmonic-regularity-bootstrap

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-einstein-harmonic-regularity-bootstrap
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-laplacian-ricci-harmonic-coords]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-higher-schauder-estimates]]'
```

# def:pet-ch11-cmalpha-norm-pointed

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-cmalpha-norm-pointed
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-holder-space]]'
```

# def:pet-ch11-cmalpha-norm-global

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-cmalpha-norm-global
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-pointed]]'
```

# ex:pet-ch11-flat-manifold-norm-zero

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-flat-manifold-norm-zero
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-global]]'
```

# def:pet-ch11-tensor-convergence-compact-subset

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-tensor-convergence-compact-subset
uses: []
```

# def:pet-ch11-pointed-cmalpha-convergence

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-pointed-cmalpha-convergence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-tensor-convergence-compact-subset]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-pointed]]'
```

# rem:pet-ch11-cmalpha-convergence-implies-gh

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-cmalpha-convergence-implies-gh
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-pointed-cmalpha-convergence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-pointed-gh-topology]]'
```

# rem:pet-ch11-cmalpha-convergence-pullback-warning

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-cmalpha-convergence-pullback-warning
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-pointed-cmalpha-convergence]]'
```

# prop:pet-ch11-norm-properties

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#prop:pet-ch11-norm-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-pointed]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-global]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-pointed-cmalpha-convergence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-norm-properties]]'
```

# cor:pet-ch11-norm-bound-ball-containment

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-norm-bound-ball-containment
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-norm-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-norm-bound-ball-containment]]'
```

# cor:pet-ch11-norm-zero-implies-flat

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-norm-zero-implies-flat
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-norm-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-norm-bound-ball-containment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-norm-zero-implies-flat]]'
```

# def:pet-ch11-harmonic-norm

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-harmonic-norm
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-pointed]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-harmonic-coordinates-exist]]'
```

# prop:pet-ch11-harmonic-norm-properties

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#prop:pet-ch11-harmonic-norm-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-harmonic-norm]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-norm-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-harmonic-coordinates-exist]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-harmonic-norm-properties]]'
```

# lem:pet-ch11-fundamental-thm-precompact-gh

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-fundamental-thm-precompact-gh
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-pointed]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-ricci-diam-precompactness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-fundamental-thm-precompact-gh]]'
```

# lem:pet-ch11-fundamental-thm-limit-is-manifold

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-fundamental-thm-limit-is-manifold
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-fundamental-thm-precompact-gh]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-norm-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-fundamental-thm-limit-is-manifold]]'
```

# thm:pet-ch11-fundamental-theorem-convergence

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-fundamental-theorem-convergence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-fundamental-thm-precompact-gh]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-fundamental-thm-limit-is-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
```

# cor:pet-ch11-fundamental-thm-diam-vol-bounded

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-fundamental-thm-diam-vol-bounded
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-fundamental-thm-diam-vol-bounded]]'
```

# cor:pet-ch11-harmonic-norm-class-compact

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-harmonic-norm-class-compact
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-harmonic-norm-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-harmonic-norm-class-compact]]'
```

# rem:pet-ch11-alternative-norm-conditions

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-alternative-norm-conditions
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-pointed]]'
```

# rem:pet-ch11-c0-norm-precompactness-only

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-c0-norm-precompactness-only
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-global]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-fundamental-thm-diam-vol-bounded]]'
```

# def:pet-ch11-reifenberg-norm

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-reifenberg-norm
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
```

# rem:pet-ch11-reifenberg-norm-properties

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-reifenberg-norm-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-reifenberg-norm]]'
```

# def:pet-ch11-holder-distance

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#def:pet-ch11-holder-distance
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-holder-pseudonorm]]'
```

# rem:pet-ch11-cheeger-colding-holder-convergence

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-cheeger-colding-holder-convergence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-holder-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#rem:pet-ch11-reifenberg-norm-properties]]'
```

# lem:pet-ch11-anderson-ricci-harmonic-c1alpha-bound

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-anderson-ricci-harmonic-c1alpha-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-harmonic-norm]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-laplacian-ricci-harmonic-coords]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-schauder-estimates]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-anderson-ricci-harmonic-c1alpha-bound]]'
```

# cor:pet-ch11-ricci-bounded-precompact-c1alpha

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-ricci-bounded-precompact-c1alpha
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-anderson-ricci-harmonic-c1alpha-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
```

# thm:pet-ch11-anderson-injectivity-radius-controls-norm

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-anderson-injectivity-radius-controls-norm
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-anderson-ricci-harmonic-c1alpha-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#rem:pet-ch11-einstein-harmonic-regularity-bootstrap]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-anderson-injectivity-radius-controls-norm]]'
```

# cor:pet-ch11-anderson-diffeo-finiteness-injectivity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-anderson-diffeo-finiteness-injectivity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-anderson-injectivity-radius-controls-norm]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-fundamental-thm-diam-vol-bounded]]'
```

# lem:pet-ch11-anderson-volume-pinching-euclidean

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-anderson-volume-pinching-euclidean
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-norm-zero-implies-flat]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-anderson-volume-pinching-euclidean]]'
```

# cor:pet-ch11-volume-pinching-precompactness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-volume-pinching-precompactness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-anderson-volume-pinching-euclidean]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-volume-pinching-precompactness]]'
```

# thm:pet-ch11-convergence-theorem-riemannian-geometry

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-convergence-theorem-riemannian-geometry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-anderson-injectivity-radius-controls-norm]]'
```

# cor:pet-ch11-cheeger-even-dim-finiteness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-cheeger-even-dim-finiteness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-convergence-theorem-riemannian-geometry]]'
```

# lem:pet-ch11-cheeger-injectivity-radius-lemma

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#lem:pet-ch11-cheeger-injectivity-radius-lemma
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-norm-zero-implies-flat]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-cheeger-injectivity-radius-lemma]]'
```

# cor:pet-ch11-cheeger-diam-vol-finiteness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-cheeger-diam-vol-finiteness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-cheeger-injectivity-radius-lemma]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-convergence-theorem-riemannian-geometry]]'
```

# thm:pet-ch11-lower-sec-bound-injectivity-norm-control

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-lower-sec-bound-injectivity-norm-control
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-pointed]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-lower-sec-bound-injectivity-norm-control]]'
```

# ex:pet-ch11-optimality-lower-curvature-example

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-optimality-lower-curvature-example
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-lower-sec-bound-injectivity-norm-control]]'
```

# ex:pet-ch11-c11-limit-example

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#ex:pet-ch11-c11-limit-example
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#ex:pet-ch11-optimality-lower-curvature-example]]'
```

# rem:pet-ch11-exercise-11-4-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-4-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#ex:pet-ch11-optimality-lower-curvature-example]]'
```

# thm:pet-ch11-anderson-cheeger-ricci-lower-bound-norm

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-anderson-cheeger-ricci-lower-bound-norm
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-harmonic-norm]]'
```

# thm:pet-ch11-ricci-pinching-einstein-closeness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-ricci-pinching-einstein-closeness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-anderson-diffeo-finiteness-injectivity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#rem:pet-ch11-einstein-harmonic-regularity-bootstrap]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-ricci-pinching-einstein-closeness]]'
```

# rem:pet-ch11-ricci-pinching-volume-alternative

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-ricci-pinching-volume-alternative
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-ricci-pinching-einstein-closeness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-volume-pinching-precompactness]]'
```

# thm:pet-ch11-sec-pinching-constant-curvature-closeness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#thm:pet-ch11-sec-pinching-constant-curvature-closeness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-ricci-pinching-einstein-closeness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-cheeger-injectivity-radius-lemma]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-sec-pinching-constant-curvature-closeness]]'
```

# cor:pet-ch11-even-dim-positive-pinching

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-even-dim-positive-pinching
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-sec-pinching-constant-curvature-closeness]]'
```

# cor:pet-ch11-odd-dim-simply-connected-pinching

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#cor:pet-ch11-odd-dim-simply-connected-pinching
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-even-dim-positive-pinching]]'
```

# rem:pet-ch11-exercise-11-6-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-hausdorff-distance]]'
```

# rem:pet-ch11-exercise-11-6-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
```

# rem:pet-ch11-exercise-11-6-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#prop:pet-ch11-gromov-precompactness-criterion]]'
```

# rem:pet-ch11-exercise-11-6-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-ricci-diam-precompactness]]'
```

# rem:pet-ch11-exercise-11-6-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-laplacian-ricci-harmonic-coords]]'
```

# rem:pet-ch11-exercise-11-6-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-schauder-estimates]]'
```

# rem:pet-ch11-exercise-11-6-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-tensor-convergence-compact-subset]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#cor:pet-ch11-anderson-diffeo-finiteness-injectivity]]'
```

# rem:pet-ch11-exercise-11-6-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
```

# rem:pet-ch11-exercise-11-6-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-global]]'
```

# rem:pet-ch11-exercise-11-6-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-cmalpha-norm-global]]'
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
```

# rem:pet-ch11-exercise-11-6-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-gromov-hausdorff-distance]]'
```

# rem:pet-ch11-exercise-11-6-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#thm:pet-ch11-fundamental-theorem-convergence]]'
```

# rem:pet-ch11-exercise-11-6-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#lem:pet-ch11-cheeger-injectivity-radius-lemma]]'
```

# rem:pet-ch11-exercise-11-6-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#rem:pet-ch11-exercise-11-6-13]]'
```

# rem:pet-ch11-exercise-11-6-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch11_Convergence.tex#rem:pet-ch11-exercise-11-6-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch11_Convergence#def:pet-ch11-harmonic-norm]]'
```
