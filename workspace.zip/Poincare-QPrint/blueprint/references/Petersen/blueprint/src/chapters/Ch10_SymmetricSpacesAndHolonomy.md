# chap:pet-symmetric-spaces-and-holonomy

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#chap:pet-symmetric-spaces-and-holonomy
uses: []
```

# def:pet-ch10-symmetric-space

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-symmetric-space
uses: []
```

# prop:pet-ch10-symmetric-homogeneous

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#prop:pet-ch10-symmetric-homogeneous
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-symmetric-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#prop:pet-ch10-symmetric-homogeneous]]'
```

# rem:pet-ch10-single-point-symmetry

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-single-point-symmetry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-symmetric-space]]'
```

# def:pet-ch10-symmetric-space-tables

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-symmetric-space-tables
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-single-point-symmetry]]'
```

# def:pet-ch10-rank

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-rank
uses: []
```

# def:pet-ch10-locally-symmetric-space

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-locally-symmetric-space
uses: []
```

# thm:pet-ch10-cartan-local-symmetry

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-cartan-local-symmetry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-locally-symmetric-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-symmetric-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-cartan-local-symmetry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-cartan-isometry-extension]]'
```

# rem:pet-ch10-non-locally-symmetric-examples

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-non-locally-symmetric-examples
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-locally-symmetric-space]]'
```

# thm:pet-ch10-cartan-isometry-extension

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-cartan-isometry-extension
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-symmetric-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-locally-symmetric-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-cartan-isometry-extension]]'
```

# prop:pet-ch10-sigma-p-involution

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#prop:pet-ch10-sigma-p-involution
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#prop:pet-ch10-sigma-p-involution]]'
```

# def:pet-ch10-tp-decomposition

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-tp-decomposition
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#prop:pet-ch10-sigma-p-involution]]'
```

# prop:pet-ch10-lie-bracket-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#prop:pet-ch10-lie-bracket-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#prop:pet-ch10-lie-bracket-curvature]]'
```

# def:pet-ch10-killing-form

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-killing-form
uses: []
```

# rem:pet-ch10-adjoint-skew-symmetric

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-adjoint-skew-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#prop:pet-ch10-lie-bracket-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-killing-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-adjoint-skew-symmetric]]'
```

# thm:pet-ch10-curvature-bracket-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-curvature-bracket-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#prop:pet-ch10-lie-bracket-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-killing-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-curvature-bracket-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-adjoint-skew-symmetric]]'
```

# def:pet-ch10-abstract-symmetric-bracket

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-abstract-symmetric-bracket
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-curvature-bracket-formula]]'
```

# cor:pet-ch10-so-membership-criterion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#cor:pet-ch10-so-membership-criterion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-so-membership-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-cartan-isometry-extension]]'
```

# cor:pet-ch10-maximal-subalgebra

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#cor:pet-ch10-maximal-subalgebra
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-abstract-symmetric-bracket]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-so-membership-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-maximal-subalgebra]]'
```

# rem:pet-ch10-symmetric-space-from-involution

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-symmetric-space-from-involution
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-maximal-subalgebra]]'
```

# ex:pet-ch10-compact-grassmannian

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#ex:pet-ch10-compact-grassmannian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-killing-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-curvature-bracket-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-maximal-subalgebra]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-compact-grassmannian]]'
```

# ex:pet-ch10-hyperbolic-grassmannian

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#ex:pet-ch10-hyperbolic-grassmannian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-compact-grassmannian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-hyperbolic-grassmannian]]'
```

# ex:pet-ch10-complex-projective-space

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#ex:pet-ch10-complex-projective-space
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-curvature-bracket-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-complex-projective-space]]'
```

# ex:pet-ch10-sl-so-quotient

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#ex:pet-ch10-sl-so-quotient
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-curvature-bracket-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-sl-so-quotient]]'
```

# ex:pet-ch10-lie-group-symmetric

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#ex:pet-ch10-lie-group-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-symmetric-space-from-involution]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-killing-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-curvature-bracket-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-lie-group-symmetric]]'
```

# def:pet-ch10-holonomy-group

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-holonomy-group
uses: []
```

# rem:pet-ch10-holonomy-properties

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-holonomy-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-holonomy-group]]'
```

# thm:pet-ch10-de-rham-decomposition

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-de-rham-decomposition
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-holonomy-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-de-rham-decomposition]]'
```

# thm:pet-ch10-parallel-tensor-eigenvalue

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-parallel-tensor-eigenvalue
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-de-rham-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-parallel-tensor-eigenvalue]]'
```

# cor:pet-ch10-irreducible-symmetric-einstein

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#cor:pet-ch10-irreducible-symmetric-einstein
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-parallel-tensor-eigenvalue]]'
```

# rem:pet-ch10-compact-flat-noncompact-type

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-compact-flat-noncompact-type
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-irreducible-symmetric-einstein]]'
```

# def:pet-ch10-symmetric-space-type-I-IV

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-symmetric-space-type-I-IV
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-compact-flat-noncompact-type]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-symmetric-space-from-involution]]'
```

# def:pet-ch10-berger-holonomy-table

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#def:pet-ch10-berger-holonomy-table
uses: []
```

# thm:pet-ch10-berger-simons-classification

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-berger-simons-classification
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-berger-holonomy-table]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-rank]]'
```

# cor:pet-ch10-nontransitive-holonomy

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#cor:pet-ch10-nontransitive-holonomy
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-berger-simons-classification]]'
```

# thm:pet-ch10-rank-rigidity-nonpositive

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-rank-rigidity-nonpositive
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-nontransitive-holonomy]]'
```

# thm:pet-ch10-gallot-meyer

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-gallot-meyer
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-berger-simons-classification]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-parallel-tensor-eigenvalue]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-de-rham-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-gallot-meyer]]'
```

# thm:pet-ch10-brendle-schoen

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#thm:pet-ch10-brendle-schoen
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-gallot-meyer]]'
```

# rem:pet-ch10-exercise-symmetric-flow-axis

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-symmetric-flow-axis
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
```

# rem:pet-ch10-exercise-pi1-abelian

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-pi1-abelian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-exercise-symmetric-flow-axis]]'
```

# rem:pet-ch10-exercise-jacobi-fields-eigenvector

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-jacobi-fields-eigenvector
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
```

# rem:pet-ch10-exercise-compact-nonneg-curvature

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-compact-nonneg-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-exercise-jacobi-fields-eigenvector]]'
```

# rem:pet-ch10-exercise-jacobi-field-equivalence

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-jacobi-field-equivalence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-holonomy-group]]'
```

# rem:pet-ch10-exercise-killing-form-classical

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-killing-form-classical
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-killing-form]]'
```

# rem:pet-ch10-exercise-gl-so-symmetric

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-gl-so-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-symmetric-space-from-involution]]'
```

# rem:pet-ch10-exercise-u-pq-so-pq-symmetric

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-u-pq-so-pq-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-symmetric-space-from-involution]]'
```

# rem:pet-ch10-exercise-cpn-holonomy

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-cpn-holonomy
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-complex-projective-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-holonomy-group]]'
```

# rem:pet-ch10-exercise-covering-symmetric

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-covering-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#prop:pet-ch10-sigma-p-involution]]'
```

# rem:pet-ch10-exercise-flat-discrete-holonomy

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-flat-discrete-holonomy
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-holonomy-group]]'
```

# rem:pet-ch10-exercise-finite-fundamental-group

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-finite-fundamental-group
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-holonomy-group]]'
```

# rem:pet-ch10-exercise-sl2-quotients

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-sl2-quotients
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-sl-so-quotient]]'
```

# rem:pet-ch10-exercise-kahler-unitary-holonomy

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-kahler-unitary-holonomy
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-holonomy-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-berger-holonomy-table]]'
```

# rem:pet-ch10-exercise-isop-so-constant-curvature

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-isop-so-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
```

# rem:pet-ch10-exercise-maximal-subalgebras-son

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-maximal-subalgebras-son
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-compact-grassmannian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-complex-projective-space]]'
```

# rem:pet-ch10-exercise-sum-in-so

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-sum-in-so
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-killing-form]]'
```

# rem:pet-ch10-exercise-tp-subset-holp

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-tp-subset-holp
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-tp-decomposition]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#def:pet-ch10-holonomy-group]]'
```

# rem:pet-ch10-exercise-tp-equals-holp-symmetric

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-tp-equals-holp-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-exercise-tp-subset-holp]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-maximal-subalgebra]]'
```

# rem:pet-ch10-exercise-son-c-sln-c-symmetric

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-son-c-sln-c-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-lie-group-symmetric]]'
```

# rem:pet-ch10-exercise-quaternionic-projective-space

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-quaternionic-projective-space
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-complex-projective-space]]'
```

# rem:pet-ch10-exercise-hyperbolic-complex-projective

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-hyperbolic-complex-projective
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-complex-projective-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#ex:pet-ch10-hyperbolic-grassmannian]]'
```

# rem:pet-ch10-exercise-lie-algebra-locally-symmetric

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-lie-algebra-locally-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-symmetric-space-from-involution]]'
```

# rem:pet-ch10-exercise-pinched-curvature-operator-constant

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-pinched-curvature-operator-constant
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#cor:pet-ch10-irreducible-symmetric-einstein]]'
```

# rem:pet-ch10-exercise-bracket-tp-isop

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-bracket-tp-isop
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#prop:pet-ch10-lie-bracket-curvature]]'
```

# rem:pet-ch10-exercise-curvature-ricci-bracket-formula

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-curvature-ricci-bracket-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#thm:pet-ch10-curvature-bracket-formula]]'
```

# rem:pet-ch10-exercise-parallel-form-holonomy-invariant

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy.tex#rem:pet-ch10-exercise-parallel-form-holonomy-invariant
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch10_SymmetricSpacesAndHolonomy#rem:pet-ch10-holonomy-properties]]'
```
