# chap:pet-geodesics-and-distance

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#chap:pet-geodesics-and-distance
uses: []
```

# lem:pet-ch5-mixed-partials-uniqueness

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-mixed-partials-uniqueness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-mixed-partials-uniqueness]]'
```

# thm:pet-ch5-mixed-partials-existence

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-mixed-partials-existence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-mixed-partials-uniqueness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-mixed-partials-existence]]'
```

# prop:pet-ch5-mixed-partials-submanifold

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-mixed-partials-submanifold
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-mixed-partials-existence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-mixed-partials-uniqueness]]'
```

# def:pet-ch5-acceleration

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-acceleration
uses: []
```

# def:pet-ch5-geodesic

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-geodesic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-acceleration]]'
```

# rem:pet-ch5-distance-function-geodesics

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-distance-function-geodesics
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-segments]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-energy-minima-geodesics]]'
```

# thm:pet-ch5-local-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-local-uniqueness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-local-uniqueness]]'
```

# thm:pet-ch5-local-existence

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-local-existence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-local-uniqueness]]'
```

# lem:pet-ch5-global-uniqueness

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-global-uniqueness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-local-uniqueness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-global-uniqueness]]'
```

# lem:pet-ch5-uniform-time-existence

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-uniform-time-existence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-local-existence]]'
```

# prop:pet-ch5-leaves-compact-set

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-leaves-compact-set
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-uniform-time-existence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-global-uniqueness]]'
```

# cor:pet-ch5-compact-manifold-complete

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-compact-manifold-complete
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-leaves-compact-set]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-global-uniqueness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-local-existence]]'
```

# def:pet-ch5-geodesically-complete

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-geodesically-complete
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
```

# lem:pet-ch5-uniform-neighborhood

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-uniform-neighborhood
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-local-existence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-global-uniqueness]]'
```

# ex:pet-ch5-punctured-plane-geodesic

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-punctured-plane-geodesic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# ex:pet-ch5-region-geodesic-jump

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-region-geodesic-jump
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-uniform-neighborhood]]'
```

# ex:pet-ch5-sphere-great-circles

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-sphere-great-circles
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-mixed-partials-submanifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#ex:pet-ch5-sphere-great-circles]]'
```

# ex:pet-ch5-hyperbolic-hyperbolas

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-hyperbolic-hyperbolas
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-mixed-partials-submanifold]]'
```

# ex:pet-ch5-lie-group-geodesics

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-lie-group-geodesics
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
```

# def:pet-ch5-piecewise-smooth-curve

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-piecewise-smooth-curve
uses: []
```

# def:pet-ch5-curve-length

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-curve-length
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-piecewise-smooth-curve]]'
```

# prop:pet-ch5-arclength-reparametrization

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-arclength-reparametrization
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-curve-length]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-arclength-reparametrization]]'
```

# def:pet-ch5-distance

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-distance
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-curve-length]]'
```

# def:pet-ch5-metric-balls

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-metric-balls
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
```

# ex:pet-ch5-infimum-not-realized

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-infimum-not-realized
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
```

# def:pet-ch5-segment

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-segment
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-curve-length]]'
```

# lem:pet-ch5-distance-function-length-bound

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-distance-function-length-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-curve-length]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-distance-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-length-bound]]'
```

# lem:pet-ch5-distance-function-segments

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-distance-function-segments
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-length-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-segments]]'
```

# rem:pet-ch5-distance-function-rigidity

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-distance-function-rigidity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-length-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-segments]]'
```

# rem:pet-ch5-minimizer-is-reparametrized-integral-curve

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-minimizer-is-reparametrized-integral-curve
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-distance-function-rigidity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-segments]]'
```

# ex:pet-ch5-euclidean-segments

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-euclidean-segments
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-segments]]'
```

# ex:pet-ch5-circle-segment

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-circle-segment
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-segments]]'
```

# ex:pet-ch5-sphere-segments

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-sphere-segments
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-segments]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#ex:pet-ch5-sphere-segments]]'
```

# ex:pet-ch5-hyperbolic-segments

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-hyperbolic-segments
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#ex:pet-ch5-sphere-segments]]'
```

# ex:pet-ch5-punctured-plane-no-segment

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-punctured-plane-no-segment
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
```

# thm:pet-ch5-metric-topology

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-metric-topology
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-metric-topology]]'
```

# cor:pet-ch5-compact-complete-metric

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-compact-complete-metric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-metric-topology]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-compact-complete-metric]]'
```

# cor:pet-ch5-regular-curve-approx

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-regular-curve-approx
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-metric-topology]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-arclength-reparametrization]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-regular-curve-approx]]'
```

# lem:pet-ch5-constant-speed-distance

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-constant-speed-distance
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-regular-curve-approx]]'
```

# rem:pet-ch5-absolutely-continuous-curves

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-absolutely-continuous-curves
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-constant-speed-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-ex-29]]'
```

# def:pet-ch5-functional-distance

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-functional-distance
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
```

# def:pet-ch5-energy-functional

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-energy-functional
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-curve-length]]'
```

# prop:pet-ch5-energy-length-minimizers

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-energy-length-minimizers
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-energy-functional]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-regular-curve-approx]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-energy-length-minimizers]]'
```

# def:pet-ch5-variation

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-variation
uses: []
```

# lem:pet-ch5-first-variation-formula

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-first-variation-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-variation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-energy-functional]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-first-variation-formula]]'
```

# thm:pet-ch5-energy-minima-geodesics

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-energy-minima-geodesics
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-energy-functional]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-first-variation-formula]]'
```

# cor:pet-ch5-segments-are-geodesics

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-segments-are-geodesics
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-energy-minima-geodesics]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-energy-length-minimizers]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
```

# rem:pet-ch5-sphere-not-locally-minimizing

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-sphere-not-locally-minimizing
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-energy-minima-geodesics]]'
```

# def:pet-ch5-exponential-map

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-exponential-map
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
```

# prop:pet-ch5-exp-diffeomorphism-properties

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-exp-diffeomorphism-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-exp-diffeomorphism-properties]]'
```

# lem:pet-ch5-exp-differential-nonsingular

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-exp-differential-nonsingular
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
```

# def:pet-ch5-injectivity-radius

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-injectivity-radius
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-exp-diffeomorphism-properties]]'
```

# lem:pet-ch5-injectivity-radius-positive

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-injectivity-radius-positive
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-injectivity-radius]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-exp-differential-nonsingular]]'
```

# rem:pet-ch5-riemannian-normal-coordinates

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-riemannian-normal-coordinates
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-injectivity-radius]]'
```

# cor:pet-ch5-uniform-injectivity-radius-compact

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-uniform-injectivity-radius-compact
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-exp-diffeomorphism-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-uniform-injectivity-radius-compact]]'
```

# rem:pet-ch5-injectivity-radius-chart-artifact

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-injectivity-radius-chart-artifact
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-injectivity-radius]]'
```

# def:pet-ch5-normal-exponential-map

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-normal-exponential-map
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
```

# cor:pet-ch5-tubular-neighborhood

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-tubular-neighborhood
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-normal-exponential-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-exp-diffeomorphism-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-tubular-neighborhood]]'
```

# thm:pet-ch5-short-geodesics-segments

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-short-geodesics-segments
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-short-geodesics-segments-normal]]'
```

# lem:pet-ch5-radial-geodesic-segment

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-radial-geodesic-segment
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-gauss-lemma]]'
```

# lem:pet-ch5-radial-geodesic-unique

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-radial-geodesic-unique
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-radial-geodesic-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-gauss-lemma]]'
```

# lem:pet-ch5-radial-geodesic-unique-piecewise

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-radial-geodesic-unique-piecewise
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-radial-geodesic-unique]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-piecewise-smooth-curve]]'
```

# lem:pet-ch5-short-geodesics-segments-normal

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-short-geodesics-segments-normal
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-radial-geodesic-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-radial-geodesic-unique-piecewise]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-metric-ball-image]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
```

# def:pet-ch5-radial-distance-function

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-radial-distance-function
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-short-geodesics-segments]]'
```

# lem:pet-ch5-gauss-lemma

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-gauss-lemma
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-radial-distance-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-gauss-lemma]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-short-geodesics-segments]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-distance-function-segments]]'
```

# cor:pet-ch5-metric-ball-image

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-metric-ball-image
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-radial-geodesic-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-metric-balls]]'
```

# rem:pet-ch5-radial-isometry

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-radial-isometry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-gauss-lemma]]'
```

# lem:pet-ch5-normal-coords-jet

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-normal-coords-jet
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-radial-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-exp-differential-nonsingular]]'
```

# lem:pet-ch5-normal-coords-first-order

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-normal-coords-first-order
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-radial-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-normal-coords-jet]]'
```

# rem:pet-ch5-hessian-r-asymptotics

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-hessian-r-asymptotics
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-normal-coords-first-order]]'
```

# thm:pet-ch5-riemann-constant-curvature-local

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-riemann-constant-curvature-local
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-hessian-r-asymptotics]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-riemann-constant-curvature-local]]'
```

# rem:pet-ch5-uniqueness-remark-5-5-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-uniqueness-remark-5-5-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-riemann-constant-curvature-local]]'
```

# def:pet-ch5-local-isometry

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-local-isometry
uses: []
```

# prop:pet-ch5-local-isometry-properties

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-local-isometry-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-local-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-global-uniqueness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-local-isometry-properties]]'
```

# rem:pet-ch5-exp-naturality-intrinsic

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-exp-naturality-intrinsic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-local-isometry-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-injectivity-radius-chart-artifact]]'
```

# prop:pet-ch5-isometry-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-isometry-uniqueness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-local-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-local-isometry-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-uniform-injectivity-radius-compact]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-isometry-uniqueness]]'
```

# prop:pet-ch5-covering-completeness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-covering-completeness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-local-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# lem:pet-ch5-local-isometry-covering

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-local-isometry-covering
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-local-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-uniform-injectivity-radius-compact]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-local-isometry-covering]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-local-isometry-properties]]'
```

# def:pet-ch5-fixed-point-set

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-fixed-point-set
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
```

# def:pet-ch5-fixed-tangent-subspace

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-fixed-tangent-subspace
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-fixed-point-set]]'
```

# prop:pet-ch5-fixed-point-component-totally-geodesic

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-fixed-point-component-totally-geodesic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-fixed-point-set]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-fixed-tangent-subspace]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-short-geodesics-segments-normal]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-local-isometry-properties]]'
```

# prop:pet-ch5-fixed-point-totally-geodesic

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-fixed-point-totally-geodesic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-fixed-point-set]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-fixed-tangent-subspace]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-fixed-point-component-totally-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-metric-ball-image]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-fixed-point-totally-geodesic]]'
```

# rem:pet-ch5-fixed-point-codimension

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-fixed-point-codimension
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-fixed-point-totally-geodesic]]'
```

# thm:pet-ch5-monodromy-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-monodromy-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-riemann-constant-curvature-local]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-isometry-uniqueness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-monodromy-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-local-isometry-covering]]'
```

# ex:pet-ch5-immersion-monodromy

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-immersion-monodromy
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-monodromy-theorem]]'
```

# ex:pet-ch5-folding-immersion

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-folding-immersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-monodromy-theorem]]'
```

# ex:pet-ch5-rp-n-no-immersion

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-rp-n-no-immersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-monodromy-theorem]]'
```

# ex:pet-ch5-universal-cover-monodromy

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-universal-cover-monodromy
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-monodromy-theorem]]'
```

# cor:pet-ch5-closed-simply-connected-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-closed-simply-connected-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-monodromy-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-closed-simply-connected-constant-curvature]]'
```

# cor:pet-ch5-noncompact-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-noncompact-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-monodromy-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-noncompact-constant-curvature]]'
```

# cor:pet-ch5-classification-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-classification-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-monodromy-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-covering-completeness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-classification-constant-curvature]]'
```

# rem:pet-ch5-polarization-metric-recovery

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-polarization-metric-recovery
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
```

# def:pet-ch5-distance-coordinates

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-distance-coordinates
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-uniform-injectivity-radius-compact]]'
```

# thm:pet-ch5-myers-steenrod-isometry

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-myers-steenrod-isometry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance-coordinates]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-local-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-myers-steenrod-isometry]]'
```

# def:pet-ch5-submetry

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-submetry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-metric-balls]]'
```

# thm:pet-ch5-berestovskii-submetry

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-berestovskii-submetry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-submetry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance-coordinates]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-berestovskii-submetry]]'
```

# rem:pet-ch5-submetry-c11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-submetry-c11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-berestovskii-submetry]]'
```

# def:pet-ch5-proper-action

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-proper-action
uses: []
```

# ex:pet-ch5-nonproper-action

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#ex:pet-ch5-nonproper-action
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-proper-action]]'
```

# thm:pet-ch5-myers-steenrod-lie-group

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-myers-steenrod-lie-group
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-proper-action]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-tubular-neighborhood]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-myers-steenrod-lie-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-uniform-injectivity-radius-compact]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-exp-diffeomorphism-properties]]'
```

# prop:pet-ch5-orbit-map-differential

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-orbit-map-differential
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-myers-steenrod-lie-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-orbit-map-differential]]'
```

# thm:pet-ch5-free-slice-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-free-slice-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-proper-action]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-tubular-neighborhood]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-myers-steenrod-lie-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-free-slice-theorem]]'
```

# rem:pet-ch5-quotient-homogeneous

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-quotient-homogeneous
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-free-slice-theorem]]'
```

# rem:pet-ch5-closed-subgroup-quotient

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-closed-subgroup-quotient
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-quotient-homogeneous]]'
```

# cor:pet-ch5-proper-action-orbit-embedding

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-proper-action-orbit-embedding
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-orbit-map-differential]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-proper-action]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-proper-action-orbit-embedding]]'
```

# def:pet-ch5-slice-representation

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-slice-representation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-proper-action-orbit-embedding]]'
```

# thm:pet-ch5-slice-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-slice-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-slice-representation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-free-slice-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-slice-theorem]]'
```

# cor:pet-ch5-isotropy-near-orbit

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-isotropy-near-orbit
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-slice-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-isotropy-near-orbit]]'
```

# cor:pet-ch5-conjugate-isotropy-manifold

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-conjugate-isotropy-manifold
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-isotropy-near-orbit]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-free-slice-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-conjugate-isotropy-manifold]]'
```

# thm:pet-ch5-hopf-rinow

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-hopf-rinow
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
```

# lem:pet-ch5-geodesics-are-piecewise-smooth

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-geodesics-are-piecewise-smooth
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-piecewise-smooth-curve]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-local-uniqueness]]'
```

# cor:pet-ch5-complete-segment-exists

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-complete-segment-exists
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-complete-segment-exists]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-geodesics-are-piecewise-smooth]]'
```

# cor:pet-ch5-segment-notation-unitspeed

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-segment-notation-unitspeed
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-complete-segment-exists]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
```

# cor:pet-ch5-proper-lipschitz-complete

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-proper-lipschitz-complete
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-metric-topology]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-proper-lipschitz-complete]]'
```

# thm:pet-ch5-tashiro

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-tashiro
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-tashiro]]'
```

# thm:pet-ch5-hessian-classification

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#thm:pet-ch5-hessian-classification
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-tashiro]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hessian-classification]]'
```

# rem:pet-ch5-obata-transnormal

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-obata-transnormal
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hessian-classification]]'
```

# def:pet-ch5-segment-domain

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-segment-domain
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
```

# prop:pet-ch5-segment-domain-injective

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-segment-domain-injective
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment-domain]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-segments-are-geodesics]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-segment-domain-injective]]'
```

# lem:pet-ch5-exp-nonsingular-segment-domain

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-exp-nonsingular-segment-domain
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-segment-domain-injective]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-uniform-injectivity-radius-compact]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-exp-nonsingular-segment-domain]]'
```

# lem:pet-ch5-cut-locus-characterization

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-cut-locus-characterization
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-exp-nonsingular-segment-domain]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-segment-domain-chart-artifact]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-cut-locus-characterization]]'
```

# rem:pet-ch5-segment-domain-chart-artifact

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-segment-domain-chart-artifact
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment-domain]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-injectivity-radius-chart-artifact]]'
```

# prop:pet-ch5-segment-domain-open

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#prop:pet-ch5-segment-domain-open
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-cut-locus-characterization]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-exp-nonsingular-segment-domain]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-segment-domain-open]]'
```

# rem:pet-ch5-segment-domain-open-blocker

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-segment-domain-open-blocker
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-segment-domain-open]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-exp-nonsingular-segment-domain]]'
```

# def:pet-ch5-cut-locus

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#def:pet-ch5-cut-locus
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment-domain]]'
```

# cor:pet-ch5-cut-locus-smoothness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#cor:pet-ch5-cut-locus-smoothness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-cut-locus]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-cut-locus-characterization]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-cut-locus-smoothness]]'
```

# rem:pet-ch5-injectivity-radius-cut-locus

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-injectivity-radius-cut-locus
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-cut-locus]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-injectivity-radius]]'
```

# lem:pet-ch5-klingenberg

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#lem:pet-ch5-klingenberg
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-injectivity-radius-cut-locus]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-cut-locus-characterization]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-klingenberg]]'
```

# rem:pet-ch5-ex-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# rem:pet-ch5-ex-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-acceleration]]'
```

# rem:pet-ch5-ex-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
```

# rem:pet-ch5-ex-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
```

# rem:pet-ch5-ex-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# rem:pet-ch5-ex-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# rem:pet-ch5-ex-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
```

# rem:pet-ch5-ex-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# rem:pet-ch5-ex-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# rem:pet-ch5-ex-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# rem:pet-ch5-ex-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# rem:pet-ch5-ex-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesically-complete]]'
```

# rem:pet-ch5-ex-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-berestovskii-submetry]]'
```

# rem:pet-ch5-ex-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-fixed-point-set]]'
```

# rem:pet-ch5-ex-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-distance-function-geodesics]]'
```

# rem:pet-ch5-ex-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-16
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-distance-function-geodesics]]'
```

# rem:pet-ch5-ex-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#ex:pet-ch5-sphere-great-circles]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#ex:pet-ch5-hyperbolic-hyperbolas]]'
```

# rem:pet-ch5-ex-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-18
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#cor:pet-ch5-proper-lipschitz-complete]]'
```

# rem:pet-ch5-ex-19

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-19
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-distance]]'
```

# rem:pet-ch5-ex-20

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-20
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-fixed-point-set]]'
```

# rem:pet-ch5-ex-21

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-21
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
```

# rem:pet-ch5-ex-22

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-22
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-radial-distance-function]]'
```

# rem:pet-ch5-ex-23

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-23
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
```

# rem:pet-ch5-ex-24

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-24
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-cut-locus]]'
```

# rem:pet-ch5-ex-25

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-25
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-cut-locus]]'
```

# rem:pet-ch5-ex-26

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-26
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
```

# rem:pet-ch5-ex-27

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-27
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-normal-coords-first-order]]'
```

# rem:pet-ch5-ex-28

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-28
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-first-variation-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-ex-26]]'
```

# rem:pet-ch5-ex-29

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-29
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-curve-length]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-ex-26]]'
```

# rem:pet-ch5-ex-30

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-30
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-radial-isometry]]'
```

# rem:pet-ch5-ex-31

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-31
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-fixed-point-set]]'
```

# rem:pet-ch5-ex-32

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-32
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-isometry-uniqueness]]'
```

# rem:pet-ch5-ex-33

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-33
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-functional-distance]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
```

# rem:pet-ch5-ex-34

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-34
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-energy-minima-geodesics]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-exp-nonsingular-segment-domain]]'
```

# rem:pet-ch5-ex-35

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-35
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-exponential-map]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
```

# rem:pet-ch5-ex-36

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-36
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-submetry]]'
```

# rem:pet-ch5-ex-37

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-37
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-submetry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
```

# rem:pet-ch5-ex-38

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-38
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-fixed-point-codimension]]'
```

# rem:pet-ch5-ex-39

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-39
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#prop:pet-ch5-isometry-uniqueness]]'
```

# rem:pet-ch5-ex-40

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-40
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-ex-39]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#ex:pet-ch5-sphere-great-circles]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#ex:pet-ch5-hyperbolic-hyperbolas]]'
```

# rem:pet-ch5-ex-41

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-41
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-myers-steenrod-lie-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-proper-action]]'
```

# rem:pet-ch5-ex-42

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-42
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#lem:pet-ch5-normal-coords-first-order]]'
```

# rem:pet-ch5-ex-43

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance.tex#rem:pet-ch5-ex-43
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#rem:pet-ch5-ex-42]]'
```
