# chap:pet-sectional-curvature-comparison-i

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#chap:pet-sectional-curvature-comparison-i
uses: []
```

# lem:chart-connection-bridge

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:chart-connection-bridge
uses: []
```

# lem:curvature-chart-bridge

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:curvature-chart-bridge
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-coordinate-formula]]'
```

# def:pet-ch6-vector-field-along-curve

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-vector-field-along-curve
uses: []
```

# def:pet-ch6-higher-order-partials

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-higher-order-partials
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-vector-field-along-curve]]'
```

# ex:pet-ch6-sphere-third-partials

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#ex:pet-ch6-sphere-third-partials
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-higher-order-partials]]'
```

# lem:pet-ch6-third-partial-commutator

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-third-partial-commutator
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-higher-order-partials]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:curvature-chart-bridge]]'
```

# def:pet-ch6-parallel-field

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-parallel-field
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-vector-field-along-curve]]'
```

# thm:pet-ch6-parallel-field-existence-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-parallel-field-existence-uniqueness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-parallel-field-chart-local]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-vector-field-along-curve]]'
```

# thm:pet-ch6-parallel-field-chart-local

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-parallel-field-chart-local
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-parallel-field-existence-uniqueness]]'
```

# def:pet-ch6-jacobi-field

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-jacobi-field
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-vector-field-along-curve]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-third-partial-commutator]]'
```

# rem:pet-ch6-jacobi-dexp-relation

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-jacobi-dexp-relation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
```

# rem:pet-ch6-jacobi-hessian-r

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-jacobi-hessian-r
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
```

# lem:pet-ch6-second-variation-integrand

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-second-variation-integrand
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-vector-field-along-curve]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-third-partial-commutator]]'
```

# lem:pet-ch6-offdiagonal-curvature-bridge

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-offdiagonal-curvature-bridge
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-coordinate-formula]]'
```

# thm:pet-ch6-synge-second-variation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-synge-second-variation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-vector-field-along-curve]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-offdiagonal-curvature-bridge]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-third-partial-commutator]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-second-variation-integrand]]'
```

# rem:pet-ch6-second-variation-special-cases

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-second-variation-special-cases
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-synge-second-variation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
```

# lem:pet-ch6-nonsingular-exp-covering

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-nonsingular-exp-covering
uses: []
```

# thm:pet-ch6-cartan-hadamard

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-cartan-hadamard
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-nonsingular-exp-covering]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-sec-bounds]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-jacobi-dexp-relation]]'
```

# rem:pet-ch6-cartan-hadamard-fails-ricci

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-cartan-hadamard-fails-ricci
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-cartan-hadamard]]'
```

# def:pet-ch6-convex-function

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-convex-function
uses: []
```

# rem:pet-ch6-hessian-f0-positive-definite

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-hessian-f0-positive-definite
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-jacobi-hessian-r]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-convex-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-cartan-hadamard]]'
```

# rem:pet-ch6-max-of-convex-functions

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-max-of-convex-functions
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-convex-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#thm:pet-ch5-hopf-rinow]]'
```

# def:pet-ch6-linfty-center-of-mass

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-linfty-center-of-mass
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-hessian-f0-positive-definite]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-max-of-convex-functions]]'
```

# thm:pet-ch6-cartan-fixed-point

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-cartan-fixed-point
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-linfty-center-of-mass]]'
```

# cor:pet-ch6-torsion-free-fundamental-group

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#cor:pet-ch6-torsion-free-fundamental-group
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-cartan-fixed-point]]'
```

# lem:pet-ch6-hessian-lower-bound

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-hessian-lower-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-hessian-f0-positive-definite]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-jacobi-hessian-r]]'
```

# rem:pet-ch6-triangle-comparison

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-triangle-comparison
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-hessian-lower-bound]]'
```

# def:pet-ch6-axis-displacement

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-axis-displacement
uses: []
```

# lem:pet-ch6-axis-existence

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-axis-existence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-axis-displacement]]'
```

# def:pet-ch6-deck-transformation

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-deck-transformation
uses: []
```

# lem:pet-ch6-deck-transformation-dilation

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-deck-transformation-dilation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-deck-transformation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-axis-displacement]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-axis-existence]]'
```

# thm:pet-ch6-preissmann

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-preissmann
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-deck-transformation-dilation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-axis-displacement]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-triangle-comparison]]'
```

# def:pet-ch6-sec-bounds

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-sec-bounds
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-sectional-curvature]]'
```

# def:pet-ch6-ricci-lower-bound

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-ricci-lower-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-ricci-curvature]]'
```

# lem:pet-ch6-bonnet-synge-index-core

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-bonnet-synge-index-core
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-sec-bounds]]'
```

# lem:pet-ch6-bonnet-synge-diameter

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-bonnet-synge-diameter
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-second-variation-special-cases]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-sec-bounds]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-bonnet-synge-index-core]]'
```

# cor:pet-ch6-hopf-rinow-myers-diameter

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#cor:pet-ch6-hopf-rinow-myers-diameter
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-bonnet-synge-diameter]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-sec-bounds]]'
```

# cor:pet-ch6-hopf-rinow-myers-geometric

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#cor:pet-ch6-hopf-rinow-myers-geometric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-sec-bounds]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-myers-ricci-geometric]]'
```

# lem:pet-ch6-myers-index

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-myers-index
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-bonnet-synge-index-core]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-second-variation-special-cases]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-sec-bounds]]'
```

# thm:pet-ch6-myers-ricci-geometric

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-myers-ricci-geometric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-myers-index]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-ricci-lower-bound]]'
```

# thm:pet-ch6-myers-explicit-cover

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-myers-explicit-cover
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-myers-ricci-geometric]]'
```

# thm:pet-ch6-myers-ricci-diameter

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-myers-ricci-diameter
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-myers-index]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#cor:pet-ch6-hopf-rinow-myers-diameter]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-ricci-lower-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-second-variation-special-cases]]'
```

# ex:pet-ch6-punctured-sphere-infinite-pi1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#ex:pet-ch6-punctured-sphere-infinite-pi1
uses: []
```

# ex:pet-ch6-doubly-warped-ricci-positive

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#ex:pet-ch6-doubly-warped-ricci-positive
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-myers-ricci-diameter]]'
```

# rem:pet-ch6-closed-parallel-field-construction

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-closed-parallel-field-construction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
```

# thm:pet-ch6-synge-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-synge-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-deck-transformation-dilation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-closed-parallel-field-construction]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-second-variation-special-cases]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-sec-bounds]]'
```

# rem:pet-ch6-hopf-problem

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-hopf-problem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-synge-theorem]]'
```

# prop:pet-ch6-riccati-comparison-principle

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#prop:pet-ch6-riccati-comparison-principle
uses: []
```

# rem:pet-ch6-riccati-principle-correction

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-riccati-principle-correction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#prop:pet-ch6-riccati-comparison-principle]]'
```

# lem:pet-ch6-riccati-comparison-le

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-riccati-comparison-le
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#prop:pet-ch6-riccati-comparison-principle]]'
```

# rem:pet-ch6-riccati-liminf-hypothesis

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-riccati-liminf-hypothesis
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-riccati-comparison-le]]'
```

# cor:pet-ch6-riccati-comparison-estimate

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#cor:pet-ch6-riccati-comparison-estimate
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#prop:pet-ch6-riccati-comparison-principle]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-riccati-comparison-le]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-riccati-liminf-hypothesis]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-riccati-estimate-strictness]]'
```

# rem:pet-ch6-riccati-estimate-strictness

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-riccati-estimate-strictness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-riccati-comparison-le]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-riccati-liminf-hypothesis]]'
```

# thm:pet-ch6-rauch-comparison

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-rauch-comparison
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#cor:pet-ch6-riccati-comparison-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-jacobi-hessian-r]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-sec-bounds]]'
```

# rem:pet-ch6-index-form-remark

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-index-form-remark
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-rauch-comparison]]'
```

# ex:pet-ch6-conjugate-point-space-form

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#ex:pet-ch6-conjugate-point-space-form
uses: []
```

# thm:pet-ch6-conjugate-radius-bound

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-conjugate-radius-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-rauch-comparison]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#ex:pet-ch6-conjugate-point-space-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-jacobi-hessian-r]]'
```

# rem:pet-ch6-injectivity-radius-nonpositive

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-injectivity-radius-nonpositive
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-cartan-hadamard]]'
```

# lem:pet-ch6-klingenberg-injectivity-estimate

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-klingenberg-injectivity-estimate
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-conjugate-radius-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-injectivity-radius-nonpositive]]'
```

# thm:pet-ch6-convexity-radius-criterion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-convexity-radius-criterion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-rauch-comparison]]'
```

# def:pet-ch6-convexity-radius

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-convexity-radius
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-convex-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-segment]]'
- '[[references/Petersen/blueprint/src/chapters/Ch05_GeodesicsAndDistance#def:pet-ch5-metric-balls]]'
```

# cor:pet-ch6-convexity-radius-bound

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#cor:pet-ch6-convexity-radius-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-convexity-radius]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-convexity-radius-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-klingenberg-injectivity-estimate]]'
```

# thm:pet-ch6-klingenberg-even-dim-injectivity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-klingenberg-even-dim-injectivity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-klingenberg-injectivity-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-synge-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-closed-parallel-field-construction]]'
```

# rem:pet-ch6-klingenberg-odd-dim-counterexample

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-klingenberg-odd-dim-counterexample
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-klingenberg-even-dim-injectivity]]'
```

# def:pet-ch6-l-connected

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-l-connected
uses: []
```

# def:pet-ch6-critical-point-index

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-critical-point-index
uses: []
```

# thm:pet-ch6-morse-connectivity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-morse-connectivity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-l-connected]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-critical-point-index]]'
```

# def:pet-ch6-path-space-AB

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#def:pet-ch6-path-space-AB
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-critical-point-index]]'
```

# thm:pet-ch6-submanifold-connectivity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-submanifold-connectivity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-path-space-AB]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-morse-connectivity]]'
```

# thm:pet-ch6-berger-sphere-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-berger-sphere-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-submanifold-connectivity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-bonnet-synge-diameter]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-l-connected]]'
```

# thm:pet-ch6-klingenberg-pinching-injectivity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#thm:pet-ch6-klingenberg-pinching-injectivity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-klingenberg-even-dim-injectivity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-klingenberg-injectivity-estimate]]'
```

# cor:pet-ch6-rauch-berger-klingenberg-sphere

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#cor:pet-ch6-rauch-berger-klingenberg-sphere
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-berger-sphere-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-klingenberg-pinching-injectivity]]'
```

# cor:pet-ch6-ricci-simply-connected

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#cor:pet-ch6-ricci-simply-connected
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-submanifold-connectivity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-myers-ricci-diameter]]'
```

# lem:pet-ch6-wilking-connectedness-principle

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#lem:pet-ch6-wilking-connectedness-principle
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-l-connected]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-second-variation-special-cases]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-submanifold-connectivity]]'
```

# rem:pet-ch6-frankel-theorem

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-frankel-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-wilking-connectedness-principle]]'
```

# rem:pet-ch6-ex-6-7-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-1
uses: []
```

# rem:pet-ch6-ex-6-7-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
```

# rem:pet-ch6-ex-6-7-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-vector-field-along-curve]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
```

# rem:pet-ch6-ex-6-7-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-conjugate-radius-bound]]'
```

# rem:pet-ch6-ex-6-7-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
```

# rem:pet-ch6-ex-6-7-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-third-partial-commutator]]'
```

# rem:pet-ch6-ex-6-7-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
```

# rem:pet-ch6-ex-6-7-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-jacobi-dexp-relation]]'
```

# rem:pet-ch6-ex-6-7-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-hessian-lower-bound]]'
```

# rem:pet-ch6-ex-6-7-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
```

# rem:pet-ch6-ex-6-7-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
```

# rem:pet-ch6-ex-6-7-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
```

# rem:pet-ch6-ex-6-7-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-vector-field-along-curve]]'
```

# rem:pet-ch6-ex-6-7-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-14
uses: []
```

# rem:pet-ch6-ex-6-7-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-rauch-comparison]]'
```

# rem:pet-ch6-ex-6-7-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-16
uses: []
```

# rem:pet-ch6-ex-6-7-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-path-space-AB]]'
```

# rem:pet-ch6-ex-6-7-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-18
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-frankel-theorem]]'
```

# rem:pet-ch6-ex-6-7-19

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-19
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-path-space-AB]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#lem:pet-ch6-wilking-connectedness-principle]]'
```

# rem:pet-ch6-ex-6-7-20

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-20
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-preissmann]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-axis-displacement]]'
```

# rem:pet-ch6-ex-6-7-21

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-21
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-closed-parallel-field-construction]]'
```

# rem:pet-ch6-ex-6-7-22

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-22
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-cartan-fixed-point]]'
```

# rem:pet-ch6-ex-6-7-23

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-23
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-rauch-comparison]]'
```

# rem:pet-ch6-ex-6-7-24

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-24
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-second-variation-special-cases]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-jacobi-field]]'
```

# rem:pet-ch6-ex-6-7-25

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-25
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#rem:pet-ch6-ex-6-7-24]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-rauch-comparison]]'
```

# rem:pet-ch6-ex-6-7-26

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-26
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#thm:pet-ch6-cartan-fixed-point]]'
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-convexity-radius]]'
```

# rem:pet-ch6-ex-6-7-27

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-27
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
```

# rem:pet-ch6-ex-6-7-28

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI.tex#rem:pet-ch6-ex-6-7-28
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch06_SectionalCurvatureComparisonI#def:pet-ch6-parallel-field]]'
```
