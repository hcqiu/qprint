# chap:pet-derivatives

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#chap:pet-derivatives
uses: []
```

# def:pet-ch2-directional-derivative

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-directional-derivative
uses: []
```

# rem:pet-ch2-gradient-not-invariant

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-gradient-not-invariant
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-directional-derivative]]'
```

# def:pet-ch2-lie-derivative-function

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-lie-derivative-function
uses: []
```

# def:pet-ch2-lie-derivative-vector-field

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-lie-derivative-vector-field
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-function]]'
```

# prop:pet-ch2-lie-derivative-bracket

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-lie-derivative-bracket
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-vector-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-bracket]]'
```

# def:pet-ch2-lie-derivative-tensor

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-lie-derivative-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-vector-field]]'
```

# prop:pet-ch2-lie-derivative-tensor-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-lie-derivative-tensor-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-bracket]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-tensor-formula]]'
```

# def:pet-ch2-tensor-product

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-tensor-product
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
```

# prop:pet-ch2-lie-derivative-product-rule

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-lie-derivative-product-rule
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-tensor-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-product-rule]]'
```

# prop:pet-ch2-lie-derivative-scaling

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-lie-derivative-scaling
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-tensor-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-scaling]]'
```

# lem:pet-ch2-lie-derivative-local-vanishing

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#lem:pet-ch2-lie-derivative-local-vanishing
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-tensor-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#lem:pet-ch2-lie-derivative-local-vanishing]]'
```

# def:pet-ch2-generalized-lie-derivative

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-generalized-lie-derivative
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
```

# prop:pet-ch2-generalized-jacobi-identity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-generalized-jacobi-identity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-generalized-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-generalized-jacobi-identity]]'
```

# def:pet-ch2-exterior-derivative-lie-formula

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-exterior-derivative-lie-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
```

# def:pet-ch2-hessian-lie-derivative

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-hessian-lie-derivative
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-directional-derivative]]'
```

# prop:pet-ch2-hessian-critical-point

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-hessian-critical-point
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-hessian-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#lem:pet-ch2-lie-derivative-local-vanishing]]'
```

# def:pet-ch2-divergence-lie-derivative

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-divergence-lie-derivative
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
```

# rem:pet-ch2-lie-derivative-volume-exact

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-lie-derivative-volume-exact
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-divergence-lie-derivative]]'
```

# def:pet-ch2-laplacian

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-laplacian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-divergence-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-directional-derivative]]'
```

# prop:pet-ch2-divergence-trace-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-divergence-trace-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-divergence-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-divergence-trace-formula]]'
```

# prop:pet-ch2-hessian-euclidean-agreement

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-hessian-euclidean-agreement
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-hessian-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-hessian-euclidean-agreement]]'
```

# lem:pet-ch2-ad-differential

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#lem:pet-ch2-ad-differential
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#lem:pet-ch2-ad-differential]]'
```

# lem:pet-ch2-gl-bracket-commutator

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#lem:pet-ch2-gl-bracket-commutator
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#lem:pet-ch2-ad-differential]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#lem:pet-ch2-gl-bracket-commutator]]'
```

# def:pet-ch2-covariant-derivative-euclidean

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-covariant-derivative-euclidean
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-directional-derivative]]'
```

# def:pet-ch2-dual-one-form

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-dual-one-form
uses: []
```

# def:pet-ch2-killing-field

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-killing-field
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
```

# rem:pet-ch2-killing-field-euclidean

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-killing-field-euclidean
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-killing-field]]'
```

# prop:pet-ch2-covariant-derivative-implicit-euclidean

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-covariant-derivative-implicit-euclidean
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-euclidean]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-dual-one-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-covariant-derivative-implicit-euclidean]]'
```

# def:pet-ch2-affine-connection

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-affine-connection
uses: []
```

# def:pet-ch2-riemannian-connection

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-riemannian-connection
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-affine-connection]]'
```

# rem:pet-ch2-koszul-formula

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-koszul-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-covariant-derivative-implicit-euclidean]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-dual-one-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
```

# lem:pet-ch2-extend-tangent-vector

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#lem:pet-ch2-extend-tangent-vector
uses: []
```

# lem:pet-ch2-riemannian-connection-koszul

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#lem:pet-ch2-riemannian-connection-koszul
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-riemannian-connection]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-koszul-formula]]'
```

# thm:pet-ch2-fundamental-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#thm:pet-ch2-fundamental-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-riemannian-connection]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-koszul-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#lem:pet-ch2-extend-tangent-vector]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#lem:pet-ch2-riemannian-connection-koszul]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#thm:pet-ch2-fundamental-theorem]]'
```

# lem:pet-ch2-locality-open-set

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#lem:pet-ch2-locality-open-set
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-affine-connection]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#lem:pet-ch2-locality-open-set]]'
```

# lem:pet-ch2-locality-along-curve

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#lem:pet-ch2-locality-along-curve
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-affine-connection]]'
```

# def:pet-ch2-normal-coordinates-frame

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-normal-coordinates-frame
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-riemannian-connection]]'
```

# def:pet-ch2-covariant-derivative-tensor

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-covariant-derivative-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-riemannian-connection]]'
```

# def:pet-ch2-parallel-tensor

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-parallel-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# prop:pet-ch2-metric-volume-parallel

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-metric-volume-parallel
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-parallel-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-metric-volume-parallel]]'
```

# prop:pet-ch2-hessian-covariant-derivative

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-hessian-covariant-derivative
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-hessian-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-hessian-covariant-derivative]]'
```

# def:pet-ch2-covariant-derivative-adjoint

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-covariant-derivative-adjoint
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# prop:pet-ch2-divergence-adjoint-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-divergence-adjoint-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-adjoint]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-divergence-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-dual-one-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-divergence-adjoint-formula]]'
```

# prop:pet-ch2-adjoint-integral-identity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-adjoint-integral-identity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-adjoint]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-adjoint-integral-identity]]'
```

# def:pet-ch2-exterior-derivative-covariant

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-exterior-derivative-covariant
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# def:pet-ch2-second-covariant-derivative

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-second-covariant-derivative
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-hessian-second-covariant-derivative

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-hessian-second-covariant-derivative
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-second-covariant-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-adjoint]]'
```

# def:pet-ch2-lie-derivative-connection

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-lie-derivative-connection
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-vector-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-riemannian-connection]]'
```

# rem:pet-ch2-lie-derivative-connection-symmetric

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-lie-derivative-connection-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-connection]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-lie-derivative-connection-symmetric]]'
```

# def:pet-ch2-covariant-derivative-connection

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-covariant-derivative-connection
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-second-covariant-derivative]]'
```

# def:pet-ch2-tensor-derivation

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-tensor-derivation
uses: []
```

# def:pet-ch2-gl-action-tensor-algebra

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-gl-action-tensor-algebra
uses: []
```

# def:pet-ch2-endomorphism-derivation

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-endomorphism-derivation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-gl-action-tensor-algebra]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-tensor-derivation]]'
```

# prop:pet-ch2-endomorphism-lie-algebra-hom

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-endomorphism-lie-algebra-hom
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-endomorphism-derivation]]'
```

# prop:pet-ch2-endomorphism-is-derivation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-endomorphism-is-derivation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-endomorphism-derivation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-tensor-derivation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-endomorphism-is-derivation]]'
```

# def:pet-ch2-tensor-algebra-inner-product

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-tensor-algebra-inner-product
uses: []
```

# prop:pet-ch2-endomorphism-adjoint-type-change

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-endomorphism-adjoint-type-change
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-endomorphism-derivation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-tensor-algebra-inner-product]]'
```

# prop:pet-ch2-lie-derivative-as-endomorphism-derivation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-lie-derivative-as-endomorphism-derivation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-vector-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-endomorphism-derivation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-as-endomorphism-derivation]]'
```

# def:pet-ch2-metric-coordinate-formulas

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-metric-coordinate-formulas
uses: []
```

# def:pet-ch2-vector-dual-to-form

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-vector-dual-to-form
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-metric-coordinate-formulas]]'
```

# rem:pet-ch2-gradient-coordinate-formula

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-gradient-coordinate-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-directional-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-vector-dual-to-form]]'
```

# def:pet-ch2-christoffel-symbols-second-kind

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-christoffel-symbols-second-kind
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-metric-coordinate-formulas]]'
```

# prop:pet-ch2-christoffel-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-christoffel-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-second-kind]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-koszul-formula]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-christoffel-formula]]'
```

# def:pet-ch2-christoffel-symbols-first-kind

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-christoffel-symbols-first-kind
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-second-kind]]'
```

# rem:pet-ch2-christoffel-non-tensorial

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-christoffel-non-tensorial
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-first-kind]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-ex-22]]'
```

# rem:pet-ch2-christoffel-normal-coordinates

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-christoffel-normal-coordinates
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-normal-coordinates-frame]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-second-kind]]'
```

# prop:pet-ch2-christoffel-symmetry-metric-property

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-christoffel-symmetry-metric-property
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-first-kind]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-second-kind]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-christoffel-symmetry-metric-property]]'
```

# prop:pet-ch2-hessian-coordinate-formula

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#prop:pet-ch2-hessian-coordinate-formula
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-hessian-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-second-kind]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-hessian-covariant-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-hessian-coordinate-formula]]'
```

# def:pet-ch2-covariant-derivative-index-notation

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#def:pet-ch2-covariant-derivative-index-notation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-ex-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-euclidean]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-affine-connection]]'
```

# rem:pet-ch2-ex-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-bracket]]'
```

# rem:pet-ch2-ex-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-affine-connection]]'
```

# rem:pet-ch2-ex-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-4
uses: []
```

# rem:pet-ch2-ex-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-divergence-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-hessian-lie-derivative]]'
```

# rem:pet-ch2-ex-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-hessian-lie-derivative]]'
```

# rem:pet-ch2-ex-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-dual-one-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-ex-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-metric-coordinate-formulas]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-second-kind]]'
```

# rem:pet-ch2-ex-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-ex-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
```

# rem:pet-ch2-ex-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-ex-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#thm:pet-ch2-fundamental-theorem]]'
```

# rem:pet-ch2-ex-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-connection]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#def:pet-ch3-curvature-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ricci-identity-derivation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#prop:pet-ch3-curvature-symmetries]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#rem:pet-ch3-ex-19]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-euclidean]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-killing-field-euclidean]]'
- '[[references/Petersen/blueprint/src/chapters/Ch03_Curvature#ex:pet-ch3-euclidean-flat]]'
```

# rem:pet-ch2-ex-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-affine-connection]]'
```

# rem:pet-ch2-ex-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-hessian-lie-derivative]]'
```

# rem:pet-ch2-ex-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-16
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#prop:pet-ch2-lie-derivative-scaling]]'
```

# rem:pet-ch2-ex-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-ex-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-18
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-hessian-lie-derivative]]'
```

# rem:pet-ch2-ex-19

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-19
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-normal-coordinates-frame]]'
```

# rem:pet-ch2-ex-20

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-20
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-normal-coordinates-frame]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-ex-21]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-first-kind]]'
```

# rem:pet-ch2-ex-21

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-21
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-second-kind]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-first-kind]]'
```

# rem:pet-ch2-ex-22

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-22
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-metric-coordinate-formulas]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-first-kind]]'
```

# rem:pet-ch2-ex-23

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-23
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-oriented]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-metric-coordinate-formulas]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-laplacian]]'
```

# rem:pet-ch2-ex-24

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-24
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-christoffel-symbols-second-kind]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-index-notation]]'
```

# rem:pet-ch2-ex-25

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-25
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-affine-connection]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#thm:pet-ch2-fundamental-theorem]]'
```

# rem:pet-ch2-ex-26

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-26
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-ex-25]]'
```

# rem:pet-ch2-ex-27

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-27
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-laplacian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-divergence-lie-derivative]]'
```

# rem:pet-ch2-ex-28

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-28
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-divergence-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-ex-29

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-29
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-dual-one-form]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-ex-30

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-30
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
```

# rem:pet-ch2-ex-31

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-31
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-parallel-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#rem:pet-ch2-ex-30]]'
```

# rem:pet-ch2-ex-32

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-32
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-tensor]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-tensor-algebra-inner-product]]'
```

# rem:pet-ch2-ex-33

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-33
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-vector-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-lie-derivative-tensor]]'
```

# rem:pet-ch2-ex-34

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch02_Derivatives.tex#rem:pet-ch2-ex-34
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-index-notation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-divergence-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch02_Derivatives#def:pet-ch2-covariant-derivative-adjoint]]'
```
