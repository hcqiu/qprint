# chap:pet-killing-fields

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#chap:pet-killing-fields
uses: []
```

# def:pet-ch8-killing-field

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#def:pet-ch8-killing-field
uses: []
```

# prop:pet-ch8-killing-lie-derivative

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#prop:pet-ch8-killing-lie-derivative
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-lie-derivative]]'
```

# prop:pet-ch8-killing-skew-symmetric

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#prop:pet-ch8-killing-skew-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-lie-derivative]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-skew-symmetric]]'
```

# prop:pet-ch8-killing-curvature-identities

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#prop:pet-ch8-killing-curvature-identities
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-curvature-identities]]'
```

# prop:pet-ch8-killing-uniqueness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#prop:pet-ch8-killing-uniqueness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-skew-symmetric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-uniqueness]]'
```

# thm:pet-ch8-zero-set-totally-geodesic

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-zero-set-totally-geodesic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-skew-symmetric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-zero-set-totally-geodesic]]'
```

# thm:pet-ch8-isometry-lie-algebra-dimension

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-isometry-lie-algebra-dimension
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-uniqueness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-isometry-lie-algebra-dimension]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-killing-flow-oneparameter-subgroup]]'
```

# lem:pet-ch8-killing-flow-oneparameter-subgroup

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#lem:pet-ch8-killing-flow-oneparameter-subgroup
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-killing-flow-oneparameter-subgroup]]'
```

# rem:pet-ch8-max-isometry-space-forms

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-max-isometry-space-forms
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-isometry-lie-algebra-dimension]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#rem:pet-ch8-max-isometry-space-forms]]'
```

# thm:pet-ch8-maximal-symmetry-constant-curvature

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-maximal-symmetry-constant-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-isometry-lie-algebra-dimension]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-uniqueness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-maximal-symmetry-constant-curvature]]'
```

# prop:pet-ch8-killing-norm-formulas

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#prop:pet-ch8-killing-norm-formulas
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-skew-symmetric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-curvature-identities]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-norm-formulas]]'
```

# thm:pet-ch8-bochner-negative-ricci

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-bochner-negative-ricci
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-norm-formulas]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-bochner-negative-ricci]]'
```

# cor:pet-ch8-isometry-dimension-bound-negative-ricci

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#cor:pet-ch8-isometry-dimension-bound-negative-ricci
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-bochner-negative-ricci]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#cor:pet-ch8-isometry-dimension-bound-negative-ricci]]'
```

# cor:pet-ch8-splitting-negative-ricci

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#cor:pet-ch8-splitting-negative-ricci
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-bochner-negative-ricci]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#cor:pet-ch8-splitting-negative-ricci]]'
```

# cor:pet-ch8-homogeneous-negative-ricci-flat

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#cor:pet-ch8-homogeneous-negative-ricci-flat
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-bochner-negative-ricci]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#cor:pet-ch8-homogeneous-negative-ricci-flat]]'
```

# thm:pet-ch8-quasi-negative-ricci-no-killing

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-quasi-negative-ricci-no-killing
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-bochner-negative-ricci]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-norm-formulas]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-quasi-negative-ricci-no-killing]]'
```

# def:pet-ch8-f-structure

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#def:pet-ch8-f-structure
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-rong-f-structure

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-rong-f-structure
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-f-structure]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-bochner-negative-ricci]]'
```

# rem:pet-ch8-hopf-conjecture-low-dimensions

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-hopf-conjecture-low-dimensions
uses: []
```

# thm:pet-ch8-berger-killing-field-zero

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-berger-killing-field-zero
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-norm-formulas]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-skew-symmetric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-berger-killing-field-zero]]'
```

# rem:pet-ch8-berger-odd-dimension-counterexample

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-berger-odd-dimension-counterexample
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-berger-killing-field-zero]]'
```

# def:pet-ch8-euler-characteristic

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#def:pet-ch8-euler-characteristic
uses: []
```

# thm:pet-ch8-euler-characteristic-zero-set-sum

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-euler-characteristic-zero-set-sum
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-euler-characteristic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-euler-characteristic-zero-set-sum]]'
```

# cor:pet-ch8-positive-euler-characteristic-6manifold

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#cor:pet-ch8-positive-euler-characteristic-6manifold
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-euler-characteristic-zero-set-sum]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-zero-set-totally-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#cor:pet-ch8-positive-euler-characteristic-6manifold]]'
```

# lem:pet-ch8-isolated-zero-orbit-angle-bound

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#lem:pet-ch8-isolated-zero-orbit-angle-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-isolated-zero-orbit-angle-bound]]'
```

# lem:pet-ch8-toponogov-angle-lower-bound

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#lem:pet-ch8-toponogov-angle-lower-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-toponogov-angle-lower-bound]]'
```

# thm:pet-ch8-hsiang-kleiner-4manifold

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-hsiang-kleiner-4manifold
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-grove-searle-codim2]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-isolated-zero-orbit-angle-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-toponogov-angle-lower-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-hsiang-kleiner-4manifold]]'
```

# thm:pet-ch8-grove-searle-commuting-dependent

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-grove-searle-commuting-dependent
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-curvature-identities]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-grove-searle-commuting-dependent]]'
```

# lem:pet-ch8-jacobi-type-field

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#lem:pet-ch8-jacobi-type-field
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-jacobi-type-field]]'
```

# lem:pet-ch8-wilking-connectedness-principle

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#lem:pet-ch8-wilking-connectedness-principle
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-jacobi-type-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-zero-set-totally-geodesic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-wilking-connectedness-principle]]'
```

# lem:pet-ch8-grove-searle-codim2

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#lem:pet-ch8-grove-searle-codim2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-wilking-connectedness-principle]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-euler-characteristic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-grove-searle-codim2]]'
```

# prop:pet-ch8-commuting-killing-fields-properties

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#prop:pet-ch8-commuting-killing-fields-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-curvature-identities]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-commuting-killing-fields-properties]]'
```

# def:pet-ch8-symmetry-rank

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#def:pet-ch8-symmetry-rank
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# thm:pet-ch8-symmetry-rank-half-classification

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-symmetry-rank-half-classification
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-grove-searle-codim2]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-commuting-killing-fields-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-symmetry-rank-half-classification]]'
```

# thm:pet-ch8-puttmann-searle-rong

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-puttmann-searle-rong
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-grove-searle-codim2]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#cor:pet-ch8-positive-euler-characteristic-6manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-puttmann-searle-rong]]'
```

# rem:pet-ch8-f4-spin8-exception

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-f4-spin8-exception
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
```

# thm:pet-ch8-wilking-symmetry-rank-classification

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-wilking-symmetry-rank-classification
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
```

# thm:pet-ch8-kennard-2013-euler-characteristic

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-kennard-2013-euler-characteristic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
```

# thm:pet-ch8-kennard-amann-betti-numbers

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#thm:pet-ch8-kennard-amann-betti-numbers
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
```

# rem:pet-ch8-ex-8-4-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-isometry-lie-algebra-dimension]]'
```

# rem:pet-ch8-ex-8-4-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-zero-set-totally-geodesic]]'
```

# rem:pet-ch8-ex-8-4-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-bochner-negative-ricci]]'
```

# rem:pet-ch8-ex-8-4-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-killing-uniqueness]]'
```

# rem:pet-ch8-ex-8-4-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#rem:pet-ch8-ex-8-4-12]]'
```

# rem:pet-ch8-ex-8-4-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```

# rem:pet-ch8-ex-8-4-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
```

# rem:pet-ch8-ex-8-4-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-16
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#prop:pet-ch8-commuting-killing-fields-properties]]'
```

# rem:pet-ch8-ex-8-4-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-symmetry-rank]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#thm:pet-ch8-symmetry-rank-half-classification]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#rem:pet-ch8-ex-8-4-16]]'
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#lem:pet-ch8-wilking-connectedness-principle]]'
```

# rem:pet-ch8-ex-8-4-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch08_KillingFields.tex#rem:pet-ch8-ex-8-4-18
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch08_KillingFields#def:pet-ch8-killing-field]]'
```
