# chap:pet-riemannian-metrics

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#chap:pet-riemannian-metrics
uses: []
```

# def:pet-ch1-riemannian-manifold

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-riemannian-manifold
uses: []
```

# ex:pet-ch1-euclidean-space

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-euclidean-space
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# def:pet-ch1-riemannian-isometry

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-riemannian-isometry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# ex:pet-ch1-inner-product-space

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-inner-product-space
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-euclidean-space]]'
```

# def:pet-ch1-pullback-metric

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-pullback-metric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# ex:pet-ch1-sphere

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-sphere
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pullback-metric]]'
```

# rem:pet-ch1-nonlinear-isometric-immersion

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-nonlinear-isometric-immersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pullback-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-euclidean-space]]'
```

# def:pet-ch1-riemannian-submersion

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-riemannian-submersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# ex:pet-ch1-orthogonal-projection

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-orthogonal-projection
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-submersion]]'
```

# ex:pet-ch1-hopf-fibration

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-hopf-fibration
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-submersion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hopf-fibration]]'
```

# def:pet-ch1-pseudo-riemannian

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-pseudo-riemannian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# ex:pet-ch1-minkowski

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-minkowski
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pseudo-riemannian]]'
```

# ex:pet-ch1-hyperbolic-space

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-hyperbolic-space
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pseudo-riemannian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-minkowski]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pullback-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hyperbolic-space]]'
```

# def:pet-ch1-signed-volume

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-signed-volume
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# prop:pet-ch1-signed-volume-basis-independent

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#prop:pet-ch1-signed-volume-basis-independent
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-signed-volume]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-signed-volume-basis-independent]]'
```

# def:pet-ch1-volume-form-oriented

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-volume-form-oriented
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-signed-volume-basis-independent]]'
```

# def:pet-ch1-volume-form-local

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-volume-form-local
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-oriented]]'
```

# rem:pet-ch1-height-base

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-height-base
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-local]]'
```

# rem:pet-ch1-integration-riemannian

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-integration-riemannian
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-local]]'
```

# def:pet-ch1-isometry-group

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-isometry-group
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-isometry]]'
```

# ex:pet-ch1-isometry-group-euclidean

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-isometry-group-euclidean
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-isometry-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-isometry]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-isometry-group-euclidean]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-17]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-19]]'
```

# ex:pet-ch1-isometry-group-sphere

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-isometry-group-sphere
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-isometry-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-isometry-group-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-20]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-17]]'
```

# ex:pet-ch1-isometry-group-hyperbolic

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-isometry-group-hyperbolic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-isometry-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hyperbolic-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-isometry-group-hyperbolic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-21]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-17]]'
```

# def:pet-ch1-left-invariant-metric

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-left-invariant-metric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-isometry]]'
```

# rem:pet-ch1-quotient-submersion

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-quotient-submersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-submersion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-left-invariant-metric]]'
```

# ex:pet-ch1-fubini-study

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-fubini-study
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-quotient-submersion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
```

# ex:pet-ch1-su2-berger

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-su2-berger
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-left-invariant-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
```

# rem:pet-ch1-covering-metric

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-covering-metric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-submersion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pullback-metric]]'
```

# ex:pet-ch1-flat-torus

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-flat-torus
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-covering-metric]]'
```

# ex:pet-ch1-real-projective-space

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-real-projective-space
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-covering-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
```

# conv:pet-ch1-einstein-summation

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#conv:pet-ch1-einstein-summation
uses: []
```

# def:pet-ch1-coordinate-metric

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-coordinate-metric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#conv:pet-ch1-einstein-summation]]'
```

# ex:pet-ch1-euclidean-coords

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-euclidean-coords
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-coordinate-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-euclidean-space]]'
```

# ex:pet-ch1-polar-coords

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-polar-coords
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-coordinate-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-euclidean-coords]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-polar-coords]]'
```

# def:pet-ch1-frame-metric

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-frame-metric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# ex:pet-ch1-left-invariant-coframe

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-left-invariant-coframe
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-frame-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-left-invariant-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-su2-berger]]'
```

# ex:pet-ch1-surface-of-revolution

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-surface-of-revolution
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-frame-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-surface-of-revolution]]'
```

# rem:pet-ch1-rotationally-symmetric

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-rotationally-symmetric
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-surface-of-revolution]]'
```

# ex:pet-ch1-sphere-revolution

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-sphere-revolution
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-rotationally-symmetric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hyperbolic-space]]'
```

# def:pet-ch1-snk-csk

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-snk-csk
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-rotationally-symmetric]]'
```

# def:pet-ch1-rot-sym-general

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-rot-sym-general
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-rotationally-symmetric]]'
```

# lem:pet-ch1-polar-coordinate-change

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#lem:pet-ch1-polar-coordinate-change
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-rot-sym-general]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#lem:pet-ch1-polar-coordinate-change]]'
```

# thm:pet-ch1-smoothness-criterion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#thm:pet-ch1-smoothness-criterion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#lem:pet-ch1-polar-coordinate-change]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#thm:pet-ch1-smoothness-criterion]]'
```

# ex:pet-ch1-space-forms

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-space-forms
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#thm:pet-ch1-smoothness-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-snk-csk]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hyperbolic-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-space-forms]]'
```

# def:pet-ch1-doubly-warped

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-doubly-warped
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-rot-sym-general]]'
```

# prop:pet-ch1-doubly-warped-smooth-zero

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#prop:pet-ch1-doubly-warped-smooth-zero
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-doubly-warped]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#thm:pet-ch1-smoothness-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-doubly-warped-smooth-zero]]'
```

# prop:pet-ch1-doubly-warped-smooth-b

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#prop:pet-ch1-doubly-warped-smooth-b
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-doubly-warped]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#thm:pet-ch1-smoothness-criterion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-doubly-warped-smooth-b]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-doubly-warped-smooth-zero]]'
```

# rem:pet-ch1-doubly-warped-topologies

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-doubly-warped-topologies
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-doubly-warped-smooth-zero]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-doubly-warped-smooth-b]]'
```

# ex:pet-ch1-sphere-doubly-warped

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-sphere-doubly-warped
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-doubly-warped-topologies]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere-doubly-warped]]'
```

# ex:pet-ch1-hopf-revisited

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-hopf-revisited
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hopf-fibration]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere-doubly-warped]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-su2-berger]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hopf-revisited]]'
```

# ex:pet-ch1-hopf-general-submersion

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-hopf-general-submersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-submersion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-doubly-warped]]'
```

# ex:pet-ch1-hopf-higher-dim

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-hopf-higher-dim
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hopf-general-submersion]]'
```

# ex:pet-ch1-hopf-su2-coframe

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-hopf-su2-coframe
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hopf-higher-dim]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-su2-berger]]'
```

# ex:pet-ch1-generalized-hopf

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#ex:pet-ch1-generalized-hopf
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hopf-higher-dim]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-fubini-study]]'
```

# def:pet-ch1-tensor-type-change

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-tensor-type-change
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# def:pet-ch1-ricci-types

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-ricci-types
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-tensor-type-change]]'
```

# def:pet-ch1-curvature-types

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-curvature-types
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-tensor-type-change]]'
```

# def:pet-ch1-contraction

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-contraction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-tensor-type-change]]'
```

# rem:pet-ch1-ricci-contraction

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ricci-contraction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-contraction]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-curvature-types]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-ricci-types]]'
```

# def:pet-ch1-scalar-curvature

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-scalar-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-contraction]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-ricci-types]]'
```

# def:pet-ch1-operator-norm

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-operator-norm
uses: []
```

# def:pet-ch1-euclidean-norm

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-euclidean-norm
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-contraction]]'
```

# prop:pet-ch1-norm-11-tensor

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#prop:pet-ch1-norm-11-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-euclidean-norm]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-tensor-type-change]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-norm-11-tensor]]'
```

# prop:pet-ch1-norm-02-tensor

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#prop:pet-ch1-norm-02-tensor
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-norm-11-tensor]]'
```

# def:pet-ch1-pointwise-tensor-inner

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-pointwise-tensor-inner
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-euclidean-norm]]'
```

# def:pet-ch1-l2-tensor-inner

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#def:pet-ch1-l2-tensor-inner
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pointwise-tensor-inner]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-oriented]]'
```

# rem:pet-ch1-positional-notation

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-positional-notation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-tensor-type-change]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-norm-11-tensor]]'
```

# rem:pet-ch1-ex-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-flat-torus]]'
```

# rem:pet-ch1-ex-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-submersion]]'
```

# rem:pet-ch1-ex-3

```qprint
kind: proof
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-covering-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-oriented]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-3]]'
```

# rem:pet-ch1-ex-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-doubly-warped]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-local]]'
```

# rem:pet-ch1-ex-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-local]]'
```

# rem:pet-ch1-ex-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-local]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-coordinate-metric]]'
```

# rem:pet-ch1-ex-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-rotationally-symmetric]]'
```

# rem:pet-ch1-ex-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#thm:pet-ch1-smoothness-criterion]]'
```

# rem:pet-ch1-ex-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-isometry-group]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-isometry-group-euclidean]]'
```

# rem:pet-ch1-ex-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pseudo-riemannian]]'
```

# rem:pet-ch1-ex-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-tensor-type-change]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-contraction]]'
```

# rem:pet-ch1-ex-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-euclidean-norm]]'
```

# rem:pet-ch1-ex-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pointwise-tensor-inner]]'
```

# rem:pet-ch1-ex-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pointwise-tensor-inner]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-tensor-type-change]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-contraction]]'
```

# rem:pet-ch1-ex-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-submersion]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-fubini-study]]'
```

# rem:pet-ch1-ex-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-16
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# rem:pet-ch1-ex-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-16]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pullback-metric]]'
```

# rem:pet-ch1-ex-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-18
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-16]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-submersion]]'
```

# rem:pet-ch1-ex-19

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-19
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-16]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-euclidean-space]]'
```

# prop:pet-ch1-no-flat-immersion

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#prop:pet-ch1-no-flat-immersion
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pullback-metric]]'
```

# rem:pet-ch1-ex-20

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-20
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-16]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-no-flat-immersion]]'
```

# rem:pet-ch1-ex-21

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-21
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hyperbolic-space]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#rem:pet-ch1-ex-16]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#prop:pet-ch1-no-flat-immersion]]'
```

# rem:pet-ch1-ex-22

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-22
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hopf-fibration]]'
```

# rem:pet-ch1-ex-23

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-23
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#ex:pet-ch1-hopf-su2-coframe]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#thm:pet-ch1-smoothness-criterion]]'
```

# rem:pet-ch1-ex-24

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-24
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-left-invariant-metric]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-volume-form-local]]'
```

# rem:pet-ch1-ex-25

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-25
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pseudo-riemannian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-left-invariant-metric]]'
```

# rem:pet-ch1-ex-26

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-26
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-riemannian-manifold]]'
```

# rem:pet-ch1-ex-27

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-27
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-left-invariant-metric]]'
```

# rem:pet-ch1-ex-28

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-28
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pseudo-riemannian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-left-invariant-metric]]'
```

# rem:pet-ch1-ex-29

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics.tex#rem:pet-ch1-ex-29
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-pseudo-riemannian]]'
- '[[references/Petersen/blueprint/src/chapters/Ch01_RiemannianMetrics#def:pet-ch1-left-invariant-metric]]'
```
