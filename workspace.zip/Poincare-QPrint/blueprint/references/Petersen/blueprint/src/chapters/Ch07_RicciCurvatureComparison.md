# chap:pet-ricci-curvature-comparison

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#chap:pet-ricci-curvature-comparison
uses: []
```

# prop:pet-ch7-volume-form-laplacian-trace

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#prop:pet-ch7-volume-form-laplacian-trace
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-volume-form-laplacian-trace]]'
```

# def:pet-ch7-polar-density

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-polar-density
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-volume-form-laplacian-trace]]'
```

# lem:pet-ch7-ricci-comparison-mean-curvature

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-ricci-comparison-mean-curvature
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-volume-form-laplacian-trace]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-polar-density]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-ricci-comparison-mean-curvature]]'
```

# lem:pet-ch7-absolute-volume-comparison

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-absolute-volume-comparison
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-ricci-comparison-mean-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-absolute-volume-comparison]]'
```

# lem:pet-ch7-relative-volume-comparison

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-relative-volume-comparison
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-ricci-comparison-mean-curvature]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-relative-volume-comparison]]'
```

# lem:pet-ch7-hessian-touching-comparison

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-hessian-touching-comparison
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-hessian-touching-comparison]]'
```

# def:pet-ch7-support-function

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-support-function
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-hessian-touching-comparison]]'
```

# thm:pet-ch7-convex-constant-near-max

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-convex-constant-near-max
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-support-function]]'
```

# def:pet-ch7-subharmonic-superharmonic

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-subharmonic-superharmonic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-support-function]]'
```

# thm:pet-ch7-strong-maximum-principle

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-strong-maximum-principle
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-subharmonic-superharmonic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-convex-constant-near-max]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-strong-maximum-principle]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-support-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-hessian-touching-comparison]]'
```

# def:pet-ch7-linear-harmonic-function

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-linear-harmonic-function
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-support-function]]'
```

# thm:pet-ch7-harmonic-regularity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-harmonic-regularity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-linear-harmonic-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-harmonic-regularity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-strong-maximum-principle]]'
```

# lem:pet-ch7-laplacian-comparison-calabi

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-laplacian-comparison-calabi
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-support-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-laplacian-comparison-calabi]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-ricci-comparison-mean-curvature]]'
```

# thm:pet-ch7-segment-inequality

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-segment-inequality
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-segment-inequality]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-ricci-comparison-mean-curvature]]'
```

# cor:pet-ch7-weak-poincare

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#cor:pet-ch7-weak-poincare
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-segment-inequality]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#cor:pet-ch7-weak-poincare]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-relative-volume-comparison]]'
```

# rem:pet-ch7-upper-gradient

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-upper-gradient
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#cor:pet-ch7-weak-poincare]]'
```

# def:pet-ch7-maximal-function

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-maximal-function
uses: []
```

# thm:pet-ch7-maximal-function-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-maximal-function-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-maximal-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-maximal-function-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-relative-volume-comparison]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#rem:pet-ch7-ex-5]]'
```

# thm:pet-ch7-weak-poincare-sobolev-estimate

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-weak-poincare-sobolev-estimate
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#cor:pet-ch7-weak-poincare]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-maximal-function-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-weak-poincare-sobolev-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-relative-volume-comparison]]'
```

# thm:pet-ch7-poincare-sobolev

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-poincare-sobolev
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-weak-poincare-sobolev-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-poincare-sobolev]]'
```

# rem:pet-ch7-dirichlet-poincare

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-dirichlet-poincare
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-poincare-sobolev]]'
```

# prop:pet-ch7-sobolev-hierarchy

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#prop:pet-ch7-sobolev-hierarchy
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-poincare-sobolev]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-sobolev-hierarchy]]'
```

# thm:pet-ch7-rellich-compactness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-rellich-compactness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-weak-poincare-sobolev-estimate]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-rellich-compactness]]'
```

# lem:pet-ch7-gromov-generators

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-gromov-generators
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-gromov-generators]]'
```

# ex:pet-ch7-lens-spaces-example

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#ex:pet-ch7-lens-spaces-example
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-gromov-generators]]'
```

# def:pet-ch7-manifold-class

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-manifold-class
uses: []
```

# thm:pet-ch7-anderson-finiteness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-anderson-finiteness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-manifold-class]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-gromov-generators]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-anderson-finiteness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-absolute-volume-comparison]]'
```

# lem:pet-ch7-anderson-short-loops

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-anderson-short-loops
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-manifold-class]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-anderson-short-loops]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-absolute-volume-comparison]]'
```

# thm:pet-ch7-cheng-rigidity

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-cheng-rigidity
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-laplacian-comparison-calabi]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-strong-maximum-principle]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-cheng-rigidity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-volume-form-laplacian-trace]]'
```

# ex:pet-ch7-anderson-cp2-example

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#ex:pet-ch7-anderson-cp2-example
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-cheng-rigidity]]'
```

# ex:pet-ch7-otsu-example

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#ex:pet-ch7-otsu-example
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#ex:pet-ch7-anderson-cp2-example]]'
```

# def:pet-ch7-ray-line

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-ray-line
uses: []
```

# def:pet-ch7-connected-infinity

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-connected-infinity
uses: []
```

# lem:pet-ch7-ray-line-existence

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-ray-line-existence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-ray-line]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-connected-infinity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-ray-line-existence]]'
```

# ex:pet-ch7-paraboloid-no-lines

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#ex:pet-ch7-paraboloid-no-lines
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-ray-line]]'
```

# ex:pet-ch7-cylinder-contains-line

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#ex:pet-ch7-cylinder-contains-line
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-ray-line-existence]]'
```

# ex:pet-ch7-schwarzschild-no-line

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#ex:pet-ch7-schwarzschild-no-line
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-ray-line]]'
```

# prop:pet-ch7-busemann-approximants

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#prop:pet-ch7-busemann-approximants
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-ray-line]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-laplacian-comparison-calabi]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-busemann-approximants]]'
```

# def:pet-ch7-busemann-function

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-busemann-function
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-busemann-approximants]]'
```

# ex:pet-ch7-euclidean-busemann

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#ex:pet-ch7-euclidean-busemann
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-busemann-function]]'
```

# def:pet-ch7-horosphere-asymptote

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#def:pet-ch7-horosphere-asymptote
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-busemann-function]]'
```

# prop:pet-ch7-busemann-asymptote-relation

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#prop:pet-ch7-busemann-asymptote-relation
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-horosphere-asymptote]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-busemann-asymptote-relation]]'
```

# lem:pet-ch7-busemann-superharmonic

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#lem:pet-ch7-busemann-superharmonic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-busemann-asymptote-relation]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-busemann-approximants]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-busemann-superharmonic]]'
```

# thm:pet-ch7-splitting-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-splitting-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-busemann-superharmonic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-strong-maximum-principle]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-harmonic-regularity]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-splitting-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-busemann-approximants]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-busemann-function]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-volume-form-laplacian-trace]]'
```

# cor:pet-ch7-no-ricci-flat-sphere-product

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#cor:pet-ch7-no-ricci-flat-sphere-product
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-splitting-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#cor:pet-ch7-no-ricci-flat-sphere-product]]'
```

# thm:pet-ch7-structure-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-structure-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-splitting-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-ray-line-existence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
```

# rem:pet-ch7-wilking-remark

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-wilking-remark
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
```

# cor:pet-ch7-flat-manifold-Kpi1

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#cor:pet-ch7-flat-manifold-Kpi1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#cor:pet-ch7-flat-manifold-Kpi1]]'
```

# cor:pet-ch7-finite-fundamental-group-positive-ricci

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#cor:pet-ch7-finite-fundamental-group-positive-ricci
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#cor:pet-ch7-finite-fundamental-group-positive-ricci]]'
```

# cor:pet-ch7-first-betti-number-bound

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#cor:pet-ch7-first-betti-number-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#cor:pet-ch7-first-betti-number-bound]]'
```

# thm:pet-ch7-homogeneous-splitting

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#thm:pet-ch7-homogeneous-splitting
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-splitting-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-homogeneous-splitting]]'
```

# rem:pet-ch7-ex-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#prop:pet-ch7-volume-form-laplacian-trace]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-polar-density]]'
```

# rem:pet-ch7-ex-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
```

# rem:pet-ch7-ex-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-support-function]]'
```

# rem:pet-ch7-ex-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-poincare-sobolev]]'
```

# rem:pet-ch7-ex-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-maximal-function-theorem]]'
```

# rem:pet-ch7-ex-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-cheng-rigidity]]'
```

# rem:pet-ch7-ex-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-poincare-sobolev]]'
```

# rem:pet-ch7-ex-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-absolute-volume-comparison]]'
```

# rem:pet-ch7-ex-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-laplacian-comparison-calabi]]'
```

# rem:pet-ch7-ex-10

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-10
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-relative-volume-comparison]]'
```

# rem:pet-ch7-ex-11

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-11
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-hessian-touching-comparison]]'
```

# rem:pet-ch7-ex-12

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-12
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#def:pet-ch7-linear-harmonic-function]]'
```

# rem:pet-ch7-ex-13

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-13
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-strong-maximum-principle]]'
```

# rem:pet-ch7-ex-14

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-14
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-cheng-rigidity]]'
```

# rem:pet-ch7-ex-15

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-15
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-cheng-rigidity]]'
```

# rem:pet-ch7-ex-16

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-16
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#rem:pet-ch7-ex-15]]'
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-cheng-rigidity]]'
```

# rem:pet-ch7-ex-17

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-17
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-poincare-sobolev]]'
```

# rem:pet-ch7-ex-18

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-18
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-relative-volume-comparison]]'
```

# rem:pet-ch7-ex-19

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-19
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#lem:pet-ch7-absolute-volume-comparison]]'
```

# rem:pet-ch7-ex-20

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-20
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
```

# rem:pet-ch7-ex-21

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-21
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-structure-theorem]]'
```

# rem:pet-ch7-ex-22

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison.tex#rem:pet-ch7-ex-22
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch07_RicciCurvatureComparison#thm:pet-ch7-cheng-rigidity]]'
```
