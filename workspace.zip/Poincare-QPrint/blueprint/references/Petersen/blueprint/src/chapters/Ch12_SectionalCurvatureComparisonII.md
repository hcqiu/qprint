# chap:pet-sectional-curvature-comparison-ii

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#chap:pet-sectional-curvature-comparison-ii
uses: []
```

# lem:pet-ch12-smooth-deformation-retraction

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-smooth-deformation-retraction
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-smooth-deformation-retraction]]'
```

# def:pet-ch12-alpha-regular

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#def:pet-ch12-alpha-regular
uses: []
```

# prop:pet-ch12-regular-point-properties

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#prop:pet-ch12-regular-point-properties
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#prop:pet-ch12-regular-point-properties]]'
```

# lem:pet-ch12-retraction-lemma

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-retraction-lemma
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#prop:pet-ch12-regular-point-properties]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-retraction-lemma]]'
```

# rem:pet-ch12-retraction-remark

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-retraction-remark
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-retraction-lemma]]'
```

# cor:pet-ch12-normal-bundle-diffeomorphism

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#cor:pet-ch12-normal-bundle-diffeomorphism
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-retraction-lemma]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#cor:pet-ch12-normal-bundle-diffeomorphism]]'
```

# def:pet-ch12-hinge

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#def:pet-ch12-hinge
uses: []
```

# def:pet-ch12-triangle

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#def:pet-ch12-triangle
uses: []
```

# lem:pet-ch12-comparison-hinge-triangle-exist

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-comparison-hinge-triangle-exist
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-hinge]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-triangle]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-comparison-hinge-triangle-exist]]'
```

# prop:pet-ch12-law-of-cosines

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#prop:pet-ch12-law-of-cosines
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#prop:pet-ch12-law-of-cosines]]'
```

# lem:pet-ch12-hessian-comparison

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-hessian-comparison
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-hessian-comparison]]'
```

# thm:pet-ch12-toponogov

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-toponogov
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-hinge]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-triangle]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-comparison-hinge-triangle-exist]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#prop:pet-ch12-law-of-cosines]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-hessian-comparison]]'
```

# rem:pet-ch12-toponogov-segment-remark

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-toponogov-segment-remark
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
```

# thm:pet-ch12-quarter-pinched-sphere

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-quarter-pinched-sphere
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-quarter-pinched-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
```

# thm:pet-ch12-diameter-sphere

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-diameter-sphere
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-diameter-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
```

# thm:pet-ch12-cross-pinching

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-cross-pinching
uses: []
```

# thm:pet-ch12-diameter-classification

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-diameter-classification
uses: []
```

# lem:pet-ch12-gromov-critical-point-estimate

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-gromov-critical-point-estimate
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-gromov-critical-point-estimate]]'
```

# def:pet-ch12-totally-convex

```qprint
kind: definition
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#def:pet-ch12-totally-convex
uses: []
```

# ex:pet-ch12-totally-convex-cylinder

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#ex:pet-ch12-totally-convex-cylinder
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-totally-convex]]'
```

# ex:pet-ch12-totally-convex-paraboloid

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#ex:pet-ch12-totally-convex-paraboloid
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-totally-convex]]'
```

# lem:pet-ch12-concave-superlevel-convex

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-concave-superlevel-convex
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-totally-convex]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-concave-superlevel-convex]]'
```

# lem:pet-ch12-busemann-proper-concave

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-busemann-proper-concave
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-totally-convex]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-concave-superlevel-convex]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-busemann-proper-concave]]'
```

# lem:pet-ch12-totally-convex-boundary-structure

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-totally-convex-boundary-structure
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-totally-convex]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-totally-convex-boundary-structure]]'
```

# lem:pet-ch12-distance-to-boundary-concave

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-distance-to-boundary-concave
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-totally-convex]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-totally-convex-boundary-structure]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-distance-to-boundary-concave]]'
```

# thm:pet-ch12-soul-theorem

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-soul-theorem
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-busemann-proper-concave]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-distance-to-boundary-concave]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#cor:pet-ch12-normal-bundle-diffeomorphism]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-soul-theorem]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-concave-superlevel-convex]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-totally-convex-boundary-structure]]'
```

# thm:pet-ch12-soul-uniqueness-submetry

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-soul-uniqueness-submetry
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-soul-theorem]]'
```

# lem:pet-ch12-corank-bound

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-corank-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-corank-bound]]'
```

# lem:pet-ch12-mayer-vietoris-rank

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-mayer-vietoris-rank
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-mayer-vietoris-rank]]'
```

# lem:pet-ch12-content-ratio-bound

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-content-ratio-bound
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-corank-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-mayer-vietoris-rank]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-content-ratio-bound]]'
```

# thm:pet-ch12-betti-number-finiteness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-betti-number-finiteness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-corank-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-content-ratio-bound]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-betti-number-finiteness]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-gromov-critical-point-estimate]]'
```

# lem:pet-ch12-alpha-regular-existence

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-alpha-regular-existence
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-alpha-regular-existence]]'
```

# cor:pet-ch12-diagonal-alpha-regular

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#cor:pet-ch12-diagonal-alpha-regular
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-alpha-regular-existence]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#cor:pet-ch12-diagonal-alpha-regular]]'
```

# cor:pet-ch12-close-maps-homotopic

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#cor:pet-ch12-close-maps-homotopic
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#cor:pet-ch12-diagonal-alpha-regular]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-retraction-lemma]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#cor:pet-ch12-close-maps-homotopic]]'
```

# lem:pet-ch12-simplex-extension

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-simplex-extension
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#cor:pet-ch12-close-maps-homotopic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-simplex-extension]]'
```

# lem:pet-ch12-gh-close-homotopy-equivalent

```qprint
kind: lemma
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#lem:pet-ch12-gh-close-homotopy-equivalent
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-simplex-extension]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#cor:pet-ch12-close-maps-homotopic]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-gh-close-homotopy-equivalent]]'
```

# thm:pet-ch12-homotopy-finiteness

```qprint
kind: theorem
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#thm:pet-ch12-homotopy-finiteness
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-gh-close-homotopy-equivalent]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-homotopy-finiteness]]'
```

# rem:pet-ch12-ex-12-8-1

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-1
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-quarter-pinched-sphere]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#def:pet-ch12-alpha-regular]]'
```

# rem:pet-ch12-ex-12-8-2

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-2
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-soul-theorem]]'
```

# rem:pet-ch12-ex-12-8-3

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-3
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
```

# rem:pet-ch12-ex-12-8-4

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-4
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
```

# rem:pet-ch12-ex-12-8-5

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-5
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
```

# rem:pet-ch12-ex-12-8-6

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-6
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
```

# rem:pet-ch12-ex-12-8-7

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-7
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#lem:pet-ch12-alpha-regular-existence]]'
```

# rem:pet-ch12-ex-12-8-8

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-8
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-soul-theorem]]'
```

# rem:pet-ch12-ex-12-8-9

```qprint
kind: other
status: not_started
tex: references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII.tex#rem:pet-ch12-ex-12-8-9
uses:
- '[[references/Petersen/blueprint/src/chapters/Ch12_SectionalCurvatureComparisonII#thm:pet-ch12-toponogov]]'
```
