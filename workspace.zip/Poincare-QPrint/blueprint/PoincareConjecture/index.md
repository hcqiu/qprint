---
title: PoincareConjecture
---

## Blueprint

- [[PoincareConjecture/blueprint/chapters/ancient-models.md]]
- [[PoincareConjecture/blueprint/chapters/annular-comparison.md]]
- [[PoincareConjecture/blueprint/chapters/compact-cores.md]]
- [[PoincareConjecture/blueprint/chapters/dehn-surfaces.md]]
- [[PoincareConjecture/blueprint/chapters/extinction.md]]
- [[PoincareConjecture/blueprint/chapters/filling-width.md]]
- [[PoincareConjecture/blueprint/chapters/finite-history.md]]
- [[PoincareConjecture/blueprint/chapters/foundations.md]]
- [[PoincareConjecture/blueprint/chapters/global-surgery.md]]
- [[PoincareConjecture/blueprint/chapters/neck-cap-topology.md]]
- [[PoincareConjecture/blueprint/chapters/ramps.md]]
- [[PoincareConjecture/blueprint/chapters/reduced-geometry.md]]
- [[PoincareConjecture/blueprint/chapters/relative-rigidity.md]]
- [[PoincareConjecture/blueprint/chapters/ricci-flow.md]]
- [[PoincareConjecture/blueprint/chapters/singular-limits.md]]
- [[PoincareConjecture/blueprint/chapters/smoothing.md]]
- [[PoincareConjecture/blueprint/chapters/sphere-reduction.md]]
- [[PoincareConjecture/blueprint/chapters/surgery.md]]
