# ch:sphere-reduction

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#ch:sphere-reduction
uses: []
```

# sec:sphere-reconstruction-interface

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#sec:sphere-reconstruction-interface
uses: []
```

# def:exact-factor-ledger

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#def:exact-factor-ledger
uses:
- '[[PoincareConjecture/blueprint/chapters/finite-history#prop:connected-sum-reconstruction]]'
lean:
- declaration: PoincareMT.M72ReconstructionConclusion
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ConnectedSum/Reconstruction.lean
  lines:
  - 226
  - 269
```

# sec:factor-fundamental-groups

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#sec:factor-fundamental-groups
uses: []
```

# lem:sphere-factor-retraction

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#lem:sphere-factor-retraction
uses:
- '[[PoincareConjecture/blueprint/chapters/finite-history#def:finite-smooth-assembly]]'
lean:
- declaration: PoincareMT.SmoothFiniteConnectedSumAssembly.piece_factor
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/GroupEffects/ConnectedSum/Reconstruction.lean
  lines:
  - 79
  - 88
- declaration: PoincareMT.SmoothFiniteConnectedSumAssembly.piece_simplyConnected
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/SphereFactors/Assembly/PieceSimplyConnected.lean
  lines:
  - 32
  - 52
```

# sec:factor-classification

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#sec:factor-classification
uses: []
```

# def:discarded-factor-types

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#def:discarded-factor-types
uses: []
lean:
- declaration: PoincareMT.SurgerySphereBundle
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ConnectedSum/Surgery/Topology.lean
  lines:
  - 27
  - 41
- declaration: PoincareMT.SurgeryPositiveSpaceform
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ConnectedSum/Surgery/Topology.lean
  lines:
  - 43
  - 48
```

# lem:sphere-bundle-obstruction

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#lem:sphere-bundle-obstruction
uses:
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#def:discarded-factor-types]]'
lean:
- declaration: PoincareMT.SurgerySphereBundle.not_simplyConnectedSpace
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/SphereFactors/Assembly/SphereBundleExclusion.lean
  lines:
  - 126
  - 165
```

# prop:positive-spaceform-sphere

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#prop:positive-spaceform-sphere
uses:
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#def:discarded-factor-types]]'
lean:
- declaration: PoincareMT.SurgeryPositiveSpaceform.nonempty_diffeomorph_threeSphere
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/SphereFactors/SimplyConnected/KillingHopf.lean
  lines:
  - 33
  - 79
```

# thm:exact-sphere-factors

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#thm:exact-sphere-factors
uses:
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#def:exact-factor-ledger]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#lem:sphere-factor-retraction]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#lem:sphere-bundle-obstruction]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#prop:positive-spaceform-sphere]]'
lean:
- declaration: PoincareMT.m73SphereFactors
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/SphereFactors/Main.lean
  lines:
  - 31
  - 49
- declaration: PoincareMT.m73SphereFactors_from_M72
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/SphereFactors/Providers.lean
  lines:
  - 22
  - 30
```

# sec:binary-sphere-gluing

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#sec:binary-sphere-gluing
uses: []
```

# def:sphere-binary-data

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#def:sphere-binary-data
uses: []
lean:
- declaration: PoincareMT.SmoothConnectedSumData
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ConnectedSum/Basic.lean
  lines:
  - 31
  - 61
```

# lem:reciprocal-sphere-end

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#lem:reciprocal-sphere-end
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#lem:neck-cap-prescribed-collar]]'
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#lem:neck-cap-sphere-isotopy]]'
lean:
- declaration: PoincareMT.SurgeryBallEmbedding.exists_canonicalPuncturedSphereEnd
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reduction/Assembly/CanonicalPuncturedSphereEnd.lean
  lines:
  - 32
  - 94
```

# thm:binary-sphere-identity

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#thm:binary-sphere-identity
uses:
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#def:sphere-binary-data]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#lem:reciprocal-sphere-end]]'
lean:
- declaration: PoincareMT.SmoothConnectedSumData.nonempty_diffeomorph_threeSphere
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reduction/Assembly/SphereConnectedSum.lean
  lines:
  - 28
  - 41
```

# sec:sphere-union-induction

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#sec:sphere-union-induction
uses: []
```

# def:sphere-union

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#def:sphere-union
uses: []
lean:
- declaration: PoincareMT.M74.SphereUnion
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reduction/Assembly/SphereUnionInvariant.lean
  lines:
  - 69
  - 72
```

# lem:sphere-union-step

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#lem:sphere-union-step
uses:
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#def:sphere-union]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#thm:binary-sphere-identity]]'
lean:
- declaration: PoincareMT.M74.SphereUnion.of_connectedSumStep
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reduction/Assembly/StepPreservesSphereUnion.lean
  lines:
  - 45
  - 228
```

# thm:sphere-finite-reduction

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#thm:sphere-finite-reduction
uses:
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#def:sphere-union]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#lem:sphere-union-step]]'
lean:
- declaration: PoincareMT.m74ConnectedSumReduction
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reduction/Main.lean
  lines:
  - 28
  - 32
- declaration: PoincareMT.M74.SphereUnion.of_reflTransGen
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reduction/Assembly/FiniteInduction.lean
  lines:
  - 26
  - 34
- declaration: PoincareMT.M74.SphereUnion.nonempty_diffeomorph_threeSphere
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reduction/Assembly/SphereUnionInvariant.lean
  lines:
  - 99
  - 105
```

# sec:m74-m75-endpoint

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#sec:m74-m75-endpoint
uses: []
```

# cor:same-slice-sphere

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#cor:same-slice-sphere
uses:
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#thm:exact-sphere-factors]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#thm:sphere-finite-reduction]]'
lean:
- declaration: PoincareMT.m74Reduction_from_M72_M73
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reduction/Providers.lean
  lines:
  - 35
  - 40
```

# thm:sphere-smooth-endpoint

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/sphere-reduction.tex#thm:sphere-smooth-endpoint
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-normalize]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-projective-exclusion]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-global-extinction]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#cor:same-slice-sphere]]'
lean:
- declaration: PoincareMT.m75EndpointInputFromExtinction
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Smooth/Providers.lean
  lines:
  - 23
  - 34
- declaration: PoincareMT.m75SmoothPoincare
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Smooth.lean
  lines:
  - 30
  - 39
- declaration: PoincareMT.m90SmoothEndpointInputs
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Final/Providers.lean
  lines:
  - 73
  - 113
```
