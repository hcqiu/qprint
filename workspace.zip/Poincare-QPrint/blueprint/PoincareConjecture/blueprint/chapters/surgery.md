# ch:surgery

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#ch:surgery
uses: []
```

# sec:surgery-carriers

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:surgery-carriers
uses: []
```

# def:surgery-regular-history

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#def:surgery-regular-history
uses: []
lean:
- declaration: PoincareMT.M33RegularHistoryData
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Continuation/RegularHistory.lean
  lines:
  - 46
  - 90
```

# sec:standard-cap

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:standard-cap
uses: []
```

# def:standard-initial-metric

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#def:standard-initial-metric
uses: []
lean:
- declaration: PoincareMT.StandardInitialMetric
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/StandardCap/Geometry.lean
  lines:
  - 79
  - 93
```

# lem:cap-common-uniqueness

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#lem:cap-common-uniqueness
uses:
- '[[PoincareConjecture/blueprint/chapters/surgery#def:standard-initial-metric]]'
lean:
- declaration: PoincareMT.M34.partialStandardCapFlow_metric_unique
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/StandardCap/Existence/RotationInvariance/Uniqueness.lean
  lines:
  - 31
  - 94
```

# thm:standard-cap-existence

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#thm:standard-cap-existence
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#thm:neck-cap-canonical]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#thm:singular-m30]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#def:standard-initial-metric]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#lem:cap-common-uniqueness]]'
lean:
- declaration: PoincareMT.repairedStandardCapExistence
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/StandardCap/Existence/Main.lean
  lines:
  - 55
  - 56
```

# thm:standard-cap-uniqueness

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#thm:standard-cap-uniqueness
uses:
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:standard-cap-existence]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#lem:cap-common-uniqueness]]'
lean:
- declaration: PoincareMT.repairedStandardCapUniqueness
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/StandardCap/Uniqueness/Main.lean
  lines:
  - 64
  - 81
```

# sec:metric-surgery

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:metric-surgery
uses: []
```

# thm:metric-surgery

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#thm:metric-surgery
uses:
- '[[PoincareConjecture/blueprint/chapters/surgery#def:standard-initial-metric]]'
lean:
- declaration: PoincareMT.repairedMetricSurgery
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Metric/Existence.lean
  lines:
  - 59
  - 116
```

# sec:surgery-continuation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:surgery-continuation
uses: []
```

# thm:branch-continuation

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#thm:branch-continuation
uses:
- '[[PoincareConjecture/blueprint/chapters/singular-limits#thm:singular-m31]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#cor:singular-selector]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#def:surgery-regular-history]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:metric-surgery]]'
lean:
- declaration: PoincareMT.repairedBranchContinuation
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Continuation/Construction.lean
  lines:
  - 56
  - 129
```

# sec:surgery-event-topology

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:surgery-event-topology
uses: []
```

# thm:surgery-local-topology

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#thm:surgery-local-topology
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#thm:neck-cap-cover]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:metric-surgery]]'
lean:
- declaration: PoincareMT.rawLocalSurgeryTopology
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Event/Main.lean
  lines:
  - 42
  - 43
```

# sec:comparison

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:comparison
uses: []
```

# thm:comparison-map

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#thm:comparison-map
uses:
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:metric-surgery]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:surgery-local-topology]]'
lean:
- declaration: PoincareMT.repairedComparisonMap
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Comparison/Extension/Existence.lean
  lines:
  - 41
  - 48
```

# thm:comparison-transport

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#thm:comparison-transport
uses:
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:comparison-map]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-top-homology]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-cw-equivalence]]'
lean:
- declaration: PoincareMT.repairedComparisonHomotopy
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Comparison/Transport/Existence.lean
  lines:
  - 46
  - 57
```

# sec:branch-dichotomy

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:branch-dichotomy
uses: []
```

# prop:unified-branch

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#prop:unified-branch
uses:
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:branch-continuation]]'
lean:
- declaration: PoincareMT.repairedBranchContinuation
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Continuation/Construction.lean
  lines:
  - 56
  - 129
```

# sec:cap-persistence

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:cap-persistence
uses: []
```

# thm:cap-persistence

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#thm:cap-persistence
uses:
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:metric-surgery]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:standard-cap-uniqueness]]'
lean:
- declaration: PoincareMT.repairedCapPersistence
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/StandardCap/Persistence/Main.lean
  lines:
  - 48
  - 51
```

# sec:surgery-interfaces

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/surgery.tex#sec:surgery-interfaces
uses: []
```
