# ch:smoothing

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#ch:smoothing
uses: []
```

# sec:smoothing-contract

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:smoothing-contract
uses: []
```

# def:smoothing-bridge

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#def:smoothing-bridge
uses: []
lean:
- declaration: PoincareMT.SmoothingBridgeConclusion
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Smoothing/Basic.lean
  lines:
  - 21
  - 30
```

# thm:m76

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#thm:m76
uses:
- '[[PoincareConjecture/blueprint/chapters/smoothing#def:smoothing-bridge]]'
- '[[PoincareConjecture/blueprint/chapters/relative-rigidity#thm:lower-handle-straightening]]'
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:smoothing-finite-assembly]]'
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:smoothing-geometric-triangulation]]'
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:smoothing-triangulation]]'
lean:
- declaration: PoincareMT.m76CompatibleSmoothing
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Compatible.lean
  lines:
  - 40
  - 91
- declaration: PoincareMT.M76.smoothingConclusion_of_lower_handle_cases
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/SmoothAtlas/Handles/HamiltonLowerHandleBridge.lean
  lines:
  - 24
  - 34
```

# sec:wall-core

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:wall-core
uses: []
```

# def:one-end

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#def:one-end
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:one-simply-connected-end]]'
lean:
- declaration: PoincareMT.M76.HasOneSimplyConnectedEnd
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonGeometricInputs.lean
  lines:
  - 88
  - 92
```

# prop:wall-core

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#prop:wall-core
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:protected-wall-core]]'
lean:
- declaration: PoincareMT.M76.hasWallCompactCore
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/CompactCore/WallCompactCore.lean
  lines:
  - 20
  - 31
- declaration: PoincareMT.M76.HasWallCompactCore
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonGeometricInputs.lean
  lines:
  - 100
  - 110
```

# sec:dehn-prime

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:dehn-prime
uses: []
```

# def:generalized-dehn

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#def:generalized-dehn
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-standard-proper]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-protected-disks]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-protected-annulus]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-enclosing-region]]'
lean:
- declaration: PoincareMT.M76.HasHamiltonGeneralizedDehnInput
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonProtectedGeometricInputs.lean
  lines:
  - 210
  - 211
- declaration: PoincareMT.M76.hasHamiltonGeneralizedDehnInput
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Generalized.lean
  lines:
  - 27
  - 28
```

# sec:handle-cases

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:handle-cases
uses: []
```

# thm:smoothing-index-three

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#thm:smoothing-index-three
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:compact-pl-domain]]'
lean:
- declaration: PoincareMT.M76.hasHamiltonChartHandleStraightening_indexThree
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonAlexanderConsequences.lean
  lines:
  - 50
  - 75
```

# sec:finite-assembly

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:finite-assembly
uses: []
```

# thm:smoothing-finite-assembly

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#thm:smoothing-finite-assembly
uses:
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:smoothing-index-three]]'
- '[[PoincareConjecture/blueprint/chapters/relative-rigidity#thm:lower-handle-straightening]]'
lean:
- declaration: PoincareMT.M76.exists_finite_atlas_supported_straightening
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonFiniteAtlasAssembly.lean
  lines:
  - 25
  - 120
```

# sec:independent-triangulation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:independent-triangulation
uses: []
```

# thm:smoothing-geometric-triangulation

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#thm:smoothing-geometric-triangulation
uses:
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:smoothing-finite-assembly]]'
lean:
- declaration: ChartedSpace.exists_finite_geometric_affine_star_triangulation
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Polyhedral/Affine/HamiltonAffineStars.lean
  lines:
  - 30
  - 66
```

# thm:smoothing-triangulation

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#thm:smoothing-triangulation
uses:
- '[[PoincareConjecture/blueprint/chapters/smoothing#def:smoothing-bridge]]'
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:smoothing-geometric-triangulation]]'
lean:
- declaration: Geometry.SimplicialComplex.exists_independent_euclidean_realization
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Polyhedral/General/IndependentVertexRealization.lean
  lines:
  - 62
  - 70
- declaration: PoincareMT.M76.smoothingConclusion_of_finite_geometric_triangulation
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/SmoothAtlas/General/FiniteTriangulationBridge.lean
  lines:
  - 35
  - 78
```

# sec:cairns-pullback

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:cairns-pullback
uses: []
```

# sec:m77-m80

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:m77-m80
uses: []
```

# thm:smoothing-hypothesis-transport

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#thm:smoothing-hypothesis-transport
uses:
- '[[PoincareConjecture/blueprint/chapters/smoothing#def:smoothing-bridge]]'
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:m76]]'
lean:
- declaration: PoincareMT.m77TransportTopologicalHypotheses
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Smoothing/Topology.lean
  lines:
  - 27
  - 38
```

# thm:topological-endpoint

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#thm:topological-endpoint
uses:
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:m76]]'
- '[[PoincareConjecture/blueprint/chapters/smoothing#thm:smoothing-hypothesis-transport]]'
- '[[PoincareConjecture/blueprint/chapters/sphere-reduction#thm:sphere-smooth-endpoint]]'
lean:
- declaration: PoincareMT.m78EndpointTransport
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Transport.lean
  lines:
  - 32
  - 42
- declaration: PoincareMT.m79TopologicalPoincare
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Topological.lean
  lines:
  - 29
  - 37
- declaration: PoincareMT.m80EndpointAssembly
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Assembly.lean
  lines:
  - 24
  - 26
- declaration: PoincareMT.m90FinalAssemblyFromMilestones
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Final/Main.lean
  lines:
  - 32
  - 34
```

# sec:smoothing-contracts

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/smoothing.tex#sec:smoothing-contracts
uses: []
```
