# ch:ancient-models

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#ch:ancient-models
uses: []
```

# def:ancient-kappa

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#def:ancient-kappa
uses: []
lean:
- declaration: PoincareMT.AncientKappaSolution
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Basic.lean
  lines:
  - 36
  - 51
```

# thm:ancient-structure

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#thm:ancient-structure
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#def:ancient-kappa]]'
lean:
- declaration: PoincareMT.ancientKappaStructuralConsequences
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Structure.lean
  lines:
  - 83
  - 89
```

# prop:ancient-sequence

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#prop:ancient-sequence
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:ancient-structure]]'
lean:
- declaration: PoincareMT.ancientBlowupSequenceSetup
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Rescaling/Construction.lean
  lines:
  - 80
  - 110
```

# lem:ancient-weak-regularity

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-weak-regularity
uses: []
lean:
- declaration: Poincare.Analysis.Parabolic.WeakRegularity.Canonical.contDiffOn_of_continuous_weakSolution_positive
  file: PoincareConjecture/PoincareLib/Analysis/Parabolic/WeakRegularity/Smooth.lean
  lines:
  - 59
  - 78
```

# thm:ancient-asymptotic

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#thm:ancient-asymptotic
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#prop:ancient-sequence]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-weak-regularity]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-compactness]]'
lean:
- declaration: PoincareMT.ancientAsymptoticSolitonLimits
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Asymptotic/Limits.lean
  lines:
  - 29
  - 50
```

# rem:ancient-energy-interface

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#rem:ancient-energy-interface
uses: []
```

# lem:surface-shrinker

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:surface-shrinker
uses: []
lean:
- declaration: PoincareMT.LeviCivitaData.compactSpace_of_surface_shrinker
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Soliton/TwoDimensional/Compactness.lean
  lines:
  - 29
  - 40
- declaration: PoincareMT.LeviCivitaData.constantPositiveSectionalCurvature_of_surface_shrinker
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Soliton/TwoDimensional/Roundness.lean
  lines:
  - 22
  - 34
```

# thm:surface-ancient

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#thm:surface-ancient
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:surface-shrinker]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:ancient-asymptotic]]'
lean:
- declaration: PoincareMT.twoDimensionalAncientAndShrinkingSolitonClassification
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Soliton/TwoDimensional.lean
  lines:
  - 29
  - 40
```

# lem:ancient-geometric-selected-line

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-geometric-selected-line
uses: []
lean:
- declaration: PoincareMT.RicciFlow.exists_isometric_line_of_selected_small_rescalings
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/AncientVolume/Splitting/SelectedComparison.lean
  lines:
  - 241
  - 368
```

# lem:ancient-heat-contacts

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-heat-contacts
uses: []
lean:
- declaration: PoincareMT.RicciFlow.Splitting.MaximumPrinciple.positive_of_connected_on_Icc
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Splitting/MaximumPrinciple/Positive.lean
  lines:
  - 120
  - 132
- declaration: PoincareMT.RicciFlow.Splitting.MaximumPrinciple.eq_zero_on_Icc_of_eq_zero
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Splitting/MaximumPrinciple/Positive.lean
  lines:
  - 158
  - 178
```

# thm:three-shrinkers

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#thm:three-shrinkers
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:surface-ancient]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-heat-contacts]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-singleton-level]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-soul-coordinates]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-terminal-cylinder]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-antipodal-collar]]'
lean:
- declaration: PoincareMT.threeDimensionalAncientAndShrinkingSolitonClassification
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Soliton/ThreeDimensional/Classification/Assembly.lean
  lines:
  - 83
  - 90
```

# lem:ancient-singleton-level

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-singleton-level
uses: []
lean:
- declaration: PoincareMT.RiemannianMetric.exists_singleton_horoball_of_strictlyPositiveSectionalCurvature
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Soul/Point/Terminal.lean
  lines:
  - 26
  - 55
```

# lem:ancient-soul-coordinates

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-soul-coordinates
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-singleton-level]]'
lean:
- declaration: PoincareMT.RiemannianMetric.exists_centered_complete_outward_flow_of_singleton_horoball
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Soul/Point/Flow/CenteredGlobal.lean
  lines:
  - 37
  - 113
- declaration: PoincareMT.RiemannianMetric.exists_euclidean_diffeomorph_of_singleton_horoball
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Soul/Point/Euclidean.lean
  lines:
  - 27
  - 37
- declaration: PoincareMT.RiemannianMetric.exists_radialHomeomorph_of_singleton_horoball
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Soul/Point/Flow/RadialFromFlow.lean
  lines:
  - 73
  - 81
```

# lem:ancient-collar-sides

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-collar-sides
uses: []
lean:
- declaration: Poincare.Topology.collared_sphere_separates
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Separation/Euclidean.lean
  lines:
  - 23
  - 50
```

# lem:ancient-antipodal-collar

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-antipodal-collar
uses: []
lean:
- declaration: Poincare.Manifold.not_isLocalDiffeomorphOn_antipodal_collar
  file: PoincareConjecture/PoincareLib/Geometry/Manifold/Immersion/AntipodalCollar.lean
  lines:
  - 148
  - 163
```

# lem:ancient-terminal-cylinder

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-terminal-cylinder
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-compactness]]'
lean:
- declaration: PoincareMT.RawAncientSequence.exists_terminal_epsilonNeck_threshold
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Compactness/Boundedness/TerminalNeck.lean
  lines:
  - 30
  - 108
```

# rem:ancient-neck-input

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#rem:ancient-neck-input
uses: []
```

# prop:ancient-avr

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#prop:ancient-avr
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#def:ancient-kappa]]'
lean:
- declaration: PoincareMT.asymptoticVolumeRatioBishopGromov
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Volume/BishopGromov.lean
  lines:
  - 96
  - 124
```

# prop:bounded-ancient-zero-volume

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#prop:bounded-ancient-zero-volume
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-bounded-harnack]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-infinite-scalar-ratio]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-selected-line]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-line-busemann]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-parallel-persistence]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-fixed-factor]]'
lean:
- declaration: PoincareMT.RicciFlow.zero_asymptoticVolumeRatio_of_bounded_ancient
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/AncientVolume/ZeroVolume/Theorem.lean
  lines:
  - 31
  - 60
```

# lem:ancient-infinite-scalar-ratio

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-infinite-scalar-ratio
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-positive-ratio-obstruction]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-zero-ratio-obstruction]]'
lean:
- declaration: PoincareMT.RicciFlow.infinite_scalar_ratio_of_bounded_ancient
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/AncientVolume/ScalarRatio/InfiniteRatio.lean
  lines:
  - 27
  - 62
```

# lem:ancient-positive-ratio-obstruction

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-positive-ratio-obstruction
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-bounded-harnack]]'
lean:
- declaration: PoincareMT.RicciFlow.false_of_positive_finite_scalar_ratio
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/AncientVolume/ScalarRatio/FiniteRatio.lean
  lines:
  - 33
  - 60
```

# eq:ancient-local-injectivity

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#eq:ancient-local-injectivity
uses: []
```

# eq:ancient-radial-connection

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#eq:ancient-radial-connection
uses: []
```

# lem:ancient-zero-ratio-obstruction

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-zero-ratio-obstruction
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-bounded-harnack]]'
lean:
- declaration: PoincareMT.RicciFlow.curvature_eq_zero_of_zero_ratio
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/AncientVolume/ScalarRatio/Cone/ZeroRatio/UmbilicRigidity.lean
  lines:
  - 31
  - 78
```

# lem:ancient-selected-line

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-selected-line
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-infinite-scalar-ratio]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-geometric-selected-line]]'
lean:
- declaration: PoincareMT.RicciFlow.exists_nonflat_small_ancient_limit_with_line_of_unbounded_scalar_ratio
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/AncientVolume/Splitting/NonflatLineLimit.lean
  lines:
  - 58
  - 103
```

# lem:ancient-line-busemann

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-line-busemann
uses: []
lean:
- declaration: PoincareMT.RiemannianMetric.busemann_minimizing_line
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Splitting/Busemann/Main.lean
  lines:
  - 44
  - 85
```

# lem:ancient-parallel-persistence

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-parallel-persistence
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-heat-contacts]]'
lean:
- declaration: PoincareMT.RicciFlow.Splitting.backward_persistence_of_parallel_gradient
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Splitting/Persistence.lean
  lines:
  - 76
  - 107
```

# lem:ancient-fixed-factor

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-fixed-factor
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-line-busemann]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-parallel-persistence]]'
lean:
- declaration: PoincareMT.RicciFlow.parallelGradientFactor_ancient_geometry
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/AncientVolume/Splitting/AncientFactor.lean
  lines:
  - 36
  - 109
```

# rem:ancient-cone-gap

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#rem:ancient-cone-gap
uses: []
```

# lem:ancient-compact-round-limit

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#lem:ancient-compact-round-limit
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#prop:ancient-sequence]]'
lean:
- declaration: PoincareMT.AncientKappaRoundness.isRoundAncientKappaSolution_of_compact_round_limit
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Noncollapse/Universal/Roundness/CompactLimit.lean
  lines:
  - 38
  - 61
```

# thm:ancient-universal

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#thm:ancient-universal
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:three-shrinkers]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#prop:ancient-avr]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#prop:bounded-ancient-zero-volume]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-compact-round-limit]]'
lean:
- declaration: PoincareMT.m22UniversalNoncollapsingAndZeroAVR
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Noncollapse/Universal/Proof.lean
  lines:
  - 23
  - 39
```

# thm:ancient-compactness

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#thm:ancient-compactness
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:ancient-universal]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:surface-ancient]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#prop:bounded-ancient-zero-volume]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-terminal-cylinder]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-collar-sides]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#lem:ancient-antipodal-collar]]'
lean:
- declaration: PoincareMT.m23NormalizedKappaCompactness
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/AncientKappa/Compactness/Proof.lean
  lines:
  - 106
  - 140
```

# rem:ancient-compactness-gaps

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#rem:ancient-compactness-gaps
uses: []
```

# thm:ancient-model-identifications

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ancient-models.tex#thm:ancient-model-identifications
uses:
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:three-shrinkers]]'
lean:
- declaration: PoincareMT.m24ModelCertificates
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Soliton/Models/Certificates.lean
  lines:
  - 29
  - 39
```
