# ch:relative-rigidity

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#ch:relative-rigidity
uses: []
```

# sec:relative-rigidity-model

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-rigidity-model
uses: []
```

# sec:relative-rigidity-contract

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-rigidity-contract
uses: []
```

# def:marked-relative-torus-rigidity

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#def:marked-relative-torus-rigidity
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:chartwise-sphere-ball]]'
- '[[PoincareConjecture/blueprint/chapters/relative-rigidity#thm:rigidity-index-zero]]'
- '[[PoincareConjecture/blueprint/chapters/relative-rigidity#thm:rigidity-index-one]]'
- '[[PoincareConjecture/blueprint/chapters/relative-rigidity#thm:rigidity-index-two]]'
lean:
- declaration: PoincareMT.M76.hasHamiltonRelativeTorusRigidity
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Rigidity/General/RelativePredicateClauses.lean
  lines:
  - 36
  - 51
```

# sec:relative-rigidity-producers

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-rigidity-producers
uses: []
```

# sec:constructed-inputs

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:constructed-inputs
uses: []
```

# sec:relative-rigidity-cuts

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-rigidity-cuts
uses: []
```

# sec:marked-hierarchy

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:marked-hierarchy
uses: []
```

# sec:relative-rigidity-index-one

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-rigidity-index-one
uses: []
```

# sec:index-one

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:index-one
uses: []
```

# thm:rigidity-index-one

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#thm:rigidity-index-one
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:chartwise-sphere-ball]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-standard-proper]]'
lean:
- declaration: PoincareMT.M76.exists_indexOne_lattice_rigidity
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Rigidity/IndexOne/LatticeRigidity.lean
  lines:
  - 18
  - 44
```

# sec:relative-rigidity-index-two

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-rigidity-index-two
uses: []
```

# sec:index-two

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:index-two
uses: []
```

# thm:rigidity-index-two

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#thm:rigidity-index-two
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:chartwise-sphere-ball]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-standard-proper]]'
lean:
- declaration: PoincareMT.M76.exists_indexTwo_lattice_rigidity
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Rigidity/General/IndexTwoRigidity.lean
  lines:
  - 43
  - 68
```

# sec:relative-rigidity-index-zero

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-rigidity-index-zero
uses: []
```

# sec:index-zero-final

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:index-zero-final
uses: []
```

# thm:rigidity-index-zero

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#thm:rigidity-index-zero
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:chartwise-sphere-ball]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-standard-proper]]'
lean:
- declaration: PoincareMT.M76.hasHamiltonRelativeTorusRigidity_of_card_zero_three
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Rigidity/General/IndexZeroRigidity.lean
  lines:
  - 87
  - 102
```

# thm:lower-handle-straightening

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#thm:lower-handle-straightening
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:protected-wall-core]]'
- '[[PoincareConjecture/blueprint/chapters/smoothing#def:generalized-dehn]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:protected-prime-replacement]]'
- '[[PoincareConjecture/blueprint/chapters/relative-rigidity#def:marked-relative-torus-rigidity]]'
lean:
- declaration: PoincareMT.M76.lowerCases_of_wall_dehn_prime
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Rigidity/Applications/HamiltonLowerHandles.lean
  lines:
  - 27
  - 51
```

# sec:relative-rigidity-sources

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-rigidity-sources
uses: []
```

# sec:relative-contracts-limitations

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/relative-rigidity.tex#sec:relative-contracts-limitations
uses: []
```
