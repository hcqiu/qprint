# ch:global-surgery-v4

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#ch:global-surgery-v4
uses: []
```

# sec:global-choice-order

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#sec:global-choice-order
uses: []
```

# thm:global-setup

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#thm:global-setup
uses:
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:cap-persistence]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#cor:singular-selector]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:metric-surgery]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-local]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-continuation]]'
lean:
- declaration: PoincareMT.repairedControlledSchedules
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Induction/Schedules/Main.lean
  lines:
  - 111
  - 127
```

# eq:global-height

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-height
uses: []
```

# eq:global-delta0

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-delta0
uses: []
```

# sec:global-prefixes

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#sec:global-prefixes
uses: []
```

# eq:global-entry

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-entry
uses: []
```

# thm:global-noncollapse

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#thm:global-noncollapse
uses:
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-setup]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m15-noncollapse]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:branch-continuation]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:cap-persistence]]'
lean:
- declaration: PoincareMT.m46NoncollapseInductionFromMilestones
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Noncollapse/Providers.lean
  lines:
  - 25
  - 34
```

# eq:global-noncollapse

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-noncollapse
uses: []
```

# thm:global-canonical

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#thm:global-canonical
uses:
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-noncollapse]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#thm:singular-m30]]'
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#thm:neck-cap-canonical]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:cap-persistence]]'
lean:
- declaration: PoincareMT.m47CanonicalInductionFromMilestones
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/CanonicalInduction/Providers.lean
  lines:
  - 36
  - 37
```

# eq:global-stability

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-stability
uses: []
```

# eq:global-profile

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-profile
uses: []
```

# sec:global-epoch

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#sec:global-epoch
uses: []
```

# thm:global-epoch

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#thm:global-epoch
uses:
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-setup]]'
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-canonical]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:branch-continuation]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#prop:unified-branch]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-pinching]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#thm:singular-m31]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#cor:singular-selector]]'
lean:
- declaration: PoincareMT.repairedEpochExtension
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Induction/EpochExtension.lean
  lines:
  - 127
  - 157
```

# eq:global-progress

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-progress
uses: []
```

# sec:global-volume-loss

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#sec:global-volume-loss
uses: []
```

# thm:global-volume-loss

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#thm:global-volume-loss
uses:
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-epoch]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:metric-surgery]]'
lean:
- declaration: PoincareMT.repairedVolumeLoss
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Volume/Surgery/VolumeLoss.lean
  lines:
  - 61
  - 162
```

# eq:global-event-volume

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-event-volume
uses: []
```

# eq:global-neck-loss

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-neck-loss
uses: []
```

# eq:global-cubic-loss

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-cubic-loss
uses: []
```

# eq:global-all-cap-loss

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-all-cap-loss
uses: []
```

# eq:global-volume-growth

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-volume-growth
uses: []
```

# sec:global-finiteness

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#sec:global-finiteness
uses: []
```

# thm:global-finiteness

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#thm:global-finiteness
uses:
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-volume-loss]]'
lean:
- declaration: PoincareMT.m50ObservedFiniteness_from_M49
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Volume/Surgery/Finiteness/Observed.lean
  lines:
  - 33
  - 56
- declaration: PoincareMT.repairedFinitePrefix
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Volume/Surgery/FinitePrefix.lean
  lines:
  - 35
  - 43
```

# sec:global-assembly

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#sec:global-assembly
uses: []
```

# eq:global-control-cutoff

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-control-cutoff
uses: []
```

# eq:global-initial-identification

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-initial-identification
uses: []
```

# thm:global-controlled-flow

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#thm:global-controlled-flow
uses:
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-setup]]'
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-epoch]]'
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-finiteness]]'
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-volume-loss]]'
lean:
- declaration: PoincareMT.repairedGlobalSchedule
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/GlobalSchedule/Main.lean
  lines:
  - 46
  - 65
- declaration: PoincareMT.repairedGlobalFlow
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Global/Existence.lean
  lines:
  - 51
  - 68
```

# sec:global-comparison-calibration

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#sec:global-comparison-calibration
uses: []
```

# eq:global-strict-control

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#eq:global-strict-control
uses: []
```

# sec:global-interfaces

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/global-surgery.tex#sec:global-interfaces
uses: []
```
