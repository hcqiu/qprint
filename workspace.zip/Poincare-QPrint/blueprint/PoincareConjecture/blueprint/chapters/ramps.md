# ch:ramps-v4

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#ch:ramps-v4
uses: []
```

# sec:ramps-purpose

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#sec:ramps-purpose
uses: []
```

# sec:ramps-corrected-evolution

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#sec:ramps-corrected-evolution
uses: []
```

# def:ramps-shrinking-curve

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#def:ramps-shrinking-curve
uses: []
lean:
- declaration: PoincareMT.M62ShrinkingCurve
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Evolution/Flow.lean
  lines:
  - 89
  - 108
```

# eq:ramps-speed

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-speed
uses: []
```

# eq:ramps-commutator

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-commutator
uses: []
```

# eq:ramps-curvature

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-curvature
uses: []
```

# eq:ramps-spacetime-curvature

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-spacetime-curvature
uses: []
```

# prop:ramps-regularization

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#prop:ramps-regularization
uses:
- '[[PoincareConjecture/blueprint/chapters/ramps#def:ramps-shrinking-curve]]'
lean:
- declaration: PoincareMT.m62CorrectedCurveEvolution_from_predecessors
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/CurveShortening/CorrectedEvolution.lean
  lines:
  - 45
  - 46
```

# prop:ramps-length-curvature

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#prop:ramps-length-curvature
uses:
- '[[PoincareConjecture/blueprint/chapters/ramps#prop:ramps-regularization]]'
lean:
- declaration: PoincareMT.m62CorrectedCurveEvolution_from_predecessors
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/CurveShortening/CorrectedEvolution.lean
  lines:
  - 45
  - 46
```

# eq:ramps-theta-integral

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-theta-integral
uses: []
```

# sec:ramps-circle

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#sec:ramps-circle
uses: []
```

# eq:ramps-slope

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-slope
uses: []
```

# sec:ramps-local-solutions

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#sec:ramps-local-solutions
uses: []
```

# thm:ramps-local

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#thm:ramps-local
uses:
- '[[PoincareConjecture/blueprint/chapters/ramps#def:ramps-shrinking-curve]]'
lean:
- declaration: PoincareMT.M63LocalCurveTheory
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Ramp/LocalFlowTheory.lean
  lines:
  - 29
  - 105
```

# eq:ramps-gauge

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-gauge
uses: []
```

# eq:ramps-speed-reconstruction

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-speed-reconstruction
uses: []
```

# sec:ramps-positive

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#sec:ramps-positive
uses: []
```

# def:ramps-ramp

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#def:ramps-ramp
uses:
- '[[PoincareConjecture/blueprint/chapters/ramps#def:ramps-shrinking-curve]]'
lean:
- declaration: PoincareMT.M63IsRampAt
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Ramp/Data.lean
  lines:
  - 108
  - 111
```

# prop:ramps-global

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#prop:ramps-global
uses:
- '[[PoincareConjecture/blueprint/chapters/ramps#def:ramps-ramp]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#prop:ramps-length-curvature]]'
lean:
- declaration: PoincareMT.m63RampEstimates_from_predecessors
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Ramp/Main.lean
  lines:
  - 126
  - 128
- declaration: PoincareMT.M63C2RampExistence
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Ramp/CurveEstimates.lean
  lines:
  - 138
  - 148
```

# eq:ramps-slope-lower

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-slope-lower
uses: []
```

# eq:ramps-forced-quotient

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-forced-quotient
uses: []
```

# thm:ramps-uniform-jets

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#thm:ramps-uniform-jets
uses:
- '[[PoincareConjecture/blueprint/chapters/ramps#prop:ramps-global]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#prop:ramps-length-curvature]]'
lean:
- declaration: PoincareMT.m63RampEstimates_from_predecessors
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Ramp/Main.lean
  lines:
  - 126
  - 128
- declaration: PoincareMT.M63UniformDerivativeEstimates
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Ramp/CurveEstimates.lean
  lines:
  - 165
  - 197
```

# eq:ramps-arc-loss

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-arc-loss
uses: []
```

# eq:ramps-local-turning

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#eq:ramps-local-turning
uses: []
```

# sec:ramps-polygons

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#sec:ramps-polygons
uses: []
```

# sec:ramps-family-approximation

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#sec:ramps-family-approximation
uses: []
```

# sec:ramps-family-solutions

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/ramps.tex#sec:ramps-family-solutions
uses: []
lean:
- declaration: PoincareMT.m63RampEstimates_from_predecessors
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Ramp/Main.lean
  lines:
  - 126
  - 128
```
