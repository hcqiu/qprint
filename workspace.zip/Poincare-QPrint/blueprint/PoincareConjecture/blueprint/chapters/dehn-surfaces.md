# ch:dehn-surfaces

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#ch:dehn-surfaces
uses: []
```

# sec:dehn-domains

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#sec:dehn-domains
uses: []
```

# def:dehn-pl-domain

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#def:dehn-pl-domain
uses: []
lean:
- declaration: PoincareMT.M76.PLDomain
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonGeometricInputs.lean
  lines:
  - 34
  - 42
```

# sec:dehn-marked-tower

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#sec:dehn-marked-tower
uses: []
```

# thm:dehn-marked-loop

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#thm:dehn-marked-loop
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#def:dehn-pl-domain]]'
lean:
- declaration: PoincareMT.M76.Dehn.exists_marked_boundary_PL_loop_disk
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Disks/MarkedLoopTheorem.lean
  lines:
  - 46
  - 67
```

# lem:dehn-boundary-rank

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#lem:dehn-boundary-rank
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#def:dehn-pl-domain]]'
lean:
- declaration: AbstractSimplicialComplex.boundary_incidence_rank_le_of_counts
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Annuli/Boundary/IncidenceRanks.lean
  lines:
  - 29
  - 56
```

# rem:dehn-local-review

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#rem:dehn-local-review
uses: []
```

# sec:dehn-proper-disk

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#sec:dehn-proper-disk
uses: []
```

# thm:dehn-standard-proper

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#thm:dehn-standard-proper
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-marked-loop]]'
lean:
- declaration: PoincareMT.M76.Dehn.exists_standard_proper_disk
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Disks/StandardProperDisk.lean
  lines:
  - 47
  - 80
```

# eq:dehn-collar-residual

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#eq:dehn-collar-residual
uses: []
```

# lem:dehn-chart-proper

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#lem:dehn-chart-proper
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-standard-proper]]'
lean:
- declaration: PoincareMT.M76.Dehn.exists_proper_disk_in_chart
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Disks/ChartProperDisk.lean
  lines:
  - 34
  - 80
```

# sec:dehn-protected-disks

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#sec:dehn-protected-disks
uses: []
```

# def:dehn-retained-block

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#def:dehn-retained-block
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#def:dehn-pl-domain]]'
lean:
- declaration: PoincareMT.M76.HamiltonRetainedBlockChart
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonProtectedGeometricInputs.lean
  lines:
  - 49
  - 58
```

# thm:dehn-protected-disks

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#thm:dehn-protected-disks
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#def:dehn-retained-block]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#lem:dehn-chart-proper]]'
lean:
- declaration: PoincareMT.M76.Dehn.ProtectedDisks.exists_protected_disk_pair
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Protected/Disks/Construction.lean
  lines:
  - 27
  - 71
```

# sec:dehn-terminal-annulus

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#sec:dehn-terminal-annulus
uses: []
```

# thm:dehn-terminal-annulus

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#thm:dehn-terminal-annulus
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#def:dehn-retained-block]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#lem:dehn-boundary-rank]]'
lean:
- declaration: PoincareMT.M76.Dehn.ProtectedAnnulus.ProtectedAnnulusTerminalData.exists_embedded_terminal_annulus
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Annuli/Descent/Tower/Terminal.lean
  lines:
  - 17
  - 41
```

# sec:dehn-annulus-descent

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#sec:dehn-annulus-descent
uses: []
```

# lem:dehn-annulus-decrease

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#lem:dehn-annulus-decrease
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#def:dehn-retained-block]]'
lean:
- declaration: PoincareMT.M76.Dehn.ProtectedAnnulus.exists_decreasing_planar_stage_annulus
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Annuli/Descent/Reduction/StageStep.lean
  lines:
  - 35
  - 119
```

# thm:dehn-protected-annulus

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#thm:dehn-protected-annulus
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#def:dehn-retained-block]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-terminal-annulus]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-annulus-termination]]'
lean:
- declaration: PoincareMT.M76.Dehn.ProtectedAnnulus.exists_embedded_chart_annulus
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Annuli/Descent/Tower/Original.lean
  lines:
  - 26
  - 50
- declaration: PoincareMT.M76.Dehn.ProtectedAnnulus.exists_protected_annulus_of_chart
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Protected/Annulus/Construction.lean
  lines:
  - 46
  - 129
```

# thm:dehn-annulus-termination

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#thm:dehn-annulus-termination
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#lem:dehn-annulus-decrease]]'
lean:
- declaration: PoincareMT.M76.Dehn.ProtectedAnnulus.exists_embedded_planar_stage_annulus
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Annuli/Descent/Reduction/Termination.lean
  lines:
  - 31
  - 58
```

# sec:dehn-enclosing-region

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#sec:dehn-enclosing-region
uses: []
```

# lem:dehn-sphere-separation

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#lem:dehn-sphere-separation
uses: []
lean:
- declaration: PoincareMT.M76.LocallyFlatTopologicalSphere.exists_bounded_complement_components
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Schoenflies/Regions/LocallyFlatBoundedRegion.lean
  lines:
  - 26
  - 74
```

# thm:dehn-enclosing-region

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#thm:dehn-enclosing-region
uses:
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-protected-disks]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-protected-annulus]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#lem:dehn-sphere-separation]]'
lean:
- declaration: PoincareMT.M76.Dehn.ProtectedAnnulus.nonempty_enclosing_region
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Protected/Annulus/EnclosingRegion.lean
  lines:
  - 23
  - 47
- declaration: PoincareMT.M76.Dehn.ProtectedDisks.nonempty_enclosing_region
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Dehn/Protected/Disks/EnclosingRegion.lean
  lines:
  - 23
  - 55
```

# sec:dehn-outputs

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/dehn-surfaces.tex#sec:dehn-outputs
uses: []
```
