# ch:ricci-flow-v4

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#ch:ricci-flow-v4
uses: []
```

# def:rf-flow

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#def:rf-flow
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-manifold]]'
lean:
- declaration: PoincareMT.RicciFlow
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Basic.lean
  lines:
  - 41
  - 57
```

# eq:rf-equation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-equation
uses: []
```

# sec:rf-normalization

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-normalization
uses: []
```

# eq:rf-scaling

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-scaling
uses: []
```

# def:rf-normalized

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#def:rf-normalized
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-manifold]]'
lean:
- declaration: PoincareMT.NormalizedInitialMetric
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Normalization/Definitions.lean
  lines:
  - 72
  - 85
```

# prop:rf-normalize

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#prop:rf-normalize
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-normalized]]'
lean:
- declaration: PoincareMT.existsNormalizedInitialMetric
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Normalization/Existence.lean
  lines:
  - 45
  - 87
```

# sec:rf-distance-comparison

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-distance-comparison
uses: []
```

# lem:rf-squared-distance-comparison

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-squared-distance-comparison
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-manifold]]'
lean:
- declaration: PoincareMT.RiemannianMetric.squared_distance_sub_sq_concave
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Comparison/Toponogov/Semiconcavity.lean
  lines:
  - 31
  - 73
- declaration: PoincareMT.RiemannianMetric.toponogov_hinge
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Comparison/Toponogov/Hinge.lean
  lines:
  - 29
  - 125
- declaration: PoincareMT.RiemannianMetric.toponogov_corresponding_side
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Comparison/Toponogov/Triangle.lean
  lines:
  - 27
  - 62
```

# sec:rf-local

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-local
uses: []
```

# thm:rf-local

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#thm:rf-local
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-short-time-family]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-uniqueness]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-continuation]]'
lean:
- declaration: PoincareMT.ricciFlowLocalTheory
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Local/ExistenceUniquenessContinuation.lean
  lines:
  - 70
  - 71
- declaration: PoincareMT.ricciFlowContinuation
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Local/ExistenceUniquenessContinuation.lean
  lines:
  - 40
  - 55
```

# lem:rf-short-time-family

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-short-time-family
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-flow]]'
lean:
- declaration: PoincareMT.exists_ricciFlow_metricFamily
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Local/ShortTime.lean
  lines:
  - 38
  - 45
```

# eq:rf-deturck

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-deturck
uses: []
```

# lem:rf-uniqueness

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-uniqueness
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-flow]]'
lean:
- declaration: PoincareMT.ricciFlowUniqueness
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Local/ShortTime.lean
  lines:
  - 64
  - 65
```

# lem:rf-continuation

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-continuation
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-short-time-family]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-uniqueness]]'
lean:
- declaration: PoincareMT.ricciFlowContinuation
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Local/ExistenceUniquenessContinuation.lean
  lines:
  - 40
  - 55
```

# sec:rf-curvature

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-curvature
uses: []
```

# prop:rf-evolution

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#prop:rf-evolution
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-flow]]'
lean:
- declaration: PoincareMT.RicciFlow.hasDerivWithinAt_scalarCurvature
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Curvature/Evolution/Scalar/Within.lean
  lines:
  - 322
  - 340
- declaration: PoincareMT.RicciFlow.hasDerivWithinAt_curvatureTensor
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Curvature/Evolution/Tensor/Within.lean
  lines:
  - 34
  - 44
- declaration: PoincareMT.RicciFlow.hasDerivWithinAt_ricci
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Curvature/Evolution/Tensor/Within.lean
  lines:
  - 47
  - 56
```

# thm:rf-shi

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#thm:rf-shi
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.local_curvatureDerivative_bound
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Curvature/Estimates/Derivative.lean
  lines:
  - 313
  - 347
- declaration: PoincareMT.local_curvatureDerivative_bound_of_initial
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Curvature/Estimates/Derivative.lean
  lines:
  - 350
  - 378
```

# prop:rf-metric-comparison

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#prop:rf-metric-comparison
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-flow]]'
lean:
- declaration: PoincareMT.RicciFlow.metric_comparison_of_curvature_bound
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/MetricComparison/Curvature.lean
  lines:
  - 29
  - 109
```

# prop:rf-scalar

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#prop:rf-scalar
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.RicciFlow.scalarCurvature_lowerBound
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Curvature/Bounds/Scalar.lean
  lines:
  - 52
  - 65
- declaration: PoincareMT.RicciFlow.scalarCurvature_lowerBound_three
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Curvature/Bounds/Scalar.lean
  lines:
  - 70
  - 91
```

# prop:rf-positivity

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#prop:rf-positivity
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.RicciFlow.nonnegativeSectionalCurvature_preserved
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Positivity/Preservation.lean
  lines:
  - 35
  - 39
- declaration: PoincareMT.RicciFlow.nonnegativeRicciCurvature_preserved
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Positivity/Preservation.lean
  lines:
  - 42
  - 46
- declaration: PoincareMT.RicciFlow.flat_of_scalarCurvature_eq_zero
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Positivity/Preservation.lean
  lines:
  - 52
  - 98
```

# sec:rf-pinching

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-pinching
uses: []
```

# eq:rf-spectrum

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-spectrum
uses: []
```

# def:rf-pinched

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#def:rf-pinched
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-flow]]'
lean:
- declaration: PoincareMT.HamiltonIveyPinchedAt
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Pinching/Conclusion.lean
  lines:
  - 22
  - 33
```

# eq:rf-log-pinching

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-log-pinching
uses: []
```

# thm:rf-pinching

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#thm:rf-pinching
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-pinched]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-scalar]]'
lean:
- declaration: PoincareMT.hamiltonIveyPinching
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Pinching.lean
  lines:
  - 27
  - 47
- declaration: Poincare.fullNorm_le_of_hamiltonIvey
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Pinching/Bounds.lean
  lines:
  - 48
  - 62
```

# eq:rf-full-bound

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-full-bound
uses: []
```

# sec:rf-harnack

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-harnack
uses: []
```

# thm:rf-harnack

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#thm:rf-harnack
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-bounded-harnack]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-slab-bound]]'
lean:
- declaration: PoincareMT.differentialHarnackAncientTheory
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Theorem.lean
  lines:
  - 23
  - 25
```

# eq:rf-harnack

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-harnack
uses: []
```

# eq:rf-harnack-path

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-harnack-path
uses: []
```

# prop:rf-bounded-harnack

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#prop:rf-bounded-harnack
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-shi]]'
lean:
- declaration: Poincare.RicciFlow.Harnack.hamiltonBlockPos_on_bounded_slab
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/BoundedFlow.lean
  lines:
  - 96
  - 162
- declaration: Poincare.RicciFlow.Harnack.ancient_differential_of_bounded_curvature
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/BoundedFlow.lean
  lines:
  - 246
  - 296
```

# lem:rf-initial-volume

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-initial-volume
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-squared-distance-comparison]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.RicciFlow.exists_initial_unit_ball_volume_lower_bound_on_component
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/InitialVolume.lean
  lines:
  - 41
  - 70
```

# sec:rf-scalar-integral

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-scalar-integral
uses: []
```

# thm:rf-scalar-integral

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#thm:rf-scalar-integral
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-squared-distance-comparison]]'
lean:
- declaration: PoincareMT.exists_uniform_unitBall_scalar_integral_bound
  file: PoincareConjecture/PoincareLib/Geometry/Curvature/Integral/Scalar.lean
  lines:
  - 185
  - 208
```

# lem:rf-volume-loss

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-volume-loss
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-scalar-integral]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.RicciFlow.exists_uniform_unitBall_volume_lower_bound
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/CurvatureControl/ScalarIntegral.lean
  lines:
  - 25
  - 49
```

# lem:rf-time-scalar

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-time-scalar
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-volume-loss]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-compactness]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#prop:bounded-ancient-zero-volume]]'
lean:
- declaration: PoincareMT.RicciFlow.exists_time_mul_scalarCurvature_bound_of_unit_ball_volume
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/CurvatureControl/VolumeToCurvature.lean
  lines:
  - 112
  - 134
```

# lem:rf-local-scalar

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-local-scalar
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-shi]]'
lean:
- declaration: PoincareMT.RicciFlow.exists_local_scalar_curvature_constant
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/CurvatureControl/ScalarEstimate.lean
  lines:
  - 241
  - 265
```

# eq:rf-chen-local

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-chen-local
uses: []
```

# lem:rf-right-bound

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-right-bound
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-initial-volume]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-volume-loss]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-time-scalar]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-local-scalar]]'
lean:
- declaration: PoincareMT.RicciFlow.exists_right_curvatureTensorNorm_bound_on_component_of_bounded_ancient_zero_volume
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/CurvatureControl/VolumeToCurvature.lean
  lines:
  - 139
  - 180
```

# lem:rf-slab-bound

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-slab-bound
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-bounded-harnack]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#lem:rf-right-bound]]'
lean:
- declaration: Poincare.RicciFlow.Harnack.exists_uniform_bound_of_local_right_bound_and_harnack
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Noncompact/CurvatureControl.lean
  lines:
  - 138
  - 198
```

# cor:rf-ancient-harnack

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#cor:rf-ancient-harnack
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-harnack]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: Poincare.Geometry.RicciFlow.Harnack.ancient_differential_of_finite
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Ancient.lean
  lines:
  - 174
  - 249
- declaration: Poincare.Geometry.RicciFlow.Harnack.ancient_integrated_of_finite_integrated
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Harnack/Ancient.lean
  lines:
  - 253
  - 313
```

# sec:rf-harmonic-coordinates

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-harmonic-coordinates
uses: []
```

# thm:rf-harmonic-radius

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#thm:rf-harmonic-radius
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-manifold]]'
lean:
- declaration: PoincareMT.RiemannianMetric.exists_uniform_harmonic_radius
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/Coordinates/Harmonic/Radius.lean
  lines:
  - 45
  - 160
```

# sec:rf-weak-harmonic-replacements

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-weak-harmonic-replacements
uses: []
```

# eq:rf-radial-frame

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-radial-frame
uses: []
```

# eq:rf-harmonic-replacement

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-harmonic-replacement
uses: []
```

# eq:rf-correction-energy

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-correction-energy
uses: []
```

# eq:rf-power-energy

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-power-energy
uses: []
```

# eq:rf-hessian-divergence

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#eq:rf-hessian-divergence
uses: []
```

# sec:rf-compactness

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-compactness
uses: []
```

# def:rf-pointed-convergence

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#def:rf-pointed-convergence
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-flow]]'
lean:
- declaration: PoincareMT.PointedGeometricConvergence
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Compactness/Convergence.lean
  lines:
  - 52
  - 110
```

# thm:rf-compactness

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#thm:rf-compactness
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-pointed-convergence]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-shi]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-metric-comparison]]'
lean:
- declaration: PoincareMT.pointedRicciFlowCompactness
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Compactness/Coordinates/SpacetimeBounds/Compactness.lean
  lines:
  - 27
  - 31
```

# lem:rf-limit-static-noncollapse

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#lem:rf-limit-static-noncollapse
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-pointed-convergence]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-compactness]]'
lean:
- declaration: PoincareMT.PointedGeometricConvergence.eventually_ball_volume_bounds_at
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Compactness/Convergence/Volume/AtPoint.lean
  lines:
  - 60
  - 134
- declaration: PoincareMT.PointedGeometricConvergence.ball_volume_lower_bound_of_eventually_static_noncollapse
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Compactness/Convergence/Volume/Noncollapse.lean
  lines:
  - 69
  - 98
```

# sec:rf-interfaces

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/ricci-flow.tex#sec:rf-interfaces
uses: []
```
