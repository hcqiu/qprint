# ch:compact-cores

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#ch:compact-cores
uses: []
```

# sec:compact-core-definitions

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:compact-core-definitions
uses: []
```

# def:compact-pl-domain

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#def:compact-pl-domain
uses: []
lean:
- declaration: PoincareMT.M76.PLDomain
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonGeometricInputs.lean
  lines:
  - 34
  - 42
```

# def:one-simply-connected-end

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#def:one-simply-connected-end
uses: []
lean:
- declaration: PoincareMT.M76.HasOneSimplyConnectedEnd
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonGeometricInputs.lean
  lines:
  - 88
  - 92
```

# def:chartwise-sphere-ball

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#def:chartwise-sphere-ball
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:compact-pl-domain]]'
lean:
- declaration: PoincareMT.M76.ChartwisePLSphere
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonGeometricInputs.lean
  lines:
  - 47
  - 51
- declaration: PoincareMT.M76.ChartwisePLBall
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonGeometricInputs.lean
  lines:
  - 57
  - 64
- declaration: PoincareMT.M76.IsPLIrreducible
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonPLIrreducibility.lean
  lines:
  - 26
  - 30
```

# sec:weak-end-core

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:weak-end-core
uses: []
```

# eq:protected-frontiers

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#eq:protected-frontiers
uses: []
```

# sec:compression-minimality

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:compression-minimality
uses: []
```

# def:compression-complexity

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#def:compression-complexity
uses: []
lean:
- declaration: PoincareMT.M76.Wall.compressionComplexity
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/CompactCore/General/CompressionComplexity.lean
  lines:
  - 21
  - 22
```

# prop:compact-core-incompressibility

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#prop:compact-core-incompressibility
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:compression-complexity]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:compact-pl-domain]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:one-simply-connected-end]]'
lean:
- declaration: PoincareMT.M76.exists_protected_core_without_essential_disk
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/CompactCore/Disks/MinimalCoreDiskIncompressibility.lean
  lines:
  - 24
  - 79
```

# sec:spherical-frontier

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:spherical-frontier
uses: []
```

# thm:compact-spherical-frontier

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:compact-spherical-frontier
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#prop:compact-core-incompressibility]]'
- '[[PoincareConjecture/blueprint/chapters/dehn-surfaces#thm:dehn-marked-loop]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:chartwise-sphere-ball]]'
lean:
- declaration: PoincareMT.M76.exists_original_terminal_spherical_family
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/CompactCore/Spheres/TerminalSphericalFamily.lean
  lines:
  - 28
  - 78
```

# sec:compact-core-filling

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:compact-core-filling
uses: []
```

# sec:sphere-merging

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:sphere-merging
uses: []
```

# thm:compact-single-sphere

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:compact-single-sphere
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:compact-spherical-frontier]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:one-simply-connected-end]]'
lean:
- declaration: PoincareMT.M76.exists_single_spherical_frontier_of_finite_family
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/CompactCore/Spheres/SingleSphericalFrontier.lean
  lines:
  - 88
  - 118
```

# thm:protected-wall-core

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:protected-wall-core
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:compact-spherical-frontier]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:compact-single-sphere]]'
lean:
- declaration: PoincareMT.M76.hasWallCompactCore
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/CompactCore/WallCompactCore.lean
  lines:
  - 20
  - 31
```

# sec:marked-handles

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:marked-handles
uses: []
```

# def:protected-marked-ball

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#def:protected-marked-ball
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:chartwise-sphere-ball]]'
lean:
- declaration: PoincareMT.M76.HamiltonMarkedProtectedBall
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/Triangulation/Handles/HamiltonProtectedGeometricInputs.lean
  lines:
  - 224
  - 239
```

# thm:protected-prime-replacement

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:protected-prime-replacement
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:protected-marked-ball]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:prime-index-zero]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:prime-index-one]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:prime-index-two]]'
lean:
- declaration: PoincareMT.M76.hasHamiltonProtectedIrreducibleReplacement
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/PrimeReduction/Handles/ProtectedIrreducibleReplacement.lean
  lines:
  - 35
  - 50
```

# sec:prime-replacement

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:prime-replacement
uses: []
```

# def:marked-sphere-cut

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#def:marked-sphere-cut
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:chartwise-sphere-ball]]'
lean:
- declaration: PoincareMT.M76.MarkedSphereCut
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/PrimeReduction/Cutting/MarkedSphereCut.lean
  lines:
  - 15
  - 42
```

# thm:prime-sphere-bound

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:prime-sphere-bound
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:marked-sphere-cut]]'
lean:
- declaration: PoincareMT.M76.HasNoPuncturedSphereComponents.card_le_original_model_bound
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/PrimeReduction/Counting/OriginalRelativeSphereBound.lean
  lines:
  - 18
  - 104
```

# eq:prime-sphere-bound

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#eq:prime-sphere-bound
uses: []
```

# sec:prime-capping

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:prime-capping
uses: []
```

# thm:prime-maximal-cut

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:prime-maximal-cut
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:prime-sphere-bound]]'
- '[[PoincareConjecture/blueprint/chapters/compact-cores#def:chartwise-sphere-ball]]'
lean:
- declaration: PoincareMT.M76.exists_maximal_original_sphere_cut
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/PrimeReduction/Counting/MaximalOriginalSphereCut.lean
  lines:
  - 24
  - 99
```

# sec:prime-index-cases

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:prime-index-cases
uses: []
```

# thm:prime-index-zero

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:prime-index-zero
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:prime-maximal-cut]]'
lean:
- declaration: PoincareMT.M76.hasHamiltonProtectedIrreducibleReplacement_of_card_eq_zero
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/PrimeReduction/Handles/ZeroProtectedIrreducibleReplacement.lean
  lines:
  - 18
  - 36
```

# thm:prime-index-one

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:prime-index-one
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:prime-maximal-cut]]'
lean:
- declaration: PoincareMT.M76.hasHamiltonProtectedIrreducibleReplacement_of_card_eq_one
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/PrimeReduction/Handles/ProtectedIrreducibleReplacement.lean
  lines:
  - 18
  - 31
```

# thm:prime-index-two

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#thm:prime-index-two
uses:
- '[[PoincareConjecture/blueprint/chapters/compact-cores#thm:prime-maximal-cut]]'
lean:
- declaration: PoincareMT.M76.hasHamiltonProtectedIrreducibleReplacement_of_card_eq_two
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Smoothing/PrimeReduction/Handles/IndexTwoProtectedIrreducibleReplacement.lean
  lines:
  - 19
  - 50
```

# sec:compact-core-contracts

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/compact-cores.tex#sec:compact-core-contracts
uses: []
```
