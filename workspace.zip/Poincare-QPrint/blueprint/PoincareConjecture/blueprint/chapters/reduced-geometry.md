# ch:reduced-geometry

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#ch:reduced-geometry
uses: []
```

# def:reduced-length

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#def:reduced-length
uses: []
lean:
- declaration: PoincareMT.reducedLength
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/LGeometry/Basic.lean
  lines:
  - 415
  - 422
- declaration: PoincareMT.BackwardTimePath
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/LGeometry/Basic.lean
  lines:
  - 109
  - 119
```

# thm:m08-l-geodesics

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#thm:m08-l-geodesics
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:reduced-length]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.lGeodesicExistenceAndVariation
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/LGeometry/Existence.lean
  lines:
  - 38
  - 78
```

# eq:regularized-action

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#eq:regularized-action
uses: []
```

# eq:first-variation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#eq:first-variation
uses: []
```

# def:reduced-regular-branch

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#def:reduced-regular-branch
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:reduced-length]]'
lean:
- declaration: PoincareMT.ReducedLengthRegularPoint
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/ReducedLength/Basic.lean
  lines:
  - 61
  - 104
- declaration: PoincareMT.reducedHarnackIntegral
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/ReducedLength/Basic.lean
  lines:
  - 41
  - 44
```

# thm:m09-differential

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#thm:m09-differential
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m08-l-geodesics]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:reduced-regular-branch]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.ReducedLengthDifferentialTheory
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/ReducedLength/Theory.lean
  lines:
  - 26
  - 98
- declaration: PoincareMT.reducedLengthDifferentialInequalities
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/ReducedLength/DifferentialInequalities.lean
  lines:
  - 51
  - 83
```

# def:reduced-volume

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#def:reduced-volume
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:reduced-length]]'
lean:
- declaration: PoincareMT.reducedVolume
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/ReducedVolume/Basic.lean
  lines:
  - 46
  - 49
- declaration: PoincareMT.reducedVolumeDensity
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/ReducedVolume/Basic.lean
  lines:
  - 32
  - 36
```

# thm:m10-reduced-volume

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#thm:m10-reduced-volume
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:reduced-volume]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m09-differential]]'
lean:
- declaration: PoincareMT.reducedVolumeMonotonicity
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/ReducedGeometry/ReducedVolume/Monotonicity.lean
  lines:
  - 51
  - 80
```

# eq:reduced-weak-inequalities

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#eq:reduced-weak-inequalities
uses: []
```

# def:generalized-spacetime

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#def:generalized-spacetime
uses: []
lean:
- declaration: PoincareMT.GeneralizedFlowSpacetime
  file: PoincareConjecture/PoincareLib/Geometry/Spacetime/Basic.lean
  lines:
  - 48
  - 99
```

# thm:m11-m12-gauge

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#thm:m11-m12-gauge
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:generalized-spacetime]]'
lean:
- declaration: PoincareMT.generalizedSpacetimeRealization
  file: PoincareConjecture/PoincareLib/Geometry/Spacetime/Realization.lean
  lines:
  - 28
  - 40
- declaration: PoincareMT.GeneralizedRicciGaugeTheory
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/Gauge/Geometry.lean
  lines:
  - 43
  - 72
- declaration: PoincareMT.generalizedRicciGaugeGeometry
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/Gauge/Assembly.lean
  lines:
  - 217
  - 224
```

# thm:m13-rescaling

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#thm:m13-rescaling
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m11-m12-gauge]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:reduced-length]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:reduced-volume]]'
lean:
- declaration: PoincareMT.ParabolicSpacetimeRescaling
  file: PoincareConjecture/PoincareLib/Geometry/Spacetime/Rescaling/Basic.lean
  lines:
  - 32
  - 94
- declaration: PoincareMT.generalizedParabolicRescaling
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Rescaling/Generalized.lean
  lines:
  - 31
  - 49
```

# def:generalized-stable-paths

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#def:generalized-stable-paths
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m11-m12-gauge]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:reduced-regular-branch]]'
lean:
- declaration: PoincareMT.M14BackwardPath
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/ReducedGeometry/Basic.lean
  lines:
  - 56
  - 75
- declaration: PoincareMT.M14StableSet
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/ReducedGeometry/Exponential.lean
  lines:
  - 232
  - 288
```

# prop:positive-start

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#prop:positive-start
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:generalized-stable-paths]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m08-l-geodesics]]'
lean:
- declaration: PoincareMT.M14.positiveStartCorrectionStatement
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/ReducedGeometry/Regularity/PositiveStart/PositiveStartCorrection.lean
  lines:
  - 30
  - 59
```

# thm:m14-generalized

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#thm:m14-generalized
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#prop:positive-start]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m10-reduced-volume]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m13-rescaling]]'
lean:
- declaration: PoincareMT.generalizedLGeometryTheory
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/ReducedGeometry/Proof.lean
  lines:
  - 98
  - 108
```

# def:parabolic-noncollapse

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#def:parabolic-noncollapse
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:generalized-spacetime]]'
lean:
- declaration: PoincareMT.M15GeneralizedNoncollapseAt
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/Noncollapse/Provider.lean
  lines:
  - 20
  - 33
```

# thm:m15-noncollapse

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#thm:m15-noncollapse
uses:
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#def:parabolic-noncollapse]]'
- '[[PoincareConjecture/blueprint/chapters/reduced-geometry#thm:m14-generalized]]'
lean:
- declaration: PoincareMT.noncollapsingGeneralizedAndCompact
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/Noncollapse/Proof.lean
  lines:
  - 56
  - 72
```

# eq:noncollapse-lower

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/reduced-geometry.tex#eq:noncollapse-lower
uses: []
```
