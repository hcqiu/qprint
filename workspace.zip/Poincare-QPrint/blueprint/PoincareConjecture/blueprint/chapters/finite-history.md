# ch:finite-history-v4

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#ch:finite-history-v4
uses: []
```

# sec:finite-event-ledger

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#sec:finite-event-ledger
uses: []
```

# eq:finite-ledger

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:finite-ledger
uses: []
```

# eq:global-discarded-index

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:global-discarded-index
uses: []
```

# def:finite-smooth-assembly

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#def:finite-smooth-assembly
uses: []
lean:
- declaration: PoincareMT.SmoothFiniteConnectedSumAssembly
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ConnectedSum/Basic.lean
  lines:
  - 80
  - 85
```

# lem:finite-assembly-transport

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#lem:finite-assembly-transport
uses:
- '[[PoincareConjecture/blueprint/chapters/finite-history#def:finite-smooth-assembly]]'
lean:
- declaration: PoincareMT.SmoothFiniteConnectedSumAssembly.nonempty_transportTarget
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ConnectedSum/Transport.lean
  lines:
  - 137
  - 153
```

# lem:finite-event-references

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#lem:finite-event-references
uses:
- '[[PoincareConjecture/blueprint/chapters/finite-history#lem:finite-assembly-transport]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:surgery-local-topology]]'
lean:
- declaration: PoincareMT.m72LocalTopologyFromRaw
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reconstruction/LocalTopology.lean
  lines:
  - 215
  - 239
```

# sec:finite-successors

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#sec:finite-successors
uses: []
```

# eq:successor-slab

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:successor-slab
uses: []
```

# eq:successor-diffeo

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:successor-diffeo
uses: []
```

# eq:successor-component

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:successor-component
uses: []
```

# sec:finite-substitution

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#sec:finite-substitution
uses: []
```

# eq:local-split

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:local-split
uses: []
```

# eq:tail-equivalence

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:tail-equivalence
uses: []
```

# sec:finite-reverse-induction

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#sec:finite-reverse-induction
uses: []
```

# eq:reverse-invariant

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:reverse-invariant
uses: []
```

# prop:connected-sum-reconstruction

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#prop:connected-sum-reconstruction
uses:
- '[[PoincareConjecture/blueprint/chapters/finite-history#lem:finite-event-references]]'
- '[[PoincareConjecture/blueprint/chapters/finite-history#lem:finite-assembly-transport]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-global-extinction]]'
lean:
- declaration: PoincareMT.m72FiniteReconstruction
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Reconstruction/Main.lean
  lines:
  - 30
  - 33
```

# sec:m82-factor-ledger

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#sec:m82-factor-ledger
uses: []
```

# eq:m82-ledger

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#eq:m82-ledger
uses: []
```

# sec:finite-history-contracts

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/finite-history.tex#sec:finite-history-contracts
uses: []
```
