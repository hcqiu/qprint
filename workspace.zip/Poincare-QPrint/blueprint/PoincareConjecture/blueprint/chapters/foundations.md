# ch:foundations-v4

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#ch:foundations-v4
uses: []
```

# sec:foundations-endpoints

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-endpoints
uses: []
```

# def:foundations-manifold

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#def:foundations-manifold
uses: []
lean:
- declaration: PoincareMT.SmoothPoincare
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Statement.lean
  lines:
  - 24
  - 28
- declaration: PoincareMT.TopologicalPoincare
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare/Statement.lean
  lines:
  - 31
  - 34
```

# thm:foundations-targets

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#thm:foundations-targets
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-manifold]]'
lean:
- declaration: PoincareMT.smoothPoincareSkeleton
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare.lean
  lines:
  - 23
  - 24
- declaration: PoincareMT.topologicalPoincareSkeleton
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Poincare.lean
  lines:
  - 30
  - 32
```

# prop:foundations-initial

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#prop:foundations-initial
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-triangulation]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-determinant-cover]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#cor:foundations-homotopy-groups]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-cw-equivalence]]'
lean:
- declaration: PoincareMT.closedSimplyConnectedThreeManifoldTopology
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/ClosedSimplyConnected.lean
  lines:
  - 33
  - 38
```

# sec:foundations-triangulation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-triangulation
uses: []
```

# lem:foundations-affine-avoidance

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#lem:foundations-affine-avoidance
uses: []
lean:
- declaration: Poincare.Topology.exists_ball_point_avoiding_affine_planes
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/Triangulation/Ambient/AmbientFiniteSlabAvoidance.lean
  lines:
  - 142
  - 252
```

# lem:foundations-join-clearance

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#lem:foundations-join-clearance
uses: []
lean:
- declaration: Poincare.Topology.affine_join_distance_lower_bound
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/Triangulation/Ambient/AmbientFiniteSlabAvoidance.lean
  lines:
  - 256
  - 324
```

# prop:foundations-embedded-triangulation

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#prop:foundations-embedded-triangulation
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-affine-avoidance]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-join-clearance]]'
lean:
- declaration: Poincare.Topology.exists_embedded_three_finite_triangulation
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/Triangulation/Embedded/EmbeddedThreeTriangulation.lean
  lines:
  - 22
  - 74
```

# prop:foundations-triangulation

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#prop:foundations-triangulation
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-embedded-triangulation]]'
lean:
- declaration: Poincare.Topology.exists_compact_three_manifold_finite_triangulation
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/Triangulation/Polyhedral/ThreeManifoldTriangulation.lean
  lines:
  - 54
  - 77
- declaration: Poincare.Topology.exists_finite_simplicialCW
  file: PoincareConjecture/PoincareLib/Topology/CWComplex/Construction/SimplicialCW.lean
  lines:
  - 85
  - 198
- declaration: Poincare.Topology.exists_finiteCW_of_homeomorph
  file: PoincareConjecture/PoincareLib/Topology/CWComplex/Construction/CWTransport.lean
  lines:
  - 22
  - 116
```

# sec:foundations-orientation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-orientation
uses: []
```

# def:foundations-chart-signs

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#def:foundations-chart-signs
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-manifold]]'
lean:
- declaration: PoincareMT.OrientationCompatibleAtlas
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/Orientation/Basic.lean
  lines:
  - 22
  - 42
```

# lem:foundations-determinant-cover

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#lem:foundations-determinant-cover
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-chart-signs]]'
lean:
- declaration: Poincare.Topology.nonempty_orientationCompatibleAtlas
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/Orientation/Existence.lean
  lines:
  - 23
  - 154
```

# def:foundations-local-orientation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#def:foundations-local-orientation
uses: []
```

# lem:foundations-coherent

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#lem:foundations-coherent
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-manifold]]'
lean:
- declaration: Poincare.Topology.exists_integralThreeLocallyRepresentedGenerators
  file: PoincareConjecture/PoincareLib/AlgebraicTopology/SingularHomology/Orientation/IntegralManifoldOrientation.lean
  lines:
  - 120
  - 134
```

# sec:foundations-top-homology

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-top-homology
uses: []
```

# lem:foundations-support-gluing

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#lem:foundations-support-gluing
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-coherent]]'
lean:
- declaration: Poincare.Topology.integralThreeManifoldCompactSupport
  file: PoincareConjecture/PoincareLib/AlgebraicTopology/SingularHomology/Relative/IntegralManifoldSupport.lean
  lines:
  - 25
  - 67
- declaration: Poincare.Topology.exists_unique_integralSupportHomology_compact_gluing
  file: PoincareConjecture/PoincareLib/AlgebraicTopology/SingularHomology/Relative/IntegralCompactGluing.lean
  lines:
  - 139
  - 177
```

# prop:foundations-top-homology

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#prop:foundations-top-homology
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-support-gluing]]'
lean:
- declaration: Poincare.Topology.nonempty_integralSupportHomologyUniv_equiv_int
  file: PoincareConjecture/PoincareLib/AlgebraicTopology/SingularHomology/Chains/IntegralTopCoefficient.lean
  lines:
  - 66
  - 112
```

# sec:foundations-second-homology

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-second-homology
uses: []
```

# def:foundations-cap-property

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#def:foundations-cap-property
uses: []
```

# eq:foundations-cap-property

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#eq:foundations-cap-property
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-support-gluing]]'
lean:
- declaration: Poincare.Topology.integralOpenCapProperty
  file: PoincareConjecture/PoincareLib/AlgebraicTopology/SingularHomology/Duality/CapProduct/IntegralOpenCapProperty.lean
  lines:
  - 20
  - 40
```

# lem:foundations-cap-union

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#lem:foundations-cap-union
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-cap-property]]'
lean:
- declaration: Poincare.Topology.integralOpenCapProperty_union
  file: PoincareConjecture/PoincareLib/AlgebraicTopology/SingularHomology/Duality/CapProduct/IntegralOpenCapUnion.lean
  lines:
  - 50
  - 74
```

# lem:foundations-chart-cap

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#lem:foundations-chart-cap
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-cap-union]]'
lean:
- declaration: Poincare.Topology.integralOpenCapProperty_of_chart
  file: PoincareConjecture/PoincareLib/AlgebraicTopology/SingularHomology/Duality/CapProduct/IntegralChartCapInduction.lean
  lines:
  - 177
  - 207
```

# prop:foundations-second-homology

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#prop:foundations-second-homology
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-chart-cap]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-cap-union]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-triangulation]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#lem:foundations-coherent]]'
lean:
- declaration: Poincare.Topology.integralThreeManifoldHomologyTwo_isZero
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/Homology/H2.lean
  lines:
  - 108
  - 128
```

# sec:foundations-hurewicz

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-hurewicz
uses: []
```

# cor:foundations-homotopy-groups

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#cor:foundations-homotopy-groups
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-top-homology]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-second-homology]]'
lean:
- declaration: Poincare.Topology.nonempty_threeManifoldTopologyConclusion_of_integralHomology_two_isZero
  file: PoincareConjecture/PoincareLib/Topology/Manifold/ThreeDimensional/Homotopy.lean
  lines:
  - 113
  - 165
```

# sec:foundations-cw-equivalence

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-cw-equivalence
uses: []
```

# prop:foundations-cw-equivalence

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#prop:foundations-cw-equivalence
uses: []
lean:
- declaration: Poincare.Topology.nonempty_homotopyEquiv_sphere_of_cw_three_pi_int
  file: PoincareConjecture/PoincareLib/Topology/CWComplex/ThreeDimensional/CWThreeSphere.lean
  lines:
  - 44
  - 64
```

# sec:foundations-projective-plane

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-projective-plane
uses: []
```

# def:foundations-projective-neighborhood

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#def:foundations-projective-neighborhood
uses: []
lean:
- declaration: PoincareMT.NoTrivialNormalProjectivePlane
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Global/Certificate.lean
  lines:
  - 27
  - 29
```

# prop:foundations-projective-exclusion

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#prop:foundations-projective-exclusion
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-chart-signs]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-projective-neighborhood]]'
lean:
- declaration: PoincareMT.m83OrientationExclusion
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Orientation/ProjectivePlane/Exclusion.lean
  lines:
  - 32
  - 45
```

# sec:foundations-route

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/foundations.tex#sec:foundations-route
uses: []
```
