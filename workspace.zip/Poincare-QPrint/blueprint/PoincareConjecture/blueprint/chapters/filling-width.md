# ch:filling-width-v4

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#ch:filling-width-v4
uses: []
```

# sec:filling-surgery-spheres

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-surgery-spheres
uses: []
```

# prop:filling-sphere-separation

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-sphere-separation
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-second-homology]]'
lean:
- declaration: PoincareMT.repairedSphereSeparation
  file: PoincareConjecture/PoincareLib/Topology/Manifold/EmbeddedSphere/Separation.lean
  lines:
  - 34
  - 42
```

# prop:filling-group-effects

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-group-effects
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-sphere-separation]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:surgery-local-topology]]'
lean:
- declaration: PoincareMT.repairedSurgeryGroupEffects
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/GroupEffects/ConnectedSum/Reconstruction.lean
  lines:
  - 94
  - 100
```

# prop:filling-child-components

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-child-components
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-group-effects]]'
lean:
- declaration: PoincareMT.repairedChildComponents
  file: PoincareConjecture/PoincareLib/Topology/Manifold/Surgery/Children/Main.lean
  lines:
  - 34
  - 36
```

# sec:filling-component-ancestry

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-component-ancestry
uses: []
```

# prop:filling-component-ancestry

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-component-ancestry
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-child-components]]'
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-finiteness]]'
lean:
- declaration: PoincareMT.repairedFiniteAncestry
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Ancestry/Finite/Main.lean
  lines:
  - 67
  - 71
```

# sec:filling-ancestry-transport

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-ancestry-transport
uses: []
```

# prop:filling-ancestry-transport

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-ancestry-transport
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-component-ancestry]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:comparison-transport]]'
lean:
- declaration: PoincareMT.repairedAncestryTransport
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Ancestry/Transport/Main.lean
  lines:
  - 40
  - 44
```

# sec:filling-loop-class

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-loop-class
uses: []
```

# prop:filling-loop-identification

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-loop-identification
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#cor:foundations-homotopy-groups]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-cw-equivalence]]'
lean:
- declaration: PoincareMT.m59LoopClassesAndComponentTopology
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Class/Topology/Main.lean
  lines:
  - 62
  - 68
```

# sec:filling-relative-square

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-relative-square
uses: []
```

# sec:filling-short-loops

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-short-loops
uses: []
```

# lem:filling-boundary-regularization

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#lem:filling-boundary-regularization
uses: []
lean:
- declaration: PoincareMT.m60Disk_regularize_boundary
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/LoopSpace/Area/Boundary/Regularization.lean
  lines:
  - 26
  - 61
```

# prop:filling-uniform-collars

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-uniform-collars
uses: []
lean:
- declaration: PoincareMT.m60_exists_controlled_local_contraction
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/LoopSpace/Area/ControlledContraction.lean
  lines:
  - 25
  - 72
```

# prop:filling-short-area

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-short-area
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-uniform-collars]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#lem:filling-boundary-regularization]]'
lean:
- declaration: PoincareMT.LoopSpace.small_loop_filling
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/LoopSpace/Area/SmallDisks.lean
  lines:
  - 61
  - 80
```

# sec:filling-width-definitions

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-width-definitions
uses: []
```

# prop:filling-width-properties

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-width-properties
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-short-area]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-loop-identification]]'
lean:
- declaration: PoincareMT.m61Widths
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Class/Main.lean
  lines:
  - 52
  - 79
```

# sec:filling-sphere-variation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-sphere-variation
uses: []
```

# prop:filling-minimal-sphere-variation

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#prop:filling-minimal-sphere-variation
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.m60AreaAndFilling
  file: PoincareConjecture/PoincareLib/Geometry/Riemannian/LoopSpace/Area/Main.lean
  lines:
  - 57
  - 74
```

# sec:filling-fixed-initial-class

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-fixed-initial-class
uses: []
```

# eq:filling-fixed-initial-width

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#eq:filling-fixed-initial-width
uses: []
```

# sec:filling-width-interfaces

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/filling-width.tex#sec:filling-width-interfaces
uses: []
```
