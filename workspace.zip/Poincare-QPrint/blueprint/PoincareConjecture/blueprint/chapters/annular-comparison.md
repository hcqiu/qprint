# ch:annular-comparison

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#ch:annular-comparison
uses: []
```

# sec:annulus-definitions

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:annulus-definitions
uses: []
```

# def:annular-admissible

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#def:annular-admissible
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#def:rf-flow]]'
lean:
- declaration: PoincareMT.M64Annulus
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Annulus.lean
  lines:
  - 46
  - 60
- declaration: PoincareMT.m64AnnulusArea
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Annulus.lean
  lines:
  - 40
  - 42
```

# lem:annular-infimum

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-infimum
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#def:annular-admissible]]'
```

# eq:guarded-infimum

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:guarded-infimum
uses: []
lean:
- declaration: PoincareMT.m64AnnulusAreaRange_nonempty
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Infimum.lean
  lines:
  - 147
  - 149
- declaration: PoincareMT.m64LeastAnnulusArea_nonneg
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Infimum.lean
  lines:
  - 163
  - 169
- declaration: PoincareMT.m64LeastAnnulusArea_le_annulus
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Infimum.lean
  lines:
  - 174
  - 176
```

# def:annular-geodesic

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#def:annular-geodesic
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#def:annular-admissible]]'
lean:
- declaration: PoincareMT.m60AreaDensity_eq_zero_of_factor
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Infimum.lean
  lines:
  - 30
  - 77
- declaration: PoincareMT.M64PiecewiseC1Annulus
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Annulus.lean
  lines:
  - 77
  - 82
- declaration: PoincareMT.M64GeodesicAnnulus
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Annulus.lean
  lines:
  - 86
  - 89
```

# sec:annular-evolution

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:annular-evolution
uses: []
```

# lem:annular-projection

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-projection
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#def:annular-admissible]]'
```

# eq:projection-area

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:projection-area
uses: []
lean:
- declaration: PoincareMT.m64CircleProduct_projected_density_le
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AreaComparison/Projection/Pointwise.lean
  lines:
  - 31
  - 139
- declaration: PoincareMT.m64ProjectedDensity_integrable
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AreaComparison/Projection/Integrability.lean
  lines:
  - 66
  - 111
- declaration: PoincareMT.m64ProjectedAnnulus_of_annulus
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AreaComparison/Projection/Complete.lean
  lines:
  - 22
  - 35
- declaration: PoincareMT.M64AnnulusProjection
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnulusTheory.lean
  lines:
  - 90
  - 96
```

# prop:annular-evolution

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#prop:annular-evolution
uses:
- '[[PoincareConjecture/blueprint/chapters/ramps#thm:ramps-uniform-jets]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#prop:ramps-global]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-infimum]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-projection]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-immersed-minimum]]'
```

# eq:annulus-forward

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:annulus-forward
uses: []
```

# eq:annulus-exponential

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:annulus-exponential
uses: []
lean:
- declaration: PoincareMT.M64AnnulusFlowConclusion
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnulusTheory.lean
  lines:
  - 42
  - 62
- declaration: PoincareMT.m64AnnulusEvolution_of_M63
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Evolution.lean
  lines:
  - 26
  - 58
```

# lem:annular-weak-minimum

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-weak-minimum
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#def:annular-admissible]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-infimum]]'
lean:
- declaration: PoincareMT.M64.auxiliaryCircle_free_ramp_weak_minimum
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Plateau/Stabilization/Free/RampWeakMinimum.lean
  lines:
  - 33
  - 126
- declaration: PoincareMT.M64FreeWeakPhaseAnnulus.exists_strict_modulus_interval
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Plateau/Stabilization/Free/PhaseConfinement.lean
  lines:
  - 31
  - 86
- declaration: PoincareMT.M64FreeWeakPhaseAnnulus.weightedEnergy_attained_positive
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Plateau/Stabilization/Free/PhaseGlobalMinimum.lean
  lines:
  - 31
  - 77
```

# sec:annular-uniformization

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:annular-uniformization
uses: []
```

# lem:annular-uniformization

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-uniformization
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-harmonic-radius]]'
lean:
- declaration: PoincareMT.M64Uniformization.exists_smooth_annular_cover_chart
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Plateau/Uniformization/Scalar/CoverRegular.lean
  lines:
  - 90
  - 143
```

# lem:annular-immersed-minimum

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-immersed-minimum
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-weak-minimum]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-uniformization]]'
lean:
- declaration: PoincareMT.M64.auxiliaryCircle_free_ramp_immersed_minimum
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Plateau/Stabilization/Free/RampImmersedMinimum.lean
  lines:
  - 29
  - 89
- declaration: PoincareMT.M64Uniformization.exists_lipschitz_free_modulus_conformal_cylinder
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AnnularEvolution/Plateau/Uniformization/Scalar/FreeClosedCylinder.lean
  lines:
  - 33
  - 123
```

# sec:small-area

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:small-area
uses: []
```

# prop:intrinsic-annular

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#prop:intrinsic-annular
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-short-area]]'
```

# eq:intrinsic-comparison

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:intrinsic-comparison
uses: []
lean:
- declaration: PoincareMT.M64IntrinsicAnnulusComparison
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Theory.lean
  lines:
  - 35
  - 43
- declaration: PoincareMT.m64IntrinsicAnnulusComparison
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/IntrinsicComparison/Comparison.lean
  lines:
  - 25
  - 62
```

# sec:annular-confined-focusing

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:annular-confined-focusing
uses: []
```

# lem:annular-ramp-comparison

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-ramp-comparison
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#prop:intrinsic-annular]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-immersed-minimum]]'
lean:
- declaration: PoincareMT.M64RampSmallAnnulusComparison
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Theory.lean
  lines:
  - 58
  - 75
- declaration: PoincareMT.m64RampSmallAnnulusComparison_of_geometry
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/RampTransport/Comparison.lean
  lines:
  - 23
  - 60
```

# eq:ramp-comparison

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:ramp-comparison
uses: []
```

# sec:static-approximation

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:static-approximation
uses: []
```

# lem:annular-static

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-static
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#def:annular-geodesic]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-infimum]]'
lean:
- declaration: PoincareMT.M64StaticApproximationTheory
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/ApproximationTheory.lean
  lines:
  - 32
  - 55
- declaration: PoincareMT.M64RawFamilyApproximation
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Approximation.lean
  lines:
  - 65
  - 108
- declaration: PoincareMT.M64RawFamilyApproximation.toM63
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Approximation.lean
  lines:
  - 112
  - 130
```

# eq:polygon-length

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:polygon-length
uses: []
```

# lem:annular-evolving

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-evolving
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-static]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#prop:ramps-global]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#thm:ramps-uniform-jets]]'
lean:
- declaration: PoincareMT.m64EvolvingApproximation_from_M63
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/FamilyAdapters.lean
  lines:
  - 48
  - 63
```

# lem:annular-finite-net

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-finite-net
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#def:annular-geodesic]]'
lean:
- declaration: PoincareMT.M64FamilyAnnulusNet
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/Theory.lean
  lines:
  - 90
  - 102
- declaration: PoincareMT.m64FamilyAnnulusNets_of_compact
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Comparison/AreaComparison/Finite/NetsComplete.lean
  lines:
  - 26
  - 49
```

# sec:width-deformation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:width-deformation
uses: []
```

# eq:comparison-profile

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:comparison-profile
uses: []
```

# thm:loop-family-deformation

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#thm:loop-family-deformation
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#prop:annular-evolution]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#prop:intrinsic-annular]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#thm:annular-plateau]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-width-properties]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#thm:ramps-uniform-jets]]'
```

# eq:initial-area-error

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:initial-area-error
uses: []
```

# eq:terminal-alternative

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:terminal-alternative
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-static]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-evolving]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-family-class]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-common-terminal]]'
lean:
- declaration: PoincareMT.m65LoopFamilyDeformation
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Main.lean
  lines:
  - 27
  - 36
- declaration: PoincareMT.m65LoopFamilyDeformation_from_predecessors
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Main.lean
  lines:
  - 41
  - 46
- declaration: PoincareMT.M65RawFlowInput
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Deformation/Data.lean
  lines:
  - 27
  - 36
- declaration: PoincareMT.M65DeformedFamily
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Deformation/Data.lean
  lines:
  - 38
  - 58
- declaration: PoincareMT.areaComparisonProfile
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Deformation/Family.lean
  lines:
  - 49
  - 57
- declaration: PoincareMT.areaComparisonProfile_hasDerivWithinAt
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Profile/ProfileODE.lean
  lines:
  - 62
  - 95
```

# sec:swept-area

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:swept-area
uses: []
```

# lem:annular-swept

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-swept
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#def:annular-admissible]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#thm:ramps-uniform-jets]]'
lean:
- declaration: PoincareMT.m65SweptMap
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/InteriorSweptAnnulus.lean
  lines:
  - 27
  - 28
- declaration: PoincareMT.m65SweptMap_contMDiff
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/InteriorSweptAnnulus.lean
  lines:
  - 40
  - 48
- declaration: PoincareMT.m65InteriorSweptAnnulus
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/InteriorSweptAnnulus.lean
  lines:
  - 53
  - 72
```

# eq:swept-area

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:swept-area
uses: []
lean:
- declaration: PoincareMT.m65FamilyInteriorSweptAnnulus_area_le
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/UniformSweptArea.lean
  lines:
  - 71
  - 94
- declaration: PoincareMT.m65FamilyTotalCurvatureBound
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/UniformSweptArea.lean
  lines:
  - 29
  - 30
```

# lem:annular-disk-gluing

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-disk-gluing
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-projection]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-infimum]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-width-properties]]'
```

# eq:disk-gluing

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:disk-gluing
uses: []
lean:
- declaration: PoincareMT.m65ProjectedDiskComparison
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/ProjectedAreaEstimate.lean
  lines:
  - 31
  - 42
- declaration: PoincareMT.m65FillingArea_le_add_annulus
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/ProjectedAreaEstimate.lean
  lines:
  - 46
  - 52
```

# lem:annular-time-control

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-time-control
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-swept]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-gluing]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-metric-comparison]]'
```

# eq:metric-area-transport

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:metric-area-transport
uses: []
```

# eq:time-area-lipschitz

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:time-area-lipschitz
uses: []
lean:
- declaration: PoincareMT.m65FillingArea_flowMetric_le
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/FlowFillingScaling.lean
  lines:
  - 26
  - 44
- declaration: PoincareMT.m65ClosedTimeFillingDifference
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/ClosedTimeFilling.lean
  lines:
  - 59
  - 77
- declaration: PoincareMT.m65UniformTimeFillingBounds
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/SweptArea/TimeAreaLipschitz.lean
  lines:
  - 28
  - 115
```

# sec:annular-plateau

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:annular-plateau
uses: []
```

# thm:annular-plateau

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#thm:annular-plateau
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-minimum]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-strict-trace]]'
lean:
- declaration: PoincareMT.m65Plateau_attainment
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/AttainmentConclusion.lean
  lines:
  - 29
  - 71
```

# lem:annular-weak-disks

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-weak-disks
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-width-properties]]'
lean:
- declaration: PoincareMT.m65NormalizedWeakDisks_boundary_equicontinuous
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Weak/MinimizerBoundaryEquicontinuity.lean
  lines:
  - 103
  - 170
- declaration: PoincareMT.m65NormalizedWeakDisks_subsequence
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Weak/MinimizerExtraction.lean
  lines:
  - 124
  - 223
- declaration: PoincareMT.m65WeakDisk_energy_le_of_limit
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Weak/MinimizerEnergyLimit.lean
  lines:
  - 51
  - 153
```

# sec:annular-disk-beltrami

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:annular-disk-beltrami
uses: []
```

# lem:annular-energy-competitor

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-energy-competitor
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-width-properties]]'
lean:
- declaration: PoincareMT.m65SpanningDisk_exists_normalized_energy_competitor
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Weak/MinimizerCompetitors.lean
  lines:
  - 26
  - 42
```

# lem:annular-disk-minimum

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-disk-minimum
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-weak-disks]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-energy-competitor]]'
lean:
- declaration: PoincareMT.m65Plateau_weak_minimum
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Weak/MinimizerConclusion.lean
  lines:
  - 68
  - 92
```

# lem:annular-disk-conformal

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-disk-conformal
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-minimum]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-energy-competitor]]'
lean:
- declaration: PoincareMT.m65WeakDisk_conformal_of_normalized_minimum
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Weak/MinimizerConformalVariation.lean
  lines:
  - 293
  - 301
```

# lem:annular-disk-interior

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-disk-interior
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-minimum]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-conformal]]'
lean:
- declaration: PoincareMT.M65Interior.localMinimum_energy_power_decay
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/InteriorRegularityPowerDecay.lean
  lines:
  - 77
  - 110
- declaration: PoincareMT.M65Boundary.quadratic_holder_contDiffAt
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Boundary/RegularityTomiRegularity.lean
  lines:
  - 92
  - 141
- declaration: PoincareMT.m65PlateauInteriorRegularityInput_proved
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/InteriorRegularityEulerAlphaOneM60.lean
  lines:
  - 57
  - 66
```

# lem:annular-disk-boundary

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-disk-boundary
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-interior]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-conformal]]'
lean:
- declaration: PoincareMT.M65Boundary.weakDisk_boundary_local_contMDiff
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Boundary/RegularityLocalConclusion.lean
  lines:
  - 31
  - 272
- declaration: PoincareMT.m65PlateauBoundaryRegularityInput_proved
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Plateau/Boundary/RegularityInput.lean
  lines:
  - 25
  - 46
```

# lem:annular-disk-strict-trace

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-disk-strict-trace
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-conformal]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-interior]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-boundary]]'
lean:
- declaration: PoincareMT.M65StrictTrace.finite_disk_branches
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/MinimalDisk/StrictTraceFiniteBranches.lean
  lines:
  - 86
  - 130
- declaration: PoincareMT.m65Plateau_strict_trace
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/MinimalDisk/StrictTrace.lean
  lines:
  - 33
  - 53
```

# eq:annular-boundary-factor

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:annular-boundary-factor
uses: []
```

# sec:annular-disk-gauss-bonnet

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:annular-disk-gauss-bonnet
uses: []
```

# lem:annular-branched-gauss

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-branched-gauss
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#thm:annular-plateau]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-strict-trace]]'
lean:
- declaration: PoincareMT.M65MinimalDisk.logarithmicGaussDensity_integrable
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/MinimalDisk/GaussBonnet/Boundary/Global.lean
  lines:
  - 261
  - 275
- declaration: PoincareMT.M65MinimalDisk.logarithmicGaussDensity_gaussBonnet
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/MinimalDisk/GaussBonnet/Scalar.lean
  lines:
  - 71
  - 105
```

# eq:annular-branched-gauss

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:annular-branched-gauss
uses: []
```

# eq:annular-interior-flux

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:annular-interior-flux
uses: []
```

# eq:annular-boundary-radial

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:annular-boundary-radial
uses: []
lean:
- declaration: PoincareMT.M65MinimalDisk.logarithmicGaussDensity_integrable
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/MinimalDisk/GaussBonnet/Boundary/Global.lean
  lines:
  - 261
  - 275
- declaration: PoincareMT.M65MinimalDisk.logarithmicGaussDensity_gaussBonnet
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/MinimalDisk/GaussBonnet/Scalar.lean
  lines:
  - 71
  - 105
```

# sec:immersed-disk-comparison

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:immersed-disk-comparison
uses: []
```

# lem:annular-immersed-disk

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-immersed-disk
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#thm:annular-plateau]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-branched-gauss]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-gluing]]'
lean:
- declaration: PoincareMT.m65EmbeddedFillingAreaInequality_proved
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/MinimalDisk/Conclusion.lean
  lines:
  - 23
  - 30
- declaration: PoincareMT.m65Exists_generic_filled_approximations
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Transfer/ImmersedPerturbationFilledApproximation.lean
  lines:
  - 32
  - 113
- declaration: PoincareMT.m65ImmersedFillingAreaComparison_of_diskComparison
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Transfer/ImmersedComparison.lean
  lines:
  - 33
  - 86
```

# sec:good-time-grid

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:good-time-grid
uses: []
```

# lem:annular-member-terminal

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-member-terminal
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-evolving]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-time-control]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-immersed-disk]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#thm:ramps-uniform-jets]]'
lean:
- declaration: PoincareMT.m65FiniteProfileComparison
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/GoodTimes/FiniteProfileComparison.lean
  lines:
  - 28
  - 87
- declaration: PoincareMT.m65Family_exists_fixed_good_grid
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/GoodTimes/Family/Grid/GridAssembly.lean
  lines:
  - 32
  - 120
- declaration: PoincareMT.m65FamilyCell_exists_filled_limit
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/GoodTimes/Family/Cell/FillingLimit.lean
  lines:
  - 38
  - 154
- declaration: PoincareMT.m65FamilyCell_exists_comparison_cutoff
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/GoodTimes/Family/Cell/Comparison.lean
  lines:
  - 34
  - 75
- declaration: PoincareMT.m65Family_pointwise_terminal_alternative
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/GoodTimes/PointwiseTerminalAlternative.lean
  lines:
  - 37
  - 130
- declaration: PoincareMT.m65FamilyCell_normalization_bounds
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/GoodTimes/Family/Cell/Normalization.lean
  lines:
  - 34
  - 178
- declaration: PoincareMT.m65Slope_sq_le_circumference
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Limit/Slope/Collapse.lean
  lines:
  - 30
  - 65
- declaration: PoincareMT.m65Projected_exists_smooth_curveShortening_limit
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Limit/SmoothLimit.lean
  lines:
  - 536
  - 686
- declaration: PoincareMT.m65FillingArea_tendsto_of_C1
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/AreaContinuity/FillingLimit.lean
  lines:
  - 28
  - 56
- declaration: PoincareMT.m65FillingArea_relabel
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/AreaContinuity/Relabeling.lean
  lines:
  - 83
  - 86
```

# sec:terminal-transfer

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:terminal-transfer
uses: []
```

# lem:annular-family-class

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-family-class
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-evolving]]'
```

# eq:projection-length

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#eq:projection-length
uses: []
lean:
- declaration: PoincareMT.m65ProjectedFamily_homotopic
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Assembly.lean
  lines:
  - 31
  - 37
- declaration: PoincareMT.m65ProjectedFamilyLength_le
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Transfer/ProjectedLength.lean
  lines:
  - 61
  - 76
- declaration: PoincareMT.m65Projection_tangentNorm_le
```

# lem:annular-area-transfer

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-area-transfer
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#prop:annular-evolution]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-disk-gluing]]'
lean:
- declaration: PoincareMT.m65AreaLoopTransfer
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Transfer/AreaLoops.lean
  lines:
  - 49
  - 93
```

# lem:annular-short-transfer

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-short-transfer
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#prop:annular-evolution]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-ramp-comparison]]'
- '[[PoincareConjecture/blueprint/chapters/ramps#thm:ramps-uniform-jets]]'
lean:
- declaration: PoincareMT.m65ShortLoopTransfer
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Transfer/ShortLoops.lean
  lines:
  - 31
  - 109
```

# lem:annular-common-terminal

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#lem:annular-common-terminal
uses:
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-finite-net]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-area-transfer]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-short-transfer]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#lem:annular-member-terminal]]'
lean:
- declaration: PoincareMT.m65CommonTerminalAlternative
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Transfer/NetAssembly.lean
  lines:
  - 29
  - 69
- declaration: PoincareMT.m65CommonTerminalAlternative_proved
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Transfer/NetConclusion.lean
  lines:
  - 25
  - 45
- declaration: PoincareMT.m65DeformedFamilyOfProjectedEstimate
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Assembly.lean
  lines:
  - 52
  - 69
- declaration: PoincareMT.m65ZeroDurationDeformedFamily
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Construction.lean
  lines:
  - 39
  - 50
- declaration: PoincareMT.m65Construction
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Construction.lean
  lines:
  - 56
  - 75
- declaration: PoincareMT.m65LoopFamilyDeformation
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Main.lean
  lines:
  - 27
  - 36
- declaration: PoincareMT.m65LoopFamilyDeformation_from_predecessors
  file: PoincareConjecture/PoincareLib/Geometry/CurveShortening/Deformation/Main.lean
  lines:
  - 41
  - 46
```

# sec:annular-interfaces

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/annular-comparison.tex#sec:annular-interfaces
uses: []
```
