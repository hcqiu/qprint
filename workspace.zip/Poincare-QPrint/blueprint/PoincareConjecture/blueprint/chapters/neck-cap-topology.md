# ch:neck-cap-topology

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#ch:neck-cap-topology
uses: []
```

# sec:neck-cap-definitions

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:neck-cap-definitions
uses: []
```

# def:neck-cap-neck

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#def:neck-cap-neck
uses:
- '[[PoincareConjecture/blueprint/chapters/foundations#def:foundations-manifold]]'
lean:
- declaration: PoincareMT.EpsilonNeck
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/CanonicalNeighborhood/Neck.lean
  lines:
  - 56
  - 90
- declaration: PoincareMT.NeckMetricJetComparison
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/CanonicalNeighborhood/Neck.lean
  lines:
  - 50
  - 54
```

# def:neck-cap-cap

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#def:neck-cap-cap
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#def:neck-cap-neck]]'
lean:
- declaration: PoincareMT.CapCertificate
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/CanonicalNeighborhood/Cap.lean
  lines:
  - 28
  - 94
```

# sec:neck-cap-full-scalar

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:neck-cap-full-scalar
uses: []
```

# lem:neck-cap-scalar

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#lem:neck-cap-scalar
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#def:neck-cap-neck]]'
lean:
- declaration: PoincareMT.EpsilonNeck.scalarCurvature_sub_one_le
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/CanonicalNeighborhood/Neck/Curvature/LinearScalar.lean
  lines:
  - 106
  - 119
```

# eq:neck-cap-full-scalar

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#eq:neck-cap-full-scalar
uses: []
```

# sec:balanced-tubes

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:balanced-tubes
uses: []
```

# sec:circle-bundle

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:circle-bundle
uses: []
```

# sec:ball-gluing

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:ball-gluing
uses: []
```

# sec:neck-cap-ambient-filling

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:neck-cap-ambient-filling
uses: []
```

# sec:neck-cap-prescribed-collars

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:neck-cap-prescribed-collars
uses: []
```

# lem:neck-cap-prescribed-collar

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#lem:neck-cap-prescribed-collar
uses: []
lean:
- declaration: PoincareMT.M25.Topology3D.schoenfliesData_of_ball
  file: PoincareConjecture/PoincareLib/Topology/Manifold/NeckCap/SourceServices/Space/SchoenfliesFromBall.lean
  lines:
  - 27
  - 98
- declaration: PoincareMT.M25.Topology3D.schoenfliesService_from_main
  file: PoincareConjecture/PoincareLib/Topology/Manifold/NeckCap/SourceServices/Gluing/SchoenfliesService.lean
  lines:
  - 23
  - 48
```

# lem:neck-cap-sphere-isotopy

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#lem:neck-cap-sphere-isotopy
uses: []
lean:
- declaration: PoincareMT.M25.Topology3D.diffSphereIsotopyService
  file: PoincareConjecture/PoincareLib/Topology/Manifold/NeckCap/SourceServices/Sphere/Service.lean
  lines:
  - 17
  - 18
```

# sec:neck-cap-planar-isotopy

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:neck-cap-planar-isotopy
uses: []
```

# sec:m25

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:m25
uses: []
```

# thm:neck-cap-cover

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#thm:neck-cap-cover
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#lem:neck-cap-prescribed-collar]]'
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#lem:neck-cap-sphere-isotopy]]'
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#def:neck-cap-cap]]'
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#lem:neck-cap-scalar]]'
lean:
- declaration: PoincareMT.m25NeckCapTopology
  file: PoincareConjecture/PoincareLib/Topology/Manifold/NeckCap.lean
  lines:
  - 165
  - 170
```

# sec:m26

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:m26
uses: []
```

# thm:neck-cap-ancient-alternatives

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#thm:neck-cap-ancient-alternatives
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#thm:neck-cap-cover]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:ancient-universal]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:ancient-compactness]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:ancient-model-identifications]]'
lean:
- declaration: PoincareMT.m26CanonicalNeighborhoods
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/CanonicalNeighborhood/Ancient/Proof.lean
  lines:
  - 26
  - 29
```

# sec:m27

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:m27
uses: []
```

# thm:neck-cap-canonical

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#thm:neck-cap-canonical
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#thm:neck-cap-ancient-alternatives]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:ancient-compactness]]'
- '[[PoincareConjecture/blueprint/chapters/ancient-models#thm:ancient-universal]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-shi]]'
lean:
- declaration: PoincareMT.m27KappaAlternatives
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/CanonicalNeighborhood/Ancient/Proof.lean
  lines:
  - 37
  - 40
```

# sec:neck-cap-contracts

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/neck-cap-topology.tex#sec:neck-cap-contracts
uses: []
```
