# ch:singular-limits-v4

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#ch:singular-limits-v4
uses: []
```

# sec:singular-bounded-distance

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#sec:singular-bounded-distance
uses: []
```

# eq:singular-weak-pinching

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-weak-pinching
uses: []
```

# thm:singular-bounded-distance

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#thm:singular-bounded-distance
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#thm:neck-cap-cover]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#lem:singular-cone-obstruction]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-shi]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-harnack]]'
lean:
- declaration: PoincareMT.m28BoundedDistance
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/BoundedDistance/Main.lean
  lines:
  - 52
  - 56
```

# eq:bounded-distance

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:bounded-distance
uses: []
```

# eq:singular-cone-chord

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-cone-chord
uses: []
```

# eq:singular-scalar-radius

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-scalar-radius
uses: []
```

# lem:singular-cone-obstruction

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#lem:singular-cone-obstruction
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.M28.no_positive_terminal_scalar_of_chord_annulus_embedding
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Generalized/BoundedDistance/Cone/Local/Geometry/LocalConeObstruction.lean
  lines:
  - 36
  - 91
```

# sec:singular-blowup

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#sec:singular-blowup
uses: []
```

# def:singular-blowup-sequence

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#def:singular-blowup-sequence
uses: []
lean:
- declaration: PoincareMT.GeneralizedBlowupSequence
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Blowup/Sequence.lean
  lines:
  - 21
  - 26
- declaration: PoincareMT.M30CommonBlowupControls
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Blowup/Controlled/Data.lean
  lines:
  - 87
  - 123
```

# eq:singular-survival

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-survival
uses: []
```

# prop:singular-m29

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#prop:singular-m29
uses:
- '[[PoincareConjecture/blueprint/chapters/singular-limits#def:singular-blowup-sequence]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#thm:singular-bounded-distance]]'
lean:
- declaration: PoincareMT.m29GeneralizedBoundedDistance
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Blowup/BoundedDistance.lean
  lines:
  - 40
  - 65
```

# eq:singular-limit-domain

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-limit-domain
uses: []
```

# def:singular-convergence

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#def:singular-convergence
uses:
- '[[PoincareConjecture/blueprint/chapters/singular-limits#def:singular-blowup-sequence]]'
lean:
- declaration: PoincareMT.GeneralizedBlowupConvergence
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Blowup/Controlled/Geometry.lean
  lines:
  - 205
  - 240
- declaration: PoincareMT.BlowupLimitFlow
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Blowup/Controlled/Geometry.lean
  lines:
  - 31
  - 60
```

# thm:singular-m30

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#thm:singular-m30
uses:
- '[[PoincareConjecture/blueprint/chapters/singular-limits#prop:singular-m29]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#def:singular-convergence]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-shi]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-harnack]]'
lean:
- declaration: PoincareMT.m30ControlledGeneralizedBlowupLimits
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Blowup/Construction/Proof.lean
  lines:
  - 64
  - 73
```

# sec:singular-retained

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#sec:singular-retained
uses: []
```

# def:singular-retained-region

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#def:singular-retained-region
uses: []
lean:
- declaration: PoincareMT.SingularTimeAssumptions
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Singular/Geometry.lean
  lines:
  - 136
  - 191
- declaration: PoincareMT.SingularTimeReference.regularLimitSet
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Singular/Geometry.lean
  lines:
  - 87
  - 94
```

# eq:singular-analytic-bounds

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-analytic-bounds
uses: []
```

# eq:singular-retained-region

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-retained-region
uses: []
```

# def:singular-terminal-horn

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#def:singular-terminal-horn
uses:
- '[[PoincareConjecture/blueprint/chapters/singular-limits#def:singular-retained-region]]'
lean:
- declaration: PoincareMT.GeneralizedFlowExtension
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Singular/Geometry.lean
  lines:
  - 198
  - 229
- declaration: PoincareMT.StrongHorn
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Singular/Geometry.lean
  lines:
  - 238
  - 261
```

# thm:singular-m31

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#thm:singular-m31
uses:
- '[[PoincareConjecture/blueprint/chapters/neck-cap-topology#thm:neck-cap-cover]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#def:singular-retained-region]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#def:singular-terminal-horn]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#thm:rf-shi]]'
lean:
- declaration: PoincareMT.m31SingularRegularLimit
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Singular/RegularLimit/Assembly/Completion.lean
  lines:
  - 101
  - 128
```

# sec:singular-terminal

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#sec:singular-terminal
uses: []
```

# eq:singular-cap-budget

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-cap-budget
uses: []
```

# sec:singular-deep-horn

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#sec:singular-deep-horn
uses: []
```

# thm:singular-m32

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#thm:singular-m32
uses:
- '[[PoincareConjecture/blueprint/chapters/singular-limits#thm:singular-m31]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#thm:singular-m30]]'
- '[[PoincareConjecture/blueprint/chapters/singular-limits#prop:singular-m29]]'
lean:
- declaration: PoincareMT.m32HornSelection
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Singular/DeepHorn/Theory.lean
  lines:
  - 68
  - 98
```

# eq:deep-height

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:deep-height
uses: []
```

# eq:singular-positive-scalar-time

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#eq:singular-positive-scalar-time
uses: []
```

# sec:singular-selector

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#sec:singular-selector
uses: []
```

# cor:singular-selector

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/singular-limits.tex#cor:singular-selector
uses:
- '[[PoincareConjecture/blueprint/chapters/singular-limits#thm:singular-m32]]'
lean:
- declaration: PoincareMT.M32DeepHornScaleSelection
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Singular/HornSelection.lean
  lines:
  - 39
  - 56
- declaration: PoincareMT.m32HornSelection
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Surgery/Singular/DeepHorn/Theory.lean
  lines:
  - 68
  - 98
```
