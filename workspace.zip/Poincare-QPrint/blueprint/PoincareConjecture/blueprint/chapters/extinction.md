# ch:extinction-v4

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#ch:extinction-v4
uses: []
```

# def:v4-null-family

```qprint
kind: definition
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#def:v4-null-family
uses: []
lean:
- declaration: PoincareMT.M61NullFamily
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Class/Based.lean
  lines:
  - 29
  - 31
```

# def:v4-family-width

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#def:v4-family-width
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#def:v4-null-family]]'
```

# def:v4-free-width

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#def:v4-free-width
uses: []
lean:
- declaration: PoincareMT.m61FamilyWidth
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Class/Based.lean
  lines:
  - 34
  - 36
- declaration: PoincareMT.m61FreeClassWidthRange
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Class/Based.lean
  lines:
  - 39
  - 42
- declaration: PoincareMT.m61FreeClassWidth
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Class/Based.lean
  lines:
  - 45
  - 47
```

# prop:v4-width-properties

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-width-properties
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-width-properties]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#def:v4-family-width]]'
lean:
- declaration: PoincareMT.m61FamilyWidth_from_M60
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Infimum/FamilyMaximum.lean
  lines:
  - 23
  - 44
- declaration: PoincareMT.m61Widths
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Class/Main.lean
  lines:
  - 52
  - 79
```

# prop:v4-endpoint-comparison

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-endpoint-comparison
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-width-properties]]'
- '[[PoincareConjecture/blueprint/chapters/annular-comparison#thm:loop-family-deformation]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-short-area]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-loop-identification]]'
lean:
- declaration: PoincareMT.m66_deformed_comparison
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/SmoothTime/Comparison.lean
  lines:
  - 45
  - 124
- declaration: PoincareMT.m66_endpoint_comparison
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/SmoothTime/Comparison.lean
  lines:
  - 128
  - 160
```

# lem:v4-metric-width

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#lem:v4-metric-width
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-width-properties]]'
lean:
- declaration: PoincareMT.m66_freeClassWidth_le_of_metric_le
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/SmoothTime/Continuity/Main.lean
  lines:
  - 46
  - 66
```

# prop:v4-smooth-time

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-smooth-time
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-endpoint-comparison]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-metric-width]]'
lean:
- declaration: PoincareMT.m66_smooth_time_theory
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/SmoothTime/Main.lean
  lines:
  - 17
  - 29
- declaration: PoincareMT.m66Width_continuousAt
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/SmoothTime/Continuity/Main.lean
  lines:
  - 69
  - 128
- declaration: PoincareMT.m66_forward_difference_bound
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/SmoothTime/ForwardBound.lean
  lines:
  - 20
  - 44
```

# eq:v4-forward

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#eq:v4-forward
uses: []
```

# prop:v4-class-transport

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-class-transport
uses:
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-ancestry-transport]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-loop-identification]]'
lean:
- declaration: PoincareMT.m67_finite_transport_section
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Transport/Assembly/ClassPath/Finite.lean
  lines:
  - 32
  - 123
- declaration: PoincareMT.m67_class_path_exists
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Transport/Assembly/ClassPath.lean
  lines:
  - 45
  - 96
```

# lem:v4-event-class

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#lem:v4-event-class
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-class-transport]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:comparison-transport]]'
lean:
- declaration: PoincareMT.m67_event_class_datum_exists
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Transport/Assembly/ClassPath/Event.lean
  lines:
  - 47
  - 114
```

# lem:v4-disk-transport

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#lem:v4-disk-transport
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-metric-width]]'
lean:
- declaration: PoincareMT.m67_filling_transport_of_lipschitz
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Transport/Event/Geometry.lean
  lines:
  - 78
  - 87
```

# eq:v4-event-factor

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#eq:v4-event-factor
uses: []
```

# prop:v4-event-width

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-event-width
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-smooth-time]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-disk-transport]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-event-class]]'
- '[[PoincareConjecture/blueprint/chapters/surgery#thm:comparison-transport]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-loop-identification]]'
lean:
- declaration: PoincareMT.m67_surgery_width_theory
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Transport/Main.lean
  lines:
  - 24
  - 90
- declaration: PoincareMT.m67_event_factor_bounds
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Transport/Assembly/EventEstimate.lean
  lines:
  - 54
  - 93
- declaration: PoincareMT.m67_lower_limit_of_factor_bounds
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Transport/Event/LowerLimit.lean
  lines:
  - 31
  - 43
```

# eq:v4-scalar-clock

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#eq:v4-scalar-clock
uses: []
```

# prop:v4-m81

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-m81
uses:
- '[[PoincareConjecture/blueprint/chapters/ricci-flow#prop:rf-evolution]]'
lean:
- declaration: PoincareMT.m81RegularSlabComparison
  file: PoincareConjecture/PoincareLib/Analysis/ODE/ForwardComparison.lean
  lines:
  - 59
  - 158
```

# lem:v4-profile

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#lem:v4-profile
uses: []
lean:
- declaration: PoincareMT.m68_profile_equation
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/ScalarClock/Comparison.lean
  lines:
  - 37
  - 94
```

# eq:v4-profile

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#eq:v4-profile
uses: []
```

# lem:v4-event-restart

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#lem:v4-event-restart
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-event-width]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-profile]]'
lean:
- declaration: PoincareMT.m68_event_restart_bound
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/ScalarClock/FiniteRestart.lean
  lines:
  - 17
  - 61
```

# prop:v4-scalar-clock

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-scalar-clock
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-m81]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-event-width]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-event-restart]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-profile]]'
lean:
- declaration: PoincareMT.m68_scalar_clock_statement
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/ScalarClock/Assembly.lean
  lines:
  - 52
  - 132
```

# prop:v4-finite-piece

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-finite-piece
uses: []
```

# prop:v4-component-contradiction

```qprint
kind: proof
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-component-contradiction
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-scalar-clock]]'
lean:
- declaration: PoincareMT.m69FinitePiecePropagation
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/FinitePiece/Propagation.lean
  lines:
  - 26
  - 45
- declaration: PoincareMT.m70FiniteExtinctionContradiction
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Width/Contradiction/Main.lean
  lines:
  - 22
  - 26
```

# lem:v4-common-width

```qprint
kind: lemma
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#lem:v4-common-width
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-class-transport]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-component-ancestry]]'
lean:
- declaration: PoincareMT.m71WidthChoice_initial_width
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Global/WidthInputs.lean
  lines:
  - 65
  - 71
```

# lem:v4-negative-time

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#lem:v4-negative-time
uses:
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-common-width]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-profile]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-width-properties]]'
```

# eq:v4-extinction-time

```qprint
kind: other
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#eq:v4-extinction-time
uses: []
lean:
- declaration: PoincareMT.m71ProfileAlgebra_neg
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Global/ProfileAlgebra.lean
  lines:
  - 20
  - 55
```

# prop:v4-global-extinction

```qprint
kind: theorem
status: not_started
tex: PoincareConjecture/blueprint/chapters/extinction.tex#prop:v4-global-extinction
uses:
- '[[PoincareConjecture/blueprint/chapters/global-surgery#thm:global-controlled-flow]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-component-ancestry]]'
- '[[PoincareConjecture/blueprint/chapters/filling-width#prop:filling-ancestry-transport]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-initial]]'
- '[[PoincareConjecture/blueprint/chapters/foundations#prop:foundations-projective-exclusion]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#prop:v4-finite-piece]]'
- '[[PoincareConjecture/blueprint/chapters/extinction#lem:v4-negative-time]]'
lean:
- declaration: PoincareMT.m71GlobalFiniteExtinction
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Global/Main.lean
  lines:
  - 35
  - 46
- declaration: PoincareMT.m71FirstEmptySurgery
  file: PoincareConjecture/PoincareLib/Geometry/RicciFlow/Extinction/Global/TerminalEvent.lean
  lines:
  - 36
  - 98
```
